# pod01-g4: we are P4; opponents P1 Sauron, the Dark Lord, P2 Sephiroth, Fabled SOLDIER, P3 Y'shtola, Night's Blessed
Result: Turn 23; P1 has won because all opponents have lost; P2 has lost because life total reached 0; P3 has lost because life total reached 0; US has lost because life total reached 0

## Turn 1 (P1, round 1)

## Turn 2 (P2, round 1)

## Turn 3 (P3, round 1)

## Turn 4 (OUR TURN, round 1) | life: US 39
Our hand: Siren Stormtamer, Marionette Apprentice, Polluted Delta, Scalding Tarn, Gray Merchant of Asphodel, Baba Lysaga, Night Witch, Ratchet Bomb, Barrin, Master Wizard
Our graveyard (0): 
Board P1: 1 lands; no nonland permanents
Board P2: 1 lands; no nonland permanents
Board P3: 1 lands; no nonland permanents
Board US: 0 lands; no nonland permanents
MEMO (start of our turn):
THIS TURN: Crack Scalding Tarn (pay 1 life) for Underground Sea, which enters untapped. Cast Siren Stormtamer ({U}). Keep Polluted Delta for next turn's land drop, fetching Bayou or Overgrown Tomb for black and green. Nothing else is castable.

TARGET: A four-colour-capable base (U/B/G) by turn 3. Plays: T2 Ratchet Bomb held at 0 counters, or Marionette Apprentice. T3 Baba Lysaga or Barrin. Muldrotha around T5–6 with Stormtamer up. Missing pieces, in tutor order: Sol Ring or Arcane Signet (ramp), Executioner's Capsule and Claws of Gix (recurring removal and outlet), Survival of the Fittest.

WIN PATH: Muldrotha loops Capsule, Seals and Ratchet Bomb to control the board. Marionette Apprentice and Gray Merchant drain; Baba Lysaga saccing a fetch plus an artifact creature drains 3. Aim to close by turns 10–12. P2 is fastest (combo turns 5–7).

THREATS & ANSWERS:
1. P2's Pitiless Plunderer, Ashnod's Altar or Sephiroth: Barrin bounces, Ratchet Bomb at 0 or 1 kills tokens and Altar-class 1-drops.
2. P1's Orc Army tokens: Ratchet Bomb at 0.
3. P3's Y'shtola: Barrin bounce buys time.
Don't feed P2 creature deaths once Sephiroth is out. Don't cast many cheap spells into Sauron.

HOLD: Keep Gray Merchant until devotion is 4+. Keep Polluted Delta as the next land drop. Once Muldrotha is out, Stormtamer's sac is saved for removal aimed at Muldrotha.

REPLAN IF: An opponent drops Sol Ring or a fast ramp start (Ratchet Bomb at 1 then answers it). P2 shows Plunderer or Altar early. Bowmasters kills Stormtamer. We draw no third land by T3 (then prioritise Ratchet Bomb and Apprentice).
PILOT OVERRULED FORGE (action, MAIN1): chose [play land Scalding Tarn (from Hand): Play land] instead of Forge's [play land Polluted Delta (from Hand): Play land]
PILOT OVERRULED FORGE (search, MAIN1): chose [Underground Sea — Land - Island Swamp — ({T}: Add {U} or {B}.)] instead of Forge's [Tropical Island — Land - Forest Island — ({T}: Add {G} or {U}.)]
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Siren Stormtamer (from Hand): Siren Stormtamer - Creature 1 / 1 [Forge's heuristic AI] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
- left battlefield: Scalding Tarn was put into Graveyard from Battlefield.
- US activated Scalding Tarn
- US cast Siren Stormtamer

## Turn 5 (P1, round 2)

## Turn 6 (P2, round 2)

## Turn 7 (P3, round 2)

## Turn 8 (OUR TURN, round 2) | life: US 38
Our hand: Marionette Apprentice, Polluted Delta, Gray Merchant of Asphodel, Baba Lysaga, Night Witch, Ratchet Bomb, Barrin, Master Wizard, Misty Rainforest
Our graveyard (1): Scalding Tarn
Board P1: 2 lands; no nonland permanents
Board P2: 2 lands; no nonland permanents
Board P3: 2 lands; no nonland permanents
Board US: 1 lands; Siren Stormtamer 1/1
MEMO (start of our turn):
THIS TURN: Play Polluted Delta, crack it (pay 1 life) for Bayou, which enters untapped and is a Swamp. Cast Marionette Apprentice ({1}{B}: Bayou plus Sea) and choose the Servo token, not the counter. The Servo is future Baba Lysaga fodder (artifact plus creature). That uses all our mana; no instant-speed plans.

TARGET: Next turn, play Misty Rainforest and fetch Tropical Island untapped, then cast Baba Lysaga ({1}{B}{G}). The turn after, activate Baba by sacrificing the Servo plus a land (land, artifact, creature = 3 types) to draw 3 and drain 3. Keep Ratchet Bomb and Barrin for turns 4-5, then Muldrotha ({3}{B}{G}{U}) with Stormtamer up. Missing pieces: Sol Ring or Arcane Signet, Executioner's Capsule, Claws of Gix, Survival of the Fittest.

WIN PATH: Loop Capsule and Ratchet Bomb through Muldrotha. The drain comes from Apprentice (each artifact or creature we lose), Baba activations and Gray Merchant. Close by about turn 12. P2 is fastest (possible combo around their turns 5-7).

THREATS & ANSWERS:
1. P2's Plunderer, Ashnod's Altar or Bitterblossom: Ratchet Bomb (tick it to the target's mana value), Barrin bounce.
2. P1's Orc Army (mana value 0): Ratchet Bomb at 0.
3. P3's Y'shtola: Barrin bounce.
Don't cast many cheap spells into Sauron. Don't sacrifice creatures while Sephiroth is out.

HOLD: Gray Merchant until devotion to black is 4+. Ratchet Bomb until a real target appears. Stormtamer's sacrifice is for removal aimed at Muldrotha or Baba.

REPLAN IF: Bowmasters or removal kills the Apprentice. An opponent lands Sol Ring or a fast ramp start (then deploy Ratchet Bomb and tick it to 1). P2 shows Plunderer or Altar. We miss a land drop.
PILOT OVERRULED FORGE (search, MAIN1): chose [Bayou — Land - Swamp Forest — ({T}: Add {B} or {G}.)] instead of Forge's [Watery Grave — Land - Island Swamp — ({T}: Add {U} or {B}.) As Watery Grave enters, you ma]
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Marionette Apprentice (from Hand): Marionette Apprentice - Creature 1 / 2 [Forge's he] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (attack, COMBAT_DECLARE_ATTACKERS): chose [don't attack with it] instead of Forge's [attack P1 (40 life)]
- left battlefield: Polluted Delta was put into Graveyard from Battlefield.
- US activated Polluted Delta
- US cast Marionette Apprentice
- US triggered Marionette Apprentice

## Turn 9 (P1, round 3)

## Turn 10 (P2, round 3)
- P2 cast Sephiroth, Fabled SOLDIER
- P2 triggered Sephiroth, Fabled SOLDIER

## Turn 11 (P3, round 3)

## Turn 12 (OUR TURN, round 3)
Our hand: Gray Merchant of Asphodel, Baba Lysaga, Night Witch, Ratchet Bomb, Barrin, Master Wizard, Misty Rainforest, Island
Our graveyard (2): Scalding Tarn, Polluted Delta
Board P1: 3 lands; no nonland permanents
Board P2: 3 lands; Sephiroth, Fabled SOLDIER 3/3
Board P3: 2 lands; no nonland permanents
Board US: 2 lands; Siren Stormtamer 1/1, Marionette Apprentice 1/2, Servo Token 1/1 [token]
MEMO (start of our turn):
THIS TURN: Play Island. Cast Baba Lysaga with Island, Underground Sea and Bayou ({1}{B}{G}). That taps us out, so Stormtamer can't protect this turn. Keep Misty Rainforest in hand, uncracked. It is next turn's land for Baba's sacrifice.

TARGET: Next turn, play Misty and do not crack it. Tap Baba and sacrifice the Servo plus Misty (land, artifact, creature = 3 types) to draw 3 and drain 3. Apprentice adds 1 more to each opponent. Then cast Barrin ({1}{U}{U}) and keep {U} for Stormtamer if we can. After that, Ratchet Bomb, then Muldrotha at 6 lands. Missing pieces: Executioner's Capsule, Claws of Gix, Sol Ring or Arcane Signet, Survival of the Fittest.

WIN PATH: Drain from Baba activations, Apprentice triggers and Gray Merchant. Merchant alone drains 4+ once Apprentice, Baba and Merchant are out. Muldrotha then recasts it all. P2 is fastest (a combo loop around turns 5-7), so outpace them.

THREATS & ANSWERS:
1. P2 Sephiroth: it transforms on the fourth death in a turn. Answer: Barrin bounce ({2}, sacrifice a land or Ratchet Bomb, never a creature).
2. P2 Pitiless Plunderer, Ashnod's Altar or Grave Pact: Ratchet Bomb ticked to their mana value.
3. P1 Orc Army: Ratchet Bomb at 0.
4. P3 Y'shtola: Barrin bounce.
Each creature we lose drains us 1 while Sephiroth is out. Keep our deaths to a minimum.

HOLD: Gray Merchant until devotion to black is 4+. Ratchet Bomb until a real target appears. Stormtamer to protect Baba or Muldrotha from targeted removal.

REPLAN IF: Baba gets countered or killed (then Barrin next turn). P2 assembles Plunderer or Altar. Sauron lands (cast fewer spells). We draw Capsule or Sol Ring.
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Baba Lysaga, Night Witch (from Hand): Baba Lysaga, Night Witch - Creature 3 / 3 [Forg] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (attack, COMBAT_DECLARE_ATTACKERS): chose [don't attack with it] instead of Forge's [attack P2 (40 life)]
- US cast Baba Lysaga, Night Witch

## Turn 13 (P1, round 4)
- P1 cast Anger

## Turn 14 (P2, round 4) | life: P1 39, P2 39, P3 39, US 38
- left battlefield: Sephiroth, Fabled SOLDIER was put into Graveyard from Battlefield.
- P2 cast Flare of Malice
- left battlefield: Baba Lysaga, Night Witch was put into Graveyard from Battlefield.
- left battlefield: Anger was put into Graveyard from Battlefield.
- US triggered Marionette Apprentice
- P2 triggered Bojuka Bog targeting [P4]
- P2 cast Ashnod's Altar

## Turn 15 (P3, round 4)

## Turn 16 (OUR TURN, round 4) | life: P1 39, P2 39, P3 39, US 37
Our hand: Gray Merchant of Asphodel, Ratchet Bomb, Barrin, Master Wizard, Misty Rainforest, Woodland Cemetery
Our graveyard (0): 
Board P1: 4 lands; no nonland permanents
Board P2: 4 lands; Ashnod's Altar
Board P3: 3 lands; no nonland permanents
Board US: 3 lands; Siren Stormtamer 1/1, Marionette Apprentice 1/2, Servo Token 1/1 [token]
MEMO (start of our turn):
THIS TURN: Baba Lysaga died and Bog exiled our yard, so the old plan is off. Crack Misty Rainforest and fetch Tropical Island. Cast Ratchet Bomb with Tropical Island and Bayou ({2}), then tap it right away to put its first charge counter on. Keep Underground Sea and Island up, so Stormtamer ({U}) can counter Swords or Snuff Out aimed at our creatures. Keep Woodland Cemetery for next turn. Don't cast Barrin this turn: it would leave no mana to use his bounce.

TARGET: Next turn: play Woodland Cemetery, tick Bomb to 2, and cast Barrin ({1}{U}{U}) with {2} open to bounce. The turn after: play a 6th land and cast Muldrotha. The turn after that: tick Bomb to 3 and fire it on the following turn. At 3 it kills Ashnod's Altar and a recast Sephiroth (it also kills Barrin, whom Muldrotha recasts). Missing: Executioner's Capsule, Claws of Gix, Survival of the Fittest, Sol Ring.

WIN PATH: Gray Merchant cast once Muldrotha is out (devotion 3+, which drains 9+ across the table). Apprentice drains on each Servo or artifact sacrifice. Muldrotha recasts Merchant every turn. P2 (Sephiroth) is the fastest at about 2 turns if they find Plunderer.

THREATS & ANSWERS:
1. Sephiroth recast: Barrin bounce ({2}, sacrifice Servo so Apprentice drains; never a real creature).
2. Ashnod's Altar or Pitiless Plunderer: Ratchet Bomb at 3 for Altar. Barrin bounces Plunderer.
3. P1 Sauron or Orc Army: cast fewer spells. Barrin can't target Sauron without paying his ward. Hold Merchant for big turns.
4. Y'shtola: Barrin bounce.

HOLD: Keep {U} for Stormtamer every turn cycle. Keep Gray Merchant until Muldrotha can recast it. Don't sacrifice creatures while Sephiroth is out.

REPLAN IF: Ratchet Bomb is destroyed. Sauron lands. Sephiroth is recast before Barrin. We draw Capsule, Seal or Assassin's Trophy (use it on the Altar now).
PILOT OVERRULED FORGE (action, MAIN1): chose [play land Misty Rainforest (from Hand): Play land] instead of Forge's [play land Woodland Cemetery (from Hand): Play land]
PILOT OVERRULED FORGE (search, MAIN1): chose [Tropical Island — Land - Forest Island — ({T}: Add {G} or {U}.)] instead of Forge's [Zagoth Triome — Land - Swamp Forest Island — ({T}: Add {B}, {G}, or {U}.) Zagoth Triome en]
PILOT OVERRULED FORGE (attack, COMBAT_DECLARE_ATTACKERS): chose [don't attack with it] instead of Forge's [attack P2 (39 life)]
PILOT OVERRULED FORGE (attack, COMBAT_DECLARE_ATTACKERS): chose [don't attack with it] instead of Forge's [attack P2 (39 life)]
PILOT OVERRULED FORGE (attack, COMBAT_DECLARE_ATTACKERS): chose [don't attack with it] instead of Forge's [attack P2 (39 life)]
- left battlefield: Misty Rainforest was put into Graveyard from Battlefield.
- US activated Misty Rainforest
- US cast Ratchet Bomb
- US activated Ratchet Bomb

## Turn 17 (P1, round 5)

## Turn 18 (P2, round 5) | life: P1 37, P2 45, P3 37, US 35
- P2 cast Gray Merchant of Asphodel
- P2 triggered Gray Merchant of Asphodel

## Turn 19 (P3, round 5)
- P3 cast Dismember targeting [Gray Merchant of Asphodel]
- left battlefield: Gray Merchant of Asphodel was put into Graveyard from Battlefield.

## Turn 20 (OUR TURN, round 5)
Our hand: Gray Merchant of Asphodel, Barrin, Master Wizard, Woodland Cemetery
Our graveyard (1): Misty Rainforest
Board P1: 5 lands; no nonland permanents
Board P2: 5 lands; Ashnod's Altar
Board P3: 3 lands; no nonland permanents
Board US: 4 lands; Siren Stormtamer 1/1, Marionette Apprentice 1/2, Servo Token 1/1 [token], Ratchet Bomb {[CHARGE]}
MEMO (start of our turn):
THIS TURN: Play Woodland Cemetery (enters untapped). Cast Barrin ({1}{U}{U}) with Island, Tropical Island and Bayou; P2 and P3 are tapped out, so only P1 can counter. Keep Underground Sea and Cemetery open: {2} for Barrin's bounce, or {U} for Stormtamer. Leave Ratchet Bomb (1 counter) untapped and tick it to 2 at P3's end step.

TARGET: Muldrotha out with Barrin up and Ratchet Bomb ticking to 3. At 3 the Bomb kills Ashnod's Altar and a recast Sephiroth, and Barrin, whom Muldrotha recasts. We need a 6th land: Misty in our graveyard is playable only once Muldrotha is out. Tutor targets: Sol Ring, Survival of the Fittest, Executioner's Capsule, Claws of Gix.

WIN PATH: Next turn, if we drew a land, cast Muldrotha (6). If not, cast Gray Merchant (devotion 3, drains 9 in total). Then Muldrotha loops Merchant, and Apprentice drains on every Servo or artifact death. We are about 5+ turns out. P2 or a Sauron hit is faster.

THREATS & ANSWERS:
1. Sephiroth recast (5 mana): bounce it with Barrin ({2}, sacrifice Servo) before it gets fodder.
2. Sauron (P1 has 5 lands, and Anger in their yard gives haste): target it with Barrin (sacrifice Servo), and pay the ward by sacrificing Barrin himself; the bounce still resolves.
3. Ashnod's Altar or Plunderer: Bomb at 3 for the Altar; Barrin bounces Plunderer.
4. Y'shtola: Barrin bounce.

HOLD: Hold Gray Merchant this turn. Keep {2} or {U} open every turn cycle. Don't fire the Bomb at 2, since that kills our own Apprentice.

REPLAN IF: Barrin is countered or killed, we draw Sol Ring or a land, Sauron resolves, or P2 assembles Altar plus fodder.
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Barrin, Master Wizard (from Hand): Barrin, Master Wizard - Creature 1 / 1 [Forge's he] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (attack, COMBAT_DECLARE_ATTACKERS): chose [don't attack with it] instead of Forge's [attack P2 (45 life)]
PILOT OVERRULED FORGE (attack, COMBAT_DECLARE_ATTACKERS): chose [don't attack with it] instead of Forge's [attack P2 (45 life)]
PILOT OVERRULED FORGE (attack, COMBAT_DECLARE_ATTACKERS): chose [don't attack with it] instead of Forge's [attack P2 (45 life)]
- US activated Ratchet Bomb
- US cast Barrin, Master Wizard
- US cast Mind Stone

## Turn 21 (P1, round 6)

## Turn 22 (P2, round 6)
- P2 cast Sephiroth, Fabled SOLDIER
- P2 triggered Sephiroth, Fabled SOLDIER

## Turn 23 (P3, round 6) | life: P1 37, P2 45, P3 36, US 35
- left battlefield: Marsh Flats was put into Graveyard from Battlefield.
- P3 activated Marsh Flats
- P3 cast Vito, Thorn of the Dusk Rose

## Turn 24 (OUR TURN, round 6) | life: P1 37, P2 45, P3 36, US 34
Our hand: Gray Merchant of Asphodel
Our graveyard (1): Misty Rainforest
Board P1: 5 lands; no nonland permanents
Board P2: 6 lands; Ashnod's Altar, Sephiroth, Fabled SOLDIER 3/3
Board P3: 4 lands; Vito, Thorn of the Dusk Rose 1/3
Board US: 5 lands; Siren Stormtamer 1/1, Marionette Apprentice 1/2, Servo Token 1/1 [token], Ratchet Bomb {[CHARGE x 2]}, Barrin, Master Wizard 1/1, Mind Stone
MEMO (start of our turn):
THIS TURN: After the draw, cast Muldrotha first with all 6 sources (Mind Stone plus the 5 lands). Tax is 0. P2 and P3 are nearly tapped out; only P1 can counter.
- If Muldrotha resolves: play Misty Rainforest from the graveyard as our land drop and fetch the basic Island. Hold {U} for Stormtamer to protect Muldrotha from P3's removal.
- If Muldrotha is countered: play any land we drew.
- At P3's end step, tick Ratchet Bomb to 3.
- Against edicts, sacrifice Servo first, then Stormtamer. Never Muldrotha.

TARGET: Muldrotha, plus a Bomb that fires at 3 each turn and is recast, plus Gray Merchant looping through Barrin's sacrifice. Missing: Sol Ring, Claws of Gix, Executioner's Capsule, Demonic Tutor, Syr Konrad.

WIN PATH: Next turn (7 mana):
1. Fire the Bomb at 3. It kills Sephiroth, Ashnod's Altar, Vito and our Barrin.
2. Cast Gray Merchant ({3}{B}{B}). Devotion is 4, so it drains 12.
3. Recast the Bomb from the graveyard ({2}).
The turn after, recast Barrin. Each later turn, Barrin ({2}) sacrifices Merchant to bounce something, then Muldrotha recasts Merchant. We close in about 4-5 turns; P2 is the fastest opponent.

THREATS & ANSWERS:
1. Sephiroth plus Altar (P2): the Bomb at 3. Don't feed it deaths, no chump blocks.
2. Sauron (P1 may reach 6 lands next turn): Barrin bounces it, paying ward by sacrificing Barrin himself. Do this before firing the Bomb.
3. Vito (P3, lifegain drain): the Bomb at 3.
4. Y'shtola: Barrin bounce.

HOLD: Gray Merchant until next turn. {U} for Stormtamer. Don't fire the Bomb at 2 (it kills our Apprentice and Mind Stone) unless P1 flashes in Bowmasters.

REPLAN IF: Muldrotha is countered (then cast Merchant next turn), Sauron resolves, a wipe lands, we draw Sol Ring or a tutor, or P2 finds a Plunderer.
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Muldrotha, the Gravetide (from Command): Muldrotha, the Gravetide - Creature 6 / 6 [F] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN1): chose [play land Misty Rainforest (from Graveyard): Play land by Muldrotha, the Gravetide (403) (] instead of Forge's [play land Misty Rainforest (from Graveyard): Play land by Muldrotha, the Gravetide (403) (]
PILOT OVERRULED FORGE (search, MAIN1): chose [Island — Basic Land - Island — ({T}: Add {U}.)] instead of Forge's [Watery Grave — Land - Island Swamp — ({T}: Add {U} or {B}.) As Watery Grave enters, you ma]
PILOT OVERRULED FORGE (attack, COMBAT_DECLARE_ATTACKERS): chose [don't attack with it] instead of Forge's [attack P2 (45 life)]
- US activated Ratchet Bomb
- US cast Muldrotha, the Gravetide
- left battlefield: Misty Rainforest was put into Graveyard from Battlefield.
- US activated Misty Rainforest

## Turn 25 (P1, round 7)
- P1 cast Sauron, the Dark Lord

## Turn 26 (P2, round 7) | life: P1 35, P2 49, P3 28, US 34
PILOT OVERRULED FORGE (action, UPKEEP): chose [activate Siren Stormtamer (from Battlefield): {U}, Sacrifice Siren Stormtamer: Counter tar] instead of Forge's [Do nothing now; let it resolve / let the turn pass]
- P2 cast Deadly Rollick targeting [Muldrotha, the Gravetide]
- P1 triggered Sauron, the Dark Lord
- left battlefield: Siren Stormtamer was put into Graveyard from Battlefield.
- US activated Siren Stormtamer targeting [Exile target creature. (If you control a commander, you may cast this spell without paying its mana cost.) ]
- P2 triggered Sephiroth, Fabled SOLDIER targeting [P3]
- US triggered Marionette Apprentice
- P2 cast Endrek Sahr, Master Breeder
- P1 triggered Sauron, the Dark Lord
- left battlefield: Endrek Sahr, Master Breeder was put into Graveyard from Battlefield.
- P2 cast Fleshbag Marauder
- P2 triggered Sephiroth, Fabled SOLDIER targeting [P3]
- P1 triggered Sauron, the Dark Lord
- P2 triggered Fleshbag Marauder
- left battlefield: Fleshbag Marauder was put into Graveyard from Battlefield.
- left battlefield: Vito, Thorn of the Dusk Rose was put into Graveyard from Battlefield.
- P2 triggered Sephiroth, Fabled SOLDIER targeting [P3]
- P2 triggered Sephiroth, Fabled SOLDIER targeting [P3]
- P2 triggered Sephiroth, Fabled SOLDIER targeting [P3]
- P2 triggered Sephiroth, Fabled SOLDIER targeting [P3]
- US triggered Marionette Apprentice

## Turn 27 (P3, round 7)
- P3 cast Alphinaud Leveilleur
- P1 triggered Sauron, the Dark Lord
- P3 triggered Alphinaud Leveilleur targeting [P3]

## Turn 28 (OUR TURN, round 7) | life: P1 25, P2 48, P3 21, US 33
Our hand: Gray Merchant of Asphodel, Toxic Deluge, Otawara, Soaring City
Our graveyard (2): Misty Rainforest, Siren Stormtamer
Board P1: 6 lands; Sauron, the Dark Lord 7/6, Orc Army Token 1/1 [token] {[P1P1]}
Board P2: 7 lands; Ashnod's Altar, Sephiroth, One-Winged Angel 5/5
Board P3: 5 lands; Alphinaud Leveilleur 2/4
Board US: 6 lands; Marionette Apprentice 1/2, Ratchet Bomb {[CHARGE x 3]}, Barrin, Master Wizard 1/1, Mind Stone, Muldrotha, the Gravetide 6/6
MEMO (start of our turn):
THIS TURN: All three opponents are tapped out, so this is our window. 8 mana after the fetch.
1. Play Misty Rainforest from the graveyard. Crack it for Watery Grave and pay 2 life so it enters untapped.
2. Channel Otawara ({1}{U}; two legends make it cheaper) targeting Sauron. Pay the ward by sacrificing Barrin.
3. Fire Ratchet Bomb at 3. It kills Sephiroth and Ashnod's Altar.
4. Cast Gray Merchant ({3}{B}{B}). Devotion is 4, so each opponent loses 4.
5. Cast Siren Stormtamer from the graveyard ({U}) and keep it up for Muldrotha.
Do not recast Ratchet Bomb this turn.

TARGET: Muldrotha, Apprentice, Merchant, Barrin, and a Bomb recast and ticked every turn. Missing: Sol Ring, Claws of Gix, Syr Konrad, Demonic Tutor.

WIN PATH: Next turn, recast the Bomb ({2}) and Barrin ({1}{U}{U}). Tick the Bomb at every P3 end step. From then on, each turn Barrin ({2}) sacrifices Merchant to bounce a threat, and we recast Merchant ({5}): about 5–6 drain per opponent per turn. P3 (~22) dies in about 4 turns.

THREATS & ANSWERS:
1. Sauron returns (8 mana with tax) with a 7-card hand, Living Death or Blasphemous Act: Barrin bounce, paying ward with Barrin; Deluge after a Living Death.
2. P2's emblem: every creature death drains us. No chump blocks, no needless sacrifices. Pitiless Plunderer: Barrin bounce.
3. Y'shtola if cast, and Alphinaud: Barrin bounce.
Against an edict, sacrifice Merchant, then Stormtamer. Never Muldrotha.

HOLD: Toxic Deluge (X≤5; Muldrotha survives) for a mass reanimation or a wide army. Stormtamer for Swords or Feed the Swarm on Muldrotha; it can't stop Void Rend.

REPLAN IF: Muldrotha dies, a wipe resolves, Sauron is recast, or we draw Sol Ring or a tutor.
MEMO (executor escalation: P2: nonland permanents 2→0 (-2); we lost: Barrin, Master Wizard):
THIS TURN: Everyone is tapped out. 7 mana; land lane already used. Let the stack resolve first.
1. Cast Barrin from the graveyard ({1}{U}{U}, creature lane).
2. Cast Ratchet Bomb from the graveyard ({2}, artifact lane). Do not tick it.
3. Channel Otawara ({1}{U}, cheaper with two legends) targeting Sauron. Pay the ward by sacrificing Barrin. Never sacrifice Muldrotha.
4. Pop Ratchet Bomb at 0 counters. This kills the Orc Army token. None of our permanents are MV 0.
5. Attack P1 with Muldrotha for 6. Their board is empty.
Cast nothing on opponents' turns, since each spell grows the Army.

TARGET: Muldrotha, Apprentice and Gray Merchant, with Barrin plus Bomb recast each turn. Replay Misty from the graveyard every turn to fetch lands. Missing: Syr Konrad, Claws of Gix, Sol Ring, Demonic Tutor.

WIN PATH: Next turn, replay Misty, cast Gray Merchant ({3}{B}{B}, drains 4 each) and recast Barrin. After that, each turn Barrin ({2}) sacrifices Merchant to bounce a threat, then recast Merchant. Add Muldrotha beats on P1. Close in about 4 turns. P1 is the fastest opponent, and bouncing Sauron resets them.

THREATS & ANSWERS:
1. Sauron recast: Barrin bounce next turn, paying ward with Barrin itself.
2. Living Death or a wide Army: Toxic Deluge with X≤5, so Muldrotha lives.
3. P2's emblem: avoid needless creature deaths. Answer Pitiless Plunderer with Barrin.
4. Y'shtola: Barrin bounce.

HOLD: Gray Merchant for next turn (7 mana is spent now). Toxic Deluge for a mass reanimation or army. Stormtamer is next turn's creature lane only if Barrin isn't needed.

REPLAN IF: Muldrotha dies, a wipe or Living Death resolves, Sauron is recast, or we draw a tutor or Sol Ring.
PILOT OVERRULED FORGE (action, MAIN1): chose [play land Misty Rainforest (from Graveyard): Play land by Muldrotha, the Gravetide (403) (] instead of Forge's [play land Otawara, Soaring City (from Hand): Play land]
PILOT OVERRULED FORGE (action, MAIN1): chose [activate Ratchet Bomb (from Battlefield): {T}, Sacrifice Ratchet Bomb: Destroy each nonlan] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
ESCALATION (p=0.8): P2: nonland permanents 2→0 (-2); we lost: Barrin, Master Wizard
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Barrin, Master Wizard (from Graveyard): Barrin, Master Wizard - Creature 1 / 1 by Mul] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Ratchet Bomb (from Graveyard): Ratchet Bomb by Muldrotha, the Gravetide (403) (Artifa] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN1): chose [activate Mind Stone (from Battlefield): {1}, {T}, Sacrifice Mind Stone: Draw a card. [Forg] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
- left battlefield: Misty Rainforest was put into Graveyard from Battlefield.
- US activated Misty Rainforest
- left battlefield: Ratchet Bomb was put into Graveyard from Battlefield.
- US activated Ratchet Bomb
- US triggered Marionette Apprentice
- left battlefield: Barrin, Master Wizard was put into Graveyard from Battlefield.
- left battlefield: Ashnod's Altar was put into Graveyard from Battlefield.
- left battlefield: Sephiroth, One-Winged Angel was put into Graveyard from Battlefield.
- US triggered Marionette Apprentice
- P2 triggered Emblem — Sephiroth, One-Winged Angel targeting [P3]
- P2 triggered Emblem — Sephiroth, One-Winged Angel targeting [P3]
- US cast Barrin, Master Wizard
- P1 triggered Sauron, the Dark Lord
- US cast Ratchet Bomb
- P1 triggered Sauron, the Dark Lord
- left battlefield: Ratchet Bomb was put into Graveyard from Battlefield.
- US activated Ratchet Bomb
- US triggered Marionette Apprentice
- P2 triggered Emblem — Sephiroth, One-Winged Angel targeting [P3]
- left battlefield: Mind Stone was put into Graveyard from Battlefield.
- US activated Mind Stone
- US triggered Marionette Apprentice
- attack: US assigned Muldrotha, the Gravetide to attack P1.

## Turn 29 (P1, round 8) | life: P1 25, P2 50, P3 19, US 23
PILOT OVERRULED FORGE (block, COMBAT_DECLARE_BLOCKERS): chose [block with Marionette Apprentice 1/2] instead of Forge's [no block (take the damage)]
- P1 cast Gothmog, Morgul Lieutenant
- P1 triggered Gothmog, Morgul Lieutenant
- attack: P1 assigned Sauron, the Dark Lord, Gothmog, Morgul Lieutenant and Orc Army Token to attack US.
- left battlefield: Marionette Apprentice was put into Graveyard from Battlefield.
- P2 triggered Emblem — Sephiroth, One-Winged Angel targeting [P3]
- P2 triggered Emblem — Sephiroth, One-Winged Angel targeting [P3]
Damage to US this turn: Sauron, the Dark Lord (combat) 7, Gothmog, Morgul Lieutenant (combat) 3

## Turn 30 (P2, round 8)
- P2 cast Sephiroth, Fabled SOLDIER
- P1 triggered Sauron, the Dark Lord
- P2 triggered Sephiroth, Fabled SOLDIER

## Turn 31 (P3, round 8)
- P3 cast Alisaie Leveilleur
- P1 triggered Sauron, the Dark Lord
- P3 triggered Alisaie Leveilleur targeting [P3]
- P3 cast Dancer's Chakrams
- P3 triggered Alphinaud Leveilleur
- P1 triggered Sauron, the Dark Lord
- P3 triggered Dancer's Chakrams

## Turn 32 (OUR TURN, round 8) | life: P1 22, P2 51, P3 12, US 31
Our hand: Gray Merchant of Asphodel, Toxic Deluge, Otawara, Soaring City, Claws of Gix, Takenuma, Abandoned Mire
Our graveyard (5): Siren Stormtamer, Misty Rainforest, Ratchet Bomb, Mind Stone, Marionette Apprentice
Board P1: 6 lands; Sauron, the Dark Lord 7/6 (tapped 1), Gothmog, Morgul Lieutenant 3/3 (tapped 1), Orc Army Token 3/3 [token] {[P1P1 x 3]}
Board P2: 7 lands; Sephiroth, Fabled SOLDIER 3/3
Board P3: 5 lands; Alphinaud Leveilleur 2/4, Alisaie Leveilleur 3/2, Dancer's Chakrams, Hero Token 3/3 [token]
Board US: 7 lands; Muldrotha, the Gravetide 6/6, Barrin, Master Wizard 1/1
MEMO (start of our turn):
THIS TURN: 8 mana after the land.
1. Play Misty Rainforest from the graveyard and crack it for a basic Forest (untapped).
2. Channel Otawara ({1}{U}; it is cheap while Barrin lives) targeting Sauron. Pay the ward by sacrificing Barrin. This is not a spell, so no amass, and Arcane Denial can't stop it.
3. Cast Ratchet Bomb from the graveyard ({2}). Pop it at 0 to kill the Orc Army and the Hero token.
4. Cast Marionette Apprentice from the graveyard ({1}{B}). Choose the +1/+1 counter, NOT a Servo.
5. Cast Claws of Gix ({0}) after the Bomb has popped.
Only 3 creatures may die this turn; a 4th flips Sephiroth into a second emblem. Don't attack; Muldrotha stays back to block. Never block a deathtouch Army with her.

TARGET: Muldrotha, Apprentice, Claws and Gray Merchant, with Barrin and Bomb recast each turn and Misty replayed each turn. Missing: Syr Konrad, Sol Ring, Demonic Tutor.

WIN PATH: Next turn, Misty, then Gray Merchant ({3}{B}{B}, drains 4 each), then recast Barrin ({1}{U}{U}). After that, each turn Barrin sacrifices Merchant to bounce a threat, and we recast Merchant for the drain. Kill P1 and P3 in about 3–4 turns, then grind P2.

THREATS & ANSWERS:
1. Sauron recast: recast Barrin and bounce it, paying ward with Barrin.
2. Living Death or a big Army: Toxic Deluge with X≤5 (P2's drains will follow).
3. Y'shtola: Barrin bounce.
4. P2's emblem: minimise creature deaths.

HOLD: Keep 2 mana up. Use {1} for Claws to sacrifice a permanent in response to theft (In the Darkness Bind Them) or removal. Also hold Toxic Deluge, Gray Merchant for next turn, and Takenuma to channel back Barrin or Merchant.

REPLAN IF: Bomb or Apprentice is countered (P1 has 2 open), Sephiroth transforms, Sauron or Y'shtola is recast, or Muldrotha dies.
PILOT OVERRULED FORGE (action, MAIN1): chose [play land Misty Rainforest (from Graveyard): Play land by Muldrotha, the Gravetide (403) (] instead of Forge's [play land Takenuma, Abandoned Mire (from Hand): Play land]
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Ratchet Bomb (from Graveyard): Ratchet Bomb by Muldrotha, the Gravetide (403) (Artifa] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Claws of Gix (from Hand): Claws of Gix] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN2): chose [cast Gray Merchant of Asphodel (from Hand): Gray Merchant of Asphodel - Creature 2 / 4] instead of Forge's [cast Marionette Apprentice (from Graveyard): Marionette Apprentice - Creature 1 / 2 by Mul]
- left battlefield: Misty Rainforest was put into Graveyard from Battlefield.
- US activated Misty Rainforest
- US cast Ratchet Bomb
- P1 triggered Sauron, the Dark Lord
- left battlefield: Ratchet Bomb was put into Graveyard from Battlefield.
- US activated Ratchet Bomb
- P2 triggered Sephiroth, Fabled SOLDIER targeting [P3]
- P2 triggered Emblem — Sephiroth, One-Winged Angel targeting [P3]
- P2 triggered Sephiroth, Fabled SOLDIER targeting [P3]
- P2 triggered Emblem — Sephiroth, One-Winged Angel targeting [P3]
- US cast Claws of Gix
- P1 triggered Sauron, the Dark Lord
- US cast Gray Merchant of Asphodel
- P1 triggered Sauron, the Dark Lord
- US triggered Gray Merchant of Asphodel

## Turn 33 (P1, round 9) | life: P1 22, P2 51, P3 5, US 31
- P1 cast Nazgûl
- P1 triggered Nazgûl
- P1 triggered Sauron, the Dark Lord
- P1 triggered Nazgûl
- attack: P1 assigned Sauron, the Dark Lord to attack P3.
- P1 cast Fellwar Stone

## Turn 34 (P2, round 9) | life: P1 22, P2 56, P3 0, US 31
MEMO (executor escalation: P3: life 19→5 (-14); P3: nonland permanents 4→2 (-2); us: life 23→31 (+8)):
THIS TURN: Marauder trigger: sacrifice Gray Merchant. Keep Muldrotha and Barrin, and don't block. We have 0 mana until our turn. Our turn, 9 mana:
1. Play Misty Rainforest from the graveyard and fetch an untapped Forest (pay 1 life).
2. Channel Otawara ({1}{U}; Muldrotha and Barrin make it cheaper) targeting Sauron. Pay the ward by sacrificing Barrin. This is not a spell, so no amass and it can't be countered.
3. Cast Ratchet Bomb from the graveyard ({2}) and pop it at 0 to kill the Orc Army. Our Claws of Gix dies with it; accept that.
4. Cast Gray Merchant from the graveyard ({3}{B}{B}). It drains 3 each and kills P3 if P3 is at 3 or less.

TARGET: Muldrotha, Merchant, Claws and Marionette Apprentice, recasting Merchant and Barrin in turns. Missing: Syr Konrad, Sol Ring, Demonic Tutor.

WIN PATH: Next turn, cast Claws from the graveyard. Channel Takenuma ({1}{B}) to return Apprentice to hand and cast it ({1}{B}). Claws sacrifices Merchant; the creature lane recasts Merchant later. Merchant drains 3–4 each turn plus 1 per Apprentice death. Kill P3 now or next turn, P1 in about 4 turns, then grind P2.

THREATS & ANSWERS:
1. Sauron and the Army: Otawara plus Bomb now. Sauron's recast costs 8.
2. P2's emblem: every creature death drains us. Minimise creature deaths.
3. Living Death or a new army: Toxic Deluge (X≤5).
4. Y'shtola recast: recast Barrin and bounce her.

HOLD: Toxic Deluge until a board worth wiping appears. Hold Takenuma for next turn's Apprentice.

REPLAN IF: P1 sacrifices or loses Sauron, Muldrotha or Barrin dies, P3 dies before our turn, Sephiroth transforms again, or P1 casts Living Death.
ESCALATION (p=0.82): P3: life 19→5 (-14); P3: nonland permanents 4→2 (-2); us: life 23→31 (+8)
- P2 cast Accursed Marauder
- P1 triggered Sauron, the Dark Lord
- P2 triggered Accursed Marauder
- left battlefield: Accursed Marauder was put into Graveyard from Battlefield.
- left battlefield: Alisaie Leveilleur was put into Graveyard from Battlefield.
- left battlefield: Barrin, Master Wizard was put into Graveyard from Battlefield.
- left battlefield: Gothmog, Morgul Lieutenant was put into Graveyard from Battlefield.
- P2 triggered Sephiroth, Fabled SOLDIER targeting [P3]
- P2 triggered Emblem — Sephiroth, One-Winged Angel targeting [P3]
- P2 triggered Sephiroth, Fabled SOLDIER targeting [P3]
- P2 triggered Emblem — Sephiroth, One-Winged Angel targeting [P3]
- P2 triggered Sephiroth, Fabled SOLDIER targeting [P3]
- P2 triggered Emblem — Sephiroth, One-Winged Angel targeting [P3]
- P2 triggered Sephiroth, Fabled SOLDIER targeting [P3]
- P2 triggered Emblem — Sephiroth, One-Winged Angel targeting [P3]

## Turn 35 (OUR TURN, round 9) | life: P1 22, P2 60, P3 0, US 26
Our hand: Toxic Deluge, Otawara, Soaring City, Takenuma, Abandoned Mire, Nurturing Peatland
Our graveyard (6): Siren Stormtamer, Mind Stone, Marionette Apprentice, Misty Rainforest, Ratchet Bomb, Barrin, Master Wizard
Board P1: 6 lands; Sauron, the Dark Lord 7/6 (tapped 1), Orc Army Token 3/3 [token] {[P1P1 x 3]}, Nazgûl 2/3 {[P1P1]}, Fellwar Stone
Board P2: 8 lands; Sephiroth, Fabled SOLDIER 3/3
Board US: 8 lands; Muldrotha, the Gravetide 6/6, Claws of Gix, Gray Merchant of Asphodel 2/4
MEMO (start of our turn):
THIS TURN (9 mana after the land):
1. Play Misty Rainforest from the graveyard. Pay 1 life and fetch a basic Forest untapped.
2. Cast Barrin from the graveyard ({1}{U}{U}). This uses the creature lane, and the Army grows.
3. Channel Otawara ({1}{U}; two legendaries) targeting Sauron. Pay the ward by sacrificing Barrin.
4. Cast Toxic Deluge ({2}{B}) with X=5. It kills the Army (5/5 after two amasses), Nazgûl, Sephiroth and Merchant. Muldrotha survives.
Expect up to about 9 drain from P2 and plan to end near 16 life.
If P1 counters Barrin, still cast Deluge. Keep 1 mana open.

TARGET: Muldrotha, Claws, Merchant and Apprentice, recast every turn. Ratchet Bomb goes back into the artifact lane. Missing pieces: Syr Konrad, Kokusho, Massacre Wurm, Demonic Tutor.

WIN PATH: Next turn, recast Merchant from the graveyard (5 mana, drains 3 each). Channel Takenuma ({2}{B}) to mill 3 and return Apprentice or Barrin to hand, then cast it. Loop Merchant through Claws each turn. P1 dies in about 5 turns. P2 at 56+ is a long grind that needs Kokusho or Konrad; dig with Takenuma. P2's drain is the fastest clock on us.

THREATS & ANSWERS:
1. Sephiroth recast or a second transform: bounce with Barrin or edict before the 4th death.
2. P2's Plunderer, Altar or Grave Pact: Ratchet Bomb ticked to the right mana value, or Barrin.
3. Sauron recast or a new Army: Ratchet Bomb at 0 hits tokens, and Muldrotha can block.
Don't feed P2 needless creature deaths or chump blocks.

HOLD: Takenuma and Nurturing Peatland for next turn.

REPLAN IF: Deluge is countered, P1 casts Living Death or Reanimate, or Muldrotha dies.
MEMO (executor escalation: we lost: Muldrotha, the Gravetide; our commander left the battlefield):
THIS TURN: No response to the four drain triggers; we drop to 26. We already made our land drop and have no castable cards, so pass with Tropical Island and Zagoth Triome open (2 mana for one Barrin activation). On opponents' turns:
(a) Sephiroth has drained 2 so far this turn, and a 4th resolution flips it into a second emblem. On any turn, if a 4th trigger goes on the stack, respond with Barrin ({2}, sacrifice Claws of Gix) to bounce Sephiroth so it can't transform.
(b) Otherwise, when P1 attacks us with the Orc Army, use Barrin ({2}, sacrifice Claws) to bounce the Army token.
Don't block Sauron or the Army, since deaths feed P2.

TARGET: Next turn (Peatland drop, pay 1 life, 10 mana): cast Muldrotha (8), Claws from the graveyard (0), and Marionette Apprentice (2), then pass. Missing pieces: Kokusho, Syr Konrad, Massacre Wurm, Demonic Tutor.

WIN PATH: Loop Gray Merchant (devotion 4+) through Claws while Apprentice drains. Channel Takenuma ({1}{B} with 2 legends) to rebuy Merchant or Barrin and dig. P1 at 22 falls in about 4 turns. P2 at 56 needs Kokusho or Konrad. P2's drain is the fastest clock on us.

THREATS & ANSWERS:
1. A Sephiroth second transform: Barrin bounce.
2. The Army and Sauron beats: Barrin now, then Ratchet Bomb at 0 once Muldrotha is back (sacrifice Claws first in response).
3. P2's Plunderer, Altar or Grave Pact: Ratchet Bomb ticked to that mana value, or Otawara.
Don't feed creature deaths.

HOLD: Otawara (channel {1}{U}) and Takenuma. Play Peatland next turn.

REPLAN IF: Muldrotha is countered, P1 casts Living Death or Reanimate, Sauron's commander damage on us reaches 14 or more, or P2 gets a second emblem.
PILOT OVERRULED FORGE (action, MAIN1): chose [play land Misty Rainforest (from Graveyard): Play land by Muldrotha, the Gravetide (403) (] instead of Forge's [play land Takenuma, Abandoned Mire (from Hand): Play land]
PILOT OVERRULED FORGE (search, MAIN1): chose [Breeding Pool — Land - Forest Island — ({T}: Add {G} or {U}.) As Breeding Pool enters, you] instead of Forge's [Overgrown Tomb — Land - Swamp Forest — ({T}: Add {B} or {G}.) As Overgrown Tomb enters, yo]
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Barrin, Master Wizard (from Graveyard): Barrin, Master Wizard - Creature 1 / 1 by Mul] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Toxic Deluge (from Hand): As an additional cost to cast this spell, pay X life. All c] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (attack, COMBAT_DECLARE_ATTACKERS): chose [attack P1 (22 life)] instead of Forge's [don't attack with it]
ESCALATION (p=0.96): we lost: Muldrotha, the Gravetide; our commander left the battlefield
- left battlefield: Misty Rainforest was put into Graveyard from Battlefield.
- US activated Misty Rainforest
- US cast Barrin, Master Wizard
- P1 triggered Sauron, the Dark Lord
- US cast Toxic Deluge
- P1 triggered Sauron, the Dark Lord
- attack: US assigned Muldrotha, the Gravetide to attack P1.
- attack: P1 assigned Nazgûl to block Muldrotha, the Gravetide.
- left battlefield: Muldrotha, the Gravetide was put into Graveyard from Battlefield.
- left battlefield: Nazgûl was put into Graveyard from Battlefield.
- P2 triggered Sephiroth, Fabled SOLDIER targeting [P4]
- P2 triggered Emblem — Sephiroth, One-Winged Angel targeting [P4]
- P2 triggered Sephiroth, Fabled SOLDIER targeting [P4]
- P2 triggered Emblem — Sephiroth, One-Winged Angel targeting [P4]

## Turn 36 (P1, round 9) | life: P1 22, P2 60, P3 0, US 7
MEMO (executor escalation: us: life 30→7 (-23)):
THIS TURN: No blocks remain and no response to the tempt trigger. Cast no spells before our turn. Every spell we cast amasses P1's Army, and every creature death is a 2-point drain on us (Sephiroth plus emblem).
P2's turn: if Sephiroth attacks us, block with Gray Merchant (2/4 survives 3 damage). If a death chain nears a 4th Sephiroth trigger, Barrin ({2}, sac Claws) bounces Sephiroth. If unused, at P2's end step Barrin ({2}, sac Claws) bounces the Orc Army token (it's gone for good).

TARGET: Our turn, 10 mana (Peatland costs 1 life), abilities only, no spells:
1. Play Peatland.
2. Channel Otawara ({2}{U}) on the bigger Nazgûl.
3. Barrin ({2}, sac a tapped land) on the other Nazgûl. Recast Nazgûl will be summoning-sick.
4. Hold at least 2 for P1's combat.
Next turn: cast Merchant from hand, then Muldrotha, Claws and Apprentice.

WIN PATH: Survive first. The bounce-and-recast Merchant loop gains life and drains. Kokusho or Syr Konrad would finish. P2's drains are the fastest clock on us.

THREATS & ANSWERS:
1. P1's attack (Sauron 7 is lethal alone). Block Sauron with Merchant, then Barrin ({2}, sac a land) bounces Merchant: no death, no damage.
2. Sephiroth deaths or a second emblem: Barrin bounce.
3. Any Army: don't block with 1/1s.
Never chump in a way that lets a creature die.

HOLD: Takenuma (channel {2}{B} later for Merchant or Stormtamer). Keep 2+ open on every opponent's turn. Hold Muldrotha until she can't just be forced into a lethal block.

REPLAN IF: P1 attacks P2 instead, a wipe hits, P2 flips Sephiroth again, or P1 recasts Sauron or gains haste.
ESCALATION (p=0.9): us: life 30→7 (-23)
- P1 cast Nazgûl
- P1 triggered Nazgûl
- P1 triggered Sauron, the Dark Lord
- P1 triggered Nazgûl
- P1 cast Nazgûl
- P1 triggered Nazgûl
- P1 triggered Sauron, the Dark Lord
- P1 triggered Nazgûl
- P1 triggered Nazgûl
- attack: P1 assigned Sauron, the Dark Lord, Orc Army Token, Nazgûl and Nazgûl to attack US.
- P1 triggered The Ring
- P1 triggered Sauron, the Dark Lord
- P1 triggered Sauron, the Dark Lord
- P1 triggered Nazgûl
- P1 triggered Nazgûl
Damage to US this turn: Sauron, the Dark Lord (combat) 7, Orc Army Token (combat) 5, Nazgûl (combat) 7

## Turn 37 (P2, round 10)
PILOT OVERRULED FORGE (action, COMBAT_DECLARE_ATTACKERS): chose [activate Barrin, Master Wizard (from Battlefield): {2}, Sacrifice a permanent: Return targ] instead of Forge's [Do nothing now; let it resolve / let the turn pass]
- attack: P2 assigned Sephiroth, Fabled SOLDIER to attack P1.
- P2 triggered Sephiroth, Fabled SOLDIER
- left battlefield: Island was put into Graveyard from Battlefield.
- US activated Barrin, Master Wizard targeting [Sephiroth, Fabled SOLDIER]
- P2 cast Warren Soultrader
- P1 triggered Sauron, the Dark Lord
- P2 cast Sephiroth, Fabled SOLDIER
- P1 triggered Sauron, the Dark Lord
- P2 triggered Sephiroth, Fabled SOLDIER

## Turn 38 (OUR TURN, round 10)
Our hand: Otawara, Soaring City, Takenuma, Abandoned Mire, Nurturing Peatland, Mishra's Bauble
Our graveyard (7): Siren Stormtamer, Mind Stone, Marionette Apprentice, Ratchet Bomb, Misty Rainforest, Toxic Deluge, Island
Board P1: 7 lands; Sauron, the Dark Lord 7/6 (tapped 1), Orc Army Token 7/7 [token] {[P1P1 x 7]} (tapped 1), Fellwar Stone (tapped 1), Nazgûl 6/7 {[P1P1 x 5]} (tapped 1), Nazgûl 5/6 {[P1P1 x 4]} (tapped 1)
Board P2: 8 lands; Warren Soultrader 3/3, Sephiroth, Fabled SOLDIER 3/3
Board US: 8 lands; Claws of Gix, Gray Merchant of Asphodel 2/4, Barrin, Master Wizard 1/1
MEMO (start of our turn):
THIS TURN: Nine mana total until our next untap. Spend 7 now, while P1 has only 2 open.
1. Play Takenuma as our land (no life cost). Keep Peatland in hand.
2. Cast Mishra's Bauble. Its amass lands on the Army we're about to remove.
3. Barrin ({2}, sac Bauble) bounces the Orc Army token, which is gone for good.
4. Channel Otawara ({2}{U}) on the 6/7 Nazgûl.
5. Barrin ({2}, sac the tapped basic Island) bounces the 5/6 Nazgûl.
6. Leave Underground Sea and Watery Grave untapped.

P1's turn: Merchant blocks Sauron. After blocks, before damage, Barrin ({2}, sac a tapped land) returns Merchant to hand.

P2's turn: we have no mana. Don't chump with Barrin unless the unblocked damage would kill us.

TARGET: Next turn, 9 mana after the Peatland drop. Recast Merchant (5; opponents lose 2 each, we gain 4) and keep 2 up for Barrin. Then Muldrotha, Marionette Apprentice, Claws loops.

WIN PATH: Survive first. Loop Merchant with Barrin bounce onto P1 (22 life), then Kokusho or Syr Konrad. P2's drains kill us fastest.

THREATS & ANSWERS:
1. P1's attackers: bounces as above. Recast Nazgûl return the following turn, so bounce again then.
2. P2: every creature death anywhere drains us 2 (Sephiroth plus emblem). Answer: Barrin bounce on Sephiroth when we have mana.
3. Never let anything die: no Deluge, no Ratchet Bomb.

HOLD: 2 mana through P1's combat for the Merchant bounce. Hold Peatland and Claws. Cast no other spells, because each one amasses a fresh haste Army.

REPLAN IF: Barrin dies, P1 attacks P2 (then save the 2 to bounce Sephiroth when it attacks), P2 transforms Sephiroth again, a new haste Army appears, or P2 edicts.
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Mishra's Bauble (from Hand): Mishra's Bauble] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN1): chose [activate Barrin, Master Wizard (from Battlefield): {2}, Sacrifice a permanent: Return targ] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN1): chose [activate Mishra's Bauble (from Battlefield): {T}, Sacrifice Mishra's Bauble: Look at the t] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
- US cast Mishra's Bauble
- P1 triggered Sauron, the Dark Lord
- left battlefield: Island was put into Graveyard from Battlefield.
- US activated Barrin, Master Wizard targeting [Orc Army Token]
- left battlefield: Mishra's Bauble was put into Graveyard from Battlefield.
- US activated Mishra's Bauble targeting [P1]

## Turn 39 (P1, round 10) | life: P1 22, P2 57, P3 0, US -11
- US triggered Mishra's Bauble
- attack: P1 assigned Sauron, the Dark Lord, Nazgûl and Nazgûl to attack US.
- P1 triggered The Ring
- P1 triggered The Ring
- P1 cast In the Darkness Bind Them
- P1 triggered In the Darkness Bind Them
- P1 triggered Sauron, the Dark Lord
- P1 triggered Nazgûl
- P1 triggered Nazgûl
- P1 cast Orcish Siegemaster
Damage to US this turn: Sauron, the Dark Lord (combat) 7, Nazgûl (combat) 11

## Turn 40 (P2, round 10)
- P2 cast Marionette Apprentice
- P1 triggered Sauron, the Dark Lord
- P2 triggered Marionette Apprentice

## Turn 41 (P1, round 11) | life: P1 10, P2 11, P3 0, US -11
- P1 triggered In the Darkness Bind Them
- P1 triggered Sauron, the Dark Lord
- P1 triggered Nazgûl
- P1 triggered Nazgûl
- P1 cast Claim the Precious targeting [Warren Soultrader]
- left battlefield: Warren Soultrader was put into Graveyard from Battlefield.
- P1 triggered Sauron, the Dark Lord
- P1 triggered Nazgûl
- P1 triggered Nazgûl
- P2 triggered Sephiroth, Fabled SOLDIER targeting [P1]
- P2 triggered Marionette Apprentice
- P2 triggered Emblem — Sephiroth, One-Winged Angel targeting [P1]
- attack: P1 assigned Orcish Siegemaster, Nazgûl, Nazgûl, Wraith Token, Sauron, the Dark Lord and Wraith Token to attack P2.
- P1 triggered The Ring
- P1 triggered Orcish Siegemaster
- attack: P2 assigned Marionette Apprentice, Servo Token and Sephiroth, Fabled SOLDIER to block Orcish Siegemaster.
- left battlefield: Orcish Siegemaster was put into Graveyard from Battlefield.
- left battlefield: Sephiroth, Fabled SOLDIER was put into Graveyard from Battlefield.
- left battlefield: Marionette Apprentice was put into Graveyard from Battlefield.
- P1 triggered The Ring
- P2 triggered Emblem — Sephiroth, One-Winged Angel targeting [P1]
- P2 triggered Sephiroth, Fabled SOLDIER targeting [P1]
- P2 triggered Emblem — Sephiroth, One-Winged Angel targeting [P1]
- P2 triggered Marionette Apprentice
- P2 triggered Emblem — Sephiroth, One-Winged Angel targeting [P1]
- P2 triggered Sephiroth, Fabled SOLDIER targeting [P1]
- P2 triggered Emblem — Sephiroth, One-Winged Angel targeting [P1]
- P2 triggered Sephiroth, Fabled SOLDIER targeting [P1]
- P2 triggered Marionette Apprentice
- P1 cast One Ring to Rule Them All
- P1 triggered One Ring to Rule Them All
- P1 triggered Sauron, the Dark Lord
- P1 triggered Nazgûl
- P1 triggered Nazgûl

## Turn 42 (P2, round 11)
- P2 cast Black Market Connections
- P1 triggered Sauron, the Dark Lord
- P1 cast Counterspell targeting [Black Market Connections]

## Turn 43 (P1, round 11) | life: P1 4, P2 7, P3 0, US -11
- P1 triggered One Ring to Rule Them All
- P1 triggered In the Darkness Bind Them
- P1 triggered Sauron, the Dark Lord
- P1 triggered Nazgûl
- P1 triggered Nazgûl
- left battlefield: Nazgûl was put into Graveyard from Battlefield.
- left battlefield: Nazgûl was put into Graveyard from Battlefield.
- P2 triggered Emblem — Sephiroth, One-Winged Angel targeting [P1]
- P2 triggered Emblem — Sephiroth, One-Winged Angel targeting [P1]
- P2 triggered Emblem — Sephiroth, One-Winged Angel targeting [P1]
- P2 triggered Emblem — Sephiroth, One-Winged Angel targeting [P1]
- P2 triggered Emblem — Sephiroth, One-Winged Angel targeting [P1]
- P2 triggered Emblem — Sephiroth, One-Winged Angel targeting [P1]
- attack: P1 assigned Sauron, the Dark Lord to attack P2.
- P1 triggered The Ring
- P1 triggered The Ring

## Turn 44 (P2, round 11)
- P2 cast Bastion of Remembrance
- P1 triggered Sauron, the Dark Lord
- P2 triggered Bastion of Remembrance

## Turn 45 (P1, round 12) | life: P1 4, P2 0, P3 0, US -11
- P1 triggered In the Darkness Bind Them targeting [Human Soldier Token]
- P1 triggered One Ring to Rule Them All
- Game Outcome: P1 has won because all opponents have lost
- Game Outcome: P2 has lost because life total reached 0
- Game Outcome: P3 has lost because life total reached 0
- Game Outcome: US has lost because life total reached 0