# pod05-g3: we are P2; opponents P1 Pantlaza, Sun-Favored, P3 Sauron, the Dark Lord, P4 Teval, the Balanced Scale
Result: Turn 19; P1 has won because all opponents have lost; US has lost because life total reached 0; P3 has lost because life total reached 0; P4 has lost because life total reached 0

## Turn 1 (OUR TURN, round 1)
Our hand: Cryogen Relic, Dalek Drone, Invasion of Innistrad, Assassin's Trophy, The Death of Gwen Stacy, Watery Grave, Shriekmaw, Wayfarer's Bauble
Our graveyard (0): 
Board P1: 0 lands; no nonland permanents
Board US: 0 lands; no nonland permanents
Board P3: 0 lands; no nonland permanents
Board P4: 0 lands; no nonland permanents
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)

## Turn 2 (P3, round 1)

## Turn 3 (P4, round 1)
- P4 cast Stitcher's Supplier
- P4 triggered Stitcher's Supplier

## Turn 4 (P1, round 1)

## Turn 5 (OUR TURN, round 2) | life: US 39
Our hand: Cryogen Relic, Dalek Drone, Invasion of Innistrad, Assassin's Trophy, The Death of Gwen Stacy, Shriekmaw, Wayfarer's Bauble, Marsh Flats
Our graveyard (0): 
Board P1: 1 lands; no nonland permanents
Board US: 1 lands; no nonland permanents
Board P3: 1 lands; no nonland permanents
Board P4: 1 lands; Stitcher's Supplier 1/1
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
- left battlefield: Marsh Flats was put into Graveyard from Battlefield.
- US activated Marsh Flats
- US cast Wayfarer's Bauble

## Turn 6 (P3, round 2)

## Turn 7 (P4, round 2) | life: US 38
- attack: P4 assigned Stitcher's Supplier to attack US.
Damage to US this turn: Stitcher's Supplier (combat) 1

## Turn 8 (P1, round 2)

## Turn 9 (OUR TURN, round 3)
Our hand: Cryogen Relic, Dalek Drone, Invasion of Innistrad, Assassin's Trophy, The Death of Gwen Stacy, Shriekmaw
Our graveyard (1): Marsh Flats
Board P1: 2 lands; no nonland permanents
Board US: 2 lands; Wayfarer's Bauble
Board P3: 2 lands; no nonland permanents
Board P4: 2 lands; Stitcher's Supplier 1/1 (tapped 1)
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
- left battlefield: Wayfarer's Bauble was put into Graveyard from Battlefield.
- US activated Wayfarer's Bauble

## Turn 10 (P3, round 3)
- P3 cast Talisman of Indulgence

## Turn 11 (P4, round 3) | life: US 37
- P4 cast Putrefy targeting [Talisman of Indulgence]
- left battlefield: Talisman of Indulgence was put into Graveyard from Battlefield.
- attack: P4 assigned Stitcher's Supplier to attack US.
Damage to US this turn: Stitcher's Supplier (combat) 1

## Turn 12 (P1, round 3)
- P1 cast Topiary Stomper
- P1 triggered Topiary Stomper

## Turn 13 (OUR TURN, round 4)
Our hand: Cryogen Relic, Dalek Drone, Invasion of Innistrad, Assassin's Trophy, The Death of Gwen Stacy, Shriekmaw, Birds of Paradise
Our graveyard (2): Marsh Flats, Wayfarer's Bauble
Board P1: 4 lands; Topiary Stomper 4/4
Board US: 3 lands; no nonland permanents
Board P3: 3 lands; no nonland permanents
Board P4: 3 lands; Stitcher's Supplier 1/1 (tapped 1)
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
- US cast Assassin's Trophy targeting [Topiary Stomper]
- left battlefield: Topiary Stomper was put into Graveyard from Battlefield.

## Turn 14 (P3, round 4)

## Turn 15 (P4, round 4) | life: US 36
- attack: P4 assigned Stitcher's Supplier to attack US.
- P4 cast Teval, the Balanced Scale
Damage to US this turn: Stitcher's Supplier (combat) 1

## Turn 16 (P1, round 4)
- P1 cast Palani's Hatcher
- P1 triggered Palani's Hatcher

## Turn 17 (OUR TURN, round 5)
Our hand: Cryogen Relic, Dalek Drone, Invasion of Innistrad, The Death of Gwen Stacy, Shriekmaw, Birds of Paradise, Secrets of the Dead, Takenuma, Abandoned Mire
Our graveyard (3): Marsh Flats, Wayfarer's Bauble, Assassin's Trophy
Board P1: 6 lands; Palani's Hatcher 5/3, Dinosaur Egg Token 0/1 [token] x2
Board US: 3 lands; no nonland permanents
Board P3: 4 lands; no nonland permanents
Board P4: 4 lands; Stitcher's Supplier 1/1 (tapped 1), Teval, the Balanced Scale 4/4
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
PILOT OVERRULED FORGE (action, MAIN2): chose [cast Shriekmaw (from Hand): Evoke {1}{B} (You may cast this spell for its evoke cost. If y] instead of Forge's [cast The Death of Gwen Stacy (from Hand): The Death of Gwen Stacy]
- US cast Shriekmaw
- US triggered Shriekmaw targeting [Palani's Hatcher]
- US triggered Shriekmaw
- left battlefield: Shriekmaw was put into Graveyard from Battlefield.
- left battlefield: Palani's Hatcher was put into Graveyard from Battlefield.
- US cast Cryogen Relic
- US triggered Cryogen Relic

## Turn 18 (P3, round 5) | life: P3 36, US 36
- P3 cast Feed the Swarm targeting [Teval, the Balanced Scale]
- left battlefield: Teval, the Balanced Scale was put into Graveyard from Battlefield.

## Turn 19 (P4, round 5) | life: P3 36, US 35
- P4 cast Tear Asunder targeting [] [Dinosaur Egg Token]
- attack: P4 assigned Stitcher's Supplier to attack US.
Damage to US this turn: Stitcher's Supplier (combat) 1

## Turn 20 (P1, round 5)
- P1 cast Pantlaza, Sun-Favored
- P1 triggered Pantlaza, Sun-Favored
- P1 cast Thrashing Brontodon

## Turn 21 (OUR TURN, round 6)
Our hand: Dalek Drone, Invasion of Innistrad, The Death of Gwen Stacy, Birds of Paradise, Secrets of the Dead, Three Visits, Spore Frog
Our graveyard (4): Marsh Flats, Wayfarer's Bauble, Assassin's Trophy, Shriekmaw
Board P1: 7 lands; Dinosaur Egg Token 0/1 [token], Pantlaza, Sun-Favored 4/4, Thrashing Brontodon 3/4
Board US: 4 lands; Cryogen Relic
Board P3: 4 lands; no nonland permanents
Board P4: 4 lands; Stitcher's Supplier 1/1 (tapped 1)
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
- US cast Three Visits
- US cast The Death of Gwen Stacy
- US triggered The Death of Gwen Stacy targeting [Pantlaza, Sun-Favored]
- left battlefield: Pantlaza, Sun-Favored was put into Graveyard from Battlefield.

## Turn 22 (P3, round 6)
- P3 cast Nazgûl
- P3 triggered Nazgûl
- P3 triggered Nazgûl

## Turn 23 (P4, round 6)
- P4 cast Assassin's Trophy targeting [Nazgûl]
- left battlefield: Nazgûl was put into Graveyard from Battlefield.

## Turn 24 (P1, round 6) | life: P1 38, P3 36, US 25
- P1 cast Gishath, Sun's Avatar
- attack: P1 assigned Thrashing Brontodon and Gishath, Sun's Avatar to attack US.
- P1 triggered Gishath, Sun's Avatar
- P1 triggered Regisaur Alpha
Damage to US this turn: Thrashing Brontodon (combat) 3, Gishath, Sun's Avatar (combat) 7

## Turn 25 (OUR TURN, round 7) | life: P1 35, P3 36, US 25
Our hand: Dalek Drone, Invasion of Innistrad, Birds of Paradise, Secrets of the Dead, Spore Frog, Braids, Arisen Nightmare
Our graveyard (5): Marsh Flats, Wayfarer's Bauble, Assassin's Trophy, Shriekmaw, Three Visits
Board P1: 8 lands; Dinosaur Egg Token 0/1 [token], Thrashing Brontodon 3/4 (tapped 1), Gishath, Sun's Avatar 7/6, Hunting Velociraptor 3/2, Regisaur Alpha 4/4, Wayward Swordtooth 5/5, Dinosaur Token 3/3 [token]
Board US: 5 lands; Cryogen Relic, The Death of Gwen Stacy {[LORE x 2]}
Board P3: 5 lands; no nonland permanents
Board P4: 5 lands; Stitcher's Supplier 1/1
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
PILOT OVERRULED FORGE (discard, MAIN1): chose [Birds of Paradise [ours, 0/1, in hand]] instead of Forge's [Secrets of the Dead [ours, in hand]]
- US triggered The Death of Gwen Stacy
- US cast Dalek Drone
- US triggered Dalek Drone targeting [Gishath, Sun's Avatar]
- left battlefield: Gishath, Sun's Avatar was put into Graveyard from Battlefield.

## Turn 26 (P3, round 7)
- P3 cast Claim the Precious targeting [Wayward Swordtooth]
- left battlefield: Wayward Swordtooth was put into Graveyard from Battlefield.

## Turn 27 (P4, round 7)
- P4 cast River Kelpie

## Turn 28 (P1, round 7) | life: P1 35, P3 36, US 7
PILOT OVERRULED FORGE (block, COMBAT_DECLARE_BLOCKERS): chose [block with Dalek Drone 3/3] instead of Forge's [no block (take the damage)]
PILOT OVERRULED FORGE (block, COMBAT_DECLARE_BLOCKERS): chose [block with Dalek Drone 3/3] instead of Forge's [no block (take the damage)]
- P1 cast Zetalpa, Primal Dawn
- attack: P1 assigned Regisaur Alpha, Thrashing Brontodon, Hunting Velociraptor, Dinosaur Token and Zetalpa, Primal Dawn to attack US.
- left battlefield: Dalek Drone was put into Graveyard from Battlefield.
Damage to US this turn: Zetalpa, Primal Dawn (combat) 8, Regisaur Alpha (combat) 4, Thrashing Brontodon (combat) 3, Dinosaur Token (combat) 3

## Turn 29 (OUR TURN, round 8) | life: P1 33, P3 34, P4 38, US 7
Our hand: Invasion of Innistrad, Secrets of the Dead, Spore Frog, Braids, Arisen Nightmare, Twisted Embrace
Our graveyard (8): Marsh Flats, Wayfarer's Bauble, Assassin's Trophy, Shriekmaw, Three Visits, Birds of Paradise, Dalek Drone, The Death of Gwen Stacy
Board P1: 8 lands; Dinosaur Egg Token 0/1 [token], Thrashing Brontodon 3/4 (tapped 1), Hunting Velociraptor 3/2 (tapped 1), Regisaur Alpha 4/4 (tapped 1), Dinosaur Token 3/3 [token] (tapped 1), Zetalpa, Primal Dawn 4/8
Board US: 5 lands; Cryogen Relic
Board P3: 6 lands; no nonland permanents
Board P4: 5 lands; Stitcher's Supplier 1/1, River Kelpie 3/3
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
PILOT OVERRULED FORGE (action, MAIN2): chose [activate Spore Frog (from Battlefield): Sacrifice Spore Frog: Prevent all combat damage th] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
- US triggered The Death of Gwen Stacy targeting [P1]
- left battlefield: The Death of Gwen Stacy was put into Graveyard from Battlefield.
- US cast Braids, Arisen Nightmare
- US cast Spore Frog
- left battlefield: Spore Frog was put into Graveyard from Battlefield.
- US activated Spore Frog
- US triggered Braids, Arisen Nightmare
- left battlefield: Cryogen Relic was put into Graveyard from Battlefield.
- US triggered Cryogen Relic

## Turn 30 (P3, round 8)
- P3 cast Sauron, the Dark Lord

## Turn 31 (P4, round 8)
- P4 cast Wonder
- P3 triggered Sauron, the Dark Lord

## Turn 32 (P1, round 8) | life: P1 33, P3 34, P4 38, US -9
- P1 cast Bonehoard Dracosaur
- P3 triggered Sauron, the Dark Lord
- P1 cast Sunfrill Imitator
- P3 triggered Sauron, the Dark Lord
- attack: P1 assigned Bonehoard Dracosaur, Regisaur Alpha, Zetalpa, Primal Dawn, Thrashing Brontodon, Hunting Velociraptor, Dinosaur Token, Sunfrill Imitator and Dinosaur Egg Token to attack US.
- P1 triggered Sunfrill Imitator targeting [Zetalpa, Primal Dawn]
Damage to US this turn: Bonehoard Dracosaur (combat) 5, Zetalpa, Primal Dawn (combat) 4, Hunting Velociraptor (combat) 3, Sunfrill Imitator (combat) 4

## Turn 33 (P3, round 9)
- P3 cast Summons of Saruman
- P4 triggered River Kelpie

## Turn 34 (P4, round 9)
- left battlefield: Swamp was put into Graveyard from Battlefield.
- P4 cast Harrow
- P3 triggered Sauron, the Dark Lord
- P4 activated Zagoth Triome

## Turn 35 (P1, round 9) | life: P1 33, P3 -11, P4 38, US -9
- P1 triggered Bonehoard Dracosaur
- P1 cast Ghalta, Stampede Tyrant
- P3 triggered Sauron, the Dark Lord
- P1 triggered Ghalta, Stampede Tyrant
- P1 cast Rampant Growth
- P3 triggered Sauron, the Dark Lord
- P4 cast An Offer You Can't Refuse targeting [Search your library for a basic land card, put that card onto the battlefield tapped, then shuffle.]
- P3 triggered Sauron, the Dark Lord
- attack: P1 assigned Ghalta, Stampede Tyrant, Zacama, Primal Calamity, Bonehoard Dracosaur, Regisaur Alpha, Zetalpa, Primal Dawn, Sunfrill Imitator, Thrashing Brontodon, Hunting Velociraptor, Dinosaur Token, Dinosaur Token and Dinosaur Egg Token to attack P3.
- P1 triggered Sunfrill Imitator targeting [Zetalpa, Primal Dawn]
- attack: P3 assigned Orc Army Token to block Ghalta, Stampede Tyrant.

## Turn 36 (P4, round 9)
- P4 cast Teval, the Balanced Scale

## Turn 37 (P1, round 10) | life: P1 33, P3 -11, P4 -11, US -9
- P1 triggered Bonehoard Dracosaur
- P1 activated Zacama, Primal Calamity targeting [Wonder]
- left battlefield: Wonder was put into Graveyard from Battlefield.
- P1 activated Zacama, Primal Calamity targeting [Stitcher's Supplier]
- left battlefield: Stitcher's Supplier was put into Graveyard from Battlefield.
- P4 triggered Stitcher's Supplier
- attack: P1 assigned Ghalta, Stampede Tyrant, Zacama, Primal Calamity, Bonehoard Dracosaur, Regisaur Alpha, Zetalpa, Primal Dawn, Sunfrill Imitator, Thrashing Brontodon, Hunting Velociraptor, Dinosaur Token, Dinosaur Token and Dinosaur Egg Token to attack P4.
- P1 triggered Sunfrill Imitator targeting [Zetalpa, Primal Dawn]
- left battlefield: River Kelpie was put into Graveyard from Battlefield.
- P4 triggered River Kelpie
- P4 triggered River Kelpie
- P4 triggered Teval, the Balanced Scale
- P1 activated Zacama, Primal Calamity targeting [River Kelpie]
- left battlefield: River Kelpie was put into Graveyard from Battlefield.
- P1 activated Zacama, Primal Calamity targeting [Zombie Druid Token]
- Game Outcome: P1 has won because all opponents have lost
- Game Outcome: US has lost because life total reached 0
- Game Outcome: P3 has lost because life total reached 0
- Game Outcome: P4 has lost because life total reached 0