# pod02-g2: we are P4; opponents P1 Teval, the Balanced Scale, P2 Hearthhull, the Worldseed, P3 Giada, Font of Hope
Result: Turn 26; P1 has lost because life total reached 0; P2 has lost because life total reached 0; P3 has won because all opponents have lost; US has lost because life total reached 0

## Turn 1 (P1, round 1)

## Turn 2 (P2, round 1)

## Turn 3 (P3, round 1)

## Turn 4 (OUR TURN, round 1) | life: US 39
Our hand: Twisted Embrace, Boseiju, Who Endures, Watery Grave, Baleful Strix, Drowned Catacomb, Plaguecrafter, Cryogen Relic, Misty Rainforest
Our graveyard (0): 
Board P1: 1 lands; no nonland permanents
Board P2: 1 lands; no nonland permanents
Board P3: 1 lands; no nonland permanents
Board US: 0 lands; no nonland permanents
MEMO (start of our turn):
THIS TURN: Crack Misty Rainforest now (1 life) and fetch Zagoth Triome, which enters tapped and taps for B, G or U. That puts a replayable land in our yard for Muldrotha later. No other plays; we have 0 mana.
Next turn: play Drowned Catacomb (untapped, since the Triome is a Swamp and an Island), then cast Baleful Strix (UB).
Turn after: play Watery Grave (pay 2), then Plaguecrafter or Cryogen Relic plus 1 open.

TARGET: 6 lands and Muldrotha by about our turn 6, with Cryogen Relic, Strix and Plaguecrafter in the yard to recast. Tutor or draw targets: Executioner's Capsule, Seal of Primordium, Claws of Gix, and ramp (Sol Ring, Arcane Signet, Farseek).

WIN PATH: Lock the board by turns 7–9, then drain with Gray Merchant or Syr Konrad recursion plus Muldrotha beats. P2 is the fastest opponent (turns 6–8), so we must slow P2 first.

THREATS & ANSWERS:
1. Hearthhull (P2, likely their turn 4): channel Boseiju ({1}{G}) while it is a noncreature artifact. Save Boseiju for Hearthhull or Zuran Orb only.
2. Giada (P3, can land next turn): Twisted Embrace. Use Plaguecrafter only if each opponent has exactly one creature; we sacrifice Strix after it has drawn.
3. Teval (P1): Twisted Embrace or Plaguecrafter.

Don't give P3 life. Don't overextend creatures into P2's Blasphemous Act.

HOLD: Boseiju in hand as removal; don't play it as a land unless we have no other green source. Keep Twisted Embrace for a commander.

REPLAN IF: An opponent plays a turn-2 ramp commander early, or Zuran Orb appears (Boseiju it at once). Also replan if we draw Sol Ring or Signet (cast it next turn instead of Strix).
PILOT OVERRULED FORGE (action, MAIN1): chose [play land Misty Rainforest (from Hand): Play land] instead of Forge's [play land Watery Grave (from Hand): Play land]
PILOT OVERRULED FORGE (search, MAIN1): chose [Zagoth Triome — Land - Swamp Forest Island — ({T}: Add {B}, {G}, or {U}.) Zagoth Triome en] instead of Forge's [Tropical Island — Land - Forest Island — ({T}: Add {G} or {U}.)]
- left battlefield: Misty Rainforest was put into Graveyard from Battlefield.
- US activated Misty Rainforest

## Turn 5 (P1, round 2)
- P1 cast Arcane Signet

## Turn 6 (P2, round 2)
- P2 cast Lotus Cobra

## Turn 7 (P3, round 2) | life: P3 42, US 39
- P3 triggered Seraph Sanctuary
- P3 cast Giada, Font of Hope
- P3 triggered Seraph Sanctuary

## Turn 8 (OUR TURN, round 2)
Our hand: Twisted Embrace, Boseiju, Who Endures, Watery Grave, Baleful Strix, Drowned Catacomb, Plaguecrafter, Cryogen Relic, Marionette Apprentice
Our graveyard (1): Misty Rainforest
Board P1: 2 lands; Arcane Signet
Board P2: 2 lands; Lotus Cobra 2/1
Board P3: 2 lands; Giada, Font of Hope 2/2
Board US: 1 lands; no nonland permanents
MEMO (start of our turn):
THIS TURN: Play Drowned Catacomb. It enters untapped because Zagoth Triome is a Swamp and an Island. Tap Triome (U) and Catacomb (B) for Baleful Strix and draw a card. That leaves 0 mana. If the draw is Sol Ring, Arcane Signet, Mind Stone or Talisman of Dominance, cast it now instead of Strix.

TARGET: Next turn, play Watery Grave and pay 2 life for 3 mana. Turn after, we have 4 lands (Boseiju is the only land left in hand unless we draw one) for Twisted Embrace. Build toward Muldrotha on 6 mana with Strix, Plaguecrafter and Cryogen Relic in the yard. Draw or tutor targets: Sol Ring, Farseek, Nature's Lore, Executioner's Capsule, Claws of Gix.

WIN PATH: Grind with recursion, then drain with Marionette Apprentice, Gray Merchant or Syr Konrad plus Muldrotha beats. P2 (turns 6–8) and P3 (turns 6–8) are the fastest clocks.

THREATS & ANSWERS:
1. Giada (P3). Next turn, if Giada is P3's only creature, cast Plaguecrafter and sacrifice Plaguecrafter itself (Strix stays). Otherwise, Twisted Embrace on the turn after, enchanting Strix. Strix blocks fliers until then.
2. Hearthhull or Zuran Orb (P2): Boseiju channel, 1G.
3. Teval (P1): Embrace or Plaguecrafter later.
4. Lotus Cobra: ignore.
Don't give P3 life.

HOLD: Boseiju for Hearthhull or Orb unless it is our only 4th land for Embrace against Giada. Keep Marionette Apprentice until we have sacrifice fodder. Commit at most two creatures into P2's possible Blasphemous Act.

REPLAN IF: Hearthhull, Zuran Orb or a Thune/Avacyn-class angel lands. Also replan if a wipe clears Strix, or if we draw ramp or lands.
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Baleful Strix (from Hand): Baleful Strix - Creature 1 / 1 [Forge's heuristic AI would] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
- US cast Baleful Strix
- US triggered Baleful Strix

## Turn 9 (P1, round 3)
- P1 cast Putrefy targeting [Giada, Font of Hope]
- left battlefield: Giada, Font of Hope was put into Graveyard from Battlefield.

## Turn 10 (P2, round 3) | life: P1 38, P2 39, P3 42, US 39
PILOT OVERRULED FORGE (confirm, DRAW): chose [no] instead of Forge's [yes, do it]
- P2 cast Assassin's Trophy targeting [Baleful Strix]
- left battlefield: Baleful Strix was put into Graveyard from Battlefield.
- P2 triggered Lotus Cobra
- attack: P2 assigned Lotus Cobra to attack P1.

## Turn 11 (P3, round 3)
- P3 cast Arcane Signet

## Turn 12 (OUR TURN, round 3)
Our hand: Twisted Embrace, Boseiju, Who Endures, Watery Grave, Plaguecrafter, Cryogen Relic, Marionette Apprentice, Sinister Concoction, Swamp
Our graveyard (2): Misty Rainforest, Baleful Strix
Board P1: 3 lands; Arcane Signet (tapped 1)
Board P2: 3 lands; Lotus Cobra 2/1 (tapped 1)
Board P3: 3 lands; Arcane Signet
Board US: 2 lands; no nonland permanents
MEMO (start of our turn):
THIS TURN: Play Watery Grave and pay 2 life so it enters untapped (3 mana). Cast Cryogen Relic with Triome (U) plus Catacomb, and draw a card. Cast Sinister Concoction with Grave (B). If the draw is Sol Ring, Signet, Mind Stone or Talisman, cast it instead of Concoction. Opponents' boards hold only Lotus Cobra, so no attacks matter.

TARGET: Next turn, play Swamp for 4 mana. If Giada is back, activate Concoction on her (B, 1 life, mill 1, discard a spare land or Apprentice), then cast Plaguecrafter (2B) to hit Cobra and anything else. If no Giada, cast Twisted Embrace on Relic to kill the best creature. Build toward Muldrotha (6 mana, no tax yet) with Strix, Plaguecrafter and Relic in the yard. Draw targets: Sol Ring, Farseek, Nature's Lore, Executioner's Capsule, Claws of Gix.

WIN PATH: Grind with recursion, then drain with Marionette Apprentice, Gray Merchant or Syr Konrad plus Muldrotha beats. P2 and P3 are the fastest, around turns 6–8.

THREATS & ANSWERS:
1. Giada or the first Angel (P3): Concoction, backed by Embrace.
2. Hearthhull or Zuran Orb (P2): Boseiju channel (1G).
3. Teval (P1): Plaguecrafter or Embrace.
4. Cobra: Plaguecrafter edict.
Don't give P3 life.

HOLD: Keep Boseiju in hand as a channel answer; play Swamp first. Hold Marionette Apprentice until we have fodder. Keep Concoction uncracked for a real threat, not Cobra. Put no more than two creatures into a possible Blasphemous Act.

REPLAN IF: Hearthhull, Zuran Orb, Thune or Avacyn lands. Also replan if Relic or Concoction is removed, or if we draw ramp.
PILOT OVERRULED FORGE (action, MAIN1): chose [play land Watery Grave (from Hand): Play land] instead of Forge's [play land Boseiju, Who Endures (from Hand): Play land]
PILOT OVERRULED FORGE (action, MAIN2): chose [cast Cryogen Relic (from Hand): Cryogen Relic] instead of Forge's [cast Marionette Apprentice (from Hand): Marionette Apprentice - Creature 1 / 2]
- US cast Cryogen Relic
- US triggered Cryogen Relic

## Turn 13 (P1, round 4) | life: P1 37, P2 39, P3 42, US 39
- left battlefield: Misty Rainforest was put into Graveyard from Battlefield.
- P1 activated Misty Rainforest
- P1 cast Teval, the Balanced Scale

## Turn 14 (P2, round 4) | life: P1 37, P2 38, P3 42, US 39
- P2 triggered Lotus Cobra
- P2 cast Evendo Brushrazer

## Turn 15 (P3, round 4)
- P3 cast Generous Gift targeting [Teval, the Balanced Scale]
- left battlefield: Teval, the Balanced Scale was put into Graveyard from Battlefield.

## Turn 16 (OUR TURN, round 4) | life: P1 37, P2 38, P3 42, US 38
Our hand: Twisted Embrace, Boseiju, Who Endures, Plaguecrafter, Marionette Apprentice, Sinister Concoction, Swamp, Command Tower, Forest
Our graveyard (2): Misty Rainforest, Baleful Strix
Board P1: 4 lands; Arcane Signet (tapped 1), Elephant Token 3/3 [token]
Board P2: 4 lands; Lotus Cobra 2/1, Evendo Brushrazer 2/2
Board P3: 3 lands; Arcane Signet
Board US: 3 lands; Cryogen Relic
MEMO (start of our turn):
THIS TURN: Play Command Tower (4 mana). Cast Sinister Concoction (B from Watery Grave). Cast Plaguecrafter (2B: Triome, Catacomb, Tower). Its edict makes P1 sacrifice the Elephant and P2 sacrifice Cobra or Brushrazer. P3 has no creature, so P3 discards. We sacrifice Plaguecrafter itself, which stocks the creature lane for Muldrotha. We are tapped out on opponents' turns. No attacks.

TARGET: Next turn, play Swamp (5 mana). Keep B open for Concoction and 1U for Relic's stun, or cast Twisted Embrace on Relic (2BB) to kill the best creature. The turn after, play Forest (6 mana) and cast Muldrotha, with Plaguecrafter, Strix and Relic in the graveyard. Draw targets: Sol Ring, Signet, Farseek, Nature's Lore, Executioner's Capsule, Claws of Gix, Seal of Primordium.

WIN PATH: Muldrotha recasts Plaguecrafter and Strix every turn, then Marionette Apprentice, Gray Merchant or Syr Konrad drain us out. P2 and P3 close fastest, around turns 6–8. Every opponent is at 37 or more life, so there is no lethal either way yet.

THREATS & ANSWERS:
1. Hearthhull or Zuran Orb (P2): Boseiju channel (1G), which works at instant speed.
2. Giada recast for 4, or Thune or Avacyn (P3): Concoction, then Embrace.
3. Teval recast for 6 (P1): Embrace, or Plaguecrafter again through Muldrotha.
Give P3 no life. Don't sacrifice into Mayhem Devil if P2 has it.

HOLD: Boseiju stays in hand for its channel; play basics and Tower as land drops. Hold Marionette Apprentice until Muldrotha is out and we have fodder. Keep Concoction for Giada or a real threat, not Cobra. Keep at most two creatures on board, since Blasphemous Act and Wrath are live.

REPLAN IF: Hearthhull, Zuran Orb, Thune, Avacyn or Living Death appears. Also replan if Concoction or Relic is removed, if we draw ramp (then cast Muldrotha a turn early), or if P3 recasts Giada with protection up.
PILOT OVERRULED FORGE (action, MAIN2): chose [Lotus Cobra [P2, 2/1]] instead of Forge's [Evendo Brushrazer [P2, 2/2]]
- US cast Marionette Apprentice
- US triggered Marionette Apprentice
- US cast Sinister Concoction
- left battlefield: Sinister Concoction was put into Graveyard from Battlefield.
- US activated Sinister Concoction targeting [Lotus Cobra]
- left battlefield: Lotus Cobra was put into Graveyard from Battlefield.

## Turn 17 (P1, round 5) | life: P1 37, P2 38, P3 42, US 35
- attack: P1 assigned Elephant Token to attack US.
- P1 cast The Gitrog Monster
Damage to US this turn: Elephant Token (combat) 3

## Turn 18 (P2, round 5) | life: P1 37, P2 37, P3 42, US 35
- left battlefield: Bloodstained Mire was put into Graveyard from Battlefield.
- P2 activated Bloodstained Mire
- P2 triggered Evendo Brushrazer
- P2 cast Baloth Prime

## Turn 19 (P3, round 5) | life: P1 37, P2 37, P3 43, US 35
- P3 cast Gisela, the Broken Blade
- P3 triggered Seraph Sanctuary

## Turn 20 (OUR TURN, round 5) | life: P1 36, P2 36, P3 42, US 35
Our hand: Twisted Embrace, Boseiju, Who Endures, Plaguecrafter, Forest, Darkslick Shores
Our graveyard (5): Misty Rainforest, Baleful Strix, Swamp, Sinister Concoction, Heroic Intervention
Board P1: 5 lands; Arcane Signet (tapped 1), Elephant Token 3/3 [token] (tapped 1), The Gitrog Monster 6/6
Board P2: 5 lands; Evendo Brushrazer 2/2, Baloth Prime 10/10 {[STUN x 6]} (tapped 1)
Board P3: 4 lands; Arcane Signet (tapped 1), Gisela, the Broken Blade 4/3
Board US: 4 lands; Cryogen Relic, Marionette Apprentice 1/2, Servo Token 1/1 [token]
MEMO (start of our turn):
**THIS TURN:** All three opponents are fully tapped out, so this is a free window.
1. Play Darkslick Shores. It enters tapped; we are spending little now, and this lets Forest come in untapped next turn.
2. Cast Plaguecrafter with 3 of our 4 mana (Triome, Catacomb, Tower).
   - P3's only creature is Gisela, so she dies.
   - P1 likely loses the Elephant.
   - P2 loses Brushrazer or Baloth.
3. We sacrifice Plaguecrafter itself. Apprentice drains each opponent 1, and the creature lane is stocked.
4. Keep Servo as fodder for future edicts. No attacks.
5. On opponents' turns: 1 mana spare, nothing planned.

**TARGET:** Next turn, play Forest (6 untapped) and cast Muldrotha for 6. The turn after, with 7 mana, cast Strix via the artifact lane (UB), Plaguecrafter via the creature lane (2B), and Concoction via the enchantment lane (B, then B to kill). Draw or tutor targets: Claws of Gix, Executioner's Capsule, Gray Merchant, Syr Konrad, Ratchet Bomb, Sol Ring.

**WIN PATH:** Muldrotha loops edicts and removal every turn, and each artifact or creature we lose drains 1 through Apprentice. Gray Merchant or Syr Konrad closes. Opponents sit at 37/37/43, so no lethal either way soon. P2 is fastest, around turns 6–8.

**THREATS & ANSWERS:**
1. Gitrog (P1): Twisted Embrace on Relic or Servo, the turn after Muldrotha.
2. Baloth Prime plus land sacrifices (P2): Concoction from the graveyard, or the next edict.
3. Hearthhull or Zuran Orb (P2): Boseiju channel. It costs {G} once Muldrotha is out.
4. Giada recast or Thune (P3): Plaguecrafter loop or Concoction.

Give P3 no life.

**HOLD:**
- Boseiju in hand for its channel.
- Embrace for Gitrog.
- Relic: 1U sacrifice to stun a tapped attacker, or to cantrip in response to removal or a wipe. Its death also drains.

**REPLAN IF:**
- Plaguecrafter is answered.
- Hearthhull, Zuran Orb, Living Death, Blasphemous Act or Wrath appears.
- We draw ramp or another untapped land.
- Teval is recast.
- Bojuka Bog empties our graveyard.
PILOT OVERRULED FORGE (action, MAIN1): chose [play land Darkslick Shores (from Hand): Play land] instead of Forge's [play land Boseiju, Who Endures (from Hand): Play land]
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Plaguecrafter (from Hand): Plaguecrafter - Creature 3 / 2 [Forge's heuristic AI would] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
- US cast Plaguecrafter
- US triggered Plaguecrafter
- left battlefield: Evendo Brushrazer was put into Graveyard from Battlefield.
- left battlefield: Gisela, the Broken Blade was put into Graveyard from Battlefield.
- US triggered Marionette Apprentice
- P2 triggered Evendo Brushrazer

## Turn 21 (P1, round 6) | life: P1 36, P2 36, P3 42, US 29
- P1 triggered The Gitrog Monster
- left battlefield: Forest was put into Graveyard from Battlefield.
- P1 triggered The Gitrog Monster
- attack: P1 assigned The Gitrog Monster to attack US.
- P1 cast Kheru Goldkeeper
- P1 cast Stitcher's Supplier
- P1 triggered Stitcher's Supplier
Damage to US this turn: The Gitrog Monster (combat) 6

## Turn 22 (P2, round 6) | life: P1 36, P2 34, P3 42, US 29
- P2 cast Infernal Grasp targeting [The Gitrog Monster]
- left battlefield: The Gitrog Monster was put into Graveyard from Battlefield.

## Turn 23 (P3, round 6) | life: P1 36, P2 34, P3 43, US 29
- P3 cast Valkyrie Harbinger
- P3 triggered Seraph Sanctuary

## Turn 24 (OUR TURN, round 6) | life: P1 36, P2 31, P3 43, US 29
Our hand: Twisted Embrace, Boseiju, Who Endures, Forest, Waterlogged Grove
Our graveyard (5): Misty Rainforest, Baleful Strix, Swamp, Sinister Concoction, Heroic Intervention
Board P1: 4 lands; Arcane Signet (tapped 1), Kheru Goldkeeper 3/3, Stitcher's Supplier 1/1
Board P2: 5 lands; Baloth Prime 10/10 {[STUN x 5]} (tapped 1)
Board P3: 5 lands; Arcane Signet (tapped 1), Valkyrie Harbinger 4/5
Board US: 5 lands; Cryogen Relic, Marionette Apprentice 1/2, Plaguecrafter 3/2
MEMO (start of our turn):
THIS TURN: P1 and P3 are tapped out. P2 has 3 open (B/R, B/R, G), so Beast Within or Putrefy on Muldrotha is possible; accept that risk.
1. Play Forest (not Boseiju or Grove).
2. Cast Muldrotha with all 6 lands (Forest for G, Triome for B, Catacomb for U).
3. Attack P2 with Plaguecrafter only. P2's only creature, Baloth, is tapped, so this is 3 free damage. Apprentice and Muldrotha stay home.
4. Nothing is open on opponents' turns.

TARGET: Next turn:
- Play Misty Rainforest from the graveyard and fetch a dual land, for 7 mana.
- Cast Sinister Concoction from the graveyard (B) and activate it (B): kill Valkyrie Harbinger or any Angel token.
- Cast Twisted Embrace (2BB) on Relic: kill Kheru Goldkeeper, or Harbinger if Concoction was used elsewhere.
- Use the last mana on Strix only if the kills are done.
Tutor or draw targets: Claws of Gix, Executioner's Capsule, Gray Merchant, Syr Konrad, Sol Ring.

WIN PATH: Muldrotha loops removal. Every artifact or creature we lose drains 1 through Apprentice. Gray Merchant or Syr Konrad closes. The table is at 36/31/43, so there is no lethal either way. P2 is the fastest.

THREATS & ANSWERS:
1. Harbinger (P3): each lifelink swing makes a 4/4 Angel. Concoction next turn.
2. Goldkeeper (P1): Twisted Embrace.
3. Baloth Prime (P2): each land sacrifice, fetches included, untaps it and makes a 4/4. Kill it with an edict or Concoction once it untaps.
4. Hearthhull or Zuran Orb: Boseiju channel for {G} while Muldrotha lives.
Give P3 no life.

HOLD:
- Boseiju in hand for its channel.
- Twisted Embrace for next turn.
- Waterlogged Grove as a spare land.
- Relic: sacrifice it in response to a wipe once mana is up.

REPLAN IF:
- Muldrotha is removed. Recast only when P2 is tapped out.
- Hearthhull, Zuran Orb, Giada, a wipe, or Bojuka Bog appears.
- Teval is recast.
PILOT OVERRULED FORGE (action, MAIN1): chose [play land Forest (from Hand): Play land] instead of Forge's [play land Boseiju, Who Endures (from Hand): Play land]
PILOT OVERRULED FORGE (attack, COMBAT_DECLARE_ATTACKERS): chose [attack P2 (34 life)] instead of Forge's [don't attack with it]
- attack: US assigned Plaguecrafter to attack P2.
- US cast Muldrotha, the Gravetide

## Turn 25 (P1, round 7) | life: P1 36, P2 31, P3 43, US 25
- attack: P1 assigned Kheru Goldkeeper and Stitcher's Supplier to attack US.
- P1 cast Sidisi, Brood Tyrant
- P1 triggered Sidisi, Brood Tyrant
Damage to US this turn: Kheru Goldkeeper (combat) 3, Stitcher's Supplier (combat) 1

## Turn 26 (P2, round 7) | life: P1 36, P2 30, P3 43, US 25
- left battlefield: Wooded Foothills was put into Graveyard from Battlefield.
- P2 activated Wooded Foothills
- P2 triggered Baloth Prime
- P2 cast The Gitrog Monster

## Turn 27 (P3, round 7) | life: P1 36, P2 26, P3 49, US 25
- attack: P3 assigned Valkyrie Harbinger to attack P2.
- P3 cast Serra Paragon
- P3 triggered Seraph Sanctuary
- P3 triggered Valkyrie Harbinger
- P3 triggered Seraph Sanctuary

## Turn 28 (OUR TURN, round 7) | life: P1 35, P2 25, P3 48, US 23
Our hand: Twisted Embrace, Boseiju, Who Endures, Waterlogged Grove, Glen Elendra Archmage
Our graveyard (5): Misty Rainforest, Baleful Strix, Swamp, Sinister Concoction, Heroic Intervention
Board P1: 4 lands; Arcane Signet (tapped 1), Kheru Goldkeeper 3/3 (tapped 1), Stitcher's Supplier 1/1 (tapped 1), Sidisi, Brood Tyrant 3/3
Board P2: 6 lands; Baloth Prime 10/10 {[STUN x 3]} (tapped 1), Beast Token 4/4 [token] (tapped 1), The Gitrog Monster 6/6
Board P3: 5 lands; Arcane Signet (tapped 1), Valkyrie Harbinger 4/5 (tapped 1), Serra Paragon 3/4, Angel Token 4/4 [token]
Board US: 6 lands; Cryogen Relic, Marionette Apprentice 1/2, Plaguecrafter 3/2, Muldrotha, the Gravetide 6/6
MEMO (start of our turn):
THIS TURN (7 mana after the land):
1. Play Misty Rainforest from the graveyard and fetch Underground Sea, untapped.
2. Cast Sinister Concoction from the graveyard (B), then activate it (B, 1 life, mill 1, discard Waterlogged Grove). Kill Valkyrie Harbinger.
3. Cast Twisted Embrace (2BB) on Cryogen Relic and kill Baloth Prime, P2's 4/4 factory. Embrace on Relic returns to the graveyard when Relic is sacrificed.
4. Pay with lands other than Forest, and keep Forest open for Boseiju's channel ({G}).
5. No attacks. Every opponent has untapped blockers, and Muldrotha must block Gitrog's team.

TARGET: Loop Concoction and the Relic sac-and-recast (draw twice, drain 3) each turn. Add Glen Elendra next turn to protect Muldrotha. Missing pieces: Claws of Gix, Executioner's Capsule, Gray Merchant, Syr Konrad, Massacre Wurm.

WIN PATH: Kill one threat per turn, and let each artifact or creature we lose drain 1 per opponent through Apprentice. Close with Gray Merchant or Syr Konrad around turns 32-34. P2 at 26 is closest to dying; P2 and P3 are the fastest clocks.

THREATS & ANSWERS:
1. The Gitrog Monster (P2): Concoction next turn.
2. P3's Angel token and Serra Paragon (11 flying power without Harbinger): Concoction or Embrace recast, and Baleful Strix as a blocker.
3. Kheru Goldkeeper (P1): after the above.
4. Hearthhull or Zuran Orb: Boseiju channel.
5. Teval if recast: kill it at once.
Give P3 no life.

HOLD:
- Boseiju plus Forest, for the channel at instant speed.
- Glen Elendra: cast it next turn, before we go all-in.
- Relic: sacrifice it only in response to a wipe or removal on it.

REPLAN IF: Muldrotha dies. Hearthhull, Orb or Teval lands. A wipe resolves. Bojuka Bog hits our graveyard.
PILOT OVERRULED FORGE (action, MAIN1): chose [play land Misty Rainforest (from Graveyard): Play land by Muldrotha, the Gravetide (403) (] instead of Forge's [play land Boseiju, Who Endures (from Hand): Play land]
PILOT OVERRULED FORGE (attack, COMBAT_DECLARE_ATTACKERS): chose [don't attack with it] instead of Forge's [attack P3 (49 life)]
PILOT OVERRULED FORGE (action, MAIN2): chose [cast Sinister Concoction (from Graveyard): Sinister Concoction by Muldrotha, the Gravetide] instead of Forge's [cast Baleful Strix (from Graveyard): Baleful Strix - Creature 1 / 1 by Muldrotha, the Grav]
PILOT OVERRULED FORGE (action, MAIN2): chose [activate Sinister Concoction (from Battlefield): {B}, Pay 1 life, Discard a card, Sacrific] instead of Forge's [cast Baleful Strix (from Graveyard): Baleful Strix - Creature 1 / 1 by Muldrotha, the Grav]
PILOT OVERRULED FORGE (action, MAIN2): chose [cast Baleful Strix (from Graveyard): Baleful Strix - Creature 1 / 1 by Muldrotha, the Grav] instead of Forge's [cast Baleful Strix (from Graveyard): Baleful Strix - Creature 1 / 1 by Muldrotha, the Grav]
PILOT OVERRULED FORGE (action, MAIN2): chose [activate Cryogen Relic (from Battlefield): {1}{U}, Sacrifice this artifact: Put a stun cou] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
- left battlefield: Misty Rainforest was put into Graveyard from Battlefield.
- US activated Misty Rainforest
- US cast Sinister Concoction
- left battlefield: Sinister Concoction was put into Graveyard from Battlefield.
- US activated Sinister Concoction targeting [Valkyrie Harbinger]
- left battlefield: Valkyrie Harbinger was put into Graveyard from Battlefield.
- US cast Baleful Strix
- US triggered Baleful Strix
- left battlefield: Cryogen Relic was put into Graveyard from Battlefield.
- US activated Cryogen Relic targeting []
- US triggered Marionette Apprentice
- US triggered Cryogen Relic

## Turn 29 (P1, round 8)
- P1 cast Teval, the Balanced Scale

## Turn 30 (P2, round 8) | life: P1 29, P2 24, P3 48, US 23
- P2 triggered The Gitrog Monster
- left battlefield: Forest was put into Graveyard from Battlefield.
- P2 triggered The Gitrog Monster
- P2 triggered Baloth Prime
- attack: P2 assigned The Gitrog Monster to attack P1.
- P2 cast Ramunap Excavator
- left battlefield: Bloodstained Mire was put into Graveyard from Battlefield.
- P2 activated Bloodstained Mire
- P2 triggered The Gitrog Monster
- P2 triggered Baloth Prime
- P2 cast Exploration Broodship
- P2 activated Exploration Broodship
- P2 activated Exploration Broodship

## Turn 31 (P3, round 8) | life: P1 29, P2 17, P3 49, US 23
- attack: P3 assigned Serra Paragon and Angel Token to attack P2.
- P3 cast Herald's Horn
- P3 cast Urza's Incubator
- P3 cast Giada, Font of Hope
- P3 triggered Seraph Sanctuary

## Turn 32 (OUR TURN, round 8) | life: P1 24, P2 12, P3 44, US 21
Our hand: Twisted Embrace, Waterlogged Grove, Glen Elendra Archmage, Mishra's Bauble, Professor Dellian Fel, Vrock
Our graveyard (7): Swamp, Heroic Intervention, Misty Rainforest, Boseiju, Who Endures, Sinister Concoction, Forest, Cryogen Relic
Board P1: 5 lands; Arcane Signet (tapped 1), Kheru Goldkeeper 3/3, Stitcher's Supplier 1/1, Sidisi, Brood Tyrant 3/3, Teval, the Balanced Scale 4/4
Board P2: 8 lands; Baloth Prime 10/10 (tapped 1), Beast Token 4/4 [token] x3 (tapped 3), The Gitrog Monster 6/6 (tapped 1), Ramunap Excavator 2/3 (tapped 1), Exploration Broodship {[CHARGE x 6]}
Board P3: 6 lands; Arcane Signet (tapped 1), Serra Paragon 3/4 (tapped 1), Angel Token 4/4 [token], Herald's Horn, Urza's Incubator, Giada, Font of Hope 2/2
Board US: 7 lands; Marionette Apprentice 1/2, Plaguecrafter 3/2, Muldrotha, the Gravetide 6/6, Baleful Strix 1/1
MEMO (start of our turn):
THIS TURN (8 mana after the land drop):
1. Play Misty Rainforest from the graveyard. Fetch Tropical Island untapped.
2. Cast Mishra's Bauble from hand (0).
3. Cast Twisted Embrace (Watery Grave, Drowned Catacomb, Forest, Command Tower) on Bauble. Kill Baloth Prime.
4. Sacrifice Bauble (Marionette drains 1 each). Embrace goes to the graveyard for recasting later.
5. Cast Sinister Concoction from the graveyard (Underground Sea). Activate it (Darkslick Shores, 1 life, discard Waterlogged Grove) to kill The Gitrog Monster.
6. Cast Cryogen Relic from the graveyard (Zagoth Triome and Tropical Island) and draw.
7. No attacks. Keep every blocker home. We are tapped out.

TARGET: Next turn: Bauble (0) and Embrace (4) from the graveyard for a kill, plus Vrock (5). Missing: Massacre Wurm, Gray Merchant, Claws of Gix, Demonic Tutor.

WIN PATH: Drain with Vrock (3), Bauble (1) and Relic sacrifices. P2 at 17 dies in about 3 turns; finish with Gray Merchant or Massacre Wurm. P2 is the fastest clock.

THREATS & ANSWERS:
1. Baloth Prime and Gitrog: answered this turn.
2. Hearthhull: once stationed to 8 it is a creature, so kill it with Embrace or Concoction. Boseiju sits in the graveyard and cannot be channelled.
3. Giada and angels: next Embrace. Strix blocks fliers.
4. Teval and Kheru: kill them later; no one-at-a-time graveyard exile.
Give P3 no life.

HOLD:
- No mana this round.
- Keep Relic on the battlefield. Sacrifice it next turn to draw and to turn on Vrock, or in response to removal.
- Blocks: Strix on the biggest attacker, Muldrotha on a 4/4. Chump with Apprentice only to survive.

REPLAN IF:
- Muldrotha dies (tax +4).
- A wipe resolves.
- Bojuka Bog or Farewell hits our graveyard.
- Hearthhull lands.
- P1 casts Living Death.
PILOT OVERRULED FORGE (action, MAIN1): chose [play land Misty Rainforest (from Graveyard): Play land by Muldrotha, the Gravetide (403) (] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (search, MAIN1): chose [Tropical Island — Land - Forest Island — ({T}: Add {G} or {U}.)] instead of Forge's [Overgrown Tomb — Land - Swamp Forest — ({T}: Add {B} or {G}.) As Overgrown Tomb enters, yo]
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Mishra's Bauble (from Hand): Mishra's Bauble] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN1): chose [activate Mishra's Bauble (from Battlefield): {T}, Sacrifice Mishra's Bauble: Look at the t] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Mishra's Bauble (from Graveyard): Mishra's Bauble by Muldrotha, the Gravetide (403) (] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN1): chose [activate Mishra's Bauble (from Battlefield): {T}, Sacrifice Mishra's Bauble: Look at the t] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (attack, COMBAT_DECLARE_ATTACKERS): chose [don't attack with it] instead of Forge's [attack P2 (15 life)]
PILOT OVERRULED FORGE (attack, COMBAT_DECLARE_ATTACKERS): chose [don't attack with it] instead of Forge's [attack P2 (15 life)]
PILOT OVERRULED FORGE (attack, COMBAT_DECLARE_ATTACKERS): chose [don't attack with it] instead of Forge's [attack P2 (15 life)]
PILOT OVERRULED FORGE (action, MAIN2): chose [cast Sinister Concoction (from Graveyard): Sinister Concoction by Muldrotha, the Gravetide] instead of Forge's [cast Sinister Concoction (from Graveyard): Sinister Concoction by Muldrotha, the Gravetide]
- left battlefield: Misty Rainforest was put into Graveyard from Battlefield.
- US activated Misty Rainforest
- US cast Mishra's Bauble
- left battlefield: Mishra's Bauble was put into Graveyard from Battlefield.
- US activated Mishra's Bauble targeting [P2]
- US triggered Marionette Apprentice
- US cast Mishra's Bauble
- left battlefield: Mishra's Bauble was put into Graveyard from Battlefield.
- US activated Mishra's Bauble targeting [P2]
- US triggered Marionette Apprentice
- US cast Sinister Concoction
- US cast Vrock
- left battlefield: Sinister Concoction was put into Graveyard from Battlefield.
- US activated Sinister Concoction targeting [Baloth Prime]
- left battlefield: Baloth Prime was put into Graveyard from Battlefield.
- US triggered Vrock

## Turn 33 (P1, round 9) | life: P1 24, P2 1, P3 44, US 21
- US triggered Mishra's Bauble
- US triggered Mishra's Bauble
- attack: P1 assigned Teval, the Balanced Scale, Sidisi, Brood Tyrant, Kheru Goldkeeper and Stitcher's Supplier to attack P2.
- P1 triggered Teval, the Balanced Scale
- P1 triggered Sidisi, Brood Tyrant
- P1 triggered Sidisi, Brood Tyrant
- P1 triggered Kheru Goldkeeper
- P1 triggered Teval, the Balanced Scale
- P1 cast Ripples of Undeath
- P1 cast Insidious Roots

## Turn 34 (P2, round 9)
- P2 triggered The Gitrog Monster
- left battlefield: Swamp was put into Graveyard from Battlefield.
- P2 triggered The Gitrog Monster
- P2 activated Exploration Broodship
- left battlefield: Forest was put into Graveyard from Battlefield.
- P2 cast Baloth Prime
- P2 triggered The Gitrog Monster
- P2 cast Springbloom Druid
- P2 triggered Springbloom Druid
- left battlefield: Swamp was put into Graveyard from Battlefield.
- P2 triggered The Gitrog Monster
- P2 triggered Baloth Prime

## Turn 35 (P3, round 9) | life: P1 22, P2 -4, P3 42, US 21
- P3 triggered Herald's Horn
- attack: P3 assigned Angel Token, Serra Paragon and Giada, Font of Hope to attack P2.
- attack: P2 assigned Exploration Broodship to block Angel Token.
- P3 cast Austere Command
- left battlefield: Giada, Font of Hope was put into Graveyard from Battlefield.
- left battlefield: Marionette Apprentice was put into Graveyard from Battlefield.
- left battlefield: Plaguecrafter was put into Graveyard from Battlefield.
- left battlefield: Baleful Strix was put into Graveyard from Battlefield.
- left battlefield: Stitcher's Supplier was put into Graveyard from Battlefield.
- left battlefield: Serra Paragon was put into Graveyard from Battlefield.
- left battlefield: Muldrotha, the Gravetide was put into Graveyard from Battlefield.
- left battlefield: Vrock was put into Graveyard from Battlefield.
- left battlefield: Kheru Goldkeeper was put into Graveyard from Battlefield.
- left battlefield: Sidisi, Brood Tyrant was put into Graveyard from Battlefield.
- left battlefield: Teval, the Balanced Scale was put into Graveyard from Battlefield.
- US triggered Marionette Apprentice
- US triggered Marionette Apprentice
- P1 triggered Stitcher's Supplier
- P1 triggered Insidious Roots

## Turn 36 (OUR TURN, round 9)
Our hand: Twisted Embrace, Glen Elendra Archmage, Professor Dellian Fel, Sakura-Tribe Elder, Shriekmaw, The Coming of Galactus
Our graveyard (14): Swamp, Heroic Intervention, Boseiju, Who Endures, Forest, Cryogen Relic, Misty Rainforest, Mishra's Bauble, Waterlogged Grove, Sinister Concoction, Swamp, Marionette Apprentice, Plaguecrafter, Baleful Strix, Vrock
Board P1: 7 lands; Arcane Signet, Treasure Token [token], Ripples of Undeath, Insidious Roots, Plant Token 1/2 [token] {[P1P1]}
Board P3: 7 lands; Arcane Signet (tapped 1), Herald's Horn, Urza's Incubator
Board US: 8 lands; no nonland permanents
MEMO (start of our turn):
THIS TURN (8 mana, no land drop yet):
1. Cast Muldrotha from the command zone using all 8 lands (tax included).
2. Play Swamp from the graveyard (land lane).
3. Cast Mishra's Bauble from the graveyard (0). Sacrifice it targeting P1 to scout for Living Death or removal. We draw next upkeep.
4. Tap Swamp to cast Sinister Concoction from the graveyard (1). Leave it on the battlefield.
5. No attacks. Opponents have no creatures, and Muldrotha stays home.

TARGET: Next turn we have 9 lands plus a graveyard land (about 10 mana).
- Recast Bauble.
- Cast The Coming of Galactus (5) on the best threat.
- Cast Vrock from the graveyard (5).
- Sacrifice Bauble or Concoction so Vrock drains at end step.
Missing pieces: Claws of Gix, Gray Merchant and Massacre Wurm. Demonic Tutor can find any of them.

WIN PATH: P1 is at 22.
- Galactus chapters II and III drain 2 each.
- Vrock drains 3 per turn.
- Marionette drains on artifact sacrifices.
- The 16/16 flier lands in about 3 turns.
- When Galactus dies after chapter IV, recast it from the graveyard.
P1's clock is Teval recast plus zombies, about 3+ turns.

THREATS & ANSWERS:
1. Teval (black): Concoction, Embrace or Dellian −3. Shriekmaw cannot hit it.
2. P3 angels: Shriekmaw evoke {1}{B}. Use Plaguecrafter for Avacyn.
3. Insidious Roots and Urza's Incubator: Galactus chapter I.
Give P3 no life.

HOLD:
- Hand: Galactus, Embrace, Shriekmaw, Glen Elendra, Dellian and Sakura-Tribe Elder. Keep them all as reload after Austere Command.
- Don't dump creatures into P3's wipes (about 1.8 in a typical list).

REPLAN IF:
- Muldrotha is countered or killed (tax becomes +4).
- P1 casts Living Death or Bojuka Bog.
- P3 casts Farewell.
- Teval or an Angel lands.
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Muldrotha, the Gravetide (from Command): Muldrotha, the Gravetide - Creature 6 / 6 [F] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN1): chose [play land Swamp (from Graveyard): Play land by Muldrotha, the Gravetide (403) (Land)] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Mishra's Bauble (from Graveyard): Mishra's Bauble by Muldrotha, the Gravetide (403) (] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN1): chose [activate Mishra's Bauble (from Battlefield): {T}, Sacrifice Mishra's Bauble: Look at the t] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN2): chose [cast Sinister Concoction (from Graveyard): Sinister Concoction by Muldrotha, the Gravetide] instead of Forge's [cast Sinister Concoction (from Graveyard): Sinister Concoction by Muldrotha, the Gravetide]
- US cast Muldrotha, the Gravetide
- US cast Mishra's Bauble
- left battlefield: Mishra's Bauble was put into Graveyard from Battlefield.
- US activated Mishra's Bauble targeting [P1]
- US cast Sinister Concoction

## Turn 37 (P1, round 10) | life: P1 21, P2 -4, P3 42, US 20
- US triggered Mishra's Bauble
- left battlefield: Misty Rainforest was put into Graveyard from Battlefield.
- P1 activated Misty Rainforest
- P1 triggered Underground Mortuary
- P1 triggered Ripples of Undeath
- attack: P1 assigned Plant Token to attack US.
- P1 cast Teval, the Balanced Scale
Damage to US this turn: Plant Token (combat) 1

## Turn 38 (P3, round 10) | life: P1 21, P2 -4, P3 44, US 20
- P3 triggered Herald's Horn
- P3 cast Giada, Font of Hope
- P3 triggered Seraph Sanctuary
- P3 cast Exemplar of Light
- P3 triggered Seraph Sanctuary
- P3 triggered Exemplar of Light
- P3 triggered Exemplar of Light
- P3 cast Lightning Greaves
- P3 activated Lightning Greaves targeting [Exemplar of Light]

## Turn 39 (OUR TURN, round 10) | life: P1 12, P2 -4, P3 41, US 19
Our hand: Twisted Embrace, Glen Elendra Archmage, Professor Dellian Fel, Sakura-Tribe Elder, Shriekmaw, The Coming of Galactus, Cabal Pit
Our graveyard (12): Heroic Intervention, Boseiju, Who Endures, Forest, Cryogen Relic, Misty Rainforest, Waterlogged Grove, Swamp, Marionette Apprentice, Plaguecrafter, Baleful Strix, Vrock, Mishra's Bauble
Board P1: 7 lands; Arcane Signet (tapped 1), Ripples of Undeath, Insidious Roots, Plant Token 1/2 [token] {[P1P1]} (tapped 1), Teval, the Balanced Scale 4/4
Board P3: 8 lands; Arcane Signet (tapped 1), Herald's Horn, Urza's Incubator, Giada, Font of Hope 2/2, Exemplar of Light 5/5 {[P1P1 x 2]}, Lightning Greaves
Board US: 9 lands; Muldrotha, the Gravetide 6/6, Sinister Concoction
MEMO (start of our turn):
THIS TURN (9 lands + Cabal Pit): 1) Cast Glen Elendra from hand (4). 2) Play Cabal Pit (land drop). Pay B from a land, tap and sac Pit: Giada gets -2/-2 (threshold on; Maneuver can't save her). 3) Cast Plaguecrafter from graveyard (3). P3 must sac Exemplar (shroud dodged); we sac Plaguecrafter. 4) Cast Mishra's Bauble from graveyard (0) and sac it to scout P1. 5) Attack P1 with Muldrotha; if Teval blocks, it dies. 6) Keep Watery Grave or Underground Sea untapped: U for Glen's counter through P1's and P3's turns. Use B on Concoction only if Giada comes back.

TARGET: Next turn replay Cabal Pit, cast The Coming of Galactus (5) killing Lightning Greaves or Insidious Roots, cast Vrock from graveyard (5), and use Concoction on Teval. Missing: Gray Merchant, Massacre Wurm, Claws of Gix.

WIN PATH: Vrock 3/turn to each + Galactus II/III 2+2 + Marionette + Muldrotha beats. P1 in ~3-4 turns, then P3 via the 16/16. P3's angel rebuild is the fastest opposing clock.

THREATS & ANSWERS: 1) P1 Living Death (5 mana next turn): Glen counter. 2) Wipes or Swords/Path/Trophy on Muldrotha: Glen. 3) Giada recast with Greaves haste: Concoction, Shriekmaw evoke. 4) Teval: Concoction, Embrace, Dellian -3 (not Shriekmaw). 5) Greaves, Roots, Incubator: Galactus I. Give P3 no life.

HOLD: Embrace, Dellian, Shriekmaw, Galactus, STE as wipe reload. Keep the U/B land open.

REPLAN IF: Glen dies; Living Death resolves; Farewell or Bojuka Bog hits our yard; Muldrotha leaves (tax +6).
PILOT OVERRULED FORGE (action, MAIN1): chose [play land Cabal Pit (from Graveyard): Play land by Muldrotha, the Gravetide (403) (Land)] instead of Forge's [play land Boseiju, Who Endures (from Graveyard): Play land by Muldrotha, the Gravetide (40]
PILOT OVERRULED FORGE (attack, COMBAT_DECLARE_ATTACKERS): chose [attack P1 (21 life)] instead of Forge's [attack P3 (44 life)]
PILOT OVERRULED FORGE (action, MAIN2): chose [cast Shriekmaw (from Hand): Evoke {1}{B} (You may cast this spell for its evoke cost. If y] instead of Forge's [cast Baleful Strix (from Graveyard): Baleful Strix - Creature 1 / 1 by Muldrotha, the Grav]
PILOT OVERRULED FORGE (action, MAIN2): chose [cast Mishra's Bauble (from Graveyard): Mishra's Bauble by Muldrotha, the Gravetide (403) (] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN2): chose [activate Mishra's Bauble (from Battlefield): {T}, Sacrifice Mishra's Bauble: Look at the t] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN2): chose [P1 (15 life)] instead of Forge's [P3 (44 life)]
- left battlefield: Sinister Concoction was put into Graveyard from Battlefield.
- US activated Sinister Concoction targeting [Teval, the Balanced Scale]
- left battlefield: Teval, the Balanced Scale was put into Graveyard from Battlefield.
- P1 triggered Insidious Roots
- left battlefield: Cabal Pit was put into Graveyard from Battlefield.
- US activated Cabal Pit targeting [Giada, Font of Hope]
- left battlefield: Giada, Font of Hope was put into Graveyard from Battlefield.
- attack: US assigned Muldrotha, the Gravetide to attack P1.
- US cast Vrock
- US cast Shriekmaw
- US triggered Shriekmaw targeting [Plant Token]
- US triggered Shriekmaw
- left battlefield: Shriekmaw was put into Graveyard from Battlefield.
- US cast Mishra's Bauble
- left battlefield: Mishra's Bauble was put into Graveyard from Battlefield.
- US activated Mishra's Bauble targeting [P1]
- US triggered Vrock

## Turn 40 (P1, round 10)
- US triggered Mishra's Bauble
- P1 triggered Ripples of Undeath
- P1 triggered Golgari Rot Farm
- P1 cast Teval's Judgment
- P1 cast Gravecrawler
- P1 cast Victimize
- left battlefield: Gravecrawler was put into Graveyard from Battlefield.
- P1 triggered Teval's Judgment
- P1 triggered Avenger of Zendikar
- P1 triggered Insidious Roots

## Turn 41 (P3, round 11) | life: P1 7, P2 -4, P3 44, US 19
- P3 triggered Herald's Horn
- attack: P3 assigned Exemplar of Light to attack P1.
- P3 cast Giada, Font of Hope
- P3 triggered Seraph Sanctuary
- P3 triggered Exemplar of Light
- P3 triggered Exemplar of Light
- P3 cast Metropolis Reformer
- P3 triggered Seraph Sanctuary
- P3 triggered Exemplar of Light
- P3 cast Segovian Angel
- P3 triggered Seraph Sanctuary
- P3 triggered Exemplar of Light

## Turn 42 (OUR TURN, round 11) | life: P1 2, P2 -4, P3 39, US 27
Our hand: Twisted Embrace, Glen Elendra Archmage, Professor Dellian Fel, Sakura-Tribe Elder, The Coming of Galactus, Verdant Catacombs, Gray Merchant of Asphodel, Assassin's Trophy
Our graveyard (15): Heroic Intervention, Boseiju, Who Endures, Forest, Cryogen Relic, Misty Rainforest, Waterlogged Grove, Swamp, Marionette Apprentice, Plaguecrafter, Baleful Strix, Sinister Concoction, Doc Aurlock, Grizzled Genius, Cabal Pit, Shriekmaw, Mishra's Bauble
Board P1: 7 lands; Arcane Signet (tapped 1), Ripples of Undeath, Insidious Roots, Plant Token 2/3 [token] {[P1P1 x 2]}, Teval's Judgment, Avenger of Zendikar 5/5 (tapped 1), Ob Nixilis, the Fallen 3/3 (tapped 1), Plant Token 1/2 [token] {[P1P1]}, Plant Token 0/1 [token] x7
Board P3: 9 lands; Arcane Signet (tapped 1), Herald's Horn, Urza's Incubator, Exemplar of Light 8/8 {[P1P1 x 5]} (tapped 1), Lightning Greaves, Giada, Font of Hope 2/2, Metropolis Reformer 4/5 {[P1P1 x 2]}, Segovian Angel 4/4 {[P1P1 x 3]}
Board US: 9 lands; Muldrotha, the Gravetide 6/6, Vrock 3/3
MEMO (start of our turn):
THIS TURN (10 mana): 1) Play Verdant Catacombs and crack it for Bayou, untapped. This turns on Vrock. 2) Cast Marionette Apprentice from the graveyard (2) and make a Servo. 3) Cast Mishra's Bauble from the graveyard (0) and sacrifice it: P1 goes to 6. 4) Cast Gray Merchant from hand (5). Devotion 6 puts P1 to 0, so P1 is dead. P3 drops to 37 and we go to about 30. 5) Cast Sinister Concoction from the graveyard (B). 6) Don't attack; keep Vrock home to block fliers. 7) On P3's turn, with 2 open: Concoction (B, discard Sakura-Tribe Elder) on Exemplar when it attacks, or on any new Thune or Avacyn. Use Assassin's Trophy (BG) on Smothering Tithe or a second threat.

TARGET: Next turn, P3 alone. Cast The Coming of Galactus on Lightning Greaves or Giada. Use Dellian -3 or Twisted Embrace on the biggest Angel. Cast Glen Elendra to guard against a wipe. Missing: Toxic Deluge, Claws of Gix, Demonic Tutor.

WIN PATH: Vrock drains 3 a turn, Galactus 2+2 then the 16/16, and Gray recurs through Plaguecrafter. That kills P3 in about 4-5 turns. P3's clock is flying combat, 18 power now.

THREATS & ANSWERS: 1) P3's fliers: Concoction, Embrace, Dellian. 2) Farewell or Austere Command: Glen next turn. 3) Greaves and Incubator: Galactus I. Give P3 no life (Reformer, Exemplar).

HOLD: B plus BG open on P3's turn. Glen, Dellian, Embrace and Galactus stay in hand as the reload.

REPLAN IF: Gray is countered or devotion drops (then Vrock's end-step 3 still finishes P1 if P1 is at 3 or less), P1 survives, or P3 wipes.
MEMO (executor escalation: us: life 19→28 (+9)):
THIS TURN (3 mana): 1) Cast Sinister Concoction from the graveyard (B, from Underground Sea). This uses the enchantment lane. 2) Activate it right away (B from Zagoth Triome, 1 life, mill 1, discard Sakura-Tribe Elder) to destroy Exemplar of Light. This cuts P3's flying power from 18 to 10, so Akroma's Will (double strike) can't kill us at 28. 3) Don't attack. P1 has 9 chump Plants, and Metropolis Reformer gains P3 life. 4) At our end step, Vrock drains 3 because Bauble and the fetch already left. P1 is at 2 and dies.

TARGET: P3 alone with Giada gone, no Angel bigger than 4, Glen Elendra guarding. Missing: Toxic Deluge and Demonic Tutor.

WIN PATH: Next turn (about 11 mana): The Coming of Galactus (5) chapter I on Giada, Professor Dellian Fel (4) −3 on the biggest Angel, and Concoction again (2). Then Vrock 3 a turn, Galactus 2+2 and the 16/16, and Muldrotha swinging once the air is clear. P3 at 39 dies in about 4-5 turns.

THREATS & ANSWERS: 1) Akroma's Will: kill Exemplar now. 2) Giada: Galactus I. 3) New Angels: Dellian −3, Twisted Embrace. 4) Farewell or Austere Command: Glen Elendra. Give P3 no life and never damage Reformer.

HOLD: Command Tower (nothing to spend it on). Twisted Embrace, Glen, Dellian and Galactus stay in hand for next turn.

REPLAN IF: P1 removes Vrock before our end step. Then P1 lives at 2: next turn cast Marionette Apprentice and let a Servo or creature die, or recast Gray. Also replan if Flawless Maneuver saves Exemplar, or if P3 wipes.
PILOT OVERRULED FORGE (action, DRAW): chose [Lightning Greaves [P3]] instead of Forge's [Avenger of Zendikar [P1, 5/5, tapped]]
PILOT OVERRULED FORGE (action, MAIN1): chose [play land Verdant Catacombs (from Hand): Play land] instead of Forge's [play land Boseiju, Who Endures (from Graveyard): Play land by Muldrotha, the Gravetide (40]
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Mishra's Bauble (from Graveyard): Mishra's Bauble by Muldrotha, the Gravetide (403) (] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN1): chose [activate Mishra's Bauble (from Battlefield): {T}, Sacrifice Mishra's Bauble: Look at the t] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Gray Merchant of Asphodel (from Hand): Gray Merchant of Asphodel - Creature 2 / 4 [Fo] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
ESCALATION (p=0.73): us: life 19→28 (+9)
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Sinister Concoction (from Graveyard): Sinister Concoction by Muldrotha, the Gravetide] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN1): chose [activate Sinister Concoction (from Battlefield): {B}, Pay 1 life, Discard a card, Sacrific] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
- US cast Assassin's Trophy targeting [Lightning Greaves]
- left battlefield: Lightning Greaves was put into Graveyard from Battlefield.
- left battlefield: Verdant Catacombs was put into Graveyard from Battlefield.
- US activated Verdant Catacombs
- US cast Mishra's Bauble
- left battlefield: Mishra's Bauble was put into Graveyard from Battlefield.
- US activated Mishra's Bauble targeting [P1]
- US cast Gray Merchant of Asphodel
- US triggered Gray Merchant of Asphodel
- US cast Sinister Concoction
- left battlefield: Sinister Concoction was put into Graveyard from Battlefield.
- US activated Sinister Concoction targeting [Exemplar of Light]
- left battlefield: Exemplar of Light was put into Graveyard from Battlefield.
- attack: US assigned Muldrotha, the Gravetide and Vrock to attack P1.
- attack: P1 assigned Plant Token to block Muldrotha, the Gravetide.
- left battlefield: Vrock was put into Graveyard from Battlefield.

## Turn 43 (P1, round 11) | life: P1 2, P2 -4, P3 28, US 24
- US triggered Mishra's Bauble
- P1 triggered Ripples of Undeath
- P1 triggered Ob Nixilis, the Fallen targeting [P4]
- P1 triggered Avenger of Zendikar
- attack: P1 assigned Ob Nixilis, the Fallen and Avenger of Zendikar to attack P3.
- P1 cast Teval, the Balanced Scale
- P1 cast Wight of the Reliquary
- P1 cast Gravecrawler
- P1 triggered Teval's Judgment
- P1 triggered Insidious Roots
- P1 triggered Teval, the Balanced Scale
- P1 triggered Teval's Judgment
- P1 triggered Teval, the Balanced Scale
- P1 cast Life from the Loam targeting [Watery Grave, Forest, Misty Rainforest]
- P1 triggered Teval's Judgment
- P1 triggered Teval, the Balanced Scale

## Turn 44 (P3, round 11) | life: P1 2, P2 -4, P3 31, US 24
- P3 triggered Emeria, the Sky Ruin targeting [Valkyrie Harbinger]
- P3 triggered Herald's Horn
- P3 triggered Seraph Sanctuary
- P3 cast Lyra Dawnbringer
- P3 triggered Seraph Sanctuary
- P3 cast Serra the Benevolent
- P3 activated Serra the Benevolent
- P3 triggered Seraph Sanctuary

## Turn 45 (OUR TURN, round 12) | life: P1 2, P2 -4, P3 31, US 23
Our hand: Glen Elendra Archmage, Professor Dellian Fel, Sakura-Tribe Elder, The Coming of Galactus, Breeding Pool, Nature's Lore
Our graveyard (20): Heroic Intervention, Boseiju, Who Endures, Forest, Cryogen Relic, Misty Rainforest, Waterlogged Grove, Swamp, Marionette Apprentice, Plaguecrafter, Baleful Strix, Doc Aurlock, Grizzled Genius, Cabal Pit, Shriekmaw, Assassin's Trophy, Verdant Catacombs, Mishra's Bauble, Twisted Embrace, Sinister Concoction, Swan Song, Vrock
Board P1: 8 lands; Arcane Signet (tapped 1), Ripples of Undeath, Insidious Roots, Teval's Judgment, Avenger of Zendikar 5/5 (tapped 1), Ob Nixilis, the Fallen 6/6 {[P1P1 x 3]} (tapped 1), Plant Token 3/4 [token] {[P1P1 x 3]}, Plant Token 2/3 [token] {[P1P1 x 2]} x6 (tapped 5), Teval, the Balanced Scale 4/4, Wight of the Reliquary 13/13, Zombie Druid Token 2/2 [token] x4, Plant Token 1/2 [token] {[P1P1]}, Treasure Token [token], Gravecrawler 2/1
Board P3: 10 lands; Arcane Signet (tapped 1), Herald's Horn, Urza's Incubator, Giada, Font of Hope 3/3, Metropolis Reformer 5/6 {[P1P1 x 2]}, Segovian Angel 5/5 {[P1P1 x 3]}, Valkyrie Harbinger 8/9 {[P1P1 x 3]}, Lyra Dawnbringer 9/9 {[P1P1 x 4]}, Serra the Benevolent {[LOYALTY]}, Angel Token 10/10 [token] {[P1P1 x 5]}
Board US: 10 lands; Muldrotha, the Gravetide 6/6, Gray Merchant of Asphodel 2/4
MEMO (start of our turn):
THIS TURN (11 mana after the land):
1) Land: play Verdant Catacombs from the graveyard. Crack it (1 life) for a basic Swamp, which enters untapped.
2) Glen Elendra Archmage from hand (4). Keep {U} open to counter Swords, Path or Trophy aimed at Apprentice.
3) Sakura-Tribe Elder from hand (2). Then Mishra's Bauble from the graveyard (0, artifact lane).
4) Marionette Apprentice from the graveyard (2, creature lane). Choose the +1/+1 counter.
5) Holding priority, sacrifice Bauble and STE (fetch an Island). Two drains kill P1. P3 goes to 29.
6) Sinister Concoction from the graveyard (B, enchantment lane). Activate it (B, 1 life, mill 1, discard Breeding Pool) on Lyra. Glen counters Flawless Maneuver.
7) Don't attack. End with 1 blue open.

TARGET: Only P3 left, with no Lyra and no Giada. Missing: Toxic Deluge, then Demonic Tutor.

WIN PATH: Next turn: Galactus I on Giada, or Serra if its loyalty is 6+. Dellian −3 on Harbinger. Evoke Shriekmaw on a nonblack Angel. Recast Vrock with a leaving permanent. Close in about 4 turns with Galactus drains, Vrock, Apprentice drains and the 16/16.

THREATS & ANSWERS:
1) P3's 40 flying power. Killing Lyra leaves about 31 even with Serra +2. Glen chumps the biggest, so about 21 gets through; we're at 22.
2) Akroma's Will: Glen's counter.
3) Serra's emblem: Galactus I or Twisted Embrace.
Never give P3 life.

HOLD: Galactus, Dellian and Nature's Lore for next turn. Keep 1 {U} open for Glen.

REPLAN IF: Apprentice dies before the sacrifices (P1 survives and threatens lethal). Lyra survives. Serra shows 6+ loyalty. P3 gets more flying power.
MEMO (executor escalation: we lost: Gray Merchant of Asphodel, Muldrotha, the Gravetide; our commander left the battlefield):
THIS TURN: Muldrotha is gone (tax +4, so 10 to recast), so no graveyard casts now. We have exactly 5 mana. Cast The Coming of Galactus ({2}{B}{B}{G}, all 5). Chapter I destroys Lyra Dawnbringer, which removes about 14 flying power and the lifelink that would undo our drains. We'll be tapped out, so Glen can't counter this cycle. Glen blocks the biggest flier and persists. Keep Breeding Pool; the land drop is used.

TARGET: Next turn after our draw, Galactus II kills P1 (2 life). Play Breeding Pool paying 2 life (13 mana) and recast Muldrotha (10). Then Doc Aurlock (2) and Mishra's Bauble (0), keeping 1 {U} for Glen. The following turn, use the lanes for Shriekmaw evoke, Twisted Embrace, Concoction and Vrock against P3's Angels.

WIN PATH: Galactus II and III drain 2 each, then a 16/16 flying trampler. Add Vrock (3 per turn), Marionette Apprentice and Gray Merchant. About 4 turns against P3 at 31. P3 can kill us sooner, so remove one flier every turn.

THREATS & ANSWERS: 1) P1's board of 50+ power plus Ob Nixilis landfall drains: no answer, since Galactus II ends it. 2) P3's Angels and Serra: Dellian −3 and Shriekmaw evoke (not on Giada or Segovian, which are fine targets; Shriekmaw cannot hit black creatures, and all Angels are white, so it works). 3) Akroma's Will or a wipe: Glen, once {U} is open. Never give P3 life, so no Dellian +2 while P3 lives.

HOLD: Dellian and Sakura-Tribe Elder until Muldrotha is back; there's no mana this turn anyway.

REPLAN IF: Galactus is removed (Trophy); P1 gains life or dies before our turn; we drop below 10 life; Lyra survives the chapter I trigger.
PILOT OVERRULED FORGE (action, MAIN1): chose [play land Verdant Catacombs (from Graveyard): Play land by Muldrotha, the Gravetide (403) ] instead of Forge's [play land Boseiju, Who Endures (from Graveyard): Play land by Muldrotha, the Gravetide (40]
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Mishra's Bauble (from Graveyard): Mishra's Bauble by Muldrotha, the Gravetide (403) (] instead of Forge's [cast Nature's Lore (from Hand): Search your library for a Forest card, put that card onto ]
PILOT OVERRULED FORGE (action, MAIN1): chose [activate Mishra's Bauble (from Battlefield): {T}, Sacrifice Mishra's Bauble: Look at the t] instead of Forge's [cast Nature's Lore (from Hand): Search your library for a Forest card, put that card onto ]
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Glen Elendra Archmage (from Hand): Glen Elendra Archmage - Creature 2 / 2 [Forge's he] instead of Forge's [cast Nature's Lore (from Hand): Search your library for a Forest card, put that card onto ]
PILOT OVERRULED FORGE (attack, COMBAT_DECLARE_ATTACKERS): chose [attack P1 (2 life)] instead of Forge's [don't attack with it]
PILOT OVERRULED FORGE (attack, COMBAT_DECLARE_ATTACKERS): chose [attack P1 (2 life)] instead of Forge's [don't attack with it]
ESCALATION (p=0.96): we lost: Gray Merchant of Asphodel, Muldrotha, the Gravetide; our commander left the battlefield
- left battlefield: Verdant Catacombs was put into Graveyard from Battlefield.
- US activated Verdant Catacombs
- US cast Mishra's Bauble
- left battlefield: Mishra's Bauble was put into Graveyard from Battlefield.
- US activated Mishra's Bauble targeting [P1]
- US cast Glen Elendra Archmage
- US cast Nature's Lore
- attack: US assigned Muldrotha, the Gravetide and Gray Merchant of Asphodel to attack P1.
- attack: P1 assigned Wight of the Reliquary to block Muldrotha, the Gravetide.
- left battlefield: Muldrotha, the Gravetide was put into Graveyard from Battlefield.
- left battlefield: Gray Merchant of Asphodel was put into Graveyard from Battlefield.
- US cast The Coming of Galactus
- US triggered The Coming of Galactus targeting [Wight of the Reliquary]
- left battlefield: Wight of the Reliquary was put into Graveyard from Battlefield.

## Turn 46 (P1, round 12) | life: P1 2, P2 -4, P3 31, US 20
- US triggered Mishra's Bauble
- P1 triggered Teval's Judgment
- P1 triggered Teval, the Balanced Scale
- P1 triggered Ripples of Undeath
- P1 triggered Ob Nixilis, the Fallen targeting [P4]
- P1 triggered Avenger of Zendikar
- P1 cast Life from the Loam targeting [Overgrown Tomb, Polluted Delta, Field of the Dead]
- P1 triggered Teval's Judgment
- P1 triggered Teval, the Balanced Scale
- P1 triggered Teval's Judgment
- P1 triggered Teval, the Balanced Scale

## Turn 47 (P3, round 12) | life: P1 2, P2 -4, P3 44, US 20
- P3 triggered Emeria, the Sky Ruin targeting [Exemplar of Light]
- P3 triggered Herald's Horn
- P3 triggered Seraph Sanctuary
- P3 triggered Exemplar of Light
- P3 triggered Exemplar of Light
- P3 activated Serra the Benevolent
- attack: P3 assigned Angel Token to attack P1.
- attack: P1 assigned Zombie Druid Token and Ob Nixilis, the Fallen to block Angel Token.
- left battlefield: Ob Nixilis, the Fallen was put into Graveyard from Battlefield.
- P3 triggered Exemplar of Light
- P3 cast Enlightened Tutor
- P3 triggered Valkyrie Harbinger
- P3 triggered Seraph Sanctuary
- P3 triggered Exemplar of Light

## Turn 48 (OUR TURN, round 12) | life: P1 0, P2 -4, P3 42, US 20
Our hand: Professor Dellian Fel, Sakura-Tribe Elder, Breeding Pool, Walking Ballista, Binding the Old Gods
Our graveyard (22): Heroic Intervention, Boseiju, Who Endures, Forest, Cryogen Relic, Misty Rainforest, Waterlogged Grove, Swamp, Marionette Apprentice, Plaguecrafter, Baleful Strix, Doc Aurlock, Grizzled Genius, Cabal Pit, Shriekmaw, Assassin's Trophy, Twisted Embrace, Sinister Concoction, Swan Song, Vrock, Verdant Catacombs, Mishra's Bauble
Board P3: 11 lands; Arcane Signet, Herald's Horn, Urza's Incubator, Giada, Font of Hope 3/3, Metropolis Reformer 5/6 {[P1P1 x 2]}, Segovian Angel 5/5 {[P1P1 x 3]}, Valkyrie Harbinger 8/9 {[P1P1 x 3]}, Lyra Dawnbringer 9/9 {[P1P1 x 4]}, Serra the Benevolent {[LOYALTY x 3]}, Exemplar of Light 13/13 {[P1P1 x 9]}, Angel Token 11/11 [token] {[P1P1 x 6]}
Board US: 12 lands; Glen Elendra Archmage 2/2, The Coming of Galactus {[LORE x 2]}
MEMO (start of our turn):
THIS TURN: P3 has about 54 flying power against our 20 life, so we must survive, not develop. Muldrotha (10) buys only 1 kill; skip her.
1) Play Breeding Pool TAPPED. Do not pay 2 life; every point matters.
2) Dellian (4): −3 on Lyra Dawnbringer. This shrinks every other Angel by 1 and ends shared lifelink.
3) Binding the Old Gods (4): chapter I destroys Exemplar of Light.
4) Walking Ballista X=2 (4): remove both counters and ping Giada, now 2/2, to death.
That is all 12 untapped mana. P3's worst attack is then about 29 (with Serra +2). Glen blocks the Angel token (about 11), so we take about 18 and live on about 2.

TARGET: Next turn, Galactus III drains 2 and Binding II fetches a Forest. We have 14 mana: Pool, 12 lands, plus Waterlogged Grove as the land drop from the graveyard. Cast Muldrotha (10), evoke Shriekmaw (2), then Sinister Concoction (1) and activate it (1). Dellian +2 is our lifegain, which is fine. Then Galactus IV gives a 16/16 flier.

WIN PATH: Galactus 16/16, then Vrock, Gray Merchant and Marionette drains. P3 has hexproof from Metropolis Reformer, so use drains, not Ballista to face. P3 is the faster clock; survive first.

THREATS & ANSWERS: 1) The Angel air force: kill one or two every turn with Shriekmaw, Concoction, Twisted Embrace and Binding. 2) Serra +2 pump: the next Binding or Twisted Embrace. 3) Akroma's Will: Glen needs {U}, which we can't spare this turn; accepted risk. 4) Valkyrie Harbinger makes 4/4s: next Shriekmaw target.

HOLD: Sakura-Tribe Elder; it's a non-flier and useless now.

REPLAN IF: P3 casts a new flier or pump before combat; a kill fizzles; we end below 8 life. If so, next turn spend everything on removal before Muldrotha.
PILOT OVERRULED FORGE (action, MAIN2): chose [cast Professor Dellian Fel (from Hand): Professor Dellian Fel] instead of Forge's [cast Walking Ballista (from Hand): Walking Ballista - Creature 0 / 0 (X=0)]
PILOT OVERRULED FORGE (action, MAIN2): chose [Exemplar of Light [P3, 13/13]] instead of Forge's [Angel Token [P3, 11/11, token]]
PILOT OVERRULED FORGE (action, MAIN2): chose [cast Binding the Old Gods (from Hand): Binding the Old Gods] instead of Forge's [cast Walking Ballista (from Hand): Walking Ballista - Creature 0 / 0 (X=0)]
PILOT OVERRULED FORGE (trigger-target, MAIN2): chose [Lyra Dawnbringer [P3, 9/9]] instead of Forge's [Angel Token [P3, 11/11, token]]
PILOT OVERRULED FORGE (action, MAIN2): chose [Giada, Font of Hope [P3, 2/2, commander]] instead of Forge's [Serra the Benevolent [P3, loyalty 3]]
PILOT OVERRULED FORGE (action, MAIN2): chose [Giada, Font of Hope [P3, 2/2 with 1 damage, commander]] instead of Forge's [Serra the Benevolent [P3, loyalty 3]]
- US triggered The Coming of Galactus
- US cast Professor Dellian Fel
- US activated Professor Dellian Fel targeting [Exemplar of Light]
- left battlefield: Exemplar of Light was put into Graveyard from Battlefield.
- US cast Binding the Old Gods
- US triggered Binding the Old Gods targeting [Lyra Dawnbringer]
- left battlefield: Lyra Dawnbringer was put into Graveyard from Battlefield.
- US cast Walking Ballista
- US activated Walking Ballista targeting [Giada, Font of Hope]
- US activated Walking Ballista targeting [Giada, Font of Hope]
- left battlefield: Walking Ballista was put into Graveyard from Battlefield.
- left battlefield: Giada, Font of Hope was put into Graveyard from Battlefield.

## Turn 49 (P3, round 13) | life: P1 0, P2 -4, P3 75, US 4
- P3 triggered Emeria, the Sky Ruin targeting [Lyra Dawnbringer]
- P3 triggered Herald's Horn
- P3 triggered Seraph Sanctuary
- P3 activated Serra the Benevolent
- left battlefield: Serra the Benevolent was put into Graveyard from Battlefield.
- P3 triggered Seraph Sanctuary
- P3 cast Giada, Font of Hope
- P3 triggered Seraph Sanctuary
- attack: P3 assigned Segovian Angel and Angel Token to attack US.
- left battlefield: Professor Dellian Fel was put into Graveyard from Battlefield.
- P3 cast Vanquisher's Banner
- P3 triggered Valkyrie Harbinger
- P3 triggered Seraph Sanctuary
Damage to US this turn: Segovian Angel (combat) 5, Angel Token (combat) 11

## Turn 50 (OUR TURN, round 13) | life: P1 0, P2 -4, P3 73, US 3
Our hand: Sakura-Tribe Elder, Otawara, Soaring City
Our graveyard (24): Heroic Intervention, Boseiju, Who Endures, Forest, Cryogen Relic, Misty Rainforest, Waterlogged Grove, Swamp, Marionette Apprentice, Plaguecrafter, Baleful Strix, Doc Aurlock, Grizzled Genius, Cabal Pit, Shriekmaw, Assassin's Trophy, Twisted Embrace, Sinister Concoction, Swan Song, Vrock, Verdant Catacombs, Mishra's Bauble
Board P3: 11 lands; Arcane Signet (tapped 1), Herald's Horn, Urza's Incubator, Metropolis Reformer 6/7 {[P1P1 x 2]}, Segovian Angel 6/6 {[P1P1 x 3]}, Valkyrie Harbinger 9/10 {[P1P1 x 3]} (tapped 1), Angel Token 12/12 [token] {[P1P1 x 6]}, Lyra Dawnbringer 6/6, Angel Token 6/6 [token], Giada, Font of Hope 4/4, Vanquisher's Banner, Angel Token 13/13 [token] {[P1P1 x 7]}
Board US: 13 lands; Glen Elendra Archmage 2/2, The Coming of Galactus {[LORE x 3]}, Binding the Old Gods {[LORE x 2]}
MEMO (start of our turn):
THIS TURN: We are at 4 life facing about 62 flying power. No line survives a full attack, so maximise what P3 must get through and hope for a partial swing.
1) Play Otawara as the land drop (untapped {U}; Waterlogged Grove costs life). That gives 14 mana.
2) Cast Muldrotha (10).
3) Cast Baleful Strix from the graveyard (2, creature lane). It draws a card and is a flying deathtouch blocker.
4) Cast Sinister Concoction from the graveyard (1, enchantment lane), then activate it (1). Discard Sakura-Tribe Elder and kill the 13/13 Angel token.
On P3's turn, Strix blocks the 12/12 token and Glen blocks the next-biggest attacker, never Lyra (first strike kills them first).

TARGET: Survive to Galactus IV (16/16), Binding III deathtouch, and Doc Aurlock discounts. Missing: Pernicious Deed or Toxic Deluge.

WIN PATH: Drains only (P3 has hexproof): Vrock, Gray Merchant, Marionette, Galactus. P3 at 73 is far away, and P3's clock is this coming turn.

THREATS & ANSWERS: 1) Angel tokens 13/13 and 12/12: Concoction now, Strix block. 2) Valkyrie Harbinger 9/10 with lifelink: Shriekmaw next turn. 3) Lyra: Dellian −3 next turn.

HOLD: Nothing is worth holding; every mana goes to reducing incoming damage. Do not pay life except Concoction's 1.

REPLAN IF: Strix draws Pernicious Deed. Then skip Concoction; Deed alone can't be afforded this turn, but keep it for next turn if we live. If we survive, next turn: Deed (3) with X=6, or Gray Merchant plus Dellian +2 for life.
PILOT OVERRULED FORGE (action, MAIN1): chose [play land Otawara, Soaring City (from Hand): Play land] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Muldrotha, the Gravetide (from Command): Muldrotha, the Gravetide - Creature 6 / 6 [F] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Baleful Strix (from Graveyard): Baleful Strix - Creature 1 / 1 by Muldrotha, the Grav] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Sinister Concoction (from Graveyard): Sinister Concoction by Muldrotha, the Gravetide] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN1): chose [activate Sinister Concoction (from Battlefield): {B}, Pay 1 life, Discard a card, Sacrific] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
- US triggered The Coming of Galactus
- US triggered Binding the Old Gods
- US cast Muldrotha, the Gravetide
- US cast Baleful Strix
- US triggered Baleful Strix
- US cast Sinister Concoction
- left battlefield: Sinister Concoction was put into Graveyard from Battlefield.
- US activated Sinister Concoction targeting [Angel Token]

## Turn 51 (P3, round 13) | life: P1 0, P2 -4, P3 80, US -3
- P3 triggered Emeria, the Sky Ruin targeting [Exemplar of Light]
- P3 triggered Herald's Horn
- P3 triggered Seraph Sanctuary
- P3 triggered Exemplar of Light
- P3 triggered Exemplar of Light
- attack: P3 assigned Angel Token, Valkyrie Harbinger, Metropolis Reformer, Segovian Angel, Lyra Dawnbringer, Angel Token and Giada, Font of Hope to attack US.
- attack: US assigned Baleful Strix to block Angel Token.
- Game Outcome: P1 has lost because life total reached 0
- Game Outcome: P2 has lost because life total reached 0
- Game Outcome: P3 has won because all opponents have lost
- Game Outcome: US has lost because life total reached 0
Damage to US this turn: Lyra Dawnbringer (combat) 6