# pod05-g4: we are P2; opponents P1 Pantlaza, Sun-Favored, P3 Sauron, the Dark Lord, P4 Teval, the Balanced Scale
Result: Turn 25; P1 has lost because life total reached 0; US has lost because life total reached 0; P3 has won because all opponents have lost; P4 has lost because life total reached 0

## Turn 1 (OUR TURN, round 1)
Our hand: Cryogen Relic, Birds of Paradise, Braids, Arisen Nightmare, Heroic Intervention, Wayfarer's Bauble, Plaguecrafter, The One Ring, Ratchet Bomb
Our graveyard (0): 
Board P1: 0 lands; no nonland permanents
Board US: 0 lands; no nonland permanents
Board P3: 0 lands; no nonland permanents
Board P4: 0 lands; no nonland permanents
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)

## Turn 2 (P3, round 1)

## Turn 3 (P4, round 1)

## Turn 4 (P1, round 1)

## Turn 5 (OUR TURN, round 2)
Our hand: Cryogen Relic, Birds of Paradise, Braids, Arisen Nightmare, Heroic Intervention, Wayfarer's Bauble, Plaguecrafter, Ratchet Bomb, Overgrown Tomb
Our graveyard (1): The One Ring
Board P1: 1 lands; no nonland permanents
Board US: 0 lands; no nonland permanents
Board P3: 1 lands; no nonland permanents
Board P4: 1 lands; no nonland permanents
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)

## Turn 6 (P3, round 2)

## Turn 7 (P4, round 2)
- P4 cast Skull Prophet
- P3 cast Soothing of Sméagol targeting [Skull Prophet]

## Turn 8 (P1, round 2)

## Turn 9 (OUR TURN, round 3)
Our hand: Cryogen Relic, Birds of Paradise, Braids, Arisen Nightmare, Heroic Intervention, Wayfarer's Bauble, Plaguecrafter, Ratchet Bomb, Counterspell
Our graveyard (1): The One Ring
Board P1: 2 lands; no nonland permanents
Board US: 1 lands; no nonland permanents
Board P3: 2 lands; no nonland permanents
Board P4: 2 lands; no nonland permanents
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
- US cast Birds of Paradise

## Turn 10 (P3, round 3)
- P3 cast The Great Goblin
- P1 cast Path to Exile targeting [The Great Goblin]
- left battlefield: The Great Goblin was put into Exile from Battlefield.

## Turn 11 (P4, round 3)
- P4 cast Skull Prophet

## Turn 12 (P1, round 3)

## Turn 13 (OUR TURN, round 4)
Our hand: Cryogen Relic, Braids, Arisen Nightmare, Heroic Intervention, Wayfarer's Bauble, Plaguecrafter, Ratchet Bomb, Counterspell, Island
Our graveyard (1): The One Ring
Board P1: 3 lands; no nonland permanents
Board US: 1 lands; Birds of Paradise 0/1
Board P3: 4 lands; no nonland permanents
Board P4: 3 lands; Skull Prophet 3/1
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
PILOT OVERRULED FORGE (action, MAIN2): chose [cast Cryogen Relic (from Hand): Cryogen Relic] instead of Forge's [cast Braids, Arisen Nightmare (from Hand): Braids, Arisen Nightmare - Creature 3 / 3]
- US cast Cryogen Relic
- US triggered Cryogen Relic
- US cast Wayfarer's Bauble

## Turn 14 (P3, round 4) | life: P3 38
- P3 cast Feed the Swarm targeting [Skull Prophet]
- left battlefield: Skull Prophet was put into Graveyard from Battlefield.

## Turn 15 (P4, round 4)
- P4 cast Aftermath Analyst
- P4 triggered Aftermath Analyst

## Turn 16 (P1, round 4)
- P1 cast Monster Manual

## Turn 17 (OUR TURN, round 5)
Our hand: Braids, Arisen Nightmare, Heroic Intervention, Plaguecrafter, Ratchet Bomb, Counterspell, Command Tower
Our graveyard (1): The One Ring
Board P1: 4 lands; Monster Manual
Board US: 2 lands; Birds of Paradise 0/1, Cryogen Relic, Wayfarer's Bauble
Board P3: 5 lands; no nonland permanents
Board P4: 3 lands; Aftermath Analyst 1/3
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
- left battlefield: Wayfarer's Bauble was put into Graveyard from Battlefield.
- US activated Wayfarer's Bauble
- US cast Ratchet Bomb
- US activated Ratchet Bomb

## Turn 18 (P3, round 5)
- P3 cast Sauron, the Dark Lord

## Turn 19 (P4, round 5)
- P4 cast Teval, the Balanced Scale
- P3 triggered Sauron, the Dark Lord

## Turn 20 (P1, round 5)
- P1 activated Monster Manual
- P1 triggered Regisaur Alpha

## Turn 21 (OUR TURN, round 6)
Our hand: Braids, Arisen Nightmare, Heroic Intervention, Plaguecrafter, Counterspell, The Coming of Galactus
Our graveyard (2): The One Ring, Wayfarer's Bauble
Board P1: 4 lands; Monster Manual (tapped 1), Regisaur Alpha 4/4, Dinosaur Token 3/3 [token]
Board US: 4 lands; Birds of Paradise 0/1, Cryogen Relic, Ratchet Bomb {[CHARGE]}
Board P3: 6 lands; Sauron, the Dark Lord 7/6, Orc Army Token 1/1 [token] {[P1P1]}
Board P4: 4 lands; Aftermath Analyst 1/3, Teval, the Balanced Scale 4/4
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
- US activated Ratchet Bomb
- US cast Muldrotha, the Gravetide
- P3 triggered Sauron, the Dark Lord

## Turn 22 (P3, round 6) | life: P3 38, US 38
PILOT OVERRULED FORGE (block, COMBAT_DECLARE_BLOCKERS): chose [block with Muldrotha, the Gravetide 6/6] instead of Forge's [no block (take the damage)]
- P3 activated Rogue's Passage targeting [Orc Army Token]
- attack: P3 assigned Sauron, the Dark Lord and Orc Army Token to attack US.
- attack: US assigned Muldrotha, the Gravetide to block Sauron, the Dark Lord.
- left battlefield: Sauron, the Dark Lord was put into Graveyard from Battlefield.
- left battlefield: Muldrotha, the Gravetide was put into Graveyard from Battlefield.
- P3 triggered Sauron, the Dark Lord
Damage to US this turn: Orc Army Token (combat) 2

## Turn 23 (P4, round 6) | life: P1 36, P3 38, US 38
- attack: P4 assigned Teval, the Balanced Scale to attack P1.
- P4 triggered Teval, the Balanced Scale
- P4 triggered Teval, the Balanced Scale
- left battlefield: Aftermath Analyst was put into Graveyard from Battlefield.
- P4 activated Aftermath Analyst
- P4 triggered Underground Mortuary
- P4 triggered Teval, the Balanced Scale
- left battlefield: Swamp was put into Graveyard from Battlefield.
- left battlefield: Forest was put into Graveyard from Battlefield.
- P4 activated Jarad, Golgari Lich Lord
- P4 triggered Teval, the Balanced Scale

## Turn 24 (P1, round 6) | life: P1 36, P3 38, P4 33, US 38
- P1 activated Monster Manual
- P1 triggered Hulking Raptor
- attack: P1 assigned Hulking Raptor, Regisaur Alpha and Dinosaur Token to attack P4.
- attack: P4 assigned Zombie Druid Token and Zombie Druid Token to block Hulking Raptor.
- left battlefield: Hulking Raptor was put into Graveyard from Battlefield.

## Turn 25 (OUR TURN, round 7) | life: P1 36, P3 38, P4 30, US 38
Our hand: Braids, Arisen Nightmare, Heroic Intervention, Plaguecrafter, Counterspell, The Coming of Galactus
Our graveyard (2): The One Ring, Wayfarer's Bauble
Board P1: 4 lands; Monster Manual (tapped 1), Regisaur Alpha 4/4 (tapped 1), Dinosaur Token 3/3 [token] (tapped 1)
Board US: 5 lands; Birds of Paradise 0/1, Cryogen Relic, Ratchet Bomb {[CHARGE x 2]}
Board P3: 6 lands; Orc Army Token 2/2 [token] {[P1P1 x 2]} (tapped 1)
Board P4: 7 lands; Teval, the Balanced Scale 4/4 (tapped 1), Zombie Druid Token 2/2 [token]
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
- US activated Ratchet Bomb
- US cast Dalek Drone
- US triggered Dalek Drone targeting [Teval, the Balanced Scale]
- left battlefield: Teval, the Balanced Scale was put into Graveyard from Battlefield.

## Turn 26 (P3, round 7) | life: P1 36, P3 38, P4 30, US 36
- attack: P3 assigned Orc Army Token to attack US.
- P3 triggered The Ring
- P3 cast In the Darkness Bind Them
- P3 triggered In the Darkness Bind Them
Damage to US this turn: Orc Army Token (combat) 2

## Turn 27 (P4, round 7)
- P4 cast Living Death
- left battlefield: Regisaur Alpha was put into Graveyard from Battlefield.
- left battlefield: Birds of Paradise was put into Graveyard from Battlefield.
- left battlefield: Dalek Drone was put into Graveyard from Battlefield.
- P4 triggered Aftermath Analyst

## Turn 28 (P1, round 7)
- P1 activated Monster Manual
- P1 triggered Hulking Raptor

## Turn 29 (OUR TURN, round 8)
Our hand: Braids, Arisen Nightmare, Heroic Intervention, Plaguecrafter, Counterspell, The Coming of Galactus
Our graveyard (4): The One Ring, Wayfarer's Bauble, Birds of Paradise, Dalek Drone
Board P1: 4 lands; Monster Manual (tapped 1), Hulking Raptor 6/4, Dinosaurs on a Spaceship 7/7
Board US: 5 lands; Cryogen Relic, Ratchet Bomb {[CHARGE x 3]}
Board P3: 6 lands; In the Darkness Bind Them {[LORE]}
Board P4: 7 lands; Skull Prophet 3/1, Aftermath Analyst 1/3
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
- US activated Ratchet Bomb
- US cast The Coming of Galactus
- US triggered The Coming of Galactus targeting [Dinosaurs on a Spaceship]
- left battlefield: Dinosaurs on a Spaceship was put into Graveyard from Battlefield.

## Turn 30 (P3, round 8)
- P3 triggered In the Darkness Bind Them
- P3 cast March from the Black Gate
- P3 triggered March from the Black Gate
- P3 cast Nazgûl
- P3 triggered Nazgûl
- P3 triggered Nazgûl

## Turn 31 (P4, round 8)
- left battlefield: Aftermath Analyst was put into Graveyard from Battlefield.
- P4 activated Aftermath Analyst
- P4 cast Putrefy targeting [Wraith Token]

## Turn 32 (P1, round 8) | life: P1 36, P3 33, P4 30, US 36
- P1 activated Monster Manual
- P1 triggered Ghalta, Stampede Tyrant
- P1 triggered Hulking Raptor
- P1 activated Rogue's Passage targeting [Hulking Raptor]
- attack: P1 assigned Hulking Raptor to attack P3.

## Turn 33 (OUR TURN, round 9) | life: P1 32, P3 29, P4 26, US 35
Our hand: Braids, Arisen Nightmare, Heroic Intervention, Plaguecrafter, Counterspell, Sol Ring, Waterlogged Grove
Our graveyard (4): The One Ring, Wayfarer's Bauble, Birds of Paradise, Dalek Drone
Board P1: 5 lands; Monster Manual (tapped 1), Hulking Raptor 5/3 (tapped 1), Ghalta, Stampede Tyrant 12/12, Otepec Huntmaster 1/2
Board US: 5 lands; Cryogen Relic, Ratchet Bomb {[CHARGE x 4]}, The Coming of Galactus {[LORE x 2]}
Board P3: 6 lands; In the Darkness Bind Them {[LORE x 2]}, March from the Black Gate, Orc Army Token 1/1 [token] {[P1P1]}, Nazgûl 2/3 {[P1P1]}
Board P4: 10 lands; Skull Prophet 3/1
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
PILOT OVERRULED FORGE (action, MAIN1): chose [activate Ratchet Bomb (from Battlefield): {T}, Sacrifice Ratchet Bomb: Destroy each nonlan] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
- US triggered The Coming of Galactus
- left battlefield: Ratchet Bomb was put into Graveyard from Battlefield.
- US activated Ratchet Bomb
- left battlefield: Monster Manual was put into Graveyard from Battlefield.
- left battlefield: Hulking Raptor was put into Graveyard from Battlefield.
- US cast Braids, Arisen Nightmare
- US cast Plaguecrafter
- US triggered Plaguecrafter
- left battlefield: Plaguecrafter was put into Graveyard from Battlefield.
- left battlefield: Skull Prophet was put into Graveyard from Battlefield.
- left battlefield: Otepec Huntmaster was put into Graveyard from Battlefield.
- US triggered Braids, Arisen Nightmare
- left battlefield: Cryogen Relic was put into Graveyard from Battlefield.
- US triggered Cryogen Relic

## Turn 34 (P3, round 9) | life: P1 26, P3 29, P4 23, US 32
- P3 triggered In the Darkness Bind Them
- P3 triggered Nazgûl
- attack: P3 assigned Nazgûl to attack P1.
- P3 triggered The Ring
- P3 triggered The Ring
- P3 cast Mauhúr, Uruk-hai Captain
- P3 cast Dreadhorde Invasion
- P3 cast Talisman of Indulgence

## Turn 35 (P4, round 9)
- P4 cast Teval, the Balanced Scale
- P4 cast Kheru Goldkeeper

## Turn 36 (P1, round 9) | life: P1 26, P3 17, P4 23, US 32
- attack: P1 assigned Ghalta, Stampede Tyrant to attack P3.
- P1 cast Palani's Hatcher
- P1 triggered Palani's Hatcher

## Turn 37 (OUR TURN, round 10) | life: P1 19, P3 13, P4 19, US 31
Our hand: Heroic Intervention, Counterspell, Sol Ring, Darkslick Shores, Cabal Pit, Syr Konrad, the Grim, Boseiju, Who Endures, Animate Dead
Our graveyard (7): The One Ring, Wayfarer's Bauble, Birds of Paradise, Dalek Drone, Ratchet Bomb, Plaguecrafter, Cryogen Relic
Board P1: 5 lands; Ghalta, Stampede Tyrant 12/12 (tapped 1), Palani's Hatcher 5/3, Dinosaur Egg Token 0/1 [token] x2
Board US: 6 lands; The Coming of Galactus {[LORE x 3]}, Braids, Arisen Nightmare 3/3
Board P3: 6 lands; In the Darkness Bind Them {[LORE x 3]}, March from the Black Gate, Nazgûl 3/4 {[P1P1 x 2]} (tapped 1), Wraith Token 4/4 [token] {[P1P1]}, Mauhúr, Uruk-hai Captain 2/2, Dreadhorde Invasion, Talisman of Indulgence
Board P4: 11 lands; Teval, the Balanced Scale 4/4, Kheru Goldkeeper 3/3
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
PILOT OVERRULED FORGE (action, MAIN1): chose [Dalek Drone [ours, 3/3, in graveyard]] instead of Forge's [Dinosaurs on a Spaceship [P1, 7/7, in graveyard]]
PILOT OVERRULED FORGE (discard, CLEANUP): chose [Sol Ring [ours, in hand]] instead of Forge's [Swamp [ours, in hand]]
- US triggered The Coming of Galactus
- US cast Animate Dead targeting [Dalek Drone]
- US triggered Animate Dead
- US triggered Dalek Drone targeting [Ghalta, Stampede Tyrant]
- left battlefield: Ghalta, Stampede Tyrant was put into Graveyard from Battlefield.
- US cast Syr Konrad, the Grim
- US triggered Braids, Arisen Nightmare
- left battlefield: Island was put into Graveyard from Battlefield.

## Turn 38 (P3, round 10) | life: P1 14, P3 12, P4 14, US 3
MEMO (executor escalation: P1: nonland permanents 4→2 (-2); P3: nonland permanents 7→12 (+5); P3: creatures 3→9 (+6)):
You've hit your session limit · resets 6:40pm (UTC)
ESCALATION (p=0.72): P1: nonland permanents 4→2 (-2); P3: nonland permanents 7→12 (+5); P3: creatures 3→9 (+6)
- P3 triggered Dreadhorde Invasion
- P3 triggered In the Darkness Bind Them targeting [Teval, the Balanced Scale, Syr Konrad, the Grim, Palani's Hatcher]
- left battlefield: In the Darkness Bind Them was put into Graveyard from Battlefield.
- P3 triggered Nazgûl
- P3 cast Summons of Saruman
- P3 triggered Teval, the Balanced Scale
- attack: P3 assigned Teval, the Balanced Scale, Wraith Token, Syr Konrad, the Grim, Palani's Hatcher and Nazgûl to attack US.
- P3 triggered Teval, the Balanced Scale
- P3 triggered The Ring
- P3 triggered Syr Konrad, the Grim
- P3 triggered Syr Konrad, the Grim
- P3 triggered Teval, the Balanced Scale
- P3 triggered The Ring
Damage to US this turn: Syr Konrad, the Grim (non-combat) 2, Teval, the Balanced Scale (combat) 4, Wraith Token (combat) 5, Syr Konrad, the Grim (combat) 5, Palani's Hatcher (combat) 5, Nazgûl (combat) 4

## Turn 39 (P4, round 10) | life: P1 14, P3 12, P4 14, US 0
- attack: P4 assigned Teval, the Balanced Scale and Kheru Goldkeeper to attack US.
- P4 triggered Teval, the Balanced Scale
- P4 triggered Kheru Goldkeeper
- P4 triggered Teval, the Balanced Scale
- attack: US assigned Dalek Drone to block Teval, the Balanced Scale.
- P4 cast River Kelpie
- P4 cast Jarad, Golgari Lich Lord
- P4 cast Timeless Witness
- P4 triggered Timeless Witness targeting [Skull Prophet]
- P4 triggered Kheru Goldkeeper
- P4 triggered Teval, the Balanced Scale
Damage to US this turn: Kheru Goldkeeper (combat) 3

## Turn 40 (P1, round 10)
- P1 cast Pantlaza, Sun-Favored
- P1 triggered Pantlaza, Sun-Favored
- P1 cast Farseek
- P4 cast An Offer You Can't Refuse targeting [Search your library for a Plains, Island, Swamp, or Mountain card, put it onto the battlefield tapped, then shuffle. (without paying its mana cost)]
- P1 cast Blasphemous Act
- left battlefield: Palani's Hatcher was put into Graveyard from Battlefield.
- left battlefield: Pantlaza, Sun-Favored was put into Graveyard from Battlefield.
- left battlefield: Nazgûl was put into Graveyard from Battlefield.
- left battlefield: Mauhúr, Uruk-hai Captain was put into Graveyard from Battlefield.
- left battlefield: Kheru Goldkeeper was put into Graveyard from Battlefield.
- left battlefield: Teval, the Balanced Scale was put into Graveyard from Battlefield.
- left battlefield: River Kelpie was put into Graveyard from Battlefield.
- left battlefield: Jarad, Golgari Lich Lord was put into Graveyard from Battlefield.
- left battlefield: Timeless Witness was put into Graveyard from Battlefield.
- P4 triggered River Kelpie
- P4 triggered River Kelpie
- left battlefield: Swamp was put into Graveyard from Battlefield.
- left battlefield: Forest was put into Graveyard from Battlefield.
- P4 activated Jarad, Golgari Lich Lord

## Turn 41 (P3, round 11) | life: P1 14, P3 11, P4 14, US 0
- P3 triggered Dreadhorde Invasion
- P3 cast Sauron, the Dark Lord

## Turn 42 (P4, round 11)
- left battlefield: Foreboding Landscape was put into Graveyard from Battlefield.
- P4 activated Foreboding Landscape
- left battlefield: Terramorphic Expanse was put into Graveyard from Battlefield.
- P4 activated Terramorphic Expanse
- P4 activated Timeless Witness
- P4 triggered Timeless Witness targeting [Kheru Goldkeeper]
- P4 cast Skull Prophet
- P3 triggered Sauron, the Dark Lord

## Turn 43 (P1, round 11)
- P1 cast Bronzebeak Foragers
- P3 triggered Sauron, the Dark Lord
- P1 triggered Bronzebeak Foragers targeting [Sauron, the Dark Lord, Timeless Witness]
- P3 triggered Sauron, the Dark Lord

## Turn 44 (P3, round 11) | life: P1 14, P3 10, P4 7, US 0
- P3 triggered Dreadhorde Invasion
- attack: P3 assigned Sauron, the Dark Lord to attack P4.
- P3 cast Nazgûl
- P3 triggered Nazgûl
- P3 triggered Sauron, the Dark Lord
- P3 triggered Nazgûl
- P3 cast Orcish Siegemaster

## Turn 45 (P4, round 12)
- P4 cast Teval, the Balanced Scale
- P3 triggered Sauron, the Dark Lord
- left battlefield: Memorial to Folly was put into Graveyard from Battlefield.
- P4 activated Memorial to Folly targeting [Aftermath Analyst]
- P3 cast Arcane Denial targeting [Teval, the Balanced Scale - Creature 4 / 4]
- P4 cast Sol Ring
- P3 triggered Sauron, the Dark Lord

## Turn 46 (P1, round 12)
- P3 triggered Arcane Denial
- P3 triggered Arcane Denial
- P1 cast Rishkar's Expertise
- P3 triggered Sauron, the Dark Lord
- P1 cast Elemental Bond
- P3 triggered Sauron, the Dark Lord

## Turn 47 (P3, round 12) | life: P1 11, P3 19, P4 -10, US 0
- P3 triggered Dreadhorde Invasion
- P3 activated Rogue's Passage targeting [Zombie Army Token]
- attack: P3 assigned Zombie Army Token, Sauron, the Dark Lord, Nazgûl and Orcish Siegemaster to attack P4.
- P3 triggered March from the Black Gate
- P3 triggered The Ring
- P3 triggered Dreadhorde Invasion
- P3 triggered Orcish Siegemaster
- P3 triggered Sauron, the Dark Lord
- P3 triggered The Ring
- P3 triggered Sauron, the Dark Lord
- P3 triggered Nazgûl
- P3 cast Nazgûl
- P3 triggered Nazgûl
- P3 triggered Sauron, the Dark Lord
- P3 triggered Nazgûl
- P3 triggered Nazgûl

## Turn 48 (P1, round 12)
- P1 cast Wayward Swordtooth
- P3 triggered Sauron, the Dark Lord
- P1 triggered Elemental Bond

## Turn 49 (P3, round 13) | life: P1 -19, P3 33, P4 -10, US 0
- P3 triggered Dreadhorde Invasion
- P3 activated Rogue's Passage targeting [Zombie Army Token]
- attack: P3 assigned Zombie Army Token, Sauron, the Dark Lord, Nazgûl, Nazgûl and Orcish Siegemaster to attack P1.
- P3 triggered March from the Black Gate
- P3 triggered The Ring
- P3 triggered Dreadhorde Invasion
- P3 triggered Orcish Siegemaster
- P1 cast Heroic Intervention
- P3 triggered Sauron, the Dark Lord
- P3 cast Saruman's Trickery targeting [Permanents you control gain hexproof and indestructible until end of turn.]
- Game Outcome: P1 has lost because life total reached 0
- Game Outcome: US has lost because life total reached 0
- Game Outcome: P3 has won because all opponents have lost
- Game Outcome: P4 has lost because life total reached 0