# pod06-g3: we are P1; opponents P2 Atraxa, Praetors' Voice, P3 Sephiroth, Fabled SOLDIER, P4 Edgar Markov
Result: Turn 23; US has lost because life total reached 0; P2 has lost because life total reached 0; P3 has lost because life total reached 0; P4 has won because all opponents have lost

## Turn 1 (OUR TURN, round 1) | life: US 39
Our hand: Nurturing Peatland, Vrock, Executioner's Capsule, Command Tower, Gravebreaker Lamia, Plaguecrafter, Cryogen Relic, Darkslick Shores
Our graveyard (0): 
Board US: 0 lands; no nonland permanents
Board P2: 0 lands; no nonland permanents
Board P3: 0 lands; no nonland permanents
Board P4: 0 lands; no nonland permanents
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
- US cast Executioner's Capsule

## Turn 2 (P2, round 1)

## Turn 3 (P3, round 1)

## Turn 4 (P4, round 1)

## Turn 5 (OUR TURN, round 2) | life: US 38
Our hand: Vrock, Command Tower, Gravebreaker Lamia, Plaguecrafter, Cryogen Relic, Darkslick Shores, Forest
Our graveyard (0): 
Board US: 1 lands; Executioner's Capsule
Board P2: 1 lands; no nonland permanents
Board P3: 1 lands; no nonland permanents
Board P4: 1 lands; no nonland permanents
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
- US cast Cryogen Relic
- US triggered Cryogen Relic

## Turn 6 (P2, round 2)

## Turn 7 (P3, round 2)
- P3 cast Jet Medallion

## Turn 8 (P4, round 2)
- P4 cast Legion Lieutenant
- P4 triggered Edgar Markov

## Turn 9 (OUR TURN, round 3)
Our hand: Vrock, Gravebreaker Lamia, Plaguecrafter, Darkslick Shores, Forest, Marsh Flats, Massacre Wurm
Our graveyard (0): 
Board US: 2 lands; Executioner's Capsule, Cryogen Relic
Board P2: 2 lands; no nonland permanents
Board P3: 2 lands; Jet Medallion
Board P4: 2 lands; Vampire Token 2/2 [token], Legion Lieutenant 2/2
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)

## Turn 10 (P2, round 3)

## Turn 11 (P3, round 3)
- P3 cast Sephiroth, Fabled SOLDIER
- P3 triggered Sephiroth, Fabled SOLDIER

## Turn 12 (P4, round 3)
- P4 triggered Bojuka Bog targeting [P1]
- P4 cast Talisman of Hierarchy

## Turn 13 (OUR TURN, round 4)
Our hand: Vrock, Gravebreaker Lamia, Plaguecrafter, Forest, Marsh Flats, Massacre Wurm, Invasion of Innistrad
Our graveyard (0): 
Board US: 3 lands; Executioner's Capsule, Cryogen Relic
Board P2: 3 lands; no nonland permanents
Board P3: 3 lands; Jet Medallion, Sephiroth, Fabled SOLDIER 3/3
Board P4: 3 lands; Vampire Token 2/2 [token], Legion Lieutenant 2/2, Talisman of Hierarchy
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)

## Turn 14 (P2, round 4) | life: P2 39, US 38
- left battlefield: Misty Rainforest was put into Graveyard from Battlefield.
- P2 activated Misty Rainforest
- P2 cast Chromatic Lantern

## Turn 15 (P3, round 4)
- P2 cast Path to Exile targeting [Sephiroth, Fabled SOLDIER]
- left battlefield: Jet Medallion was put into Graveyard from Battlefield.
- P3 cast Deadly Dispute
- left battlefield: Sephiroth, Fabled SOLDIER was put into Graveyard from Battlefield.
- P3 cast Flare of Malice
- left battlefield: Legion Lieutenant was put into Graveyard from Battlefield.

## Turn 16 (P4, round 4) | life: P2 39, US 37
- attack: P4 assigned Vampire Token to attack US.
- P4 cast Drana, Liberator of Malakir
- P4 triggered Edgar Markov
Damage to US this turn: Vampire Token (combat) 1

## Turn 17 (OUR TURN, round 5) | life: P2 39, US 35
Our hand: Vrock, Gravebreaker Lamia, Plaguecrafter, Marsh Flats, Massacre Wurm, Invasion of Innistrad, Eternal Witness
Our graveyard (0): 
Board US: 4 lands; Executioner's Capsule, Cryogen Relic
Board P2: 4 lands; Chromatic Lantern (tapped 1)
Board P3: 4 lands; Treasure Token [token]
Board P4: 3 lands; Vampire Token 1/1 [token] x2 (tapped 1), Talisman of Hierarchy, Drana, Liberator of Malakir 2/3
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
PILOT OVERRULED FORGE (action, MAIN1): chose [activate Cryogen Relic (from Battlefield): {1}{U}, Sacrifice this artifact: Put a stun cou] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
- left battlefield: Marsh Flats was put into Graveyard from Battlefield.
- US activated Marsh Flats
- left battlefield: Cryogen Relic was put into Graveyard from Battlefield.
- US activated Cryogen Relic targeting []
- US triggered Cryogen Relic
- US cast Eternal Witness
- US triggered Eternal Witness targeting [Cryogen Relic]

## Turn 18 (P2, round 5)
- P3 cast Fell the Profane targeting [Drana, Liberator of Malakir]
- left battlefield: Drana, Liberator of Malakir was put into Graveyard from Battlefield.
- P2 cast Atraxa, Praetors' Voice
- P2 triggered Atraxa, Praetors' Voice

## Turn 19 (P3, round 5)
- P3 cast Dictate of Erebos

## Turn 20 (P4, round 5)
- P4 cast Sanctum Seeker
- P4 triggered Edgar Markov

## Turn 21 (OUR TURN, round 6) | life: P2 39, US 33
Our hand: Vrock, Gravebreaker Lamia, Plaguecrafter, Massacre Wurm, Invasion of Innistrad, Waterlogged Grove, Cryogen Relic, Nature's Lore
Our graveyard (1): Marsh Flats
Board US: 5 lands; Executioner's Capsule, Eternal Witness 2/1
Board P2: 4 lands; Chromatic Lantern (tapped 1), Atraxa, Praetors' Voice 4/4
Board P3: 5 lands; Dictate of Erebos
Board P4: 3 lands; Vampire Token 1/1 [token] x3, Talisman of Hierarchy (tapped 1), Sanctum Seeker 3/4
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
- US cast Nature's Lore
- US cast Gravebreaker Lamia
- US triggered Gravebreaker Lamia

## Turn 22 (P2, round 6) | life: P2 43, US 29
- attack: P2 assigned Atraxa, Praetors' Voice to attack US.
- P2 cast Narset, Parter of Veils
- P2 activated Narset, Parter of Veils
- P2 cast Sol Ring
- P2 cast Glistening Sphere
- P2 triggered Glistening Sphere
- P2 triggered Atraxa, Praetors' Voice
Damage to US this turn: Atraxa, Praetors' Voice (combat) 4

## Turn 23 (P3, round 6) | life: P2 43, P3 38, US 29
- P3 cast Withering Torment targeting [Atraxa, Praetors' Voice]
- left battlefield: Atraxa, Praetors' Voice was put into Graveyard from Battlefield.
- P3 triggered Bojuka Bog targeting [P1]

## Turn 24 (P4, round 6) | life: P2 38, P3 34, P4 44, US 25
- attack: P4 assigned Vampire Token to attack P2.
- P4 triggered Sanctum Seeker
- P4 triggered Sanctum Seeker
- P4 triggered Sanctum Seeker
- P4 triggered Sanctum Seeker
- left battlefield: Narset, Parter of Veils was put into Graveyard from Battlefield.
- P4 cast Vanquisher's Banner

## Turn 25 (OUR TURN, round 7) | life: P2 38, P3 34, P4 38, US 24
Our hand: Vrock, Plaguecrafter, Massacre Wurm, Invasion of Innistrad, Cryogen Relic, Survival of the Fittest
Our graveyard (0): 
Board US: 7 lands; Executioner's Capsule, Eternal Witness 2/1, Gravebreaker Lamia 4/4
Board P2: 4 lands; Chromatic Lantern (tapped 1), Sol Ring (tapped 1), Glistening Sphere (tapped 1)
Board P3: 6 lands; Dictate of Erebos
Board P4: 4 lands; Vampire Token 2/2 [token] x3 (tapped 3), Talisman of Hierarchy (tapped 1), Sanctum Seeker 4/5 (tapped 1), Vanquisher's Banner
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
PILOT OVERRULED FORGE (attack, COMBAT_DECLARE_ATTACKERS): chose [don't attack with it] instead of Forge's [attack P4 (38 life)]
PILOT OVERRULED FORGE (attack, COMBAT_DECLARE_ATTACKERS): chose [don't attack with it] instead of Forge's [attack P4 (38 life)]
- US cast Massacre Wurm
- US triggered Massacre Wurm
- US triggered Massacre Wurm
- US triggered Massacre Wurm
- US triggered Massacre Wurm

## Turn 26 (P2, round 7)
- P2 cast Vorinclex, Monstrous Raider

## Turn 27 (P3, round 7)
- P3 cast Sephiroth, Fabled SOLDIER
- P2 cast Counterspell targeting [Sephiroth, Fabled SOLDIER - Creature 3 / 3]

## Turn 28 (P4, round 7)
- P4 cast Herald's Horn
- P4 cast Knight of the Ebon Legion
- P4 triggered Vanquisher's Banner
- P4 triggered Edgar Markov

## Turn 29 (OUR TURN, round 8) | life: P2 33, P3 31, P4 29, US 22
Our hand: Vrock, Plaguecrafter, Invasion of Innistrad, Cryogen Relic, Survival of the Fittest
Our graveyard (0): 
Board US: 7 lands; Executioner's Capsule, Eternal Witness 2/1, Gravebreaker Lamia 4/4, Massacre Wurm 6/5
Board P2: 4 lands; Chromatic Lantern (tapped 1), Sol Ring (tapped 1), Glistening Sphere (tapped 1), Vorinclex, Monstrous Raider 6/6
Board P3: 7 lands; Dictate of Erebos
Board P4: 5 lands; Talisman of Hierarchy, Sanctum Seeker 4/5, Vanquisher's Banner, Herald's Horn, Vampire Token 2/2 [token], Knight of the Ebon Legion 2/3
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
- left battlefield: Executioner's Capsule was put into Graveyard from Battlefield.
- US activated Executioner's Capsule targeting [Vorinclex, Monstrous Raider]
- left battlefield: Vorinclex, Monstrous Raider was put into Graveyard from Battlefield.
- US triggered Massacre Wurm
- attack: US assigned Massacre Wurm to attack P4.
- US cast Vrock
- US triggered Vrock

## Turn 30 (P2, round 8)
- P2 cast Atraxa, Praetors' Voice
- P2 cast Cankerbloom
- P2 triggered Atraxa, Praetors' Voice

## Turn 31 (P3, round 8)
- P3 cast Sephiroth, Fabled SOLDIER
- P3 triggered Sephiroth, Fabled SOLDIER

## Turn 32 (P4, round 8) | life: P2 30, P3 31, P4 28, US 21
- P4 triggered Herald's Horn
- P4 cast Patron of the Vein
- P4 triggered Vanquisher's Banner
- P4 triggered Edgar Markov
- P4 triggered Patron of the Vein targeting [Atraxa, Praetors' Voice]
- left battlefield: Atraxa, Praetors' Voice was put into Graveyard from Battlefield.
- P4 triggered Patron of the Vein
- US triggered Massacre Wurm
- P3 triggered Sephiroth, Fabled SOLDIER targeting [P4]
- attack: P4 assigned Sanctum Seeker to attack US.
- P4 triggered Sanctum Seeker
- P3 cast Deadly Rollick targeting [Sanctum Seeker]
- left battlefield: Sanctum Seeker was put into Exile from Battlefield.
- P4 cast Cordial Vampire
- P4 triggered Vanquisher's Banner
- P4 triggered Edgar Markov

## Turn 33 (OUR TURN, round 9) | life: P2 27, P3 28, P4 25, US 18
Our hand: Plaguecrafter, Invasion of Innistrad, Cryogen Relic, Survival of the Fittest, Doc Aurlock, Grizzled Genius, Wooded Foothills
Our graveyard (1): Executioner's Capsule
Board US: 7 lands; Eternal Witness 2/1, Gravebreaker Lamia 4/4, Massacre Wurm 6/5, Vrock 3/3
Board P2: 4 lands; Chromatic Lantern (tapped 1), Sol Ring (tapped 1), Glistening Sphere (tapped 1), Cankerbloom 3/2
Board P3: 8 lands; Dictate of Erebos, Sephiroth, Fabled SOLDIER 3/3
Board P4: 6 lands; Talisman of Hierarchy (tapped 1), Vanquisher's Banner, Herald's Horn, Vampire Token 3/3 [token] {[P1P1]} x2, Knight of the Ebon Legion 3/4 {[P1P1]}, Patron of the Vein 6/6 {[P1P1]}, Vampire Token 2/2 [token], Cordial Vampire 2/2
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
PILOT OVERRULED FORGE (search, MAIN1): chose [Overgrown Tomb — Land - Swamp Forest — ({T}: Add {B} or {G}.) As Overgrown Tomb enters, yo] instead of Forge's [Zagoth Triome — Land - Swamp Forest Island — ({T}: Add {B}, {G}, or {U}.) Zagoth Triome en]
- left battlefield: Wooded Foothills was put into Graveyard from Battlefield.
- US activated Wooded Foothills
- US cast Muldrotha, the Gravetide
- US cast Executioner's Capsule
- US triggered Vrock

## Turn 34 (P2, round 9) | life: P2 26, P3 28, P4 25, US 18
- left battlefield: Flooded Strand was put into Graveyard from Battlefield.
- P2 activated Flooded Strand
- P2 cast Atraxa, Praetors' Voice
- P2 triggered Atraxa, Praetors' Voice

## Turn 35 (P3, round 9)
- P3 cast Bontu's Monument

## Turn 36 (P4, round 9) | life: P2 26, P3 28, P4 25, US 12
- P4 triggered Herald's Horn
- P4 cast Edgar Markov
- P4 triggered Vanquisher's Banner
- P4 cast Twilight Prophet
- P4 triggered Vanquisher's Banner
- P4 triggered Edgar Markov
- attack: P4 assigned Patron of the Vein to attack US.
- P4 triggered Knight of the Ebon Legion
Damage to US this turn: Patron of the Vein (combat) 6

## Turn 37 (OUR TURN, round 10) | life: P2 21, P3 30, P4 17, US 9
Our hand: Plaguecrafter, Invasion of Innistrad, Cryogen Relic, Survival of the Fittest, Doc Aurlock, Grizzled Genius
Our graveyard (1): Wooded Foothills
Board US: 8 lands; Eternal Witness 2/1, Gravebreaker Lamia 4/4, Massacre Wurm 6/5, Vrock 3/3, Muldrotha, the Gravetide 6/6, Executioner's Capsule
Board P2: 5 lands; Chromatic Lantern (tapped 1), Sol Ring (tapped 1), Glistening Sphere (tapped 1), Cankerbloom 3/2, Atraxa, Praetors' Voice 4/4
Board P3: 9 lands; Dictate of Erebos, Sephiroth, Fabled SOLDIER 3/3, Bontu's Monument
Board P4: 7 lands; Talisman of Hierarchy (tapped 1), Vanquisher's Banner, Herald's Horn, Vampire Token 3/3 [token] {[P1P1]} x2, Knight of the Ebon Legion 4/5 {[P1P1 x 2]}, Patron of the Vein 6/6 {[P1P1]} (tapped 1), Vampire Token 2/2 [token] x2, Cordial Vampire 2/2, Edgar Markov 5/5, Twilight Prophet 3/5
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
MEMO (executor escalation: we lost: Massacre Wurm):
You've hit your session limit · resets 6:40pm (UTC)
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Executioner's Capsule (from Graveyard): Executioner's Capsule by Muldrotha, the Grave] instead of Forge's [activate Bloodstained Mire (from Battlefield): {T}, Pay 1 life, Sacrifice Bloodstained Mir]
PILOT OVERRULED FORGE (search, MAIN1): chose [Watery Grave — Land - Island Swamp — ({T}: Add {U} or {B}.) As Watery Grave enters, you ma] instead of Forge's [Zagoth Triome — Land - Swamp Forest Island — ({T}: Add {B}, {G}, or {U}.) Zagoth Triome en]
PILOT OVERRULED FORGE (attack, COMBAT_DECLARE_ATTACKERS): chose [attack P4 (24 life)] instead of Forge's [don't attack with it]
ESCALATION (p=0.64): we lost: Massacre Wurm
PILOT OVERRULED FORGE (sacrifice, MAIN2): chose [Plaguecrafter [ours, 3/2]] instead of Forge's [Eternal Witness [ours, 2/1]]
PILOT OVERRULED FORGE (sacrifice, MAIN2): chose [Doc Aurlock, Grizzled Genius [ours, 2/3]] instead of Forge's [Eternal Witness [ours, 2/1]]
- left battlefield: Executioner's Capsule was put into Graveyard from Battlefield.
- US activated Executioner's Capsule targeting [Cankerbloom]
- left battlefield: Cankerbloom was put into Graveyard from Battlefield.
- US triggered Massacre Wurm
- P3 triggered Sephiroth, Fabled SOLDIER targeting [P4]
- P4 triggered Patron of the Vein
- P4 triggered Cordial Vampire
- US cast Executioner's Capsule
- left battlefield: Bloodstained Mire was put into Graveyard from Battlefield.
- US activated Bloodstained Mire
- attack: US assigned Massacre Wurm to attack P4.
- attack: P4 assigned Knight of the Ebon Legion to block Massacre Wurm.
- left battlefield: Massacre Wurm was put into Graveyard from Battlefield.
- P3 triggered Sephiroth, Fabled SOLDIER targeting [P4]
- P4 triggered Patron of the Vein
- P4 triggered Cordial Vampire
- US cast Doc Aurlock, Grizzled Genius
- US cast Plaguecrafter
- US triggered Plaguecrafter
- left battlefield: Plaguecrafter was put into Graveyard from Battlefield.
- left battlefield: Atraxa, Praetors' Voice was put into Graveyard from Battlefield.
- left battlefield: Sephiroth, Fabled SOLDIER was put into Graveyard from Battlefield.
- P3 triggered Sephiroth, Fabled SOLDIER targeting [P4]
- P3 triggered Sephiroth, Fabled SOLDIER targeting [P4]
- P3 triggered Dictate of Erebos
- P3 triggered Sephiroth, Fabled SOLDIER targeting [P4]
- P4 triggered Patron of the Vein
- P4 triggered Patron of the Vein
- P4 triggered Patron of the Vein
- P4 triggered Cordial Vampire
- P4 triggered Cordial Vampire
- P4 triggered Cordial Vampire
- P4 triggered Cordial Vampire
- left battlefield: Doc Aurlock, Grizzled Genius was put into Graveyard from Battlefield.
- P4 triggered Patron of the Vein
- P4 triggered Cordial Vampire
- P4 triggered Cordial Vampire
- US triggered Vrock

## Turn 38 (P2, round 10) | life: P2 21, P3 30, P4 37, US 9
- P2 cast Brokers Ascendancy
- P2 cast Cultivate
- P2 cast Oko, Thief of Crowns
- P2 activated Oko, Thief of Crowns
- P2 cast Swords to Plowshares targeting [Patron of the Vein]
- left battlefield: Patron of the Vein was put into Exile from Battlefield.
- P2 triggered Brokers Ascendancy

## Turn 39 (P3, round 10) | life: P2 20, P3 31, P4 36, US 8
- P3 cast Sephiroth, Fabled SOLDIER
- P3 triggered Bontu's Monument
- P3 triggered Sephiroth, Fabled SOLDIER

## Turn 40 (P4, round 10) | life: P2 18, P3 29, P4 37, US -31
- P4 triggered Herald's Horn
- P4 triggered Twilight Prophet
- P4 cast Stromkirk Captain
- P4 triggered Vanquisher's Banner
- P4 triggered Edgar Markov
- P4 cast Master of Dark Rites
- P4 triggered Vanquisher's Banner
- P4 triggered Edgar Markov
- P4 cast Vengeful Bloodwitch
- P4 triggered Vanquisher's Banner
- P4 triggered Edgar Markov
- P4 cast Blade of the Bloodchief
- P4 activated Blade of the Bloodchief targeting [Twilight Prophet]
- attack: P4 assigned Edgar Markov, Knight of the Ebon Legion, Vampire Token, Vampire Token, Twilight Prophet and Cordial Vampire to attack US.
- P4 triggered Edgar Markov
- attack: US assigned Eternal Witness to block Edgar Markov.
- P4 cast Black Market Connections
- P4 triggered Knight of the Ebon Legion
Damage to US this turn: Twilight Prophet (combat) 19, Cordial Vampire (combat) 18

## Turn 41 (P2, round 11)
- P2 activated Oko, Thief of Crowns targeting [Sol Ring]
- P2 triggered Brokers Ascendancy

## Turn 42 (P3, round 11)

## Turn 43 (P4, round 11) | life: P2 -118, P3 27, P4 38, US -31
- P4 triggered Herald's Horn
- P4 triggered Twilight Prophet
- P4 cast Boros Charm
- P4 triggered Black Market Connections
- attack: P4 assigned Knight of the Ebon Legion, Edgar Markov, Vampire Token, Vampire Token, Twilight Prophet, Cordial Vampire, Vampire Token, Stromkirk Captain, Vampire Token, Master of Dark Rites, Vampire Token and Vengeful Bloodwitch to attack P2.
- P4 triggered Edgar Markov
- P2 activated Food Token
- P4 activated Knight of the Ebon Legion
- P4 activated Knight of the Ebon Legion
- P4 triggered Knight of the Ebon Legion

## Turn 44 (P3, round 11) | life: P2 -118, P3 28, P4 37, US -31
- P3 cast Marionette Apprentice
- P3 triggered Bontu's Monument
- P3 triggered Marionette Apprentice

## Turn 45 (P4, round 12) | life: P2 -118, P3 -83, P4 34, US -31
- P4 triggered Herald's Horn
- P4 triggered Twilight Prophet
- P4 triggered Black Market Connections
- attack: P4 assigned Knight of the Ebon Legion, Edgar Markov, Vampire Token, Vampire Token, Twilight Prophet, Cordial Vampire, Vampire Token, Stromkirk Captain, Vampire Token, Master of Dark Rites, Vampire Token and Vengeful Bloodwitch to attack P3.
- P4 triggered Edgar Markov
- attack: P3 assigned Marionette Apprentice to block Knight of the Ebon Legion.
- P3 cast Village Rites
- P4 triggered Cordial Vampire
- P4 triggered Blade of the Bloodchief
- P3 triggered Dictate of Erebos
- P3 triggered Sephiroth, Fabled SOLDIER targeting [P4]
- P3 triggered Marionette Apprentice
- P4 triggered Vengeful Bloodwitch targeting [P3]
- P4 triggered Cordial Vampire
- P4 triggered Blade of the Bloodchief
- P3 triggered Sephiroth, Fabled SOLDIER targeting [P4]
- Game Outcome: US has lost because life total reached 0
- Game Outcome: P2 has lost because life total reached 0
- Game Outcome: P3 has lost because life total reached 0
- Game Outcome: P4 has won because all opponents have lost