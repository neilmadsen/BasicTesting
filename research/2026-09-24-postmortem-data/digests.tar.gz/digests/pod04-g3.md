# pod04-g3: we are P1; opponents P2 Giada, Font of Hope, P3 Edgar Markov, P4 Sephiroth, Fabled SOLDIER
Result: Turn 16; US has lost because life total reached 0; P2 has won because all opponents have lost; P3 has lost because life total reached 0; P4 has lost because life total reached 0

## Turn 1 (OUR TURN, round 1)
Our hand: Eternal Witness, Siren Stormtamer, Glen Elendra Archmage, Wayfarer's Bauble, Mind Stone, Forest, Woodland Cemetery, Seal of Primordium
Our graveyard (0): 
Board US: 0 lands; no nonland permanents
Board P2: 0 lands; no nonland permanents
Board P3: 0 lands; no nonland permanents
Board P4: 0 lands; no nonland permanents
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
- US cast Wayfarer's Bauble

## Turn 2 (P2, round 1)

## Turn 3 (P3, round 1) | life: P3 41
- P3 cast Vampire of the Dire Moon
- P3 triggered Edgar Markov
- P2 cast Swords to Plowshares targeting [Vampire of the Dire Moon]
- left battlefield: Vampire of the Dire Moon was put into Exile from Battlefield.

## Turn 4 (P4, round 1)
- P4 cast Sol Ring

## Turn 5 (OUR TURN, round 2)
Our hand: Eternal Witness, Siren Stormtamer, Glen Elendra Archmage, Mind Stone, Woodland Cemetery, Seal of Primordium, Twisted Embrace
Our graveyard (0): 
Board US: 1 lands; Wayfarer's Bauble
Board P2: 1 lands; no nonland permanents
Board P3: 1 lands; Vampire Token 1/1 [token]
Board P4: 1 lands; Sol Ring
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
- left battlefield: Wayfarer's Bauble was put into Graveyard from Battlefield.
- US activated Wayfarer's Bauble

## Turn 6 (P2, round 2)
- P2 cast Giada, Font of Hope

## Turn 7 (P3, round 2)

## Turn 8 (P4, round 2)
- P4 cast Crypt Ghast

## Turn 9 (OUR TURN, round 3)
Our hand: Eternal Witness, Siren Stormtamer, Glen Elendra Archmage, Mind Stone, Seal of Primordium, Twisted Embrace, Mishra's Bauble
Our graveyard (1): Wayfarer's Bauble
Board US: 3 lands; no nonland permanents
Board P2: 2 lands; Giada, Font of Hope 2/2
Board P3: 2 lands; Vampire Token 1/1 [token]
Board P4: 2 lands; Sol Ring (tapped 1), Crypt Ghast 2/2
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Mishra's Bauble (from Hand): Mishra's Bauble] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN1): chose [activate Mishra's Bauble (from Battlefield): {T}, Sacrifice Mishra's Bauble: Look at the t] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (trigger-target, MAIN2): chose [Mishra's Bauble [ours, in graveyard]] instead of Forge's [Wayfarer's Bauble [ours, in graveyard]]
- US cast Mishra's Bauble
- left battlefield: Mishra's Bauble was put into Graveyard from Battlefield.
- US activated Mishra's Bauble targeting [P4]
- US cast Eternal Witness
- US triggered Eternal Witness targeting [Mishra's Bauble]

## Turn 10 (P2, round 3) | life: P3 41, P4 38
- US triggered Mishra's Bauble
- attack: P2 assigned Giada, Font of Hope to attack P4.
- P2 cast Serra Paragon

## Turn 11 (P3, round 3)
- P3 cast Path to Exile targeting [Serra Paragon]
- left battlefield: Serra Paragon was put into Exile from Battlefield.

## Turn 12 (P4, round 3) | life: P2 39, P3 40, P4 41, US 39
- P4 cast Warren Soultrader
- P4 triggered Crypt Ghast
- P4 cast Sephiroth, Fabled SOLDIER
- P4 triggered Crypt Ghast
- P4 triggered Sephiroth, Fabled SOLDIER

## Turn 13 (OUR TURN, round 4) | life: P2 39, P3 40, P4 41, US 38
Our hand: Siren Stormtamer, Glen Elendra Archmage, Mind Stone, Seal of Primordium, Twisted Embrace, Mishra's Bauble, The Death of Gwen Stacy, Misty Rainforest
Our graveyard (1): Wayfarer's Bauble
Board US: 3 lands; Eternal Witness 2/1
Board P2: 4 lands; Giada, Font of Hope 2/2 (tapped 1)
Board P3: 3 lands; Vampire Token 1/1 [token]
Board P4: 3 lands; Sol Ring (tapped 1), Crypt Ghast 2/2, Warren Soultrader 3/3, Sephiroth, Fabled SOLDIER 3/3
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
PILOT OVERRULED FORGE (action, MAIN1): chose [play land Misty Rainforest (from Hand): Play land] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (search, MAIN1): chose [Zagoth Triome — Land - Swamp Forest Island — ({T}: Add {B}, {G}, or {U}.) Zagoth Triome en] instead of Forge's [Watery Grave — Land - Island Swamp — ({T}: Add {U} or {B}.) As Watery Grave enters, you ma]
PILOT OVERRULED FORGE (trigger-target, MAIN2): chose [Sephiroth, Fabled SOLDIER [P4, 3/3, commander]] instead of Forge's [Warren Soultrader [P4, 3/3]]
- left battlefield: Misty Rainforest was put into Graveyard from Battlefield.
- US activated Misty Rainforest
- US cast The Death of Gwen Stacy
- US triggered The Death of Gwen Stacy targeting [Sephiroth, Fabled SOLDIER]
- left battlefield: Sephiroth, Fabled SOLDIER was put into Graveyard from Battlefield.

## Turn 14 (P2, round 4) | life: P2 39, P3 40, P4 39, US 38
- attack: P2 assigned Giada, Font of Hope to attack P4.
- P2 cast Resplendent Angel

## Turn 15 (P3, round 4)
- P3 cast Clavileño, First of the Blessed
- P3 triggered Edgar Markov

## Turn 16 (P4, round 4) | life: P2 38, P3 39, P4 42, US 37
- P4 cast Sephiroth, Fabled SOLDIER
- P4 triggered Crypt Ghast
- P4 triggered Sephiroth, Fabled SOLDIER

## Turn 17 (OUR TURN, round 5) | life: P2 38, P3 39, P4 43, US 36
Our hand: Siren Stormtamer, Glen Elendra Archmage, Mind Stone, Seal of Primordium, Twisted Embrace, Mishra's Bauble, Grist, the Hunger Tide
Our graveyard (2): Wayfarer's Bauble, Misty Rainforest
Board US: 4 lands; Eternal Witness 2/1, The Death of Gwen Stacy {[LORE x 2]}
Board P2: 5 lands; Giada, Font of Hope 2/2, Resplendent Angel 4/4 {[P1P1]}
Board P3: 4 lands; Vampire Token 1/1 [token] x2, Clavileño, First of the Blessed 2/2
Board P4: 4 lands; Sol Ring (tapped 1), Crypt Ghast 2/2, Warren Soultrader 3/3, Sephiroth, Fabled SOLDIER 3/3
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
PILOT OVERRULED FORGE (action, MAIN2): chose [cast Grist, the Hunger Tide (from Hand): Grist, the Hunger Tide] instead of Forge's [cast Glen Elendra Archmage (from Hand): Glen Elendra Archmage - Creature 2 / 2]
PILOT OVERRULED FORGE (trigger-target, MAIN2): chose [Grist, the Hunger Tide [ours, loyalty 1]] instead of Forge's [Resplendent Angel [P2, 4/4]]
- US triggered The Death of Gwen Stacy
- US cast Grist, the Hunger Tide
- US activated Grist, the Hunger Tide
- left battlefield: Eternal Witness was put into Graveyard from Battlefield.
- US triggered Grist, the Hunger Tide targeting [Grist, the Hunger Tide]
- P4 triggered Sephiroth, Fabled SOLDIER targeting [P1]
- left battlefield: Grist, the Hunger Tide was put into Graveyard from Battlefield.
- US cast Siren Stormtamer

## Turn 18 (P2, round 5) | life: P2 46, P3 39, P4 35, US 36
- P2 cast Lyra Dawnbringer
- attack: P2 assigned Resplendent Angel and Giada, Font of Hope to attack P4.
- P2 triggered Resplendent Angel

## Turn 19 (P3, round 5)
- P3 cast Charismatic Conqueror
- P3 triggered Edgar Markov

## Turn 20 (P4, round 5) | life: P2 45, P3 38, P4 38, US 35
- P4 cast Jet Medallion
- P4 triggered Crypt Ghast
- P3 triggered Charismatic Conqueror

## Turn 21 (OUR TURN, round 6) | life: P2 45, P3 38, P4 38, US 34
Our hand: Glen Elendra Archmage, Mind Stone, Seal of Primordium, Twisted Embrace, Wooded Foothills
Our graveyard (6): Wayfarer's Bauble, Misty Rainforest, Mishra's Bauble, Eternal Witness, Grist, the Hunger Tide, The Death of Gwen Stacy
Board US: 4 lands; Siren Stormtamer 1/1
Board P2: 6 lands; Giada, Font of Hope 3/3, Resplendent Angel 5/5 {[P1P1]} (tapped 1), Lyra Dawnbringer 7/7 {[P1P1 x 2]}, Angel Token 8/8 [token] {[P1P1 x 3]}
Board P3: 4 lands; Vampire Token 1/1 [token] x3, Clavileño, First of the Blessed 2/2, Charismatic Conqueror 2/2
Board P4: 5 lands; Sol Ring (tapped 1), Crypt Ghast 2/2, Warren Soultrader 3/3, Sephiroth, Fabled SOLDIER 3/3, Jet Medallion (tapped 1)
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
- US triggered The Death of Gwen Stacy targeting [P2]
- left battlefield: The Death of Gwen Stacy was put into Graveyard from Battlefield.
- left battlefield: Wooded Foothills was put into Graveyard from Battlefield.
- US activated Wooded Foothills
- US cast Glen Elendra Archmage
- P3 triggered Charismatic Conqueror

## Turn 22 (P2, round 6) | life: P2 69, P3 38, P4 15, US 34
- P2 cast Inspiring Overseer
- P2 triggered Inspiring Overseer
- P3 triggered Charismatic Conqueror
- attack: P2 assigned Lyra Dawnbringer, Resplendent Angel, Angel Token and Giada, Font of Hope to attack P4.
- P2 cast Starnheim Aspirant
- P3 triggered Charismatic Conqueror
- P2 triggered Resplendent Angel
- P3 triggered Charismatic Conqueror

## Turn 23 (P3, round 6)
- P3 cast Legion Lieutenant
- P3 triggered Edgar Markov

## Turn 24 (P4, round 6) | life: P2 68, P3 37, P4 18, US 33
- P4 cast Deadly Rollick targeting [Angel Token]
- P4 triggered Crypt Ghast

## Turn 25 (OUR TURN, round 7)
Our hand: Mind Stone, Seal of Primordium, Twisted Embrace, Vrock
Our graveyard (7): Wayfarer's Bauble, Misty Rainforest, Mishra's Bauble, Eternal Witness, Grist, the Hunger Tide, The Death of Gwen Stacy, Wooded Foothills
Board US: 5 lands; Siren Stormtamer 1/1, Glen Elendra Archmage 2/2
Board P2: 7 lands; Giada, Font of Hope 3/3, Resplendent Angel 5/5 {[P1P1]} (tapped 1), Lyra Dawnbringer 7/7 {[P1P1 x 2]} (tapped 1), Angel Token 8/8 [token] {[P1P1 x 3]}, Inspiring Overseer 7/6 {[P1P1 x 4]} (tapped 1), Starnheim Aspirant 2/2 (tapped 1)
Board P3: 4 lands; Vampire Token 2/2 [token] x4, Clavileño, First of the Blessed 3/3, Charismatic Conqueror 3/3, Legion Lieutenant 2/2
Board P4: 5 lands; Sol Ring, Crypt Ghast 2/2, Warren Soultrader 3/3, Sephiroth, Fabled SOLDIER 3/3, Jet Medallion
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
- US cast Vrock
- P3 triggered Charismatic Conqueror

## Turn 26 (P2, round 7) | life: P2 100, P3 5, P4 18, US 33
- attack: P2 assigned Lyra Dawnbringer, Inspiring Overseer, Resplendent Angel, Angel Token and Giada, Font of Hope to attack P3.
- P2 activated Resplendent Angel
- P2 triggered Resplendent Angel
- P3 triggered Charismatic Conqueror

## Turn 27 (P3, round 7)

## Turn 28 (P4, round 7) | life: P2 99, P3 4, P4 25, US 28
MEMO (executor escalation: P2: life 68→99 (+31); P3: life 37→4 (-33)):
You've hit your session limit · resets 6:40pm (UTC)
ESCALATION (p=0.69): P2: life 68→99 (+31); P3: life 37→4 (-33)
- P4 cast Fleshbag Marauder
- P4 triggered Crypt Ghast
- P4 triggered Fleshbag Marauder
- P3 triggered Charismatic Conqueror
- left battlefield: Fleshbag Marauder was put into Graveyard from Battlefield.
- left battlefield: Siren Stormtamer was put into Graveyard from Battlefield.
- left battlefield: Starnheim Aspirant was put into Graveyard from Battlefield.
- P4 triggered Sephiroth, Fabled SOLDIER targeting [P1]
- P4 triggered Sephiroth, Fabled SOLDIER targeting [P1]
- P4 triggered Sephiroth, Fabled SOLDIER targeting [P1]
- P4 triggered Sephiroth, Fabled SOLDIER targeting [P1]

## Turn 29 (OUR TURN, round 8) | life: P2 96, P3 -2, P4 22, US 28
Our hand: Mind Stone, Seal of Primordium, Twisted Embrace, Doc Aurlock, Grizzled Genius
Our graveyard (8): Wayfarer's Bauble, Misty Rainforest, Mishra's Bauble, Eternal Witness, Grist, the Hunger Tide, The Death of Gwen Stacy, Wooded Foothills, Siren Stormtamer
Board US: 5 lands; Glen Elendra Archmage 2/2, Vrock 3/3
Board P2: 7 lands; Giada, Font of Hope 3/3, Resplendent Angel 5/5 {[P1P1]} (tapped 1), Lyra Dawnbringer 7/7 {[P1P1 x 2]} (tapped 1), Angel Token 8/8 [token] {[P1P1 x 3]}, Inspiring Overseer 7/6 {[P1P1 x 4]} (tapped 1), Angel Token 10/10 [token] {[P1P1 x 5]} (tapped 1)
Board P3: 4 lands; Vampire Token 2/2 [token] x3, Clavileño, First of the Blessed 3/3, Charismatic Conqueror 3/3, Legion Lieutenant 2/2
Board P4: 5 lands; Sol Ring, Crypt Ghast 2/2, Warren Soultrader 3/3, Sephiroth, One-Winged Angel 5/5, Jet Medallion
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
PILOT OVERRULED FORGE (attack, COMBAT_DECLARE_ATTACKERS): chose [attack P3 (4 life)] instead of Forge's [don't attack with it]
PILOT OVERRULED FORGE (action, MAIN2): chose [cast Seal of Primordium (from Hand): Seal of Primordium] instead of Forge's [cast Mind Stone (from Hand): Mind Stone]
PILOT OVERRULED FORGE (action, MAIN2): chose [Sol Ring [P4]] instead of Forge's [Jet Medallion [P4]]
- attack: US assigned Vrock to attack P3.
- US cast Doc Aurlock, Grizzled Genius
- P3 triggered Charismatic Conqueror
- US cast Seal of Primordium
- left battlefield: Seal of Primordium was put into Graveyard from Battlefield.
- US activated Seal of Primordium targeting [Sol Ring]
- left battlefield: Sol Ring was put into Graveyard from Battlefield.
- US triggered Vrock

## Turn 30 (P2, round 8) | life: P2 126, P3 -2, P4 -6, US 25
MEMO (executor escalation: P2: life 99→126 (+27)):
You've hit your session limit · resets 6:40pm (UTC)
ESCALATION (p=0.67): P2: life 99→126 (+27)
- P2 cast Swiftfoot Boots
- P2 activated Swiftfoot Boots targeting [Angel Token]
- attack: P2 assigned Angel Token, Angel Token, Lyra Dawnbringer, Inspiring Overseer, Resplendent Angel and Giada, Font of Hope to attack P4.
- attack: P4 assigned Sephiroth, One-Winged Angel to block Angel Token.
- left battlefield: Sephiroth, One-Winged Angel was put into Graveyard from Battlefield.
- P4 activated Warren Soultrader
- P4 triggered Emblem — Sephiroth, One-Winged Angel targeting [P1]
- left battlefield: Crypt Ghast was put into Graveyard from Battlefield.
- P4 activated Warren Soultrader
- P4 triggered Emblem — Sephiroth, One-Winged Angel targeting [P1]
- left battlefield: Warren Soultrader was put into Graveyard from Battlefield.
- P4 activated High Market
- P4 triggered Emblem — Sephiroth, One-Winged Angel targeting [P1]
- P2 cast Court of Grace
- P2 triggered Court of Grace
- P2 triggered The Monarch
- P2 triggered Resplendent Angel

## Turn 31 (OUR TURN, round 8) | life: P2 123, P3 -2, P4 -6, US 25
Our hand: Mind Stone, Twisted Embrace, Executioner's Capsule
Our graveyard (9): Wayfarer's Bauble, Misty Rainforest, Mishra's Bauble, Eternal Witness, Grist, the Hunger Tide, The Death of Gwen Stacy, Wooded Foothills, Siren Stormtamer, Seal of Primordium
Board US: 5 lands; Glen Elendra Archmage 2/2, Vrock 3/3, Doc Aurlock, Grizzled Genius 2/3
Board P2: 7 lands; Giada, Font of Hope 3/3, Resplendent Angel 5/5 {[P1P1]} (tapped 1), Lyra Dawnbringer 7/7 {[P1P1 x 2]} (tapped 1), Angel Token 8/8 [token] {[P1P1 x 3]}, Inspiring Overseer 7/6 {[P1P1 x 4]} (tapped 1), Angel Token 10/10 [token] {[P1P1 x 5]}, Swiftfoot Boots, Court of Grace, Angel Token 11/11 [token] {[P1P1 x 6]}
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
PILOT OVERRULED FORGE (action, MAIN1): chose [Giada, Font of Hope [P2, 3/3, commander]] instead of Forge's [Angel Token [P2, 11/11, token]]
- US cast Executioner's Capsule
- left battlefield: Executioner's Capsule was put into Graveyard from Battlefield.
- US activated Executioner's Capsule targeting [Giada, Font of Hope]
- left battlefield: Giada, Font of Hope was put into Graveyard from Battlefield.
- US cast Mind Stone
- US triggered Vrock

## Turn 32 (P2, round 8) | life: P2 171, P3 -2, P4 -6, US -2
- P2 triggered Court of Grace
- P2 cast Archangel of Tithes
- P2 cast Giada, Font of Hope
- P2 triggered Path of Ancestry
- attack: P2 assigned Angel Token, Angel Token, Angel Token, Lyra Dawnbringer, Inspiring Overseer and Resplendent Angel to attack US.
- attack: US assigned Glen Elendra Archmage to block Angel Token.
- Game Outcome: US has lost because life total reached 0
- Game Outcome: P2 has won because all opponents have lost
- Game Outcome: P3 has lost because life total reached 0
- Game Outcome: P4 has lost because life total reached 0
Damage to US this turn: Lyra Dawnbringer (combat) 7, Angel Token (combat) 8, Inspiring Overseer (combat) 7, Resplendent Angel (combat) 5