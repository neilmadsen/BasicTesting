# pod04-g4: we are P1; opponents P2 Giada, Font of Hope, P3 Edgar Markov, P4 Sephiroth, Fabled SOLDIER
Result: Turn 18; US has lost because life total reached 0; P2 has lost because life total reached 0; P3 has lost because life total reached 0; P4 has won because all opponents have lost

## Turn 1 (OUR TURN, round 1) | life: US 39
Our hand: Talisman of Dominance, Sinister Concoction, Assassin's Trophy, Soul-Guide Lantern, Nurturing Peatland, Baleful Strix, Arcane Signet, Shriekmaw
Our graveyard (0): 
Board US: 0 lands; no nonland permanents
Board P2: 0 lands; no nonland permanents
Board P3: 0 lands; no nonland permanents
Board P4: 0 lands; no nonland permanents
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
- US cast Sinister Concoction

## Turn 2 (P2, round 1)

## Turn 3 (P3, round 1)
- P3 cast Vampire of the Dire Moon
- P3 triggered Edgar Markov

## Turn 4 (P4, round 1)

## Turn 5 (OUR TURN, round 2) | life: US 37
Our hand: Talisman of Dominance, Assassin's Trophy, Soul-Guide Lantern, Baleful Strix, Arcane Signet, Shriekmaw, Vrock
Our graveyard (0): 
Board US: 1 lands; Sinister Concoction
Board P2: 1 lands; no nonland permanents
Board P3: 1 lands; Vampire Token 1/1 [token], Vampire of the Dire Moon 1/1
Board P4: 1 lands; no nonland permanents
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
PILOT OVERRULED FORGE (action, MAIN1): chose [activate Sinister Concoction (from Battlefield): {B}, Pay 1 life, Discard a card, Sacrific] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
- left battlefield: Sinister Concoction was put into Graveyard from Battlefield.
- US activated Sinister Concoction targeting [Vampire of the Dire Moon]
- left battlefield: Vampire of the Dire Moon was put into Graveyard from Battlefield.

## Turn 6 (P2, round 2)
- P2 cast Giada, Font of Hope

## Turn 7 (P3, round 2) | life: P4 39, US 37
- P3 cast Path to Exile targeting [Giada, Font of Hope]
- left battlefield: Giada, Font of Hope was put into Exile from Battlefield.
- attack: P3 assigned Vampire Token to attack P4.

## Turn 8 (P4, round 2)
- P4 cast Jet Medallion

## Turn 9 (OUR TURN, round 3) | life: P4 39, US 36
Our hand: Talisman of Dominance, Assassin's Trophy, Soul-Guide Lantern, Baleful Strix, Arcane Signet, Vrock, Binding the Old Gods
Our graveyard (3): Shriekmaw, Sinister Concoction, Demonic Tutor
Board US: 1 lands; no nonland permanents
Board P2: 3 lands; no nonland permanents
Board P3: 2 lands; Vampire Token 1/1 [token] (tapped 1)
Board P4: 2 lands; Jet Medallion
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
PILOT OVERRULED FORGE (trigger-target, MAIN2): chose [Vampire of the Dire Moon [P3, 1/1, in graveyard]] instead of Forge's [Path to Exile [P3, in graveyard]]
- US cast Soul-Guide Lantern
- US triggered Soul-Guide Lantern targeting [Vampire of the Dire Moon]
- left battlefield: Soul-Guide Lantern was put into Graveyard from Battlefield.
- US activated Soul-Guide Lantern

## Turn 10 (P2, round 3)
- P2 cast Resplendent Angel

## Turn 11 (P3, round 3) | life: P3 42, P4 39, US 36
- P3 cast Captivating Vampire
- P3 triggered Edgar Markov
- P2 cast Swords to Plowshares targeting [Captivating Vampire]
- left battlefield: Captivating Vampire was put into Exile from Battlefield.

## Turn 12 (P4, round 3) | life: P3 42, P4 36, US 36
- P4 cast Feed the Swarm targeting [Resplendent Angel]
- left battlefield: Resplendent Angel was put into Graveyard from Battlefield.
- P4 cast Sephiroth, Fabled SOLDIER
- P4 triggered Sephiroth, Fabled SOLDIER

## Turn 13 (OUR TURN, round 4)

## Turn 14 (P2, round 4)
- P2 cast Giada, Font of Hope

## Turn 15 (P3, round 4)
- P3 cast Black Market Connections

## Turn 16 (P4, round 4) | life: P2 37, P3 42, P4 39, US 33
- attack: P4 assigned Sephiroth, Fabled SOLDIER to attack P2.
- P4 triggered Sephiroth, Fabled SOLDIER
- P4 triggered Bojuka Bog targeting [P1]
- P4 cast Plaguecrafter
- P4 triggered Plaguecrafter
- left battlefield: Plaguecrafter was put into Graveyard from Battlefield.
- left battlefield: Giada, Font of Hope was put into Graveyard from Battlefield.
- P4 triggered Sephiroth, Fabled SOLDIER targeting [P1]
- P4 triggered Sephiroth, Fabled SOLDIER targeting [P1]
- P4 triggered Sephiroth, Fabled SOLDIER targeting [P1]

## Turn 17 (OUR TURN, round 5)

## Turn 18 (P2, round 5)
- P2 cast Herald of War

## Turn 19 (P3, round 5) | life: P2 37, P3 41, P4 39, US 33
- P3 triggered Black Market Connections
- P3 cast Edgar Markov

## Turn 20 (P4, round 5) | life: P2 37, P3 41, P4 42, US 30
- P4 cast Fleshbag Marauder
- P4 triggered Fleshbag Marauder
- left battlefield: Fleshbag Marauder was put into Graveyard from Battlefield.
- left battlefield: Herald of War was put into Graveyard from Battlefield.
- P4 triggered Sephiroth, Fabled SOLDIER targeting [P1]
- P4 triggered Sephiroth, Fabled SOLDIER targeting [P1]
- P4 triggered Sephiroth, Fabled SOLDIER targeting [P1]
- P4 cast Morbid Opportunist

## Turn 21 (OUR TURN, round 6)
Our hand: Talisman of Dominance, Assassin's Trophy, Baleful Strix, Arcane Signet, Binding the Old Gods, Seal of Doom, Counterspell, Kaya's Ghostform
Our graveyard (1): Vrock
Board US: 1 lands; no nonland permanents
Board P2: 5 lands; no nonland permanents
Board P3: 5 lands; Black Market Connections, Edgar Markov 4/4
Board P4: 5 lands; Jet Medallion, Sephiroth, Fabled SOLDIER 3/3, Morbid Opportunist 1/3
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)

## Turn 22 (P2, round 6) | life: P2 37, P3 41, P4 43, US 29
- P2 cast Stroke of Midnight targeting [Edgar Markov]
- left battlefield: Edgar Markov was put into Graveyard from Battlefield.
- P4 triggered Sephiroth, Fabled SOLDIER targeting [P1]
- P4 triggered Morbid Opportunist
- P2 cast Youthful Valkyrie

## Turn 23 (P3, round 6) | life: P2 37, P3 40, P4 43, US 29
- P3 triggered Black Market Connections
- P3 cast Talisman of Indulgence

## Turn 24 (P4, round 6) | life: P2 37, P3 36, P4 33, US 29
- attack: P4 assigned Sephiroth, Fabled SOLDIER and Morbid Opportunist to attack P3.
- P4 triggered Sephiroth, Fabled SOLDIER
- P4 cast Bolas's Citadel
- P4 cast Carrion Feeder
- P4 cast Drivnod, Carnage Dominus
- P4 cast Grave Pact

## Turn 25 (OUR TURN, round 7) | life: P2 37, P3 36, P4 40, US 21
Our hand: Talisman of Dominance, Assassin's Trophy, Baleful Strix, Arcane Signet, Seal of Doom, Counterspell, Kaya's Ghostform, Forest
Our graveyard (2): Vrock, Binding the Old Gods
Board US: 1 lands; no nonland permanents
Board P2: 5 lands; Youthful Valkyrie 1/3
Board P3: 6 lands; Black Market Connections, Human Token 1/1 [token], Treasure Token [token], Talisman of Indulgence
Board P4: 6 lands; Jet Medallion, Sephiroth, Fabled SOLDIER 3/3 (tapped 1), Morbid Opportunist 1/3 (tapped 1), Bolas's Citadel, Carrion Feeder 1/1, Drivnod, Carnage Dominus 8/3, Grave Pact
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
- US cast Assassin's Trophy targeting [Drivnod, Carnage Dominus]
- left battlefield: Morbid Opportunist was put into Graveyard from Battlefield.
- P4 activated Carrion Feeder
- P4 triggered Sephiroth, Fabled SOLDIER targeting [P1]
- P4 triggered Sephiroth, Fabled SOLDIER targeting [P1]
- P4 triggered Grave Pact
- P4 triggered Grave Pact
- left battlefield: Youthful Valkyrie was put into Graveyard from Battlefield.
- P4 triggered Sephiroth, Fabled SOLDIER targeting [P1]
- P4 triggered Sephiroth, Fabled SOLDIER targeting [P1]
- P4 triggered Sephiroth, Fabled SOLDIER targeting [P1]
- P4 triggered Sephiroth, Fabled SOLDIER targeting [P1]
- left battlefield: Drivnod, Carnage Dominus was put into Graveyard from Battlefield.
- P4 activated Carrion Feeder
- P4 triggered Grave Pact
- P4 triggered Grave Pact
- P4 triggered Emblem — Sephiroth, One-Winged Angel targeting [P1]

## Turn 26 (P2, round 7)
- P2 cast Vanquisher's Banner

## Turn 27 (P3, round 7) | life: P2 37, P3 35, P4 40, US 21
- P3 triggered Black Market Connections
- P3 cast Edgar Markov
- attack: P3 assigned Edgar Markov to attack P4.
- P3 triggered Edgar Markov
- P4 cast Deadly Rollick targeting [Edgar Markov]
- left battlefield: Edgar Markov was put into Exile from Battlefield.

## Turn 28 (P4, round 7) | life: P2 37, P3 27, P4 26, US 21
- attack: P4 assigned Sephiroth, One-Winged Angel and Carrion Feeder to attack P3.
- P4 triggered Sephiroth, One-Winged Angel
- P4 cast Zulaport Cutthroat
- P4 cast Pitiless Plunderer
- P4 cast Pawn of Ulamog
- P4 cast Syr Konrad, the Grim
- P4 cast Ophiomancer

## Turn 29 (OUR TURN, round 8) | life: P2 37, P3 27, P4 26, US 20
Our hand: Talisman of Dominance, Baleful Strix, Arcane Signet, Seal of Doom, Counterspell, Kaya's Ghostform
Our graveyard (3): Vrock, Binding the Old Gods, Assassin's Trophy
Board US: 2 lands; no nonland permanents
Board P2: 5 lands; Vanquisher's Banner
Board P3: 7 lands; Black Market Connections, Treasure Token [token], Talisman of Indulgence (tapped 1)
Board P4: 7 lands; Jet Medallion, Sephiroth, One-Winged Angel 5/5 (tapped 1), Bolas's Citadel, Carrion Feeder 3/3 {[P1P1 x 2]} (tapped 1), Grave Pact, Zulaport Cutthroat 1/1, Pitiless Plunderer 1/4, Pawn of Ulamog 2/2, Syr Konrad, the Grim 5/4, Ophiomancer 2/2
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
- P4 triggered Ophiomancer
- US cast Seal of Doom

## Turn 30 (P2, round 8) | life: P2 36, P3 26, P4 27, US 18
- P2 cast Exemplar of Light
- P2 triggered Vanquisher's Banner
- P2 cast Authority of the Consuls
- left battlefield: Seal of Doom was put into Graveyard from Battlefield.
- US activated Seal of Doom targeting [Exemplar of Light]
- left battlefield: Exemplar of Light was put into Graveyard from Battlefield.
- P4 triggered Syr Konrad, the Grim
- P4 triggered Emblem — Sephiroth, One-Winged Angel targeting [P1]
Damage to US this turn: Syr Konrad, the Grim (non-combat) 1

## Turn 31 (P3, round 8) | life: P2 33, P3 21, P4 27, US 14
- P3 triggered Black Market Connections
- P3 cast Edgar Markov
- P2 triggered Authority of the Consuls
- P4 activated Syr Konrad, the Grim
- P4 triggered Syr Konrad, the Grim
- P4 triggered Syr Konrad, the Grim
- P4 activated Syr Konrad, the Grim
- P4 triggered Syr Konrad, the Grim
- P4 triggered Syr Konrad, the Grim
Damage to US this turn: Syr Konrad, the Grim (non-combat) 4

## Turn 32 (P4, round 8) | life: P2 35, P3 1, P4 27, US 14
- attack: P4 assigned Sephiroth, One-Winged Angel, Syr Konrad, the Grim, Carrion Feeder, Pawn of Ulamog, Ophiomancer, Zulaport Cutthroat, Pitiless Plunderer and Snake Token to attack P3.
- P4 triggered Sephiroth, One-Winged Angel
- P4 cast Jadar, Ghoulcaller of Nephalia
- P2 triggered Authority of the Consuls
- P4 triggered Jadar, Ghoulcaller of Nephalia
- P2 triggered Authority of the Consuls

## Turn 33 (OUR TURN, round 9)
Our hand: Talisman of Dominance, Baleful Strix, Arcane Signet, Counterspell, Kaya's Ghostform, Farseek
Our graveyard (6): Vrock, Binding the Old Gods, Assassin's Trophy, Seal of Doom, Spore Frog, Mulldrifter
Board US: 3 lands; no nonland permanents
Board P2: 5 lands; Vanquisher's Banner, Authority of the Consuls
Board P3: 7 lands; Black Market Connections, Talisman of Indulgence (tapped 1), Edgar Markov 4/4 (tapped 1)
Board P4: 7 lands; Jet Medallion, Sephiroth, One-Winged Angel 5/5 (tapped 1), Bolas's Citadel, Carrion Feeder 3/3 {[P1P1 x 2]} (tapped 1), Grave Pact, Zulaport Cutthroat 1/1 (tapped 1), Pitiless Plunderer 1/4 (tapped 1), Pawn of Ulamog 2/2 (tapped 1), Syr Konrad, the Grim 5/4 (tapped 1), Ophiomancer 2/2 (tapped 1), Snake Token 1/1 [token] (tapped 1), Jadar, Ghoulcaller of Nephalia 1/1 (tapped 1), Zombie Token 2/2 [token] (tapped 1)
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
PILOT OVERRULED FORGE (search, MAIN1): chose [Zagoth Triome — Land - Swamp Forest Island — ({T}: Add {B}, {G}, or {U}.) Zagoth Triome en] instead of Forge's [Watery Grave — Land - Island Swamp — ({T}: Add {U} or {B}.) As Watery Grave enters, you ma]
- US cast Farseek

## Turn 34 (P2, round 9)
- P2 cast Archangel of Thune
- P2 triggered Vanquisher's Banner

## Turn 35 (P3, round 9) | life: P2 34, P3 0, P4 27, US 13
- P3 triggered Black Market Connections
- P4 activated Syr Konrad, the Grim
- P4 triggered Syr Konrad, the Grim
Damage to US this turn: Syr Konrad, the Grim (non-combat) 1

## Turn 36 (P4, round 9) | life: P2 0, P3 0, P4 31, US 0
- left battlefield: Zulaport Cutthroat was put into Graveyard from Battlefield.
- P4 cast Flare of Malice
- P4 triggered Grave Pact
- P4 triggered Syr Konrad, the Grim
- P4 triggered Emblem — Sephiroth, One-Winged Angel targeting [P1]
- P4 triggered Zulaport Cutthroat
- P4 triggered Pitiless Plunderer
- P4 triggered Pawn of Ulamog
- P2 triggered Authority of the Consuls
- P2 triggered Archangel of Thune
- left battlefield: Archangel of Thune was put into Graveyard from Battlefield.
- P4 triggered Syr Konrad, the Grim
- P4 triggered Emblem — Sephiroth, One-Winged Angel targeting [P1]
- attack: P4 assigned Sephiroth, One-Winged Angel, Zombie Token, Syr Konrad, the Grim, Carrion Feeder, Pawn of Ulamog, Ophiomancer, Pitiless Plunderer, Snake Token and Jadar, Ghoulcaller of Nephalia to attack P2.
- P4 triggered Zombie Token
- P4 triggered Sephiroth, One-Winged Angel
- P4 triggered Zombie Token
- P4 triggered Grave Pact
- P4 triggered Syr Konrad, the Grim
- P4 triggered Emblem — Sephiroth, One-Winged Angel targeting [P1]
- P4 triggered Pitiless Plunderer
- P4 cast Reassembling Skeleton
- P2 triggered Authority of the Consuls
- P4 activated Carrion Feeder
- P4 triggered Grave Pact
- P4 triggered Syr Konrad, the Grim
- P4 triggered Emblem — Sephiroth, One-Winged Angel targeting [P1]
- P4 triggered Pitiless Plunderer
- P4 activated Carrion Feeder
- P4 triggered Grave Pact
- P4 triggered Syr Konrad, the Grim
- P4 triggered Emblem — Sephiroth, One-Winged Angel targeting [P1]
- P4 triggered Pitiless Plunderer
- left battlefield: Jadar, Ghoulcaller of Nephalia was put into Graveyard from Battlefield.
- P4 activated Carrion Feeder
- P4 triggered Grave Pact
- P4 triggered Syr Konrad, the Grim
- P4 triggered Emblem — Sephiroth, One-Winged Angel targeting [P1]
- P4 triggered Pitiless Plunderer
- P4 triggered Pawn of Ulamog
- P2 triggered Authority of the Consuls
- P4 activated Carrion Feeder
- P4 triggered Grave Pact
- P4 triggered Syr Konrad, the Grim
- P4 triggered Emblem — Sephiroth, One-Winged Angel targeting [P1]
- P4 triggered Pitiless Plunderer
- left battlefield: Reassembling Skeleton was put into Graveyard from Battlefield.
- P4 activated Carrion Feeder
- P4 triggered Grave Pact
- P4 triggered Syr Konrad, the Grim
- P4 triggered Emblem — Sephiroth, One-Winged Angel targeting [P2]
- P4 triggered Pitiless Plunderer
- P4 triggered Pawn of Ulamog
- P2 triggered Authority of the Consuls
- P4 activated Reassembling Skeleton
- P4 triggered Syr Konrad, the Grim
- P2 triggered Authority of the Consuls
- P4 activated Carrion Feeder
- P4 triggered Grave Pact
- P4 triggered Syr Konrad, the Grim
- P4 triggered Emblem — Sephiroth, One-Winged Angel targeting [P2]
- P4 triggered Pitiless Plunderer
- left battlefield: Reassembling Skeleton was put into Graveyard from Battlefield.
- P4 activated Carrion Feeder
- P4 triggered Grave Pact
- P4 triggered Syr Konrad, the Grim
- P4 triggered Emblem — Sephiroth, One-Winged Angel targeting [P2]
- P4 triggered Pitiless Plunderer
- P4 triggered Pawn of Ulamog
- P2 triggered Authority of the Consuls
- P4 activated Reassembling Skeleton
- P4 triggered Syr Konrad, the Grim
- P2 triggered Authority of the Consuls
- P4 activated Carrion Feeder
- P4 triggered Grave Pact
- P4 triggered Syr Konrad, the Grim
- P4 triggered Emblem — Sephiroth, One-Winged Angel targeting [P2]
- P4 triggered Pitiless Plunderer
- left battlefield: Reassembling Skeleton was put into Graveyard from Battlefield.
- P4 activated Carrion Feeder
- P4 triggered Grave Pact
- P4 triggered Syr Konrad, the Grim
- P4 triggered Emblem — Sephiroth, One-Winged Angel targeting [P2]
- P4 triggered Pitiless Plunderer
- P4 triggered Pawn of Ulamog
- P2 triggered Authority of the Consuls
- P4 activated Reassembling Skeleton
- P4 triggered Syr Konrad, the Grim
- P2 triggered Authority of the Consuls
- P4 activated Carrion Feeder
- P4 triggered Grave Pact
- P4 triggered Syr Konrad, the Grim
- P4 triggered Emblem — Sephiroth, One-Winged Angel targeting [P2]
- P4 triggered Pitiless Plunderer
- Game Outcome: US has lost because life total reached 0
- Game Outcome: P2 has lost because life total reached 0
- Game Outcome: P3 has lost because life total reached 0
- Game Outcome: P4 has won because all opponents have lost
Damage to US this turn: Syr Konrad, the Grim (non-combat) 6