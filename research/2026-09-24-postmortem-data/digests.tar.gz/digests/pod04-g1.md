# pod04-g1: we are P1; opponents P2 Giada, Font of Hope, P3 Edgar Markov, P4 Sephiroth, Fabled SOLDIER
Result: Turn 18; US has lost because life total reached 0; P2 has lost because life total reached 0; P3 has won because all opponents have lost; P4 has lost because life total reached 0

## Turn 1 (P2, round 1)

## Turn 2 (P3, round 1)

## Turn 3 (P4, round 1)

## Turn 4 (OUR TURN, round 1)
Our hand: Swamp, Gravebreaker Lamia, Bojuka Bog, Forest, Birds of Paradise, Siren Stormtamer, Grist, the Hunger Tide, Tropical Island
Our graveyard (0): 
Board US: 0 lands; no nonland permanents
Board P2: 1 lands; no nonland permanents
Board P3: 1 lands; no nonland permanents
Board P4: 1 lands; no nonland permanents
MEMO (start of our turn):
THIS TURN: Play Tropical Island and tap it for G to cast Birds of Paradise. We have no other mana, so we pass with 6 cards in hand and don't discard. Nothing to do on opponents' turns.

TARGET: Next turn play Swamp and cast Grist (1BG) with Island plus Birds. +1 Grist every turn to make Insect chump fodder and mill into the lanes. Turn after, play Forest (4 mana): Stormtamer (U) plus hold, or Grist -2 on a key creature. Then Gravebreaker Lamia (5 mana): tutor Executioner's Capsule (default), Massacre Wurm if P3 or P4 has gone wide, or Seal of Primordium if Giada gets an engine artifact or enchantment. Muldrotha at 6 mana with Stormtamer up.

WIN PATH: Muldrotha recasts Capsule, Seal and Grist each turn to lock the board by turn 8. Close with Gray Merchant or Syr Konrad drains and Muldrotha beats. Our clock is about 9 turns; opponents' is 6-8.

THREATS & ANSWERS: Early Giada: Grist -2. P3 Vito or Skullclamp: Capsule or Seal once online. P4 Pitiless Plunderer or Ashnod's Altar: Grist -2 or Seal. Don't chump or kill creatures needlessly while P3 or P4 drainers are out.

HOLD: Bojuka Bog. Play it on a turn when entering tapped costs nothing, aimed at P4's graveyard (Bloodghast, Reanimate targets). Keep Stormtamer until Muldrotha lands unless we need a blocker.

REPLAN IF: Birds dies (cast Grist a turn later), a fast combo piece appears, or a wipe looks likely before Muldrotha.
- US cast Birds of Paradise

## Turn 5 (P2, round 2)
- P2 cast Giada, Font of Hope

## Turn 6 (P3, round 2)

## Turn 7 (P4, round 2)

## Turn 8 (OUR TURN, round 2)
Our hand: Swamp, Gravebreaker Lamia, Bojuka Bog, Forest, Siren Stormtamer, Grist, the Hunger Tide, Vrock
Our graveyard (0): 
Board US: 1 lands; Birds of Paradise 0/1
Board P2: 2 lands; Giada, Font of Hope 2/2
Board P3: 2 lands; no nonland permanents
Board P4: 2 lands; no nonland permanents
MEMO (start of our turn):
THIS TURN: Play Swamp. Cast Grist (1BG) using Swamp, Tropical Island and Birds. Use Grist +1 to make an Insect and mill (loyalty 4). Keep Birds; don't sacrifice our only ramp for a 2/2 yet. No mana is left for opponents' turns.

TARGET: Next turn, Grist -2, sacrificing the Insect, to destroy Giada. Only sacrifice Birds if the Insect is gone. Play Bojuka Bog tapped next turn (nothing in hand costs 4), aimed at whichever graveyard holds the most value, likely P4's. Cast Stormtamer (U) with 2 open. The turn after, play Forest (5 mana): Gravebreaker Lamia, tutoring Executioner's Capsule by default. Tutor Massacre Wurm if P3 or P4 has gone wide, or Seal of Primordium for a key artifact or enchantment. Cast Muldrotha on the next land drop, with Stormtamer up.

WIN PATH: Muldrotha loops Grist, Capsule and Seal to lock the board. Vrock plus a sacrifice each turn drains 3 from each opponent per turn. Close with Gray Merchant or Syr Konrad. Our clock is about 9 turns; theirs is 6-8.

THREATS & ANSWERS: 1) Giada and any Angel she buffs: Grist -2 next turn. 2) P4's Pitiless Plunderer or Ashnod's Altar: Grist -2 or Capsule. 3) P3's Vito, Skullclamp or Exquisite Blood: Capsule or Seal. Don't chump or kill creatures needlessly while drainers are out.

HOLD: Siren Stormtamer until Muldrotha, to counter Swords or Path on him. Save Vrock until we can reliably make a permanent leave the battlefield each turn.

REPLAN IF: Giada lands an Angel next turn (point -2 at the bigger Angel only if it's Archangel of Thune or Avacyn). Replan if Grist dies, Birds dies, or a combo piece appears.
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Grist, the Hunger Tide (from Hand): Grist, the Hunger Tide [Forge's heuristic AI woul] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
- US cast Grist, the Hunger Tide
- US activated Grist, the Hunger Tide

## Turn 9 (P2, round 3)
- P2 cast Firemane Commando

## Turn 10 (P3, round 3)
- P3 cast Drana, Liberator of Malakir
- P3 triggered Edgar Markov

## Turn 11 (P4, round 3)
- P4 cast Sephiroth, Fabled SOLDIER
- P4 triggered Sephiroth, Fabled SOLDIER

## Turn 12 (OUR TURN, round 3) | life: P4 41, US 39
Our hand: Gravebreaker Lamia, Bojuka Bog, Forest, Siren Stormtamer, Vrock, Sakura-Tribe Elder
Our graveyard (1): Arcane Signet
Board US: 2 lands; Birds of Paradise 0/1, Grist, the Hunger Tide {[LOYALTY x 4]}, Insect Token 1/1 [token]
Board P2: 3 lands; Giada, Font of Hope 2/2 (tapped 1), Firemane Commando 5/4 {[P1P1]}
Board P3: 3 lands; Vampire Token 1/1 [token], Drana, Liberator of Malakir 2/3
Board P4: 3 lands; Sephiroth, Fabled SOLDIER 3/3
MEMO (start of our turn):
THIS TURN: 1) Play Bojuka Bog. Its trigger must target someone, so target P4's empty graveyard. 2) Grist −2: sacrifice the Insect and destroy Sephiroth. This beats the old Giada plan because our deck sacrifices every turn, and Sephiroth drains us and transforms at 4 deaths. Do this before any other creature dies. 3) Cast Sakura-Tribe Elder ({1}{G}: Birds for G, Swamp). 4) Cast Siren Stormtamer (U from Tropical Island). On opponents' turns, block a ground attacker with Elder, then sacrifice it for a basic Island. Sacrifice it by P4's end step at the latest.

TARGET: Next turn play Forest. Tropical Island, Swamp, Bog, the fetched Island, Forest and Birds make 6: cast Muldrotha. The turn after, cast Gravebreaker Lamia and tutor Executioner's Capsule, or Massacre Wurm if P3 or P4 has gone wide. Then recast Grist from the graveyard.

WIN PATH: Muldrotha loops Grist −2 and Capsule. Vrock plus a sacrifice each turn drains 3 per opponent. Close with Gray Merchant or Syr Konrad around turn 18-20. P2's fliers are the fastest clock, at 6-8 turns.

THREATS & ANSWERS: 1) Giada and Firemane Commando: next Grist −2 via Muldrotha. 2) P3's Drana and any Vito, Skullclamp or Exquisite Blood: Capsule or Seal of Doom. 3) Sephiroth recast: Grist or Capsule. Don't chump-block while Sephiroth or P3's drainers are out.

HOLD: Stormtamer's U, to counter Swords or Path on Muldrotha. Hold Vrock until Muldrotha is online. Hold Forest for next turn's land drop.

REPLAN IF: Grist survives at 2 loyalty. P2 lands Archangel of Thune or Avacyn. We get wiped. Or Sephiroth transforms.
PILOT OVERRULED FORGE (trigger-target, MAIN1): chose [Sephiroth, Fabled SOLDIER [P4, 3/3, commander]] instead of Forge's [Firemane Commando [P2, 5/4]]
PILOT OVERRULED FORGE (action, MAIN1): chose [play land Bojuka Bog (from Hand): Play land] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (trigger-target, MAIN1): chose [P4 (41 life)] instead of Forge's [P2 (40 life)]
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Sakura-Tribe Elder (from Hand): Sakura-Tribe Elder - Creature 1 / 1 [Forge's heuristi] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (search, MAIN1): chose [Forest — Basic Land - Forest — ({T}: Add {G}.)] instead of Forge's [Swamp — Basic Land - Swamp — ({T}: Add {B}.)]
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Siren Stormtamer (from Hand): Siren Stormtamer - Creature 1 / 1 [Forge's heuristic AI] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
- US activated Grist, the Hunger Tide
- US triggered Grist, the Hunger Tide targeting [Sephiroth, Fabled SOLDIER]
- P4 triggered Sephiroth, Fabled SOLDIER targeting [P1]
- left battlefield: Sephiroth, Fabled SOLDIER was put into Graveyard from Battlefield.
- US triggered Bojuka Bog targeting [P4]
- US cast Sakura-Tribe Elder
- left battlefield: Sakura-Tribe Elder was put into Graveyard from Battlefield.
- US activated Sakura-Tribe Elder
- US cast Siren Stormtamer

## Turn 13 (P2, round 4) | life: P2 46, P4 41, US 39
- P2 cast Lyra Dawnbringer
- attack: P2 assigned Firemane Commando to attack Grist, the Hunger Tide.
- left battlefield: Grist, the Hunger Tide was put into Graveyard from Battlefield.

## Turn 14 (P3, round 4)
- P3 cast Forerunner of the Legion
- P3 triggered Edgar Markov
- P3 triggered Forerunner of the Legion
- P3 cast Sol Ring

## Turn 15 (P4, round 4)
MEMO (executor escalation: we lost: Grist, the Hunger Tide):
THIS TURN: Resolve Demon's Disciple by sacrificing Siren Stormtamer and keeping Birds of Paradise. Birds is our sixth mana for Muldrotha next turn, and Stormtamer can come back later through Muldrotha's creature lane. Don't block with Birds on anyone's turn.

TARGET: Next turn, play Forest, then cast Muldrotha for {3}{B}{G}{U}. Take U from Tropical Island, B from Swamp, G from Forest, and generic from Bojuka Bog, the second Forest and Birds. The turn after, use graveyard lanes: Grist ({1}{B}{G}), then −2 sacrificing Birds or a recast creature to kill Lyra. Add Sakura-Tribe Elder and Arcane Signet with any leftover mana. Then cast Gravebreaker Lamia to tutor Executioner's Capsule, or Massacre Wurm if P3 goes wide.

WIN PATH: Loop Grist −2 and Capsule through Muldrotha. Add Vrock and sacrifice Elder each turn, draining each opponent for 3. Close with Gray Merchant or Syr Konrad. P2 is the fastest clock: about 16 flying power a turn, so roughly 3 swings to kill someone.

THREATS & ANSWERS: 1) Lyra 7/7 first strike and lifelink: Grist −2. 2) Firemane Commando and Giada: Capsule, or the next Grist −2. 3) P3's Drana and any Vito, Skullclamp or Exquisite Blood: Capsule or Seal of Doom. 4) A recast Sephiroth: kill before 4 deaths in a turn, and don't chump while it's out.

HOLD: Vrock until Muldrotha resolves and we have a sacrifice each turn. Hold Lamia until Muldrotha is out, since it only discounts graveyard casts. Keep Forest for next turn's land drop.

REPLAN IF: Birds dies (Muldrotha slips a turn; cast Lamia for Capsule instead). Muldrotha gets removed or wiped. P2 lands Thune or Avacyn. Sephiroth returns.
ESCALATION (p=0.89): we lost: Grist, the Hunger Tide
- P4 cast Demon's Disciple
- P4 triggered Demon's Disciple
- left battlefield: Demon's Disciple was put into Graveyard from Battlefield.
- left battlefield: Siren Stormtamer was put into Graveyard from Battlefield.
- left battlefield: Giada, Font of Hope was put into Graveyard from Battlefield.

## Turn 16 (OUR TURN, round 4)
Our hand: Gravebreaker Lamia, Forest, Vrock, Sol Ring
Our graveyard (4): Arcane Signet, Sakura-Tribe Elder, Grist, the Hunger Tide, Siren Stormtamer
Board US: 4 lands; Birds of Paradise 0/1
Board P2: 4 lands; Firemane Commando 6/5 {[P1P1]} (tapped 1), Lyra Dawnbringer 7/7 {[P1P1 x 2]}
Board P3: 4 lands; Drana, Liberator of Malakir 2/3, Vampire Token 1/1 [token], Forerunner of the Legion 2/2, Sol Ring
Board P4: 4 lands; no nonland permanents
MEMO (start of our turn):
THIS TURN: Play Forest. Cast Sol Ring by tapping the new Forest. Cast Muldrotha ({3}{B}{G}{U}): U from Tropical Island, B from Swamp, G from the old Forest, and generic from Sol Ring (2) plus Bojuka Bog. Birds' last mana then casts Siren Stormtamer ({U}) from the graveyard through the creature lane, so it can protect Muldrotha from next turn on. No blocks unless we're facing lethal.

TARGET: Next turn we have 8 mana. Cast Grist from the graveyard ({1}{B}{G}) and −2, sacrificing Birds, to kill Lyra. Cast Gravebreaker Lamia (5) to tutor Executioner's Capsule into the graveyard. Keep U up for Stormtamer when possible. Later add Arcane Signet, Sakura-Tribe Elder and Vrock. Tutor Massacre Wurm if P3 goes wide.

WIN PATH: Loop Grist −2 and Capsule each turn. Add Vrock and sacrifice Elder every turn to drain each opponent for 3. Close with Gray Merchant or Syr Konrad. P2 is the fastest clock at 13 flying a turn, so we survive about 3 swings from 39.

THREATS & ANSWERS: 1) Lyra 7/7: Grist −2. 2) Firemane Commando 6/5 and a recast Giada: Capsule. 3) P3's Drana, and any Vito, Exquisite Blood or Skullclamp: Capsule or Seal of Doom. 4) Recast Sephiroth: kill it before 4 deaths in a turn, and don't chump while it's out.

HOLD: Vrock (5) and Lamia (5) this turn, since we can't afford them. Hold Lamia until Muldrotha survives a turn cycle.

REPLAN IF: Muldrotha is removed or wiped (recast with tax 2; cast Lamia for Capsule instead). Birds dies. P2 lands Thune or Avacyn. Sephiroth or Vito appears.
PILOT OVERRULED FORGE (search, MAIN2): chose [Executioner's Capsule — Artifact — {1}{B}, {T}, Sacrifice Executioner's Capsule: Destroy t] instead of Forge's [Massacre Wurm — Creature - Phyrexian Wurm — When Massacre Wurm enters, creatures your oppo]
- US cast Gravebreaker Lamia
- US triggered Gravebreaker Lamia
- US cast Sol Ring

## Turn 17 (P2, round 5) | life: P2 59, P3 27, P4 41, US 39
- P2 cast Gisela, the Broken Blade
- attack: P2 assigned Lyra Dawnbringer and Firemane Commando to attack P3.
- P2 triggered Firemane Commando

## Turn 18 (P3, round 5)
- P3 cast Bloodthirsty Conqueror
- P3 triggered Edgar Markov
- P3 triggered Forerunner of the Legion targeting [Drana, Liberator of Malakir]
- P3 triggered Forerunner of the Legion targeting [Drana, Liberator of Malakir]

## Turn 19 (P4, round 5) | life: P2 58, P3 28, P4 41, US 39
- P4 cast Nether Traitor
- attack: P4 assigned Nether Traitor to attack P2.
- P3 triggered Bloodthirsty Conqueror

## Turn 20 (OUR TURN, round 5)
Our hand: Vrock, Soul-Guide Lantern
Our graveyard (5): Arcane Signet, Sakura-Tribe Elder, Grist, the Hunger Tide, Siren Stormtamer, Executioner's Capsule
Board US: 5 lands; Birds of Paradise 0/1, Gravebreaker Lamia 4/4, Sol Ring
Board P2: 5 lands; Firemane Commando 6/5 {[P1P1]} (tapped 1), Lyra Dawnbringer 7/7 {[P1P1 x 2]} (tapped 1), Gisela, the Broken Blade 5/4
Board P3: 5 lands; Drana, Liberator of Malakir 2/3, Vampire Token 1/1 [token] x2, Forerunner of the Legion 2/2, Sol Ring (tapped 1), Bloodthirsty Conqueror 5/5
Board P4: 4 lands; Nether Traitor 1/1 (tapped 1)
MEMO (start of our turn):
THIS TURN: No land in hand. 1) Cast Muldrotha: U from Tropical Island, B from Swamp, G from Forest, and 3 generic from Sol Ring plus Bojuka Bog. 2) Tap Birds for B and the second Forest for G. Cast Grist from the graveyard as a planeswalker ({B}{G} after Lamia's discount). 3) Grist −2, sacrifice the tapped Birds, and destroy Bloodthirsty Conqueror. It's black, so only Grist can kill it. If Muldrotha costs 8 because of tax, cast only Muldrotha. Block ground attackers with Muldrotha or Lamia. Never chump.

TARGET: Next turn, cast Capsule ({B}) and activate it ({1}{B}) on Lyra. Cast Stormtamer ({U}) and keep it up to protect Muldrotha. After that, use Capsule each turn on Firemane Commando, Gisela, then Drana. Replay Sakura-Tribe Elder for lands. Tutor for Massacre Wurm and Seal of Doom.

WIN PATH: Vrock plus a sacrifice every turn drains each opponent for 3. Add Gray Merchant or Syr Konrad, and take P3 (28) out first. P2 swings 18 in the air, or 36 with Akroma's Will, so we have about 2 turns.

THREATS & ANSWERS: 1) Conqueror, Vito, Exquisite Blood: Grist now, Seal of Doom later. 2) Lyra: Capsule next turn. 3) Firemane Commando, Gisela, a recast Giada: Capsule, then Grist. 4) Sephiroth: Grist before 4 deaths. Don't drain while Conqueror is alive.

HOLD: Vrock until Conqueror is dead and we have 5 spare mana. Soul-Guide Lantern: exile a Reanimate target from P4's graveyard or a Bruna from P2's, otherwise use it as a cantrip.

REPLAN IF: Muldrotha is removed (tax goes up by 2). Grist fails to resolve. Vito, Exquisite Blood or Sephiroth appears. P2 casts Akroma's Will or a wipe.
PILOT OVERRULED FORGE (action, MAIN2): chose [cast Grist, the Hunger Tide (from Graveyard): Grist, the Hunger Tide by Muldrotha, the Gra] instead of Forge's [cast Grist, the Hunger Tide (from Graveyard): Grist, the Hunger Tide by Muldrotha, the Gra]
PILOT OVERRULED FORGE (trigger-target, MAIN2): chose [Bloodthirsty Conqueror [P3, 5/5]] instead of Forge's [Lyra Dawnbringer [P2, 7/7, tapped]]
- US cast Muldrotha, the Gravetide
- US cast Grist, the Hunger Tide
- US activated Grist, the Hunger Tide
- left battlefield: Gravebreaker Lamia was put into Graveyard from Battlefield.
- US triggered Grist, the Hunger Tide targeting [Bloodthirsty Conqueror]
- left battlefield: Bloodthirsty Conqueror was put into Graveyard from Battlefield.

## Turn 21 (P2, round 6) | life: P2 76, P3 28, P4 41, US 28
- P2 cast Serra Paragon
- attack: P2 assigned Firemane Commando and Gisela, the Broken Blade to attack US.
- P2 triggered Firemane Commando
- left battlefield: Grist, the Hunger Tide was put into Graveyard from Battlefield.
Damage to US this turn: Gisela, the Broken Blade (combat) 5, Firemane Commando (combat) 6

## Turn 22 (P3, round 6) | life: P2 69, P3 28, P4 41, US 28
- P3 cast Patron of the Vein
- P3 triggered Edgar Markov
- P3 triggered Forerunner of the Legion targeting [Drana, Liberator of Malakir]
- P3 triggered Patron of the Vein targeting [Lyra Dawnbringer]
- P3 triggered Forerunner of the Legion targeting [Drana, Liberator of Malakir]
- left battlefield: Lyra Dawnbringer was put into Graveyard from Battlefield.
- P3 triggered Patron of the Vein
- P3 cast Cruel Celebrant
- P3 triggered Edgar Markov
- P3 triggered Forerunner of the Legion targeting [Drana, Liberator of Malakir]
- P3 triggered Forerunner of the Legion targeting [Drana, Liberator of Malakir]
- attack: P3 assigned Drana, Liberator of Malakir to attack P2.
- P3 triggered Drana, Liberator of Malakir

## Turn 23 (P4, round 6) | life: P2 69, P3 27, P4 41, US 28
- attack: P4 assigned Nether Traitor to attack P3.
- P4 cast Ophiomancer

## Turn 24 (OUR TURN, round 6) | life: P2 68, P3 28, P4 40, US 27
Our hand: Vrock, Soul-Guide Lantern, Baba Lysaga, Night Witch
Our graveyard (6): Arcane Signet, Sakura-Tribe Elder, Siren Stormtamer, Executioner's Capsule, Gravebreaker Lamia, Grist, the Hunger Tide
Board US: 5 lands; Birds of Paradise 0/1, Sol Ring, Muldrotha, the Gravetide 6/6
Board P2: 5 lands; Firemane Commando 5/4 {[P1P1]} (tapped 1), Gisela, the Broken Blade 4/3 (tapped 1), Serra Paragon 3/4
Board P3: 6 lands; Drana, Liberator of Malakir 4/5 {[P1P1 x 2]} (tapped 1), Vampire Token 2/2 [token] {[P1P1]} x3, Forerunner of the Legion 3/3 {[P1P1]}, Sol Ring (tapped 1), Patron of the Vein 5/5 {[P1P1]}, Vampire Token 1/1 [token], Cruel Celebrant 1/2
Board P4: 4 lands; Nether Traitor 1/1 (tapped 1), Ophiomancer 2/2, Snake Token 1/1 [token]
MEMO (start of our turn):
THIS TURN: 1) Cast Gravebreaker Lamia from the graveyard through the ENCHANTMENT lane (5: Swamp B, Sol Ring 2, Tropical, Forest). Tutor Massacre Wurm into the graveyard. 2) Cast Executioner's Capsule from the graveyard ({B}: Bog). Activate it ({1}{B}: Birds B, Forest) on Firemane Commando. That uses all 8 mana, with the creature lane left unused. Block ground attackers with Muldrotha (6/6) and Lamia (4/4 lifelink; block only attackers with 3 power or less). Never chump, and keep Birds alive. Patron exiles our dead creatures and pumps P3's Vampires.

TARGET: Next turn: Arcane Signet from the graveyard ({1} after Lamia's discount). Then Massacre Wurm from the graveyard ({2}{B}{B}{B}: Swamp, Bog, Signet, Sol Ring). Then Grist from the graveyard ({B}{G}: Birds, Forest). Wurm wipes P3's tokens, Forerunner, Celebrant, Gisela and P4's small creatures. Grist −2 (sacrifice Birds) then kills Patron or Drana.

WIN PATH: Wurm drains about 12 from P3 and 6 from P4, then Vrock plus a Capsule sacrifice each turn drains 3 per opponent. Tutor Gray Merchant or Syr Konrad after that. P3 dies first (27 life). P3 could hit us for about 20 next turn, so we must stabilise now.

THREATS & ANSWERS: 1) P3's board (Drana, Patron): Wurm, then Grist. 2) P2's fliers (Gisela, Paragon, a returning Giada): Capsule each turn. 3) Sephiroth: Grist before four deaths. Capsule can't hit black creatures.

HOLD: Vrock (5 mana) until after the Wurm turn. Soul-Guide Lantern for a Reanimate or Bruna target. Baba Lysaga for later.

REPLAN IF: Lamia is removed or P2 wipes the board, Muldrotha dies, Giada or Sephiroth is cast, Vito appears, or we drop below 15 life.
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Gravebreaker Lamia (from Graveyard): Gravebreaker Lamia - Creature 4 / 4 by Muldrotha] instead of Forge's [cast Executioner's Capsule (from Graveyard): Executioner's Capsule by Muldrotha, the Grave]
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Executioner's Capsule (from Graveyard): Executioner's Capsule by Muldrotha, the Grave] instead of Forge's [cast Executioner's Capsule (from Graveyard): Executioner's Capsule by Muldrotha, the Grave]
PILOT OVERRULED FORGE (action, MAIN1): chose [Firemane Commando [P2, 5/4, tapped]] instead of Forge's [Gisela, the Broken Blade [P2, 4/3, tapped]]
PILOT OVERRULED FORGE (attack, COMBAT_DECLARE_ATTACKERS): chose [attack P3 (27 life)] instead of Forge's [don't attack with it]
- P4 triggered Ophiomancer
- US cast Gravebreaker Lamia
- US triggered Gravebreaker Lamia
- US cast Executioner's Capsule
- left battlefield: Executioner's Capsule was put into Graveyard from Battlefield.
- US activated Executioner's Capsule targeting [Firemane Commando]
- left battlefield: Firemane Commando was put into Graveyard from Battlefield.
- P3 triggered Patron of the Vein
- attack: US assigned Muldrotha, the Gravetide to attack P3.
- attack: P3 assigned Cruel Celebrant and Forerunner of the Legion to block Muldrotha, the Gravetide.
- left battlefield: Muldrotha, the Gravetide was put into Graveyard from Battlefield.
- left battlefield: Forerunner of the Legion was put into Graveyard from Battlefield.
- P3 triggered Patron of the Vein
- P3 triggered Cruel Celebrant

## Turn 25 (P2, round 7)
- P2 cast Angel of Finality
- P2 triggered Angel of Finality targeting [P1]
- P2 cast Segovian Angel

## Turn 26 (P3, round 7) | life: P2 47, P3 28, P4 40, US 27
- P3 cast Edgar Markov
- attack: P3 assigned Edgar Markov, Patron of the Vein and Drana, Liberator of Malakir to attack P2.
- P3 triggered Edgar Markov
- P3 triggered Drana, Liberator of Malakir

## Turn 27 (P4, round 7) | life: P2 46, P3 28, P4 39, US 26
MEMO (executor escalation: we lost: Muldrotha, the Gravetide; our commander left the battlefield; P2: life 69→47 (-22)):
THIS TURN: Edict resolving: sacrifice Birds of Paradise and keep Gravebreaker Lamia (a 4/4 lifelink blocker whose discount matters once Muldrotha returns). We have no mana on P4's turn. Our turn, 7 mana (5 lands + Sol Ring): 1) Soul-Guide Lantern ({1}); its ETB exiles the best creature card in P4's or P3's graveyard (Reanimate insurance). 2) Vrock ({3}{B}{B}, B from Swamp and Bog). 3) Lantern {1}, tap, sacrifice: draw. That uses all 7 and turns on Vrock, so each opponent loses 3 at our end step. Exceptions: if we draw Toxic Deluge, cast it instead with X=6, before Vrock. It kills P3's tokens, Celebrant and Edgar, and Gisela, Paragon and Finality; we lose about 12 life to X plus Celebrant. If we draw Pernicious Deed, cast it (3) and hold 4 to activate X=4 on P3's turn.

TARGET: Muldrotha (8 mana, tax 2) once the graveyard has Birds and Lantern to replay. Draw toward Toxic Deluge, Pernicious Deed, Grist and Demonic Tutor. Massacre Wurm does NOT kill P3's 4/4 and 5/5 tokens.

WIN PATH: Vrock drains 3 per opponent each turn we sacrifice something. Then Baba Lysaga (sacrifice land, Sol Ring and Lamia: draw 3, drain 3), then Gray Merchant or Syr Konrad. P3 (about 50 power) is far faster than us.

THREATS & ANSWERS: 1) P3's army: Deluge or Deed only. 2) P2's fliers: Grist later. 3) Sephiroth, if cast: Grist or a removal draw. Don't feed creature deaths (Patron, Celebrant, Nether Traitor).

HOLD: Baba Lysaga until the turn after Vrock. Block only to prevent lethal, never chump.

REPLAN IF: we draw Deluge, Deed, Demonic Tutor or a land; Lamia dies; P3 attacks us; or Sephiroth or Vito lands.
ESCALATION (p=0.97): we lost: Muldrotha, the Gravetide; our commander left the battlefield; P2: life 69→47 (-22)
- P4 cast Sheoldred's Edict
- left battlefield: Birds of Paradise was put into Graveyard from Battlefield.
- left battlefield: Segovian Angel was put into Graveyard from Battlefield.
- left battlefield: Cruel Celebrant was put into Graveyard from Battlefield.
- P3 triggered Patron of the Vein
- P3 triggered Patron of the Vein
- P3 triggered Cruel Celebrant
- attack: P4 assigned Nether Traitor to attack P3.

## Turn 28 (OUR TURN, round 7) | life: P2 43, P3 25, P4 36, US 25
Our hand: Vrock, Soul-Guide Lantern, Baba Lysaga, Night Witch, Wooded Foothills
Our graveyard (0): 
Board US: 5 lands; Sol Ring, Gravebreaker Lamia 4/4
Board P2: 5 lands; Gisela, the Broken Blade 4/3, Serra Paragon 3/4, Angel of Finality 3/4
Board P3: 6 lands; Drana, Liberator of Malakir 10/11 {[P1P1 x 8]} (tapped 1), Vampire Token 7/7 [token] {[P1P1 x 6]} x3, Sol Ring (tapped 1), Patron of the Vein 11/11 {[P1P1 x 7]} (tapped 1), Vampire Token 6/6 [token] {[P1P1 x 5]}, Edgar Markov 8/8 {[P1P1 x 4]} (tapped 1)
Board P4: 4 lands; Nether Traitor 1/1 (tapped 1), Ophiomancer 2/2, Snake Token 1/1 [token]
MEMO (start of our turn):
THIS TURN: 1) Play Wooded Foothills and crack it (pay 1 life) for Bayou, which enters untapped: 8 mana. 2) Soul-Guide Lantern (Forest). Its ETB exiles the best creature card in P4's graveyard, or P3's if P4's is empty. 3) Pay {1} (Forest), tap and sacrifice the Lantern: draw. Then branch:
- Drew Toxic Deluge: cast it with X=11 (Swamp). It kills Patron, Drana, Edgar, all tokens, P2's angels and our Lamia. Then Baba Lysaga with the last 3.
- Drew Demonic Tutor: cast it (Bog) for Toxic Deluge, then Deluge X=11 (Bayou).
- Drew Pernicious Deed: cast it and hold 3. Activate X=3 at P3's beginning of combat to kill the tokens and Drana.
- Otherwise: cast Vrock (Swamp, Bog, Sol Ring, Tropical Island). The fetch and Lantern already left, so each opponent loses 3 at our end step.

TARGET: P3's army cleared, then Muldrotha (8), replaying Lantern and a fetch every turn with Vrock and Baba Lysaga out. Missing pieces: Toxic Deluge, Pernicious Deed, Demonic Tutor.

WIN PATH: Vrock drains 9 per turn. Baba Lysaga (sac a land, an artifact and Lamia) draws 3 and drains 3. Gray Merchant or Syr Konrad closes. P3 (56 power, first strike, flying) can kill us next turn, so survival comes first.

THREATS & ANSWERS: 1) P3's board (Patron, Drana, Edgar, tokens): only Deluge or Deed. 2) P2's fliers: Deluge, Grist later. 3) P4's Nether Traitor and deaths: Lantern exile. Don't feed creature deaths.

HOLD: Baba Lysaga (summoning sick; cast next turn unless Deluge resolves). Block only to prevent lethal.

REPLAN IF: P3 attacks us, Lamia or Vrock dies, Sephiroth or Vito lands, or we draw a wipe.
PILOT OVERRULED FORGE (search, MAIN1): chose [Bayou — Land - Swamp Forest — ({T}: Add {B} or {G}.)] instead of Forge's [Zagoth Triome — Land - Swamp Forest Island — ({T}: Add {B}, {G}, or {U}.) Zagoth Triome en]
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Soul-Guide Lantern (from Hand): Soul-Guide Lantern [Forge's heuristic AI would not do] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Vrock (from Hand): Vrock - Creature 3 / 3 [Forge's heuristic AI would not do this: Ca] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
- left battlefield: Wooded Foothills was put into Graveyard from Battlefield.
- US activated Wooded Foothills
- US cast Soul-Guide Lantern
- US triggered Soul-Guide Lantern targeting [Bloodthirsty Conqueror]
- left battlefield: Soul-Guide Lantern was put into Graveyard from Battlefield.
- US activated Soul-Guide Lantern
- US cast Vrock
- US triggered Vrock

## Turn 29 (P2, round 8) | life: P2 48, P3 18, P4 36, US 25
- P2 cast Angel of Vitality
- attack: P2 assigned Gisela, the Broken Blade and Serra Paragon to attack P3.
- P2 cast Folk Hero

## Turn 30 (P3, round 8) | life: P2 4, P3 18, P4 36, US 25
- P3 cast Sorin, Imperious Bloodlord
- attack: P3 assigned Edgar Markov, Patron of the Vein, Drana, Liberator of Malakir, Vampire Token, Vampire Token, Vampire Token and Vampire Token to attack P2.
- P3 triggered Edgar Markov
- left battlefield: Angel of Vitality was put into Graveyard from Battlefield.
- P3 triggered Patron of the Vein
- left battlefield: Angel of Finality was put into Graveyard from Battlefield.
- P3 triggered Patron of the Vein
- P3 cast Phyrexian Arena

## Turn 31 (P4, round 8)
- P4 cast Skullclamp
- P4 activated Skullclamp targeting [Ophiomancer]
- attack: P4 assigned Nether Traitor to attack Sorin, Imperious Bloodlord.

## Turn 32 (OUR TURN, round 8) | life: P2 0, P3 15, P4 33, US 28
Our hand: Baba Lysaga, Night Witch, Mishra's Bauble
Our graveyard (2): Wooded Foothills, Soul-Guide Lantern
Board US: 6 lands; Sol Ring, Gravebreaker Lamia 4/4, Vrock 3/3
Board P2: 5 lands; Gisela, the Broken Blade 4/3 (tapped 1), Serra Paragon 3/4 (tapped 1), Folk Hero
Board P3: 6 lands; Drana, Liberator of Malakir 13/14 {[P1P1 x 11]} (tapped 1), Vampire Token 10/10 [token] {[P1P1 x 9]} x3 (tapped 3), Sol Ring (tapped 1), Patron of the Vein 14/14 {[P1P1 x 10]} (tapped 1), Vampire Token 9/9 [token] {[P1P1 x 8]} (tapped 1), Edgar Markov 11/11 {[P1P1 x 7]} (tapped 1), Sorin, Imperious Bloodlord {[LOYALTY x 3]}, Phyrexian Arena
Board P4: 4 lands; Nether Traitor 1/1 (tapped 1), Ophiomancer 3/1, Snake Token 1/1 [token], Skullclamp
MEMO (start of our turn):
THIS TURN: 1) Cast Muldrotha, the Gravetide from the command zone for 8 (6 lands plus Sol Ring). 2) Play Wooded Foothills from the graveyard. Don't crack it yet. 3) Cast Soul-Guide Lantern from the graveyard for 0 (Lamia's discount). Its ETB then has no target, so it can't exile our fetch. 4) Crack Foothills (pay 1 life) for a basic Forest, which enters untapped. 5) Pay {1} (the new Forest), tap and sacrifice Lantern: draw. 6) Cast Mishra's Bauble and sacrifice it, looking at our own top card. 7) Combat: attack P2 with Gravebreaker Lamia only. P2 is at 4 with every creature and land tapped, so this is lethal, and lifelink puts us to 28. Keep Vrock and Muldrotha home. 8) At our end step, Vrock drains 3 from P3 and P4.

TARGET: P3's army wiped with Muldrotha, Vrock, Baba Lysaga and Lamia surviving. Missing: Toxic Deluge (from hand), Pernicious Deed (castable from the graveyard), Demonic Tutor.

WIN PATH: Vrock drains 3 per opponent each turn and Baba Lysaga adds 3. Gray Merchant or Syr Konrad finishes. P3's board (80+ power) can kill us next turn, so we cannot outrace it.

THREATS & ANSWERS: 1) P3's Patron, Drana, Edgar and tokens: Deluge at X=15 or Deed at X=6. Block Drana or Patron with Vrock and a token with Muldrotha, only to prevent lethal. 2) P4's Skullclamp and deaths: recast Lantern to exile their graveyard. Avoid needless chumps.

HOLD: Baba Lysaga; there's no mana left this turn. Next turn, spend 9+ mana on a wipe first, then Baba.

REPLAN IF: P2 survives combat, we draw a wipe or tutor, P3 attacks P4 instead, or Muldrotha is removed.
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Muldrotha, the Gravetide (from Command): Muldrotha, the Gravetide - Creature 6 / 6 [F] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN1): chose [play land Wooded Foothills (from Graveyard): Play land by Muldrotha, the Gravetide (100) (] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Mishra's Bauble (from Hand): Mishra's Bauble] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN1): chose [activate Mishra's Bauble (from Battlefield): {T}, Sacrifice Mishra's Bauble: Look at the t] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Mishra's Bauble (from Graveyard): Mishra's Bauble by Muldrotha, the Gravetide (100) (] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN1): chose [activate Mishra's Bauble (from Battlefield): {T}, Sacrifice Mishra's Bauble: Look at the t] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (attack, COMBAT_DECLARE_ATTACKERS): chose [attack P2 (4 life)] instead of Forge's [don't attack with it]
- US cast Muldrotha, the Gravetide
- left battlefield: Wooded Foothills was put into Graveyard from Battlefield.
- US activated Wooded Foothills
- US cast Mishra's Bauble
- left battlefield: Mishra's Bauble was put into Graveyard from Battlefield.
- US activated Mishra's Bauble targeting [P3]
- US cast Mishra's Bauble
- left battlefield: Mishra's Bauble was put into Graveyard from Battlefield.
- US activated Mishra's Bauble targeting [P3]
- attack: US assigned Gravebreaker Lamia to attack P2.
- US triggered Vrock

## Turn 33 (P3, round 9) | life: P2 0, P3 14, P4 -5, US 28
- P3 triggered Phyrexian Arena
- US triggered Mishra's Bauble
- US triggered Mishra's Bauble
- P3 cast Olivia's Wrath
- left battlefield: Nether Traitor was put into Graveyard from Battlefield.
- left battlefield: Ophiomancer was put into Graveyard from Battlefield.
- left battlefield: Gravebreaker Lamia was put into Graveyard from Battlefield.
- left battlefield: Vrock was put into Graveyard from Battlefield.
- left battlefield: Muldrotha, the Gravetide was put into Graveyard from Battlefield.
- P3 triggered Patron of the Vein
- P3 triggered Patron of the Vein
- P3 triggered Patron of the Vein
- P3 triggered Patron of the Vein
- P3 triggered Patron of the Vein
- P3 triggered Patron of the Vein
- P4 triggered Skullclamp
- attack: P3 assigned Patron of the Vein, Drana, Liberator of Malakir, Edgar Markov, Vampire Token, Vampire Token, Vampire Token and Vampire Token to attack P4.
- P3 triggered Edgar Markov
- P3 triggered Drana, Liberator of Malakir

## Turn 34 (OUR TURN, round 9)
Our hand: Baba Lysaga, Night Witch, Waterlogged Grove, Scalding Tarn, Farseek
Our graveyard (3): Soul-Guide Lantern, Wooded Foothills, Mishra's Bauble
Board US: 7 lands; Sol Ring
Board P3: 6 lands; Drana, Liberator of Malakir 21/22 {[P1P1 x 19]} (tapped 1), Vampire Token 18/18 [token] {[P1P1 x 17]} x3 (tapped 3), Sol Ring (tapped 1), Patron of the Vein 22/22 {[P1P1 x 18]} (tapped 1), Vampire Token 17/17 [token] {[P1P1 x 16]} (tapped 1), Edgar Markov 19/19 {[P1P1 x 15]} (tapped 1), Sorin, Imperious Bloodlord {[LOYALTY x 3]}, Phyrexian Arena
MEMO (start of our turn):
THIS TURN: Olivia's Wrath killed our board, and P3 swings about 135 power next turn, including 43 in flyers. We are at 28, so only a wipe saves us. Dig for one:
1) Play Waterlogged Grove as the land drop.
2) Cast Farseek using Forest plus Sol Ring, fetching Underground Sea. One colourless floats.
3) Use the floating colourless and tap and sacrifice Grove to draw a card.
4) With the 6 remaining lands:
- If we drew Toxic Deluge: cast it with X=22 (we go to 6), then cast Baba Lysaga with the last 3.
- If we drew Demonic Tutor (2 mana): get Toxic Deluge and cast it with X=22 (3 mana).
- Otherwise: cast Baba Lysaga and pass. We can't afford Muldrotha (10).

TARGET: P3's board empty, then Muldrotha online to recast Mishra's Bauble and Soul-Guide Lantern, with Baba Lysaga draining.

WIN PATH: After a wipe, P3 is at 14. Two Baba Lysaga activations (sacrifice a land, an artifact and a creature) plus combat finish them. Tutor Gray Merchant.

THREATS & ANSWERS: 1) The P3 army: Toxic Deluge X=22 is the only out. Pernicious Deed needs 9 mana, so skip it this turn. 2) Sorin (3 loyalty) can put a Vampire from hand into play and gains them life: attack it after a wipe.

HOLD: Scalding Tarn for next turn's land drop.

REPLAN IF: We draw Pernicious Deed, Assassin's Trophy or Demonic Tutor and want another line, or P3 doesn't attack.
PILOT OVERRULED FORGE (action, MAIN1): chose [play land Waterlogged Grove (from Hand): Play land] instead of Forge's [cast Farseek (from Hand): Search your library for a Plains, Island, Swamp, or Mountain car]
PILOT OVERRULED FORGE (search, MAIN1): chose [Underground Sea — Land - Island Swamp — ({T}: Add {U} or {B}.)] instead of Forge's [Watery Grave — Land - Island Swamp — ({T}: Add {U} or {B}.) As Watery Grave enters, you ma]
PILOT OVERRULED FORGE (action, MAIN1): chose [activate Waterlogged Grove (from Battlefield): {1}, {T}, Sacrifice Waterlogged Grove: Draw] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
- US cast Farseek
- left battlefield: Waterlogged Grove was put into Graveyard from Battlefield.
- US activated Waterlogged Grove
- US cast Baba Lysaga, Night Witch

## Turn 35 (P3, round 9) | life: P2 0, P3 16, P4 -5, US -18
- P3 triggered Phyrexian Arena
- P3 cast Markov Baron
- P3 triggered Edgar Markov
- P3 activated Sorin, Imperious Bloodlord
- P3 triggered Sorin, Imperious Bloodlord targeting [Baba Lysaga, Night Witch]
- left battlefield: Baba Lysaga, Night Witch was put into Graveyard from Battlefield.
- P3 triggered Patron of the Vein
- P3 cast Blade of the Bloodchief
- P3 activated Blade of the Bloodchief targeting [Drana, Liberator of Malakir]
- attack: P3 assigned Patron of the Vein, Drana, Liberator of Malakir, Edgar Markov, Vampire Token, Vampire Token, Vampire Token and Vampire Token to attack US.
- P3 triggered Edgar Markov
- Game Outcome: US has lost because life total reached 0
- Game Outcome: P2 has lost because life total reached 0
- Game Outcome: P3 has won because all opponents have lost
- Game Outcome: P4 has lost because life total reached 0
Damage to US this turn: Drana, Liberator of Malakir (combat) 24, Edgar Markov (combat) 22