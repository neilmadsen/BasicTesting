# pod03-g3: we are P4; opponents P1 Teval, the Balanced Scale, P2 Giada, Font of Hope, P3 Edgar Markov
Result: Turn 32; P1 has lost because life total reached 0; P2 has won because all opponents have lost; P3 has lost because life total reached 0; US has lost because life total reached 0

## Turn 1 (P1, round 1)

## Turn 2 (P2, round 1)

## Turn 3 (P3, round 1)
- P3 cast Dark Ritual

## Turn 4 (OUR TURN, round 1)
Our hand: Animate Dead, Kaya's Ghostform, Tropical Island, Assassin's Trophy, Darkslick Shores, Bojuka Bog, Ratchet Bomb, Demonic Tutor
Our graveyard (0): 
Board P1: 1 lands; no nonland permanents
Board P2: 1 lands; no nonland permanents
Board P3: 1 lands; no nonland permanents
Board US: 0 lands; no nonland permanents
MEMO (start of our turn):
THIS TURN: Play Darkslick Shores now, while it still enters untapped (0 other lands). Cast nothing. We have no 1-mana play: Ghostform has no target. Pass.

TARGET: Muldrotha on 6 lands around our turn 6, with Ratchet Bomb and Animate Dead/Ghostform recurring each turn. Kaya's Ghostform goes on Muldrotha. Missing pieces: Executioner's Capsule, Claws of Gix, Pernicious Deed, and Sol Ring or Arcane Signet to speed Muldrotha up.

WIN PATH: Control through turn 7-8, then Gray Merchant/Syr Konrad loops through the creature lane plus Muldrotha beats. P3 is fastest: he cast Dark Ritual on turn 1, which points to a turn 6-7 kill. Our clock is slower, so we must survive first.

THREATS & ANSWERS:
1. P3 Vampires. Ratchet Bomb held at 0 wipes the tokens. Assassin's Trophy goes on Vito, Exquisite Blood or Skullclamp. Don't chump-block.
2. P2 Giada. Trophy if she lands before P3 shows a combo piece. Otherwise tick Ratchet Bomb to 2.
3. P1 Teval. Bojuka Bog when his graveyard is stacked or Living Death is likely.

Next turn: play Tropical Island. Cast Ratchet Bomb (2) and leave it at 0 counters. If P3 or P2 has a kill-on-sight card out, hold Trophy (B from Shores, G from Tropical) instead. Our 3rd land is Bog, unless we need untapped mana. Then Demonic Tutor: Toxic Deluge if P3 goes wide, otherwise Sol Ring or Arcane Signet.

HOLD: Assassin's Trophy for a kill-on-sight target only, never a vanilla creature. Hold Bojuka Bog for P1's graveyard. Keep Ghostform for Muldrotha.

REPLAN IF: P3 goes wide early (Deluge now). Someone mills our threats. A Vito combo piece appears (Trophy immediately).

## Turn 5 (P1, round 2)

## Turn 6 (P2, round 2)
- P2 cast Giada, Font of Hope

## Turn 7 (P3, round 2)

## Turn 8 (OUR TURN, round 2)
Our hand: Animate Dead, Kaya's Ghostform, Tropical Island, Assassin's Trophy, Bojuka Bog, Ratchet Bomb, Demonic Tutor, Bloodstained Mire
Our graveyard (0): 
Board P1: 2 lands; no nonland permanents
Board P2: 2 lands; Giada, Font of Hope 2/2
Board P3: 2 lands; no nonland permanents
Board US: 1 lands; no nonland permanents
MEMO (start of our turn):
THIS TURN: Play Tropical Island, keeping Mire and Bog for later drops. Cast nothing at sorcery speed. Hold Assassin's Trophy (B from Shores, G from Tropical) through the opponents' turns and fire it at the first match in this list:
(1) P3 lands Vito, Exquisite Blood, Bloodthirsty Conqueror or Skullclamp: Trophy it.
(2) P2 resolves Archangel of Thune, Righteous Valkyrie or Avacyn: Trophy it.
(3) P2 casts any other Angel: Trophy Giada in response, so the Angel enters without counters.
(4) Nothing above happened: Trophy Giada at the end of P3's turn.

TARGET: Next turn, play Bloodstained Mire and fetch Overgrown Tomb or Bayou untapped. Then Demonic Tutor for Sol Ring, cast Sol Ring, and use its 2 mana for Ratchet Bomb, left at 0 counters. Muldrotha around our turn 5 with Kaya's Ghostform on her. Later tutor or draw targets: Executioner's Capsule, Claws of Gix, Pernicious Deed.

WIN PATH: Lock the board, then Gray Merchant and Syr Konrad loops plus Muldrotha beats, closing turns 9-12. P3 (Dark Ritual, kill turns 6-8) and P2 (turns 6-8) are faster, so survive first.

THREATS & ANSWERS:
1. P3 Vampire tokens: Ratchet Bomb at 0, or Toxic Deluge via Tutor if he goes wide before the Bomb lands.
2. P2 Giada and Angels: Trophy now; later Ratchet Bomb ticked to 2 or 4.
3. P1 Teval self-mill: Bojuka Bog once his yard is stacked or Living Death is likely.
Don't chump-block into P3. Don't give anyone life.

HOLD: Trophy for kill-on-sight targets only. Bog for P1's yard. Ghostform for Muldrotha.

REPLAN IF: Trophy fires on a Vampire piece, then Tutor for Toxic Deluge or another answer instead of Sol Ring. P3 has 4+ tokens before our turn: Deluge is the Tutor target. An opponent Bogs or mills us.
- US cast Assassin's Trophy targeting [Giada, Font of Hope]
- left battlefield: Giada, Font of Hope was put into Graveyard from Battlefield.

## Turn 9 (P1, round 3)
- P1 cast Shigeki, Jukai Visionary

## Turn 10 (P2, round 3)
- P2 cast Giada, Font of Hope

## Turn 11 (P3, round 3) | life: P3 39
- left battlefield: Marsh Flats was put into Graveyard from Battlefield.
- P3 activated Marsh Flats

## Turn 12 (OUR TURN, round 3) | life: P3 39, US 39
Our hand: Animate Dead, Kaya's Ghostform, Bojuka Bog, Ratchet Bomb, Demonic Tutor, Bloodstained Mire, Drowned Catacomb
Our graveyard (1): Assassin's Trophy
Board P1: 2 lands; Shigeki, Jukai Visionary 1/3
Board P2: 4 lands; Giada, Font of Hope 2/2
Board P3: 3 lands; no nonland permanents
Board US: 2 lands; no nonland permanents
MEMO (start of our turn):
THIS TURN: Crack Bloodstained Mire (1 life) for Bayou. Demonic Tutor for Sol Ring (Shores + Bayou). Cast Sol Ring (Tropical Island). Tap Sol Ring for Ratchet Bomb and leave it untapped at 0. Keep Drowned Catacomb for next turn; it enters untapped because Tropical Island is an Island. During opponents' turns, pop Bomb at 0 if P3 has 2+ tokens. Otherwise tick it to 1 at the end of P3's turn. Never pop at 1: that kills our Sol Ring.

TARGET: Next turn, play Catacomb. Cast Muldrotha for exactly 6: Catacomb B, Bayou G, Tropical U, Shores and Sol Ring for the generic. The turn after, Ghostform on Muldrotha, and replay Mire from the graveyard as the land drop. Next tutor targets: Executioner's Capsule, Claws of Gix, Pernicious Deed, Gray Merchant.

WIN PATH: Muldrotha recurs Bomb, Capsule and Seals each turn to lock the board, then Gray Merchant and Syr Konrad drain, closing around turns 9-11. P2 and P3 threaten turns 6-8, so survive first.

THREATS & ANSWERS:
1. P3 Vampire tokens and Vito/Exquisite Blood: Bomb at 0 for tokens; Capsule or Seal via Muldrotha for Vito or Blood.
2. P2 Giada (MV 2): tick Bomb to 2 and pop it, which also kills P1's Shigeki. Recast the Bomb later with Muldrotha.
3. P1 Teval self-mill: Bojuka Bog when his yard is stacked or Living Death is likely.
Don't chump-block P3. Give no one life.

HOLD: Ghostform for Muldrotha. Bog for P1's yard. Animate Dead for the best creature in an opponent's graveyard.

REPLAN IF: Sol Ring is answered (Muldrotha slips a turn; cast Bomb or Ghostform plays instead). P3 goes wide early. P2 lands Thune, Avacyn or Valkyrie: tutor or recur removal first.
PILOT OVERRULED FORGE (action, MAIN1): chose [play land Bloodstained Mire (from Hand): Play land] instead of Forge's [play land Drowned Catacomb (from Hand): Play land]
PILOT OVERRULED FORGE (search, MAIN1): chose [Bayou — Land - Swamp Forest — ({T}: Add {B} or {G}.)] instead of Forge's [Underground Sea — Land - Island Swamp — ({T}: Add {U} or {B}.)]
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Demonic Tutor (from Hand): Search your library for a card, put that card into your ha] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (search, MAIN1): chose [Executioner's Capsule — Artifact — {1}{B}, {T}, Sacrifice Executioner's Capsule: Destroy t] instead of Forge's [Kokusho, the Evening Star — Legendary Creature - Dragon Spirit — Flying When Kokusho, the ]
- left battlefield: Bloodstained Mire was put into Graveyard from Battlefield.
- US activated Bloodstained Mire
- US cast Demonic Tutor
- US cast Executioner's Capsule

## Turn 13 (P1, round 4)

## Turn 14 (P2, round 4) | life: P1 41, P3 39, US 39
- P2 cast Swords to Plowshares targeting [Shigeki, Jukai Visionary]
- left battlefield: Shigeki, Jukai Visionary was put into Exile from Battlefield.
- P2 cast Lyra Dawnbringer

## Turn 15 (P3, round 4)
- P3 cast Charismatic Conqueror
- P3 triggered Edgar Markov

## Turn 16 (OUR TURN, round 4)
Our hand: Animate Dead, Kaya's Ghostform, Bojuka Bog, Ratchet Bomb, Drowned Catacomb
Our graveyard (3): Assassin's Trophy, Bloodstained Mire, Demonic Tutor
Board P1: 2 lands; no nonland permanents
Board P2: 5 lands; Giada, Font of Hope 3/3 (tapped 1), Lyra Dawnbringer 6/6 {[P1P1]}
Board P3: 3 lands; Vampire Token 1/1 [token], Charismatic Conqueror 2/2
Board US: 3 lands; Executioner's Capsule
MEMO (start of our turn):
THIS TURN: Play Drowned Catacomb; it enters untapped because Tropical Island is an Island. That gives 4 mana. Main phase 1: activate Executioner's Capsule on Lyra Dawnbringer (Catacomb B + Shores). Then cast Animate Dead on Lyra from P2's graveyard (Bayou B + Tropical). When P3's Charismatic Conqueror triggers, DON'T tap Lyra; let P3 have the 1/1 so Lyra stays up as our blocker. No attacks.

TARGET: Lyra on our side, then Ratchet Bomb, then Muldrotha at 6 lands. Muldrotha then recurs Capsule and Bomb every turn. Tutor targets: Sol Ring, Claws of Gix, Pernicious Deed, Gray Merchant (via Gravebreaker Lamia or Survival of the Fittest).

WIN PATH: Lyra (4/5 flying, first strike, lifelink) holds the air and pressures P2. Muldrotha locks the board, then Gray Merchant and Syr Konrad drain. P2 and P3 threaten around turns 6-8, so defend first.

THREATS & ANSWERS:
1. P3 tokens and Vito/Exquisite Blood: Ratchet Bomb at 0 for tokens; Capsule via Muldrotha for Vito.
2. P2 Giada and new Angels: Capsule recurs once Muldrotha is out. Don't pop Bomb at 2 while Animate Dead holds Lyra; it would kill our Aura and lose Lyra.
3. P1 Living Death or reanimation: Bojuka Bog on P1's yard.
Never chump-block P3.

HOLD: Kaya's Ghostform (B) for Muldrotha, or for Lyra if she's targeted later. Bog for P1's stacked yard. Ratchet Bomb for next turn (2 mana).

REPLAN IF: Flawless Maneuver fizzles the Capsule (cast Ratchet Bomb instead). Lyra is removed. P3 goes wide fast (pop Bomb at 0). P1 casts Living Death (Bog in response isn't possible; play it at our next land drop).
- left battlefield: Executioner's Capsule was put into Graveyard from Battlefield.
- US activated Executioner's Capsule targeting [Lyra Dawnbringer]
- left battlefield: Lyra Dawnbringer was put into Graveyard from Battlefield.
- US cast Animate Dead targeting [Lyra Dawnbringer]
- US triggered Animate Dead
- P3 triggered Charismatic Conqueror

## Turn 17 (P1, round 5)
- P1 cast Awaken the Honored Dead
- P1 triggered Awaken the Honored Dead targeting [Lyra Dawnbringer]
- left battlefield: Lyra Dawnbringer was put into Graveyard from Battlefield.
- left battlefield: Animate Dead was put into Graveyard from Battlefield.
- US triggered Animate Dead

## Turn 18 (P2, round 5) | life: P1 41, P3 37, US 39
- P2 cast Lightning Greaves
- P3 triggered Charismatic Conqueror
- P2 activated Lightning Greaves targeting [Giada, Font of Hope]
- attack: P2 assigned Giada, Font of Hope to attack P3.
- P2 cast Arcane Signet
- P3 triggered Charismatic Conqueror

## Turn 19 (P3, round 5) | life: P1 41, P2 38, P3 37, US 39
- attack: P3 assigned Charismatic Conqueror to attack P2.
- P3 cast Forerunner of the Legion
- P3 triggered Edgar Markov
- P3 triggered Forerunner of the Legion

## Turn 20 (OUR TURN, round 5)
Our hand: Kaya's Ghostform, Bojuka Bog, Ratchet Bomb, Dalek Drone, Gravebreaker Lamia
Our graveyard (5): Assassin's Trophy, Bloodstained Mire, Demonic Tutor, Executioner's Capsule, Animate Dead
Board P1: 3 lands; Awaken the Honored Dead {[LORE]}
Board P2: 6 lands; Giada, Font of Hope 2/2, Lightning Greaves (tapped 1), Arcane Signet (tapped 1)
Board P3: 3 lands; Vampire Token 1/1 [token] x2, Charismatic Conqueror 2/2, Forerunner of the Legion 2/2
Board US: 4 lands; no nonland permanents
MEMO (start of our turn):
THIS TURN: Play Bojuka Bog, targeting P1's graveyard. Don't target P2's: Lyra stays there for our Animate Dead via Muldrotha. Cast Ratchet Bomb (2 mana). When P3's Charismatic Conqueror triggers, tap Bomb for a counter in response, so it's at 1. P3 gets a 1/1 lifelink token; accept that. No attacks. Nothing else fits, since Drone and Lamia cost 5.

TARGET: Next turn: at 6 lands cast Muldrotha, at 5 cast Dalek Drone on Forerunner or Conqueror. Tick Bomb to 2 on our next turn, then pop it the turn after. At 2 it destroys Giada (shroud doesn't matter), Greaves, Signet and Conqueror. Then Muldrotha recurs Capsule, Animate Dead (Lyra from P2's yard) and Bomb. Lamia tutor target: Pernicious Deed. Later: Gray Merchant.

WIN PATH: Grind with recurring Capsule, Bomb and Drone, then close with Gray Merchant and Syr Konrad drains plus Drone and Muldrotha beats. P2 and P3 clock around turns 6-8, so defend first.

THREATS & ANSWERS: 1) P3 going wide or Edgar: Bomb at 1 is too late for tokens; Drone kills Edgar. Never chump-block P3. 2) P2 Giada and Angels: Bomb at 2, then Capsule. 3) P1 Awaken the Honored Dead III or Living Death: Drone later, Bog replay via Muldrotha.

HOLD: Kaya's Ghostform (B) for Muldrotha once he lands. Don't cast Muldrotha without Ghostform mana unless P2 and P3 are tapped out.

REPLAN IF: Bomb is destroyed (switch to Drone plus Capsule). Vito, Exquisite Blood or Skullclamp appears (Drone or Capsule first). P2 lands a big Angel (Drone it; Capsule can't hit black creatures).
PILOT OVERRULED FORGE (trigger-target, MAIN1): chose [P1 (41 life)] instead of Forge's [P2 (38 life)]
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Ratchet Bomb (from Hand): Ratchet Bomb [Forge's heuristic AI would not do this: CantP] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
- US triggered Bojuka Bog targeting [P1]
- US cast Ratchet Bomb
- P3 triggered Charismatic Conqueror
- US activated Ratchet Bomb
- P3 triggered Forerunner of the Legion targeting [Charismatic Conqueror]

## Turn 21 (P1, round 6) | life: P1 40, P2 38, P3 37, US 39
- P1 triggered Awaken the Honored Dead
- P1 cast Teval, the Balanced Scale
- P3 triggered Charismatic Conqueror

## Turn 22 (P2, round 6)
- P2 cast Wrath of God
- left battlefield: Giada, Font of Hope was put into Graveyard from Battlefield.
- left battlefield: Charismatic Conqueror was put into Graveyard from Battlefield.
- left battlefield: Forerunner of the Legion was put into Graveyard from Battlefield.
- left battlefield: Teval, the Balanced Scale was put into Graveyard from Battlefield.

## Turn 23 (P3, round 6)
- P3 cast Black Market Connections

## Turn 24 (OUR TURN, round 6)
Our hand: Kaya's Ghostform, Dalek Drone, Gravebreaker Lamia
Our graveyard (5): Assassin's Trophy, Bloodstained Mire, Demonic Tutor, Executioner's Capsule, Animate Dead
Board P1: 4 lands; Awaken the Honored Dead {[LORE x 2]}
Board P2: 7 lands; Lightning Greaves, Arcane Signet
Board P3: 3 lands; Black Market Connections
Board US: 5 lands; Ratchet Bomb {[CHARGE]}
MEMO (start of our turn):
THIS TURN: Wrath of God cleared every creature, so nobody threatens lethal. Tap Ratchet Bomb to move it from 1 to 2 counters (free). If you draw a land: play it and cast Muldrotha with all 6 mana. If you draw no land: cast Gravebreaker Lamia (5 mana) and put Sol Ring into our graveyard. Don't cast Dalek Drone into empty boards, since its kill would be wasted. No attacks.

TARGET: Muldrotha, Lamia and Sol Ring on board, with Bomb at 2 counters. Each turn, recast Capsule and Animate Dead from the graveyard and replay Bloodstained Mire from it. Next Lamia or Muldrotha tutor target: Pernicious Deed, then Gray Merchant.

WIN PATH: Stabilise, then drain with Gray Merchant and Syr Konrad while Muldrotha and Drone attack. P3 is the fastest opponent (turns 6–8 or the Vito combo), so we close around turn 10+.

THREATS & ANSWERS:
1) P3: Vito, Exquisite Blood, Skullclamp or Edgar. Answer with Drone, or Capsule once Muldrotha is out. Never chump-block P3.
2) P2 recasting Giada with Greaves. Pop Bomb at 2, which kills Giada, Greaves, Signet and Charismatic Conqueror.
3) P1's Awaken chapter III next turn, then Teval. Answer Teval with Drone.

HOLD: Keep Dalek Drone until an opponent has a creature worth killing. Save Kaya's Ghostform ({B}) for Muldrotha once we have 7 mana. Pop Bomb only when it hits 2+ relevant permanents.

REPLAN IF: Muldrotha is exiled or stolen (Captivating Vampire). Vito plus Exquisite Blood lands (Drone Vito immediately). P3 goes wide with 0-MV tokens (reconsider Bomb's count). We miss land drops for 2 turns.
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Gravebreaker Lamia (from Hand): Gravebreaker Lamia - Creature 4 / 4 [Forge's heuristi] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (search, MAIN1): chose [Pernicious Deed — Enchantment — {X}, Sacrifice Pernicious Deed: Destroy each artifact, cre] instead of Forge's [Massacre Wurm — Creature - Phyrexian Wurm — When Massacre Wurm enters, creatures your oppo]
- US activated Ratchet Bomb
- US cast Gravebreaker Lamia
- US triggered Gravebreaker Lamia

## Turn 25 (P1, round 7)
- P1 triggered Awaken the Honored Dead
- left battlefield: Awaken the Honored Dead was put into Graveyard from Battlefield.
- P1 triggered Awaken the Honored Dead targeting [Crypt of Agadeem]
- P1 cast Lethal Scheme targeting [Gravebreaker Lamia]
- left battlefield: Gravebreaker Lamia was put into Graveyard from Battlefield.

## Turn 26 (P2, round 7) | life: P1 40, P2 38, P3 32, US 39
- P2 cast Firemane Commando
- P2 activated Lightning Greaves targeting [Firemane Commando]
- P2 cast Angel of Jubilation
- P2 triggered Path of Ancestry
- attack: P2 assigned Firemane Commando to attack P3.

## Turn 27 (P3, round 7) | life: P1 40, P2 38, P3 31, US 39
- P3 triggered Black Market Connections
- P3 cast Demonic Tutor
- P3 cast Sol Ring

## Turn 28 (OUR TURN, round 7) | life: P1 40, P2 35, P3 31, US 39
Our hand: Kaya's Ghostform, Dalek Drone, Barrin, Master Wizard
Our graveyard (7): Assassin's Trophy, Bloodstained Mire, Demonic Tutor, Executioner's Capsule, Animate Dead, Pernicious Deed, Gravebreaker Lamia
Board P1: 5 lands; no nonland permanents
Board P2: 7 lands; Lightning Greaves, Arcane Signet (tapped 1), Firemane Commando 5/4 (tapped 1), Angel of Jubilation 3/3
Board P3: 3 lands; Black Market Connections, Treasure Token [token], Sol Ring
Board US: 5 lands; Ratchet Bomb {[CHARGE x 2]}
MEMO (start of our turn):
THIS TURN: Draw first. Leave Ratchet Bomb untapped at 2: it only works while untapped. If you drew a land, play it and cast Muldrotha (6, tapping out). P2 is fully tapped and P1 has 1 land open. If you drew no land, cast Barrin (1UU from Darkslick, Tropical and Catacomb) and keep Bayou and Bog open. On opponents' turns, Barrin ({2}, sacrifice Bojuka Bog) bounces Vito, Giada, Teval or Captivating Vampire. Pop Bomb at instant speed once Giada resolves or P3 lands a 2-drop: with Greaves and Signet that is 3 or more hits. No attacks.

TARGET: Muldrotha with Ghostform, Barrin and Lamia recast. Each turn replay Mire and recast Capsule and Deed. Lamia's tutor target: Gray Merchant; if P3 goes wide, Seal of Doom.

WIN PATH: Gray Merchant drains, rebought by Barrin bouncing it or Muldrotha's creature lane, plus Drone and Muldrotha attacks. We close in about 5 of our turns. P3's Vito combo is the fastest threat.

THREATS & ANSWERS:
1) P3 fetched something with Demonic Tutor, likely Vito, Exquisite Blood or Bloodthirsty Conqueror. Answer at instant speed with Barrin's bounce or Bomb. Vito is black, so Capsule can't hit him; use Drone. Deed (X=5) kills Blood.
2) P2 has 8 power of fliers. Drone kills Angel of Jubilation. Bomb at 2 kills Greaves, Giada and Signet; then Capsule kills Commando.
3) P1 recasting Teval (black): Drone or Barrin.
Never chump-block P3. Jubilation stops us sacrificing creatures, so sacrifice lands or Bomb instead.

HOLD: Keep Ghostform ({B}) for Muldrotha next turn. Cast Drone next turn if Jubilation is still the best target, unless Vito appears first.

REPLAN IF: Vito plus Blood resolves; Muldrotha is exiled or stolen; Giada returns; P1's Living Death.
- US activated Ratchet Bomb
- US cast Dalek Drone
- US triggered Dalek Drone targeting [Angel of Jubilation]
- left battlefield: Angel of Jubilation was put into Graveyard from Battlefield.

## Turn 29 (P1, round 8) | life: P1 39, P2 35, P3 31, US 39
- P1 cast Will of the Sultai

## Turn 30 (P2, round 8) | life: P1 39, P2 35, P3 27, US 39
- attack: P2 assigned Firemane Commando to attack P3.
- P2 cast Archangel of Tithes

## Turn 31 (P3, round 8) | life: P1 39, P2 30, P3 26, US 39
- P3 triggered Black Market Connections
- P3 cast Edgar Markov
- attack: P3 assigned Edgar Markov to attack P2.
- P3 triggered Edgar Markov

## Turn 32 (OUR TURN, round 8) | life: P1 39, P2 30, P3 23, US 39
Our hand: Kaya's Ghostform, Barrin, Master Wizard, Secrets of the Dead
Our graveyard (7): Assassin's Trophy, Bloodstained Mire, Demonic Tutor, Executioner's Capsule, Animate Dead, Pernicious Deed, Gravebreaker Lamia
Board P1: 6 lands; no nonland permanents
Board P2: 7 lands; Lightning Greaves, Arcane Signet, Firemane Commando 4/3 (tapped 1), Archangel of Tithes 3/5
Board P3: 3 lands; Black Market Connections, Sol Ring (tapped 1), Edgar Markov 5/5 {[P1P1]} (tapped 1)
Board US: 5 lands; Ratchet Bomb {[CHARGE x 3]}, Dalek Drone 3/3
MEMO (start of our turn):
THIS TURN: Draw first. Tap Ratchet Bomb to tick it from 3 to 4 counters. At 4 it kills Firemane Commando and Archangel of Tithes; shroud from Greaves doesn't stop it. We have nothing at mana value 4. If you drew a land, play it and cast Muldrotha for 6, tapping out. P1 and P3 are fully tapped, and P2 has only about 4 open with 1 card and no counters. If you drew no land, cast Barrin (1UU from Darkslick, Tropical and Catacomb) and keep Bayou and Bog open. Attack P3 with Dalek Drone; P3 has no untapped blockers.

TARGET: Muldrotha wearing Ghostform, with Lamia recast. Each turn, replay Mire from the graveyard and recast Capsule, Deed and Drone. Lamia tutors Gray Merchant, or Seal of Doom if P3 goes wide.

WIN PATH: Gray Merchant drains of 7 or more, rebought by Barrin's bounce or Muldrotha's creature lane. Add Drone recasts (3 life each) and Muldrotha beats. About 4-5 of our turns. P3's Vito combo is the fastest threat.

THREATS & ANSWERS:
1) P3's Demonic Tutor target: Vito, Exquisite Blood or Bloodthirsty Conqueror. Barrin ({2}, sacrifice Drone, which we can recast) bounces Vito or Conqueror at instant speed. Vito is black, so Capsule can't hit him. For Blood, cast Assassin's Trophy from the graveyard with Muldrotha. Never chump-block P3.
2) P2's fliers: Bomb at 4 next turn.
3) Teval (black): Barrin or a Drone recast.

HOLD: Ghostform ({B}) goes on Muldrotha next turn. Pop Bomb only when untapped, from next turn onward.

REPLAN IF: Vito and Blood both land. Muldrotha is exiled or stolen. Giada returns (Bomb can't hit her at 4). P1 casts Living Death.
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Barrin, Master Wizard (from Hand): Barrin, Master Wizard - Creature 1 / 1 [Forge's he] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (attack, COMBAT_DECLARE_ATTACKERS): chose [attack P3 (26 life)] instead of Forge's [attack P2 (30 life)]
- US activated Ratchet Bomb
- US cast Kaya's Ghostform targeting [Dalek Drone]
- US cast Barrin, Master Wizard
- attack: US assigned Dalek Drone to attack P3.

## Turn 33 (P1, round 9)
- P1 cast Teval, the Balanced Scale

## Turn 34 (P2, round 9) | life: P1 39, P2 30, P3 23, US 32
- attack: P2 assigned Firemane Commando and Archangel of Tithes to attack US.
- P2 triggered Firemane Commando
- P2 cast Gisela, the Broken Blade
Damage to US this turn: Firemane Commando (combat) 4, Archangel of Tithes (combat) 3

## Turn 35 (P3, round 9) | life: P1 39, P2 24, P3 28, US 32
- P3 triggered Black Market Connections
- P3 cast Bloodthirsty Conqueror
- P3 triggered Edgar Markov
- attack: P3 assigned Edgar Markov to attack P2.
- P3 triggered Edgar Markov
- P3 triggered Bloodthirsty Conqueror

## Turn 36 (OUR TURN, round 9) | life: P1 39, P2 24, P3 25, US 32
Our hand: Secrets of the Dead, Professor Dellian Fel
Our graveyard (7): Assassin's Trophy, Bloodstained Mire, Demonic Tutor, Executioner's Capsule, Animate Dead, Pernicious Deed, Gravebreaker Lamia
Board P1: 7 lands; Teval, the Balanced Scale 4/4
Board P2: 8 lands; Lightning Greaves, Arcane Signet, Firemane Commando 4/3 (tapped 1), Archangel of Tithes 3/5 (tapped 1), Gisela, the Broken Blade 4/3
Board P3: 3 lands; Black Market Connections, Sol Ring (tapped 1), Edgar Markov 6/6 {[P1P1 x 2]} (tapped 1), Treasure Token [token], Vampire Token 2/2 [token] {[P1P1]}, Bloodthirsty Conqueror 6/6 {[P1P1]}
Board US: 5 lands; Ratchet Bomb {[CHARGE x 4]}, Dalek Drone 3/3, Kaya's Ghostform, Barrin, Master Wizard 1/1
MEMO (start of our turn):
THIS TURN: Draw. 1) Tap and sacrifice Ratchet Bomb at 4 counters. It kills Teval, Firemane Commando, Archangel of Tithes and Gisela. We have nothing at mana value 4 on the battlefield. 2) Barrin: pay {2} and sacrifice Dalek Drone, targeting Edgar to bounce him. Ghostform returns the Drone. Point Exterminate at Bloodthirsty Conqueror; P3 loses 3. 3) With no land drawn (3 left), cast Secrets of the Dead. With a land drawn (4 left), cast Professor Dellian Fel instead and use her 0 (draw). Secrets waits a turn. No attacks, since the Drone re-entered this turn and can't attack.

TARGET: Muldrotha out next turn (6 mana, needs a land) with Secrets. Each turn: Ghostform on Muldrotha, Capsule, Ratchet Bomb rearmed, Lamia recast to tutor Gray Merchant into the graveyard.

WIN PATH: Gray Merchant drains, recast from the graveyard or rebought with Barrin. Drone re-entries drain 3 each, plus Muldrotha beats. About 4 turns. P3 is the fastest threat.

THREATS & ANSWERS:
1) P3 (7 cards, tutored): Vito or Exquisite Blood, or a recast Conqueror. Answer with a Barrin bounce, or Dellian's -3 on a creature. Blood needs Assassin's Trophy, which is an instant we can't cast from the graveyard, so find it with Demonic Tutor. Never chump-block P3.
2) P1 Living Death or reanimation: Barrin can sacrifice Bojuka Bog, then Muldrotha replays it to exile P1's graveyard.
3) Returning Giada: Capsule (she is nonblack).

HOLD: Pernicious Deed in the graveyard for the vampire go-wide. Don't cast Muldrotha without Ghostform available while P3 holds Swords to Plowshares or Path to Exile.

REPLAN IF: Vito lands, Muldrotha is exiled, or P3 casts Olivia's Wrath.
MEMO (executor escalation: P2: nonland permanents 5→2 (-3); P2: creatures 3→0 (-3)):
THIS TURN: No land in hand. 1) Pay Barrin {2} and sacrifice Dalek Drone, targeting Edgar to bounce him. Ghostform returns the Drone. Point Exterminate at Bloodthirsty Conqueror (P3 loses 3). 2) Keep the other 3 mana open. Do not cast Secrets. On opponents' turns, pay Barrin {2} and sacrifice the Drone to bounce Vito, a recast Conqueror or a combo creature, in response to the combo. No attacks.

TARGET: Muldrotha on 6 lands, then Ghostform on Muldrotha, Capsule, Ratchet Bomb, Deed and Lamia recurring from the graveyard, with Secrets drawing. Lamia tutors Gray Merchant or Seal of Primordium into the graveyard.

WIN PATH: Gray Merchant plus Drone re-entries (3 each), then Muldrotha beats. About 5 turns. P3 is the fastest opponent.

THREATS & ANSWERS:
1) P3 (7 cards): Vito, Exquisite Blood, a recast Conqueror. Answer creatures with Barrin, Hostage Taker or Dellian's -3. Answer Blood with a graveyard Deed or a Seal of Primordium put there by Lamia. Never chump-block P3.
2) P1 Living Death or Teval: Barrin sacrifices Bojuka Bog, then Muldrotha replays it.
3) Giada recast: Executioner's Capsule (she is nonblack).

HOLD: 3 mana for Barrin on opponents' turns. Next turn, draw a land: cast Muldrotha. No land: cast Hostage Taker (steal P3's best creature) or Dellian (-3), plus Secrets if mana remains. Don't cast Muldrotha into P3's Swords or Path unless Ghostform can follow.

REPLAN IF: Vito or Exquisite Blood lands, Olivia's Wrath, Farewell, Living Death, or Muldrotha is exiled.
ESCALATION (p=0.74): P2: nonland permanents 5→2 (-3); P2: creatures 3→0 (-3)
PILOT OVERRULED FORGE (action, MAIN1): chose [activate Barrin, Master Wizard (from Battlefield): {2}, Sacrifice a permanent: Return targ] instead of Forge's [cast Hostage Taker (from Hand): Hostage Taker - Creature 2 / 3]
PILOT OVERRULED FORGE (action, MAIN2): chose [activate Barrin, Master Wizard (from Battlefield): {2}, Sacrifice a permanent: Return targ] instead of Forge's [cast Secrets of the Dead (from Hand): Secrets of the Dead]
- left battlefield: Ratchet Bomb was put into Graveyard from Battlefield.
- US activated Ratchet Bomb
- left battlefield: Teval, the Balanced Scale was put into Graveyard from Battlefield.
- left battlefield: Firemane Commando was put into Graveyard from Battlefield.
- left battlefield: Archangel of Tithes was put into Graveyard from Battlefield.
- left battlefield: Gisela, the Broken Blade was put into Graveyard from Battlefield.
- left battlefield: Kaya's Ghostform was put into Graveyard from Battlefield.
- US activated Barrin, Master Wizard targeting [Bloodthirsty Conqueror]
- attack: US assigned Dalek Drone to attack P3.
- left battlefield: Dalek Drone was put into Graveyard from Battlefield.
- US activated Barrin, Master Wizard targeting [Edgar Markov]

## Turn 37 (P1, round 10) | life: P1 34, P2 24, P3 22, US 32
- P1 cast Reanimate targeting [Dalek Drone]
- P1 triggered Dalek Drone targeting [Vampire Token]
- P1 cast Tear Asunder targeting [] [Black Market Connections]
- left battlefield: Black Market Connections was put into Exile from Battlefield.

## Turn 38 (P2, round 10) | life: P1 34, P2 24, P3 20, US 32
- P2 cast Giada, Font of Hope
- P2 activated Lightning Greaves targeting [Giada, Font of Hope]
- attack: P2 assigned Giada, Font of Hope to attack P3.

## Turn 39 (P3, round 10) | life: P1 34, P2 19, P3 20, US 32
- P3 cast Edgar Markov
- attack: P3 assigned Edgar Markov to attack P2.
- P3 triggered Edgar Markov

## Turn 40 (OUR TURN, round 10)
Our hand: Secrets of the Dead, Professor Dellian Fel, Hostage Taker, The Coming of Galactus
Our graveyard (9): Assassin's Trophy, Bloodstained Mire, Demonic Tutor, Executioner's Capsule, Animate Dead, Pernicious Deed, Gravebreaker Lamia, Ratchet Bomb, Kaya's Ghostform
Board P1: 7 lands; Dalek Drone 3/3
Board P2: 9 lands; Lightning Greaves, Arcane Signet, Giada, Font of Hope 2/2
Board P3: 4 lands; Sol Ring (tapped 1), Treasure Token [token], Edgar Markov 5/5 {[P1P1]} (tapped 1)
Board US: 5 lands; Barrin, Master Wizard 1/1
MEMO (start of our turn):
THIS TURN: No land in hand, so Muldrotha (6) is out. 1) Cast Hostage Taker (4) and exile Dalek Drone from P1. It is our card, so if Taker ever leaves, the Drone returns to us and Exterminate fires again. 2) Keep 1 open. No attacks. From now on, the instant-speed trick is: pay Barrin {2}, sacrifice Hostage Taker, bounce a creature. The Drone then returns to us and Exterminate kills a second creature, and that player loses 3.

TARGET: Muldrotha on 6 lands. From the graveyard: Ghostform on Muldrotha, Animate Dead, Deed, Lamia (tutoring Gray Merchant or Seal of Primordium into the yard) and Mire. Secrets draws off each graveyard cast.

WIN PATH: The Coming of Galactus (drains 4 per opponent, then a 16/16 flyer) plus Gray Merchant and Drone re-entries. About 5–6 turns. P3 is fastest (7 cards, Conqueror in hand, eminence tokens).

THREATS & ANSWERS:
1) P3's Vito, Exquisite Blood or a recast Conqueror. Creatures: Barrin plus the Taker trick, Drone cast from exile, or Dellian -3. Exquisite Blood: Galactus chapter I or a graveyard Deed. Capsule is useless here; all of P3's threats are black. Never chump-block P3.
2) P1 Living Death or Teval: Barrin sacrifices Bojuka Bog in response, and Muldrotha replays it.
3) Giada has shroud from Greaves. If needed, Galactus I on the Greaves.

HOLD: Dellian, Galactus and Secrets this turn. Next turn:
- Draw a land: play it, cast Muldrotha.
- No land: keep 2 up for the Barrin trick and cast Secrets (3), or cast the Drone (5) to kill Edgar if the board is quiet.

REPLAN IF: Hostage Taker is countered or removed before its trigger resolves, Vito or Exquisite Blood lands, a wipe (Olivia's Wrath, Farewell, Living Death), or Muldrotha is exiled.
- US cast Hostage Taker
- US triggered Hostage Taker targeting [Edgar Markov]
- left battlefield: Edgar Markov was put into Graveyard from Battlefield.
- P3 cast Village Rites

## Turn 41 (P1, round 11) | life: P1 33, P2 16, P3 20, US 32
- attack: P1 assigned Dalek Drone to attack P2.
- P1 cast Sidisi, Brood Tyrant
- P1 triggered Sidisi, Brood Tyrant
- P1 triggered Sidisi, Brood Tyrant
- P1 cast Victimize

## Turn 42 (P2, round 11) | life: P1 31, P2 16, P3 20, US 32
- attack: P2 assigned Giada, Font of Hope to attack P1.

## Turn 43 (P3, round 11)
- P3 cast Yahenni, Undying Partisan
- P3 triggered Edgar Markov
- P3 cast Elenda, the Dusk Rose
- P3 triggered Edgar Markov

## Turn 44 (OUR TURN, round 11)
Our hand: Secrets of the Dead, Professor Dellian Fel, The Coming of Galactus, Nature's Lore
Our graveyard (9): Assassin's Trophy, Bloodstained Mire, Demonic Tutor, Executioner's Capsule, Animate Dead, Pernicious Deed, Gravebreaker Lamia, Ratchet Bomb, Kaya's Ghostform
Board P1: 7 lands; Dalek Drone 3/3 (tapped 1), Sidisi, Brood Tyrant 3/3, Ob Nixilis, the Fallen 3/3 (tapped 1), Wight of the Reliquary 2/2 (tapped 1)
Board P2: 10 lands; Lightning Greaves, Arcane Signet, Giada, Font of Hope 2/2
Board P3: 5 lands; Sol Ring (tapped 1), Vampire Token 1/1 [token] x2, Yahenni, Undying Partisan 2/2, Elenda, the Dusk Rose 1/1
Board US: 5 lands; Barrin, Master Wizard 1/1, Hostage Taker 2/3
MEMO (start of our turn):
THIS TURN: 1) Nature's Lore (2 mana) for Overgrown Tomb. Pay 2 life so it enters untapped. That gives 6 lands and 4 mana left. 2) Barrin, pay {2} and sacrifice Hostage Taker to bounce Dalek Drone. We own the Drone, so it returns to OUR hand. Taker is holding nothing, since Edgar went to the command zone, and it goes to our graveyard for Muldrotha to recast. 3) Keep 2 open. On opponents' turns, Barrin (sacrificing Barrin himself) bounces a newly cast Bloodthirsty Conqueror, a Vito or a grown Elenda. No attacks.

TARGET: Muldrotha plus Kaya's Ghostform on him. Then Drone and Taker recast as removal, Secrets drawing, and Lamia tutoring Gray Merchant into the graveyard.

WIN PATH: The Coming of Galactus drains 2 from each opponent twice, then brings a 16/16 flyer. Add Drone (3 life loss each time it enters) and Gray Merchant. P2 at 16 dies first. We need about 4 turns; P3 is fastest.

THREATS & ANSWERS:
1) P3: Conqueror (in hand), Vito, Elenda (bounce her, never kill her while she's big). Answer with Barrin or Drone Exterminate. Exquisite Blood: Galactus chapter I or Deed from the graveyard. Capsule can't hit P3; they're all black. Never chump-block P3.
2) P1: Ob Nixilis landfall drain. Dellian -3 or Drone.
3) P2: Giada, shrouded by Greaves. Galactus chapter I on Greaves if needed.

HOLD: Dellian, Galactus, Secrets, Drone. Next turn: cast Muldrotha (6). With a 7th land, add Ghostform on him (1). The turn after: Drone (5) plus graveyard lanes. Don't sacrifice lands to Barrin before Muldrotha resolves.

REPLAN IF: Drone doesn't return to our hand, Vito or Exquisite Blood lands, a wipe or Living Death happens, or Muldrotha is exiled or countered.
PILOT OVERRULED FORGE (search, MAIN1): chose [Overgrown Tomb — Land - Swamp Forest — ({T}: Add {B} or {G}.) As Overgrown Tomb enters, yo] instead of Forge's [Zagoth Triome — Land - Swamp Forest Island — ({T}: Add {B}, {G}, or {U}.) Zagoth Triome en]
PILOT OVERRULED FORGE (action, MAIN1): chose [activate Barrin, Master Wizard (from Battlefield): {2}, Sacrifice a permanent: Return targ] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
- US cast Nature's Lore
- left battlefield: Tropical Island was put into Graveyard from Battlefield.
- US activated Barrin, Master Wizard targeting [Dalek Drone]

## Turn 45 (P1, round 12) | life: P1 31, P2 10, P3 8, US 32
- P1 activated Foreboding Landscape
- P1 cast Nature's Lore
- P1 triggered Ob Nixilis, the Fallen targeting [P2]
- P1 triggered Hedge Maze
- attack: P1 assigned Sidisi, Brood Tyrant, Ob Nixilis, the Fallen and Wight of the Reliquary to attack P3.
- P1 triggered Sidisi, Brood Tyrant
- left battlefield: Sidisi, Brood Tyrant was put into Graveyard from Battlefield.
- P1 activated Wight of the Reliquary
- P3 triggered Yahenni, Undying Partisan
- P3 triggered Elenda, the Dusk Rose
- P1 triggered Ob Nixilis, the Fallen targeting [P2]

## Turn 46 (P2, round 12) | life: P1 31, P2 13, P3 5, US 32
- P2 triggered Emeria, the Sky Ruin targeting [Lyra Dawnbringer]
- attack: P2 assigned Giada, Font of Hope to attack P3.

## Turn 47 (P3, round 12)
- P3 cast Bloodthirsty Conqueror
- P3 triggered Edgar Markov

## Turn 48 (OUR TURN, round 12) | life: P1 31, P2 13, P3 2, US 32
Our hand: Secrets of the Dead, Professor Dellian Fel, The Coming of Galactus, Dalek Drone, Doc Aurlock, Grizzled Genius
Our graveyard (11): Assassin's Trophy, Bloodstained Mire, Demonic Tutor, Executioner's Capsule, Animate Dead, Pernicious Deed, Gravebreaker Lamia, Ratchet Bomb, Kaya's Ghostform, Nature's Lore, Tropical Island
Board P1: 9 lands; Ob Nixilis, the Fallen 9/9 {[P1P1 x 6]} (tapped 1), Wight of the Reliquary 3/3 (tapped 1)
Board P2: 11 lands; Lightning Greaves, Arcane Signet, Giada, Font of Hope 3/3, Lyra Dawnbringer 6/6 {[P1P1]}
Board P3: 5 lands; Sol Ring (tapped 1), Vampire Token 1/1 [token] x3, Yahenni, Undying Partisan 3/3 {[P1P1]}, Elenda, the Dusk Rose 2/2 {[P1P1]}, Bloodthirsty Conqueror 5/5
Board US: 5 lands; Barrin, Master Wizard 1/1, Hostage Taker 2/3
MEMO (start of our turn):
THIS TURN: 1) Cast Dalek Drone using all 5 mana ({3}{B}{B}; every land makes B). Exterminate targets Bloodthirsty Conqueror, and P3 drops from 5 to 2. If P3 sacrifices Conqueror to Yahenni in response, the trigger fizzles, but Conqueror is still gone. 2) Don't attack; P3 has 6 untapped blockers. Barrin has no mana on opponents' turns, so just block sensibly. Never block with Drone, and never chump against P3.

TARGET: Muldrotha on board with Kaya's Ghostform, Doc Aurlock and Secrets. We recast Capsule, Deed and Drone from the graveyard, and replay Tropical Island and the Mire.

WIN PATH: Next turn Drone (3/3, flying, menace) swings at P3 at 2 for lethal. Then cast one of these with 5 mana: Muldrotha if we draw a land (6 mana), otherwise Galactus with chapter I on Lyra. Galactus drains 2 twice and brings the 16/16 to finish P2 (13), then P1.

THREATS & ANSWERS: 1) P3 (6 cards): a new Conqueror, Vito, or Exquisite Blood. Answer with Dellian -3 or Galactus chapter I. Never kill Elenda (3 counters leave 3 lifelink tokens); bounce her with Barrin instead. 2) P2: Lyra (6/6 lifelink flyer) and Giada. Galactus I, Capsule (nonblack is fine), or Deed at X=5 later. 3) P1: Ob Nixilis landfall. Dellian -3 (Capsule can't; it's black).

HOLD: Dellian, Galactus, Secrets, Doc. We deliberately hold Doc and Secrets back until Muldrotha, so nothing extra walks into Olivia's Wrath.

REPLAN IF: P3 stays at 5 or gains life, Drone is removed, a wipe resolves, Vito or Exquisite Blood lands, or we draw a land (then cast Muldrotha).
PILOT OVERRULED FORGE (trigger-target, MAIN1): chose [Bloodthirsty Conqueror [P3, 5/5]] instead of Forge's [Lyra Dawnbringer [P2, 6/6]]
- US cast Dalek Drone
- US triggered Dalek Drone targeting [Bloodthirsty Conqueror]
- left battlefield: Bloodthirsty Conqueror was put into Graveyard from Battlefield.
- P3 triggered Elenda, the Dusk Rose

## Turn 49 (P1, round 13)
- attack: P1 assigned Ob Nixilis, the Fallen and Wight of the Reliquary to attack P3.
- attack: P3 assigned Vampire Token to block Ob Nixilis, the Fallen.
- left battlefield: Ob Nixilis, the Fallen was put into Graveyard from Battlefield.
- P1 activated Wight of the Reliquary
- P3 triggered Yahenni, Undying Partisan
- P3 triggered Elenda, the Dusk Rose
- left battlefield: Wight of the Reliquary was put into Graveyard from Battlefield.
- left battlefield: Yahenni, Undying Partisan was put into Graveyard from Battlefield.
- P3 triggered Elenda, the Dusk Rose
- P3 triggered Yahenni, Undying Partisan
- P3 triggered Elenda, the Dusk Rose
- P1 cast Teval, the Balanced Scale

## Turn 50 (P2, round 13) | life: P1 31, P2 19, P3 -4, US 32
- P2 triggered Emeria, the Sky Ruin targeting [Gisela, the Broken Blade]
- P2 cast Path to Exile targeting [Elenda, the Dusk Rose]
- left battlefield: Elenda, the Dusk Rose was put into Exile from Battlefield.
- attack: P2 assigned Lyra Dawnbringer and Giada, Font of Hope to attack P3.
- P2 activated Minas Tirith

## Turn 51 (OUR TURN, round 13)
Our hand: Secrets of the Dead, Professor Dellian Fel, The Coming of Galactus, Doc Aurlock, Grizzled Genius, Three Visits
Our graveyard (11): Assassin's Trophy, Bloodstained Mire, Demonic Tutor, Executioner's Capsule, Animate Dead, Pernicious Deed, Gravebreaker Lamia, Ratchet Bomb, Kaya's Ghostform, Nature's Lore, Tropical Island
Board P1: 10 lands; Teval, the Balanced Scale 4/4
Board P2: 11 lands; Lightning Greaves, Arcane Signet, Giada, Font of Hope 3/3, Lyra Dawnbringer 6/6 {[P1P1]} (tapped 1), Gisela, the Broken Blade 7/6 {[P1P1 x 2]}
Board US: 5 lands; Barrin, Master Wizard 1/1, Hostage Taker 2/3, Dalek Drone 3/3
MEMO (start of our turn):
THIS TURN: 1) Three Visits ({1}{G}, using Bayou for G) to fetch a basic Forest untapped. It costs no life, and we stay at 32 against a possible Akroma's Will swing. 2) Professor Dellian Fel ({2}{B}{G}, using Overgrown Tomb for G, which uses the last 4) and −3 on Lyra, which is tapped, gives the anthem and grants lifelink. If Lyra has Greaves (shroud), kill Gisela instead. 3) Don't attack. On opponents' turns, block Giada with Drone. If P2 swings with double strike, chump to stay alive.

TARGET: 6 lands next turn, then cast Muldrotha (6) and replay Tropical Island for Executioner's Capsule, which kills nonblack angels. Then Gravebreaker Lamia puts Soul-Guide Lantern in our graveyard, and the artifact lane recasts Lantern to exile the opponents' graveyards every turn. Then Doc, Secrets and Kaya's Ghostform on Muldrotha.

WIN PATH: Galactus once Muldrotha is safe: I kills an angel, II and III drain 4 total, IV makes a 16/16 flyer. Recast Drone for drain 3. P2 (19) dies first, around 4-5 turns. P2's clock is faster, about 16 flying power per turn.

THREATS & ANSWERS: 1) P2 angels, with Emeria rebuying one per upkeep: Dellian now, then Capsule/Galactus I. Lantern/Bog exile P2's graveyard, and Barrin bounces at P2's beginning of combat. 2) P1: Teval 4/4 flyer, Living Death (19 in graveyard). Galactus I or Dellian −3 (Capsule can't; Teval is black). Exile P1's yard all at once.

HOLD: Galactus, Doc, Secrets until Muldrotha resolves. Never sacrifice Bojuka Bog while it would cost the sixth land for Muldrotha.

REPLAN IF: P2 wipes, Akroma's Will shows, we draw a land (cast Muldrotha next turn with spare mana), Dellian dies, or Living Death resolves.
PILOT OVERRULED FORGE (action, MAIN1): chose [activate Barrin, Master Wizard (from Battlefield): {2}, Sacrifice a permanent: Return targ] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN1): chose [Teval, the Balanced Scale [P1, 4/4, commander]] instead of Forge's [Gisela, the Broken Blade [P2, 7/6]]
- US cast Three Visits
- left battlefield: Bayou was put into Graveyard from Battlefield.
- US activated Barrin, Master Wizard targeting [Teval, the Balanced Scale]

## Turn 52 (P1, round 13) | life: P1 29, P2 19, P3 -4, US 32
- left battlefield: Misty Rainforest was put into Graveyard from Battlefield.
- P1 activated Misty Rainforest
- P1 cast Muldrotha, the Gravetide
- left battlefield: Memorial to Folly was put into Graveyard from Battlefield.
- P1 activated Memorial to Folly targeting [Ob Nixilis, the Fallen]

## Turn 53 (P2, round 14) | life: P1 29, P2 35, P3 -4, US 19
- P2 triggered Emeria, the Sky Ruin targeting [Archangel of Tithes]
- attack: P2 assigned Gisela, the Broken Blade, Lyra Dawnbringer and Giada, Font of Hope to attack US.
- left battlefield: Giada, Font of Hope was put into Graveyard from Battlefield.
- left battlefield: Dalek Drone was put into Graveyard from Battlefield.
- P2 activated Lightning Greaves targeting [Gisela, the Broken Blade]
- P2 cast Smothering Tithe
- P2 cast Giada, Font of Hope
- P2 triggered Path of Ancestry
Damage to US this turn: Gisela, the Broken Blade (combat) 7, Lyra Dawnbringer (combat) 6

## Turn 54 (OUR TURN, round 14)
Our hand: Secrets of the Dead, Professor Dellian Fel, The Coming of Galactus, Doc Aurlock, Grizzled Genius, Shriekmaw
Our graveyard (14): Assassin's Trophy, Bloodstained Mire, Demonic Tutor, Executioner's Capsule, Animate Dead, Pernicious Deed, Gravebreaker Lamia, Ratchet Bomb, Kaya's Ghostform, Nature's Lore, Tropical Island, Three Visits, Bayou, Dalek Drone
Board P1: 10 lands; Muldrotha, the Gravetide 6/6
Board P2: 11 lands; Lightning Greaves, Arcane Signet (tapped 1), Lyra Dawnbringer 6/6 {[P1P1]} (tapped 1), Gisela, the Broken Blade 7/6 {[P1P1 x 2]} (tapped 1), Archangel of Tithes 7/9 {[P1P1 x 3]}, Smothering Tithe, Giada, Font of Hope 3/3
Board US: 5 lands; Barrin, Master Wizard 1/1, Hostage Taker 2/3
MEMO (start of our turn):
THIS TURN: Don't pay 2 to Smothering Tithe; we need all 5 mana. P2 has about 23 flying power (Lyra 6, Gisela 7, Tithes 7, Giada 3) against our 19 life, so this turn is survival.
1) Evoke Shriekmaw ({1}{B}). Its enter trigger destroys Lyra (the anthem and lifelink source).
2) With the evoke sacrifice trigger still on the stack, activate Barrin ({2}), sacrificing Shriekmaw, and bounce Archangel of Tithes.
If Greaves has moved and shrouds Lyra or Tithes, hit Gisela in that slot instead.
3) Don't attack; 1 mana stays floating.
On P1's turn, block their Muldrotha 6/6 with Hostage Taker, then Barrin. Hostage Taker in the graveyard is a future recast.
Worst case on P2's turn: Emeria returns Lyra and they recast Tithes, but only one gets haste from Greaves. That's 17 damage, and we survive at 2.

TARGET: Draw a land, then Muldrotha (6 mana). Recast Hostage Taker to steal an angel or P1's Muldrotha. Recast Capsule, Shriekmaw and Dalek Drone every turn, then Doc, Secrets, and Ghostform on Muldrotha.

WIN PATH: Stabilise first. Then Galactus (II and III drain 4, IV is a 16/16 flyer) plus the Drone and Shriekmaw loops. P2's clock is next turn; ours is 5+ turns.

THREATS & ANSWERS: 1) P2's angels plus Emeria rebuying one each upkeep. Next turn: Dellian −3 or Galactus I on Lyra, then Pernicious Deed later via Muldrotha. 2) P1's Muldrotha (black, so Shriekmaw and Capsule can't hit it): use Galactus I, Dellian −3, or a stolen body via Hostage Taker. Watch for Living Death.

HOLD: Galactus, Dellian, Doc, Secrets until next turn. Keep Bojuka Bog; it counts toward Muldrotha.

REPLAN IF: P2 shows Akroma's Will or extra hasty angels, Emeria returns something other than Lyra, P1 plays Living Death, or we drop below 10 before P2 attacks.
MEMO (executor escalation: we lost: Barrin, Master Wizard):
THIS TURN: No attacks. Hostage Taker stays home as our only ground blocker. Nothing in hand costs 1, so pass with Zagoth Triome untapped. On P1's turn, if their Muldrotha (6/6) attacks us, block it with Hostage Taker; we can't afford 6 on top of P2's fliers. On P2's turn we have no flying blockers and no instant plays. Expected hit is about 17 (Gisela 7, Giada 3, plus one Greaves-hasted Lyra or Archangel of Tithes at 7), leaving us at 2.

TARGET: Kill angels until Muldrotha, then Doc, then Pernicious Deed (from the graveyard with Doc it costs {B}{G} plus X) sweeps P2. After that, the Capsule, Shriekmaw and Drone loops.

WIN PATH: Survive first. Then Galactus drains 2 twice and brings the 16/16, backed by the recurring Dalek Drone drain. P2's clock is 1 turn, ours is 5 or more.

THREATS & ANSWERS: 1) P2's angels; Lyra returns via Emeria each upkeep. Next turn cast Dellian ({2}{B}{G}) and −3 on the biggest unshrouded angel, Lyra first because she gives the anthem and lifelink. With a 6th mana, add Doc. If only one big angel remains, cast Galactus instead: chapter I destroys it. 2) P1's Muldrotha (black). Answer it later with Galactus I or Dellian.

HOLD: Galactus and Secrets until the angels are handled. Don't pay 2 to Smothering Tithe on our draw; we need the mana.

REPLAN IF: P2 shows Akroma's Will or casts a third attacking angel, since we're likely dead and should dump removal on the biggest attacker. Also replan if P1 casts Living Death, attacks P2 instead of us, or we draw a land and P2's board shrinks enough to make Muldrotha plus Doc the better play.
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Shriekmaw (from Hand): Evoke {1}{B} (You may cast this spell for its evoke cost. If y] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (trigger-target, MAIN1): chose [Lyra Dawnbringer [P2, 6/6, tapped]] instead of Forge's [Archangel of Tithes [P2, 7/9]]
PILOT OVERRULED FORGE (action, MAIN1): chose [activate Barrin, Master Wizard (from Battlefield): {2}, Sacrifice a permanent: Return targ] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
ESCALATION (p=0.89): we lost: Barrin, Master Wizard
PILOT OVERRULED FORGE (attack, COMBAT_DECLARE_ATTACKERS): chose [don't attack with it] instead of Forge's [attack P2 (35 life)]
- P2 triggered Smothering Tithe
- US cast Shriekmaw
- US triggered Shriekmaw targeting [Lyra Dawnbringer]
- US triggered Shriekmaw
- left battlefield: Shriekmaw was put into Graveyard from Battlefield.
- left battlefield: Lyra Dawnbringer was put into Graveyard from Battlefield.
- left battlefield: Barrin, Master Wizard was put into Graveyard from Battlefield.
- US activated Barrin, Master Wizard targeting [Archangel of Tithes]

## Turn 55 (P1, round 14) | life: P1 28, P2 29, P3 -4, US 19
- P2 triggered Smothering Tithe
- attack: P1 assigned Muldrotha, the Gravetide to attack P2.
- P1 cast Sidisi, Brood Tyrant
- P1 triggered Sidisi, Brood Tyrant
- P1 triggered Sidisi, Brood Tyrant
- P1 cast Hedge Shredder
- P1 cast Awaken the Honored Dead
- P1 triggered Awaken the Honored Dead targeting [Giada, Font of Hope]
- left battlefield: Giada, Font of Hope was put into Graveyard from Battlefield.

## Turn 56 (P2, round 14) | life: P1 21, P2 36, P3 -4, US 19
- P2 triggered Emeria, the Sky Ruin targeting [Lyra Dawnbringer]
- P2 cast Archangel of Tithes
- P2 cast Giada, Font of Hope
- P2 triggered Path of Ancestry
- attack: P2 assigned Gisela, the Broken Blade to attack P1.

## Turn 57 (OUR TURN, round 15)
Our hand: Secrets of the Dead, Professor Dellian Fel, The Coming of Galactus, Doc Aurlock, Grizzled Genius, Watery Grave
Our graveyard (16): Assassin's Trophy, Bloodstained Mire, Demonic Tutor, Executioner's Capsule, Animate Dead, Pernicious Deed, Gravebreaker Lamia, Ratchet Bomb, Kaya's Ghostform, Nature's Lore, Tropical Island, Three Visits, Bayou, Dalek Drone, Shriekmaw, Barrin, Master Wizard
Board P1: 11 lands; Muldrotha, the Gravetide 6/6 (tapped 1), Sidisi, Brood Tyrant 3/3, Zombie Token 2/2 [token], Hedge Shredder, Awaken the Honored Dead {[LORE]}
Board P2: 11 lands; Lightning Greaves, Arcane Signet (tapped 1), Gisela, the Broken Blade 7/6 {[P1P1 x 2]} (tapped 1), Smothering Tithe, Lyra Dawnbringer 5/5, Archangel of Tithes 4/6, Giada, Font of Hope 3/3, Treasure Token [token]
Board US: 5 lands; Hostage Taker 2/3
MEMO (start of our turn):
THIS TURN: 1) Play Watery Grave and pay 2 life (to 17). 2) Cast Doc Aurlock with {G}{U}. 3) Cast Professor Dellian Fel with {2}{B}{G} and −3 on Giada. Don't target Lyra or Archangel: Emeria (8 Plains) returns them at P2's upkeep with Giada counters, bigger. Giada goes to the command zone at tax 6 and stops the free Flawless Maneuver. No attacks. On P1's turn, Hostage Taker blocks the biggest ground attacker. Doc blocks only a 2/2 Zombie, unless unblocked damage would put us at 8 or lower.

TARGET: Next turn: Muldrotha (6), then Bayou from the graveyard. With Doc, graveyard casts cost 2 less: Shriekmaw evoke {B} kills an angel; Capsule {B}; Kaya's Ghostform {B} on Muldrotha. If Dellian dies, recast from the graveyard for {B}{G} and −3 again. Pernicious Deed for {B}{G}+X once Giada is gone.

WIN PATH: Stabilise, then The Coming of Galactus (drain 2 twice, then a 16/16 flier) plus the Dalek Drone loop (drain 3 each cast). P2's clock is about 1–2 turns; ours is 5 or more.

THREATS & ANSWERS: 1) P2's angels: Gisela (shrouded by Greaves), Lyra, Archangel. Answers: Shriekmaw loop, Capsule, Deed. 2) P1's Muldrotha and Teval engine: Galactus I or Dellian −3 (Muldrotha is black, so Capsule and Shriekmaw can't hit it). Don't grind P1's graveyard one card at a time.

HOLD: Galactus until the Muldrotha turn is done. Secrets of the Dead comes after Muldrotha. Don't pay Smothering Tithe.

REPLAN IF: Flawless Maneuver saves Giada; P2 moves Greaves off Gisela (Gisela becomes targetable); P1 casts Living Death; or we fall to 8 or lower before our turn. In that last case, cast Galactus on the biggest flier instead of Muldrotha.
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Doc Aurlock, Grizzled Genius (from Hand): Doc Aurlock, Grizzled Genius - Creature 2 /] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
- P2 triggered Smothering Tithe
- US cast Doc Aurlock, Grizzled Genius
- US cast Secrets of the Dead

## Turn 58 (P1, round 15) | life: P1 21, P2 25, P3 -4, US 19
- P2 triggered Smothering Tithe
- P1 cast Putrefy targeting [Lyra Dawnbringer]
- left battlefield: Lyra Dawnbringer was put into Graveyard from Battlefield.
- P1 triggered Awaken the Honored Dead
- P1 triggered Hedge Shredder
- P1 triggered Sidisi, Brood Tyrant
- P1 triggered Golgari Rot Farm
- P1 activated Hedge Shredder
- attack: P1 assigned Hedge Shredder and Muldrotha, the Gravetide to attack P2.
- P1 triggered Hedge Shredder
- P1 triggered Hedge Shredder
- P1 cast Kotis, Sibsig Champion
- P1 triggered Kotis, Sibsig Champion
- P1 cast Wight of the Reliquary
- P1 triggered Kotis, Sibsig Champion
- P1 cast Gravecrawler
- P1 triggered Kotis, Sibsig Champion

## Turn 59 (P2, round 15) | life: P1 5, P2 41, P3 -4, US 19
- P2 triggered Emeria, the Sky Ruin targeting [Lyra Dawnbringer]
- P2 cast Archangel of Thune
- P2 cast Angelic Field Marshal
- P2 triggered Path of Ancestry
- attack: P2 assigned Gisela, the Broken Blade, Archangel of Tithes and Giada, Font of Hope to attack P1.
- P2 triggered Archangel of Thune
- P2 triggered Archangel of Thune
- P2 triggered Archangel of Thune
- P2 activated Minas Tirith
- P2 cast Land Tax

## Turn 60 (OUR TURN, round 15)
Our hand: Professor Dellian Fel, The Coming of Galactus, Heroic Intervention
Our graveyard (16): Assassin's Trophy, Bloodstained Mire, Demonic Tutor, Executioner's Capsule, Animate Dead, Pernicious Deed, Gravebreaker Lamia, Ratchet Bomb, Kaya's Ghostform, Nature's Lore, Tropical Island, Three Visits, Bayou, Dalek Drone, Shriekmaw, Barrin, Master Wizard
Board P1: 15 lands; Muldrotha, the Gravetide 6/6 (tapped 1), Sidisi, Brood Tyrant 3/3, Zombie Token 2/2 [token] x2 (tapped 1), Hedge Shredder (tapped 1), Awaken the Honored Dead {[LORE x 2]}, Kotis, Sibsig Champion 9/9 {[P1P1 x 6]}, Wight of the Reliquary 2/2, Gravecrawler 2/1
Board P2: 11 lands; Lightning Greaves, Arcane Signet (tapped 1), Gisela, the Broken Blade 10/9 {[P1P1 x 5]}, Smothering Tithe, Archangel of Tithes 7/9 {[P1P1 x 3]}, Giada, Font of Hope 6/6 {[P1P1 x 3]}, Treasure Token [token], Lyra Dawnbringer 11/11 {[P1P1 x 6]}, Archangel of Thune 11/12 {[P1P1 x 7]}, Angelic Field Marshal 14/14 {[P1P1 x 8]}, Land Tax
Board US: 6 lands; Hostage Taker 2/3, Doc Aurlock, Grizzled Genius 2/3, Secrets of the Dead
MEMO (start of our turn):
THIS TURN: 1) Don't pay Smothering Tithe (now or on later draws). 2) Cast Muldrotha with 6 lands. 3) Cast Ratchet Bomb from the graveyard for {0} (Doc makes it free); Secrets draws a card. 4) Play Bayou from the graveyard. 5) Evoke Shriekmaw from the graveyard for {B} (Bayou) and kill Giada. She goes to the command zone, where Emeria can't return her. Field Marshal loses +2/+2 and vigilance, and free Flawless Maneuver stops. Leave Ratchet Bomb at 0. No attacks. On P1's turn, if Zombie tokens attack, sacrifice Ratchet at 0 to kill all tokens (P2's Treasures too). Blocks: Muldrotha blocks Hedge Shredder or Sidisi, where it kills the attacker and survives. Hostage Taker chumps Kotis only if needed to stay alive. Doc blocks a 2/2 only.

TARGET: Next turn: Tropical Island from the graveyard (8 mana). Recast Pernicious Deed from the graveyard for {B}{G} and pop it at X=5 to clear P2's angels and P1's board; Muldrotha (MV 6) survives. Rebuy Doc and the Ratchet Bomb/Capsule loop the turn after.

WIN PATH: After Deed: Dalek Drone (P1 loses 3), then Galactus II/III drains finish P1 (5 life). Then grind P2 with Galactus's 16/16 and the drains. P2 has about 50 flying power: lethal on us next turn if they choose us.

THREATS & ANSWERS: 1) P2's angel alpha: Deed next turn; we have no answer before then. 2) P1's Muldrotha and Kotis: Dellian −3 or Galactus I.

HOLD: Dellian, Galactus and Heroic Intervention; there's no mana for them this turn.

REPLAN IF: Muldrotha is removed; a drawn card is Toxic Deluge or a mana rock (fit it in only after Shriekmaw); P1 casts Living Death; or P2 wipes the board.
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Muldrotha, the Gravetide (from Command): Muldrotha, the Gravetide - Creature 6 / 6 [F] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN1): chose [play land Bayou (from Graveyard): Play land by Muldrotha, the Gravetide (403) (Land)] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Executioner's Capsule (from Graveyard): Executioner's Capsule by Muldrotha, the Grave] instead of Forge's [cast Animate Dead (from Graveyard): Animate Dead by Muldrotha, the Gravetide (403) (Enchan]
- P2 triggered Smothering Tithe
- US cast Muldrotha, the Gravetide
- US cast Executioner's Capsule
- US triggered Secrets of the Dead
- P2 triggered Smothering Tithe

## Turn 61 (P1, round 16) | life: P1 4, P2 41, P3 -4, US 19
- left battlefield: Polluted Delta was put into Graveyard from Battlefield.
- P1 activated Polluted Delta
- left battlefield: Terramorphic Expanse was put into Graveyard from Battlefield.
- P1 activated Terramorphic Expanse
- P2 triggered Smothering Tithe
- P1 triggered Awaken the Honored Dead
- left battlefield: Awaken the Honored Dead was put into Graveyard from Battlefield.
- P1 triggered Awaken the Honored Dead targeting [Island]
- P1 cast Farseek
- left battlefield: Gravecrawler was put into Graveyard from Battlefield.
- P1 activated Wight of the Reliquary
- P1 triggered Field of the Dead
- P1 cast Awaken the Honored Dead
- P1 triggered Awaken the Honored Dead targeting [Angelic Field Marshal]
- left battlefield: Angelic Field Marshal was put into Graveyard from Battlefield.
- P1 cast Gravecrawler
- P1 triggered Kotis, Sibsig Champion
- P1 cast Teval, the Balanced Scale
- P1 cast Six

## Turn 62 (P2, round 16) | life: P1 -6, P2 62, P3 -4, US 19
- P2 triggered Emeria, the Sky Ruin targeting [Angelic Field Marshal]
- P2 triggered Land Tax
- attack: P2 assigned Lyra Dawnbringer, Archangel of Thune, Gisela, the Broken Blade, Archangel of Tithes and Giada, Font of Hope to attack P1.
- attack: P1 assigned Six to block Lyra Dawnbringer.
- P2 triggered Archangel of Thune
- P2 triggered Archangel of Thune
- P2 cast Court of Grace
- P2 triggered Court of Grace
- P2 activated Minas Tirith
- P2 cast Metropolis Reformer
- P2 triggered Path of Ancestry
- P2 triggered The Monarch
- P2 cast Stroke of Midnight targeting [Muldrotha, the Gravetide]
- left battlefield: Muldrotha, the Gravetide was put into Graveyard from Battlefield.

## Turn 63 (OUR TURN, round 16)
Our hand: Professor Dellian Fel, The Coming of Galactus, Heroic Intervention, Sakura-Tribe Elder
Our graveyard (14): Assassin's Trophy, Bloodstained Mire, Demonic Tutor, Animate Dead, Pernicious Deed, Gravebreaker Lamia, Ratchet Bomb, Kaya's Ghostform, Nature's Lore, Tropical Island, Three Visits, Dalek Drone, Shriekmaw, Barrin, Master Wizard
Board P2: 12 lands; Lightning Greaves, Arcane Signet (tapped 1), Gisela, the Broken Blade 12/11 {[P1P1 x 7]}, Smothering Tithe, Archangel of Tithes 9/11 {[P1P1 x 5]}, Giada, Font of Hope 8/8 {[P1P1 x 5]}, Treasure Token [token] x4, Lyra Dawnbringer 13/13 {[P1P1 x 8]}, Archangel of Thune 13/14 {[P1P1 x 9]}, Land Tax, Angelic Field Marshal 13/13 {[P1P1 x 7]}, Court of Grace, Metropolis Reformer 9/10 {[P1P1 x 6]}
Board US: 7 lands; Hostage Taker 2/3, Doc Aurlock, Grizzled Genius 2/3, Secrets of the Dead, Executioner's Capsule, Human Token 1/1 [token]
MEMO (start of our turn):
THIS TURN: P1 is gone, so it's us against P2. P2 has about 77 flying power, and that kills us next turn unless we hit an out. Muldrotha costs 8 and Deed is unreachable, so we dig.
1) Draw step: don't pay Smothering Tithe.
2) Pay for Dellian with Darkslick, Drowned Catacomb, Watery Grave and Bayou. Keep Bog, Overgrown Tomb and Zagoth, which hold the green.
3) Branch on the drawn card:
- Toxic Deluge: cast it with X=13, then Dellian +2 (life 6 to 9).
- Spore Frog: cast it for {G}, then Dellian and use its 0 ability, then Sakura-Tribe Elder.
- Survival of the Fittest: cast it, then {G} and discard STE to find Spore Frog, then cast Frog.
- Eternal Witness: return Demonic Tutor, find Spore Frog, cast it.
- Untapped land or Sol Ring: play it, then as the blank branch with one extra mana.
- Blank: cast Dellian and use 0 to draw. Then Deluge (X=13) or Frog with the 3 lands left. If Frog, add STE.
4) Nothing hit: cast STE, sacrifice it for a Swamp. Capsule Lyra during P2's combat.

TARGET: 8+ lands, Muldrotha, and Spore Frog recast from the graveyard every turn as a fog. Pernicious Deed at X=5 once we reach 15 mana.

WIN PATH: Galactus drains 2 twice, then the 16/16. Dalek Drone drains 3. This is slow against 62 life. Our clock: survive first.

THREATS & ANSWERS: 1) P2's alpha strike: Deluge or Frog. 2) Hasty Greaves attacker next turn: Capsule or Dellian −3. 3) Court of Grace makes a 4/4 each turn: Galactus chapter I.

HOLD: Sacrifice Frog after P2 declares attackers, or in response to removal aimed at it. Keep Heroic Intervention if mana allows.

REPLAN IF: P2 doesn't attack, or wipes the board. Or we draw a second out.
PILOT OVERRULED FORGE (action, UPKEEP): chose [Giada, Font of Hope [P2, 8/8, commander]] instead of Forge's [Lyra Dawnbringer [P2, 13/13]]
PILOT OVERRULED FORGE (action, MAIN2): chose [cast Mishra's Bauble (from Hand): Mishra's Bauble] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN2): chose [activate Mishra's Bauble (from Battlefield): {T}, Sacrifice Mishra's Bauble: Look at the t] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
- left battlefield: Executioner's Capsule was put into Graveyard from Battlefield.
- US activated Executioner's Capsule targeting [Giada, Font of Hope]
- left battlefield: Giada, Font of Hope was put into Graveyard from Battlefield.
- P2 triggered Smothering Tithe
- US cast The Coming of Galactus
- US triggered The Coming of Galactus targeting [Lyra Dawnbringer]
- left battlefield: Lyra Dawnbringer was put into Graveyard from Battlefield.
- US cast Mishra's Bauble
- left battlefield: Mishra's Bauble was put into Graveyard from Battlefield.
- US activated Mishra's Bauble targeting [P4]

## Turn 64 (P2, round 16) | life: P1 -6, P2 118, P3 -4, US -37
- P2 triggered Emeria, the Sky Ruin targeting [Lyra Dawnbringer]
- P2 triggered Court of Grace
- US triggered Mishra's Bauble
- P2 triggered Smothering Tithe
- P2 cast Giada, Font of Hope
- P2 triggered Path of Ancestry
- attack: P2 assigned Archangel of Thune, Angelic Field Marshal, Gisela, the Broken Blade, Archangel of Tithes and Metropolis Reformer to attack US.
- P2 cast Akroma's Will
- Game Outcome: P1 has lost because life total reached 0
- Game Outcome: P2 has won because all opponents have lost
- Game Outcome: P3 has lost because life total reached 0
- Game Outcome: US has lost because life total reached 0
Damage to US this turn: Archangel of Thune (combat) 13, Angelic Field Marshal (combat) 13, Gisela, the Broken Blade (combat) 12, Archangel of Tithes (combat) 9, Metropolis Reformer (combat) 9