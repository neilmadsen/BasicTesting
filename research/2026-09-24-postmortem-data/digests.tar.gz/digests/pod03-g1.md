# pod03-g1: we are P4; opponents P1 Teval, the Balanced Scale, P2 Giada, Font of Hope, P3 Edgar Markov
Result: Turn 24; P1 has lost because life total reached 0; P2 has lost because life total reached 0; P3 has won because all opponents have lost; US has lost because life total reached 0

## Turn 1 (P2, round 1)
- P2 cast Enlightened Tutor

## Turn 2 (P3, round 1)

## Turn 3 (OUR TURN, round 1)
Our hand: Doc Aurlock, Grizzled Genius, Swamp, Syr Konrad, the Grim, Sol Ring, Island, Forest, Zagoth Triome, Braids, Arisen Nightmare
Our graveyard (0): 
Board P1: 0 lands; no nonland permanents
Board P2: 1 lands; no nonland permanents
Board P3: 1 lands; no nonland permanents
Board US: 0 lands; no nonland permanents
MEMO (start of our turn):
THIS TURN: Play Swamp and tap it for Sol Ring. Nothing else is castable. We have no instant-speed plays on opponents' turns.

TARGET: Muldrotha on our turn 4, from 4 lands plus Sol Ring (needs B, G and U, with Triome covering one colour). Then Doc Aurlock so graveyard casts cost 2 less. Stock the lanes with Executioner's Capsule, Seal of Doom and Plaguecrafter. Key tutor targets: Survival of the Fittest, Demonic Tutor (for Pernicious Deed or Toxic Deluge against go-wide boards).
- Next turn, if we draw an untapped dual: play it and cast Braids (needs BB) or Doc (needs GU), or any mana rock. Otherwise play Zagoth Triome tapped and cast any drawn rock with Swamp plus Sol Ring.
- Turn after: Island, then Syr Konrad using Swamp B, Triome B and Sol Ring.
- Turn 4: Forest, then Muldrotha.

WIN PATH: Muldrotha recurs removal every turn, Braids end-step drains, and Syr Konrad pings on every death. Close with Gray Merchant or Massacre Wurm, targeting turns 9-11. Edgar (P3) is fastest at turns 6-8, then Giada (P2).

THREATS & ANSWERS: 1) P3 Edgar tokens, Vito or Skullclamp: no answer in hand yet; Massacre Wurm or Deed later. 2) P2 Giada, who Enlightened Tutored, so watch for Smothering Tithe or Land Tax. 3) P1 Teval ramp. Don't cast Konrad into an obvious Olivia's Wrath with Blood Artist out.

HOLD: Braids until Muldrotha is online or we have a spent artifact to sacrifice. Never sacrifice lands to Braids before turn 6. Don't cycle the Triome.

REPLAN IF: Sol Ring is removed. We draw a tutor or ramp spell. P3 lands Vito or Exquisite Blood. P2 reveals a Smothering Tithe.
- US cast Sol Ring

## Turn 4 (P1, round 1)

## Turn 5 (P2, round 2)
- P2 cast Giada, Font of Hope

## Turn 6 (P3, round 2)

## Turn 7 (OUR TURN, round 2)
Our hand: Doc Aurlock, Grizzled Genius, Syr Konrad, the Grim, Island, Forest, Zagoth Triome, Braids, Arisen Nightmare, Sheoldred
Our graveyard (0): 
Board P1: 1 lands; no nonland permanents
Board P2: 2 lands; Giada, Font of Hope 2/2
Board P3: 2 lands; no nonland permanents
Board US: 1 lands; Sol Ring
MEMO (start of our turn):
THIS TURN: Play Zagoth Triome (enters tapped). Nothing in hand is castable with Swamp plus Sol Ring. Braids needs BB and Doc needs G and U, and an untapped basic doesn't fix either, so the tapped land costs nothing. No instant-speed plays on opponents' turns. Do not cycle the Triome.

TARGET:
- Next turn: play Island, then cast Sheoldred (Swamp B, Triome B, Sol Ring 2, Island 1). Every opponent sacrifices a nontoken creature, which should hit Giada or her best Angel.
- Turn after: play Forest and cast Muldrotha (Swamp B, Forest G, Island U, Triome, Sol Ring 2).
- Then Doc Aurlock, and stock the lanes with Executioner's Capsule, Seal of Doom and Plaguecrafter.
- Tutor targets: Survival of the Fittest, Demonic Tutor for Pernicious Deed or Toxic Deluge.

WIN PATH: Muldrotha recurs removal. Braids drains at end step and Syr Konrad pings on every death. Close with Gray Merchant or Massacre Wurm around turns 10-12. P3 Edgar (turns 6-8) and P2 Giada are the fastest clocks. No one threatens lethal before our next turn.

THREATS & ANSWERS:
1) P2 Giada and incoming Angels: Sheoldred's edict next turn.
2) P3 Edgar's Vampire tokens, Vito and Skullclamp: Massacre Wurm or Deed later.
3) P1 Teval: don't feed its graveyard. Sheoldred's edict also hits Teval if it's their only creature.

HOLD: Braids until Muldrotha is out or we have a spent artifact to sacrifice. Syr Konrad comes after Muldrotha. Don't cast Konrad into an obvious Olivia's Wrath.

REPLAN IF:
- Sol Ring is removed.
- We draw an untapped dual or a mana rock (Braids plus Doc may then fit next turn).
- P3 lands Vito, Exquisite Blood or Skullclamp.
- P2 casts Smothering Tithe or goes wide with Angels before Sheoldred resolves.
PILOT OVERRULED FORGE (action, MAIN1): chose [play land Zagoth Triome (from Hand): Play land] instead of Forge's [Take no further action this phase: hold remaining mana and cards]

## Turn 8 (P1, round 2)
- P1 cast Assassin's Trophy targeting [Giada, Font of Hope]
- left battlefield: Giada, Font of Hope was put into Graveyard from Battlefield.

## Turn 9 (P2, round 3)
- P2 cast Gisela, the Broken Blade

## Turn 10 (P3, round 3)

## Turn 11 (OUR TURN, round 3)
Our hand: Doc Aurlock, Grizzled Genius, Syr Konrad, the Grim, Island, Forest, Braids, Arisen Nightmare, Sheoldred, Bayou
Our graveyard (0): 
Board P1: 2 lands; no nonland permanents
Board P2: 4 lands; Gisela, the Broken Blade 4/3
Board P3: 3 lands; no nonland permanents
Board US: 2 lands; Sol Ring
MEMO (start of our turn):
THIS TURN: Play Bayou (untapped B/G). Cast Sheoldred with Swamp B, Bayou B, Triome and Sol Ring 2 for 5 mana. Every opponent sacrifices a nontoken creature or planeswalker. Only P2 has one, so Gisela dies. P1 and P2 are tapped out, so this is a clean window. P3 can Swords Sheoldred, but the edict still resolves. Nothing is left to use on opponents' turns.

TARGET: Next turn, play Island and cast Muldrotha for 6 (Swamp B, Bayou G, Island U, Triome, Sol Ring 2). The turn after, play Forest and cast Braids plus Doc Aurlock, then Syr Konrad. Draw or tutor into Executioner's Capsule, Seal of Doom, Plaguecrafter and Survival of the Fittest. Demonic Tutor goes to Pernicious Deed or Toxic Deluge if P3 goes wide.

WIN PATH: Muldrotha recasts Sheoldred and our removal permanents every turn. Braids drains at end step and Konrad pings on each death. Close with Gray Merchant or Massacre Wurm. Our clock is about 4-5 more turns. The opponents are slow: P1 has 2 lands, P3 has no board. Nobody can kill us before our next turn.

THREATS & ANSWERS:
1) P2: Giada recast (4 mana with tax) plus Angels. Answer with Sheoldred's edict now; after that, Muldrotha recasts Sheoldred or the Seals.
2) P3 Edgar (7 cards): Vito, Skullclamp or a token swarm. Answer with Deed or Massacre Wurm.
3) P1 Teval: don't let it stock its graveyard. Its Assassin's Trophy may come for Muldrotha.

HOLD: Braids, Doc and Konrad until Muldrotha is down. Don't cast Konrad into an obvious Olivia's Wrath. Keep Island and Forest for the next land drops.

REPLAN IF: Sheoldred is countered, or P2 flashes in or protects Gisela. P3 lands Vito or Skullclamp. Sol Ring is removed. Giada returns with Angels before Muldrotha.
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Sheoldred (from Hand): Sheoldred - Creature 4 / 5 [Forge's heuristic AI would not do ] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
- US cast Sheoldred
- US triggered Sheoldred
- left battlefield: Gisela, the Broken Blade was put into Graveyard from Battlefield.

## Turn 12 (P1, round 3)
- P1 triggered Golgari Rot Farm

## Turn 13 (P2, round 4)
- P2 cast Lyra Dawnbringer

## Turn 14 (P3, round 4)

## Turn 15 (OUR TURN, round 4) | life: P1 38, P2 38, P3 38
Our hand: Doc Aurlock, Grizzled Genius, Syr Konrad, the Grim, Island, Forest, Braids, Arisen Nightmare, Nature's Lore
Our graveyard (0): 
Board P1: 2 lands; no nonland permanents
Board P2: 5 lands; Lyra Dawnbringer 5/5
Board P3: 4 lands; no nonland permanents
Board US: 3 lands; Sol Ring, Sheoldred 4/5
MEMO (start of our turn):
THIS TURN: 1) Play Island. 2) Cast Nature's Lore using Bayou G plus Sol Ring. Sol makes CC, so one C floats. Fetch Tropical Island, which enters untapped. 3) Right away, cast Braids with Swamp B, Triome B and the floating C. 4) Cast Doc Aurlock with Tropical Island G and Island U. That uses all 7 mana. 5) End step, Braids trigger: sacrifice Sol Ring. No opponent has an artifact, so each loses 2 life and we draw 3. Keep Sheoldred on board.

TARGET: Next turn, play Forest. Cast Muldrotha with the six lands. Recast Sol Ring from the graveyard for free (Doc makes it cost 0) to get CC. Sacrifice Sol Ring to Braids every end step, which drains each opponent 2 and draws us 3 per turn. Later, sacrifice Sheoldred to Braids only when we can recast it (3 mana with Doc) on our very next turn. Tutor for Executioner's Capsule, Seal of Doom, Survival of the Fittest and Demonic Tutor.

WIN PATH: The Braids loop drains 6 per turn in total, plus Konrad pings and Gray Merchant. We should close in about 5 turns. No opponent can kill us before our next turn.

THREATS & ANSWERS: 1) P2's Lyra and a Giada recast: kill with a Sheoldred recast edict, or Capsule (Lyra is nonblack). 2) P3 Edgar tokens, Vito or Skullclamp: answer with Pernicious Deed or Massacre Wurm. 3) P1 Teval's self-mill: Konrad later punishes its mills. Don't leave Sheoldred in our graveyard, because P1 could Reanimate it.

HOLD: Syr Konrad: no spare mana, and don't cast it into an Olivia's Wrath or Farewell. Keep Forest for next turn's land drop.

REPLAN IF: An opponent has an artifact at our end step, Doc dies, our graveyard is exiled by Bojuka Bog, P2 wipes the board, or P3 lands Vito.
PILOT OVERRULED FORGE (search, MAIN1): chose [Tropical Island — Land - Forest Island — ({T}: Add {G} or {U}.)] instead of Forge's [Breeding Pool — Land - Forest Island — ({T}: Add {G} or {U}.) As Breeding Pool enters, you]
- US cast Nature's Lore
- US cast Braids, Arisen Nightmare
- US triggered Braids, Arisen Nightmare
- left battlefield: Sol Ring was put into Graveyard from Battlefield.

## Turn 16 (P1, round 4)
- P1 cast Teval, the Balanced Scale

## Turn 17 (P2, round 5) | life: P1 38, P2 43, P3 38, US 35
- P2 cast Giada, Font of Hope
- attack: P2 assigned Lyra Dawnbringer to attack US.
Damage to US this turn: Lyra Dawnbringer (combat) 5

## Turn 18 (P3, round 5)
- P3 cast Damn
- left battlefield: Sheoldred was put into Graveyard from Battlefield.
- left battlefield: Braids, Arisen Nightmare was put into Graveyard from Battlefield.
- left battlefield: Teval, the Balanced Scale was put into Graveyard from Battlefield.
- left battlefield: Lyra Dawnbringer was put into Graveyard from Battlefield.
- left battlefield: Giada, Font of Hope was put into Graveyard from Battlefield.

## Turn 19 (OUR TURN, round 5) | life: P1 36, P2 41, P3 36, US 35
Our hand: Doc Aurlock, Grizzled Genius, Syr Konrad, the Grim, Forest, Survival of the Fittest, Otawara, Soaring City, Professor Dellian Fel, Animate Dead
Our graveyard (4): Nature's Lore, Sol Ring, Sheoldred, Braids, Arisen Nightmare
Board P1: 3 lands; no nonland permanents
Board P2: 5 lands; no nonland permanents
Board P3: 5 lands; no nonland permanents
Board US: 5 lands; no nonland permanents
MEMO (start of our turn):
THIS TURN: The board was just wiped, so rebuild cheaply. 1) Play Forest. 2) Cast Doc Aurlock (Forest G, Island U). 3) Cast Animate Dead (Swamp B, Tropical Island) on Braids from our graveyard. It comes back as a 2/3. 4) Cast Survival of the Fittest (Bayou G, Triome). That uses all 6 mana. 5) End step, Braids trigger: sacrifice Survival. No opponent has an enchantment, so each loses 2 and we draw 3. Muldrotha recasts Survival next turn for just G.

TARGET: Next turn, play Otawara and cast Muldrotha with 6 of 7 lands. Recast Sol Ring from the graveyard for free, then Sheoldred for 1BB or Survival for G. Doc discounts only generic mana. After that: Braids sac every end step, and Survival tutors Gray Merchant, Massacre Wurm and Shriekmaw.

WIN PATH: The Braids drain gives 6 per turn in total. Add Syr Konrad pings, then Gray Merchant recast through the creature lane. Close in about 5 turns. No one can kill us before our next turn.

THREATS & ANSWERS:
1) P2 recasting Giada, then Lyra: answer with Professor Dellian Fel's -3 or a Sheoldred recast edict.
2) P1 Teval, castable now off Rot Farm: answer with Dellian -3. Otawara channel (costs 1U with two legends) can tuck it to hand.
3) P3 Vito or Skullclamp: answer with Dellian, Deed or Wurm.

HOLD: Syr Konrad and Dellian Fel: don't overcommit right after P3's Damn. P2 still has Farewell or Austere Command. Keep Otawara for next turn's land drop, or as a bounce in an emergency.

REPLAN IF: Braids or Doc is removed before our end step, P1 exiles our graveyard, an opponent lands an enchantment before our end step (sacrifice Animate Dead or skip the trigger instead), or Vito or Exquisite Blood appears.
PILOT OVERRULED FORGE (action, MAIN1): chose [Braids, Arisen Nightmare [ours, 3/3, in graveyard]] instead of Forge's [Lyra Dawnbringer [P2, 5/5, in graveyard]]
PILOT OVERRULED FORGE (action, MAIN2): chose [cast Survival of the Fittest (from Hand): Survival of the Fittest] instead of Forge's [cast Doc Aurlock, Grizzled Genius (from Hand): Doc Aurlock, Grizzled Genius - Creature 2 /]
- US cast Animate Dead targeting [Braids, Arisen Nightmare]
- US triggered Animate Dead
- US cast Survival of the Fittest
- US cast Doc Aurlock, Grizzled Genius
- US triggered Braids, Arisen Nightmare
- left battlefield: Survival of the Fittest was put into Graveyard from Battlefield.

## Turn 20 (P1, round 5)
- P1 cast Six
- P1 cast Shigeki, Jukai Visionary

## Turn 21 (P2, round 6)
- P2 cast Vanquisher's Banner

## Turn 22 (P3, round 6) | life: P1 36, P2 41, P3 36, US 30
- P3 cast Edgar Markov
- attack: P3 assigned Edgar Markov to attack US.
- P3 triggered Edgar Markov
Damage to US this turn: Edgar Markov (combat) 5

## Turn 23 (OUR TURN, round 6) | life: P1 34, P2 39, P3 34, US 29
Our hand: Syr Konrad, the Grim, Forest, Professor Dellian Fel, Verdant Catacombs, Cryogen Relic, Kaya's Ghostform, Eternal Witness
Our graveyard (4): Nature's Lore, Sol Ring, Sheoldred, Survival of the Fittest
Board P1: 4 lands; Six 2/4, Shigeki, Jukai Visionary 1/3
Board P2: 5 lands; Vanquisher's Banner
Board P3: 6 lands; Edgar Markov 5/5 {[P1P1]} (tapped 1)
Board US: 6 lands; Animate Dead, Braids, Arisen Nightmare 2/3, Doc Aurlock, Grizzled Genius 2/3
MEMO (start of our turn):
THIS TURN: 1) Play Verdant Catacombs (pay 1 life) and fetch Underground Sea untapped. Keep Forest in hand. 2) Cast Muldrotha for 6 from lands: Swamp B, Tropical G, Island U, plus Otawara, Triome and Bayou. Leave Underground Sea untapped. 3) From the graveyard, cast Sol Ring (free with Doc). 4) Cast Kaya's Ghostform on Muldrotha using Underground Sea's B. Sol Ring's CC goes unused. Sheoldred is not castable this turn: after Muldrotha, only one black source is left. 5) End step, Braids: sacrifice Sol Ring. P2 may sacrifice Vanquisher's Banner; everyone else loses 2 and we draw. Don't block Edgar with Muldrotha: his first strike kills it.

TARGET: Next turn, replay Catacombs through the land lane, then recast Sol Ring (free), Sheoldred (1BB) and Survival (G). Add Dellian Fel and Syr Konrad. Survival finds Gray Merchant, Massacre Wurm and Shriekmaw.

WIN PATH: Braids drains about 6 per turn, plus Konrad pings and recast Gray Merchant. Opponents are at 36/41/36. Expect roughly 5 turns, about the same as P2 and P3's clocks, so remove their engines first.

THREATS & ANSWERS: 1) Edgar and P3's Vampires (Vito, Exquisite Blood): Sheoldred edict next turn, Massacre Wurm for tokens. 2) P2 Giada and Angels: Dellian -3. 3) P1 Teval: Dellian -3 or an Otawara tuck. Don't chump-block creatures into P3's death triggers.

HOLD: Syr Konrad, Dellian Fel and Eternal Witness stay in hand against P2's Farewell or Austere Command and P1's Living Death. Hold Cryogen Relic for next turn.

REPLAN IF: Muldrotha is exiled or countered, our graveyard is exiled, P3 lands Vito or Exquisite Blood (Dellian -3 or Sheoldred first), or Teval hits the battlefield.
PILOT OVERRULED FORGE (action, MAIN1): chose [play land Verdant Catacombs (from Hand): Play land] instead of Forge's [play land Forest (from Hand): Play land]
PILOT OVERRULED FORGE (search, MAIN1): chose [Underground Sea — Land - Island Swamp — ({T}: Add {U} or {B}.)] instead of Forge's [Breeding Pool — Land - Forest Island — ({T}: Add {G} or {U}.) As Breeding Pool enters, you]
PILOT OVERRULED FORGE (action, MAIN1): chose [Braids, Arisen Nightmare [ours, 2/3]] instead of Forge's [Doc Aurlock, Grizzled Genius [ours, 2/3]]
PILOT OVERRULED FORGE (attack, COMBAT_DECLARE_ATTACKERS): chose [don't attack with it] instead of Forge's [attack P3 (36 life)]
PILOT OVERRULED FORGE (attack, COMBAT_DECLARE_ATTACKERS): chose [don't attack with it] instead of Forge's [attack P3 (36 life)]
PILOT OVERRULED FORGE (action, MAIN2): chose [cast Sol Ring (from Graveyard): Sol Ring by Muldrotha, the Gravetide (403) (Artifact)] instead of Forge's [cast Sol Ring (from Graveyard): Sol Ring by Muldrotha, the Gravetide (403) (Artifact)]
- left battlefield: Verdant Catacombs was put into Graveyard from Battlefield.
- US activated Verdant Catacombs
- US cast Kaya's Ghostform targeting [Braids, Arisen Nightmare]
- US cast Muldrotha, the Gravetide
- US cast Sol Ring
- US triggered Braids, Arisen Nightmare
- left battlefield: Swamp was put into Graveyard from Battlefield.

## Turn 24 (P1, round 6)
- P1 cast Muldrotha, the Gravetide

## Turn 25 (P2, round 7)
- P2 cast Giada, Font of Hope
- P2 triggered Vanquisher's Banner

## Turn 26 (P3, round 7) | life: P1 34, P2 39, P3 31, US 23
- P3 cast Anguished Unmaking targeting [Muldrotha, the Gravetide]
- left battlefield: Muldrotha, the Gravetide was put into Exile from Battlefield.
- P3 cast Vampire of the Dire Moon
- P3 triggered Edgar Markov
- attack: P3 assigned Edgar Markov to attack US.
- P3 triggered Edgar Markov
Damage to US this turn: Edgar Markov (combat) 6

## Turn 27 (OUR TURN, round 7) | life: P1 32, P2 37, P3 29, US 22
Our hand: Syr Konrad, the Grim, Professor Dellian Fel, Cryogen Relic, Eternal Witness, Barrin, Master Wizard, Misty Rainforest, Binding the Old Gods, Three Visits
Our graveyard (6): Nature's Lore, Sheoldred, Survival of the Fittest, Verdant Catacombs, Swamp, Forest
Board P1: 5 lands; Six 2/4, Shigeki, Jukai Visionary 1/3, Muldrotha, the Gravetide 6/6
Board P2: 6 lands; Vanquisher's Banner, Giada, Font of Hope 3/3
Board P3: 7 lands; Edgar Markov 6/6 {[P1P1 x 2]} (tapped 1), Vampire Token 2/2 [token] {[P1P1]}, Vampire of the Dire Moon 2/2 {[P1P1]}
Board US: 6 lands; Animate Dead, Braids, Arisen Nightmare 2/3, Doc Aurlock, Grizzled Genius 2/3, Kaya's Ghostform, Sol Ring
MEMO (start of our turn):
THIS TURN: 1) Play Misty Rainforest, pay 1 life, fetch a basic Forest untapped (9 mana). 2) Cast Binding the Old Gods with Underground Sea (B), Tropical Island (G), Island and Otawara. Chapter I destroys P1's Muldrotha. 3) Cast Professor Dellian Fel with Bayou (B), Forest (G) and Sol Ring. Use −3 on Edgar Markov (6/6 haste first striker, their fastest clock; recast costs them 8). 4) End step: Braids sacrifices Dellian. No opponent has a planeswalker, so each loses 2 and we draw 3. Never sacrifice Sol Ring: we need it next turn. Blocks: Doc or Braids may block 2/2 tokens. Never block Vampire of the Dire Moon (deathtouch).

TARGET: Next turn: Muldrotha (8 of our 9), Verdant Catacombs from the graveyard for an untapped Swamp, then Dellian from the graveyard (BG with Doc), −3 a creature, and sacrifice it to Braids again. Then add Sheoldred (1BB), Survival (G) and Sol Ring loops. Use Survival to find Massacre Wurm, Gray Merchant and Shriekmaw.

WIN PATH: Loop Dellian with Braids: one kill, 6 drain and 3 cards every turn. Then Syr Konrad, Gray Merchant and Massacre Wurm finish. The clock is roughly 6+ turns, so keep P3's board empty.

THREATS & ANSWERS: 1) P3 Vampires (Vito, Exquisite Blood, Captivating Vampire): Dellian loop, Sheoldred, Wurm. 2) P1 Six retrace recasting Muldrotha: Sheoldred edict, then Binding again. 3) P2 Giada, Banner and Angels: Sheoldred edict (Giada is their only creature).

HOLD: Syr Konrad, Eternal Witness, Barrin, Cryogen Relic and Three Visits stay in hand against P3's Olivia's Wrath and P2's Farewell. Witness rebuys whatever dies.

REPLAN IF: Farewell or Bojuka Bog hits our graveyard, P1 recasts Muldrotha, P3 lands Vito or Captivating Vampire, or Sol Ring dies (then there's no Muldrotha next turn: cast Sheoldred via Eternal Witness instead).
PILOT OVERRULED FORGE (search, MAIN1): chose [Breeding Pool — Land - Forest Island — ({T}: Add {G} or {U}.) As Breeding Pool enters, you] instead of Forge's [Watery Grave — Land - Island Swamp — ({T}: Add {U} or {B}.) As Watery Grave enters, you ma]
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Binding the Old Gods (from Hand): Binding the Old Gods [Forge's heuristic AI would no] instead of Forge's [cast Three Visits (from Hand): Search your library for a Forest card, put that card onto t]
PILOT OVERRULED FORGE (discard, CLEANUP): chose [Soul-Guide Lantern [ours, in hand]] instead of Forge's [Wooded Foothills [ours, in hand]]
- left battlefield: Misty Rainforest was put into Graveyard from Battlefield.
- US activated Misty Rainforest
- US cast Binding the Old Gods
- US triggered Binding the Old Gods targeting [Edgar Markov]
- left battlefield: Edgar Markov was put into Graveyard from Battlefield.
- US cast Three Visits
- US cast Cryogen Relic
- US triggered Cryogen Relic
- US triggered Braids, Arisen Nightmare
- left battlefield: Island was put into Graveyard from Battlefield.

## Turn 28 (P1, round 7) | life: P1 32, P2 37, P3 29, US 16
- attack: P1 assigned Muldrotha, the Gravetide to attack US.
- P1 cast Teval, the Balanced Scale
Damage to US this turn: Muldrotha, the Gravetide (combat) 6

## Turn 29 (P2, round 8) | life: P1 32, P2 37, P3 29, US 13
- P2 cast Swiftfoot Boots
- P2 cast Angelic Field Marshal
- P2 triggered Vanquisher's Banner
- attack: P2 assigned Giada, Font of Hope to attack US.
Damage to US this turn: Giada, Font of Hope (combat) 3

## Turn 30 (P3, round 8) | life: P1 32, P2 37, P3 25, US 13
- P3 cast Champion of Dusk
- P3 triggered Edgar Markov
- P3 triggered Champion of Dusk
- P3 cast Cruel Celebrant
- P3 triggered Edgar Markov

## Turn 31 (OUR TURN, round 8) | life: P1 30, P2 35, P3 23, US 12
Our hand: Syr Konrad, the Grim, Professor Dellian Fel, Eternal Witness, Barrin, Master Wizard, Massacre Wurm, Wooded Foothills, Takenuma, Abandoned Mire, Bloodstained Mire
Our graveyard (10): Nature's Lore, Sheoldred, Survival of the Fittest, Verdant Catacombs, Swamp, Forest, Misty Rainforest, Three Visits, Island, Soul-Guide Lantern
Board P1: 6 lands; Six 2/4, Shigeki, Jukai Visionary 1/3, Muldrotha, the Gravetide 6/6 (tapped 1), Teval, the Balanced Scale 4/4
Board P2: 7 lands; Vanquisher's Banner, Giada, Font of Hope 3/3, Swiftfoot Boots, Angelic Field Marshal 7/7 {[P1P1]}
Board P3: 8 lands; Vampire Token 2/2 [token] {[P1P1]}, Vampire of the Dire Moon 2/2 {[P1P1]}, Vampire Token 1/1 [token] x2, Champion of Dusk 4/4, Cruel Celebrant 1/2
Board US: 7 lands; Animate Dead, Braids, Arisen Nightmare 2/3, Doc Aurlock, Grizzled Genius 2/3, Kaya's Ghostform, Sol Ring, Binding the Old Gods {[LORE x 2]}, Cryogen Relic
MEMO (start of our turn):
THIS TURN: 1) Let Binding II resolve and fetch a basic Forest (it enters tapped). 2) Play Wooded Foothills and leave it uncracked to save life. 3) Cast Dellian (Bayou B, Overgrown Tomb G, Zagoth, Tropical Island) and −3 Angelic Field Marshal. If Boots gives it hexproof, −3 Giada instead. 4) Cast Barrin (Otawara U, Underground Sea U, Breeding Pool). Keep Sol Ring untapped for one {2} Barrin bounce on opponents' turns, sacrificing Cryogen Relic (draws). Priority: bounce Teval when it attacks us, or Vito or Captivating Vampire on entry. 5) End step: Braids sacrifices Dellian for 6 drain and 3 cards.

TARGET: Next turn has 12 mana: Muldrotha (8), Verdant Catacombs from the graveyard, then Sheoldred (3) or Dellian (BG), plus Lantern (free). Then Barrin bounces Cruel Celebrant before Massacre Wurm, which kills P3's tokens with no Celebrant drain on us. Survival finds Gray Merchant and Shriekmaw.

WIN PATH: Loop Wurm and Dellian, with Braids draining 6 a turn, then Syr Konrad and Gray Merchant. About 5 turns, while P3/P2 threaten turns 2-3.

THREATS & ANSWERS: 1) P2 fliers (Field Marshal plus Giada, 10 flying, near lethal with Teval): Dellian now, Sheoldred next. 2) P3 go-wide, Vito, Exquisite Blood: Barrin bounce, Binding recast for Blood, Wurm after Celebrant leaves. Never cast Wurm while Celebrant lives (5 drain on us). 3) P1 Teval and Muldrotha: Barrin now, Binding next.

HOLD: Wurm, Konrad, Witness, Takenuma (channel returns Sheoldred for 2), Bloodstained Mire. Don't block Dire Moon.

REPLAN IF: Field Marshal survives (Flawless Maneuver): Barrin bounces it when it attacks. Also replan if Barrin dies, a wipe resolves, or P1 casts Living Death.
PILOT OVERRULED FORGE (action, MAIN1): chose [play land Wooded Foothills (from Hand): Play land] instead of Forge's [play land Takenuma, Abandoned Mire (from Hand): Play land]
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Professor Dellian Fel (from Hand): Professor Dellian Fel [Forge's heuristic AI would ] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN2): chose [cast Barrin, Master Wizard (from Hand): Barrin, Master Wizard - Creature 1 / 1] instead of Forge's [cast Syr Konrad, the Grim (from Hand): Syr Konrad, the Grim - Creature 5 / 4]
PILOT OVERRULED FORGE (action, MAIN2): chose [activate Barrin, Master Wizard (from Battlefield): {2}, Sacrifice a permanent: Return targ] instead of Forge's [cast Eternal Witness (from Hand): Eternal Witness - Creature 2 / 1]
PILOT OVERRULED FORGE (action, MAIN2): chose [Cruel Celebrant [P3, 1/2]] instead of Forge's [Muldrotha, the Gravetide [P1, 6/6, tapped]]
- US triggered Binding the Old Gods
- left battlefield: Wooded Foothills was put into Graveyard from Battlefield.
- US activated Wooded Foothills
- US cast Professor Dellian Fel
- US activated Professor Dellian Fel targeting [Angelic Field Marshal]
- left battlefield: Angelic Field Marshal was put into Graveyard from Battlefield.
- US cast Barrin, Master Wizard
- left battlefield: Forest was put into Graveyard from Battlefield.
- US activated Barrin, Master Wizard targeting [Cruel Celebrant]
- US triggered Braids, Arisen Nightmare
- left battlefield: Forest was put into Graveyard from Battlefield.

## Turn 32 (P1, round 8) | life: P1 30, P2 35, P3 23, US 6
- attack: P1 assigned Muldrotha, the Gravetide to attack US.
- P1 triggered Teval, the Balanced Scale
- left battlefield: Professor Dellian Fel was put into Graveyard from Battlefield.
- P1 cast The Scarab God
- P1 cast Lightning Greaves
- P1 triggered Teval, the Balanced Scale
- P1 activated Lightning Greaves targeting [Muldrotha, the Gravetide]
Damage to US this turn: Muldrotha, the Gravetide (combat) 6

## Turn 33 (P2, round 9)
- left battlefield: Myriad Landscape was put into Graveyard from Battlefield.
- P2 activated Myriad Landscape
- P2 cast Starnheim Aspirant
- P2 cast Youthful Valkyrie
- P2 triggered Vanquisher's Banner
- P2 activated Swiftfoot Boots targeting [Giada, Font of Hope]

## Turn 34 (P3, round 9)
- P3 cast Edgar Markov

## Turn 35 (OUR TURN, round 9) | life: P1 28, P2 33, P3 21, US 5
Our hand: Syr Konrad, the Grim, Eternal Witness, Massacre Wurm, Bloodstained Mire, Scalding Tarn, Assassin's Trophy, Plaguecrafter
Our graveyard (15): Nature's Lore, Sheoldred, Survival of the Fittest, Verdant Catacombs, Swamp, Forest, Misty Rainforest, Three Visits, Island, Soul-Guide Lantern, Wooded Foothills, Forest, Forest, Takenuma, Abandoned Mire, Professor Dellian Fel
Board P1: 7 lands; Six 2/4, Shigeki, Jukai Visionary 1/3, Muldrotha, the Gravetide 6/6 (tapped 1), Teval, the Balanced Scale 4/4 (tapped 1), The Scarab God 5/5, Zombie Druid Token 2/2 [token], Lightning Greaves
Board P2: 9 lands; Vanquisher's Banner, Giada, Font of Hope 3/3, Swiftfoot Boots, Starnheim Aspirant 2/2, Youthful Valkyrie 3/5 {[P1P1]}
Board P3: 9 lands; Vampire Token 2/2 [token] {[P1P1]}, Vampire of the Dire Moon 2/2 {[P1P1]}, Vampire Token 1/1 [token] x2, Champion of Dusk 4/4, Edgar Markov 4/4
Board US: 7 lands; Animate Dead, Braids, Arisen Nightmare 2/3, Doc Aurlock, Grizzled Genius 2/3, Kaya's Ghostform, Sol Ring, Binding the Old Gods {[LORE x 2]}, Cryogen Relic, Barrin, Master Wizard 1/1
MEMO (start of our turn):
THIS TURN: No one can respond with mana: P1 has only Command Beacon open, P2 and P3 are tapped out. Don't attack; keep every blocker home.
1) Let Binding III resolve.
2) Play Bloodstained Mire and crack it for a basic Swamp (6→5 life). That gives 10 mana.
3) Cast Massacre Wurm (Swamp, Underground Sea, Zagoth, Sol Ring, Tropical Island). Celebrant is in P3's hand, so Wurm is safe now. It kills 7 creatures (P3 −8, P1 −4, P2 −2), including the Zombie token, so Scarab God's upkeep drain drops to 0.
4) Assassin's Trophy (Overgrown Tomb, Breeding Pool) on Youthful Valkyrie. P2's fliers alone are lethal against us.
5) Keep Bayou and Otawara open for one Barrin bounce ({2}, sacrifice Cryogen Relic, which draws). First choice: Teval if it attacks us. Otherwise a hasty angel on P2's turn, or Edgar.
6) End step: Braids sacrifices Kaya's Ghostform. No opponent will have an enchantment, so each loses 2 and we draw 3.

TARGET: Next turn: Muldrotha (8), play Takenuma from the graveyard, recast Binding (BG) on Scarab God. Then Sheoldred or Plaguecrafter to edict Giada once she is P2's only creature.

WIN PATH: Barrin bounces our own Wurm to recast the sweep. Wurm drains, Syr Konrad pings, Braids drains 6 a turn. About 4 turns.

THREATS & ANSWERS:
1) P2 fliers. Giada is hexproof, so use edicts only.
2) P1 Scarab God: it can copy our Sheoldred from our graveyard, and upkeep activations add drain. Answer it with Binding next turn. Teval gets the Barrin bounce.
3) P3 Edgar rebuild and Vito: Plaguecrafter, Wurm recast.

HOLD: Konrad, Witness, Plaguecrafter, Scalding Tarn (next land drop). Blocking: Wurm blocks Muldrotha. Barrin may chump, and can sacrifice itself to its own ability.

REPLAN IF: Valkyrie survives (Flawless Maneuver): save Barrin for it on P2's turn. Also replan if Scarab upkeep drain leaves us at 3 or less, or if Wurm is removed before P3's turn.
MEMO (executor escalation: we lost: Binding the Old Gods):
THIS TURN: Priority is survival at 6 life. Binding is gone.
1) Play Bloodstained Mire and crack it for a basic Swamp (life 6→5).
2) Cast Massacre Wurm using Swamp, Underground Sea, Zagoth, Sol Ring and Breeding Pool. It kills Shigeki, the Zombie token, Aspirant and P3's four small Vampires (P3 −8, P1 −4, P2 −2).
3) Keep Otawara and Tropical Island open for one Barrin bounce ({2}, sacrifice Cryogen Relic to draw). Use it on the first of these:
   - Teval when it attacks us.
   - On P2's turn, whichever flier attacking us lacks hexproof. If Boots move, bounce Giada.
   - On P3's turn, Vito, Bloodthirsty Conqueror or an unblocked attacker.
4) End step: Braids sacrifices Kaya's Ghostform. No opponent will have an enchantment, so each loses 2 and we draw 3.

TARGET: Next turn: Muldrotha. Recast Professor Dellian Fel (+2, gain 3). Recast Sheoldred to edict; Giada goes if she's P2's only creature. Soul-Guide Lantern is free: exile a key yard creature on entry, and later sacrifice it to exile all opponents' yards, which weakens Scarab God. Recast Binding on Scarab God.

WIN PATH: Wurm drains, Braids drains 6 a turn, and Syr Konrad pings. That's roughly 5 turns. P3 is fastest.

THREATS & ANSWERS: 1) P3's swarm plus Cruel Celebrant: Wurm is the answer; avoid needless chump blocks. 2) Teval, 4 in the air: Barrin. 3) Scarab God's upkeep drain and copies: Binding next turn. 4) Giada, who is hexproof: Sheoldred or Plaguecrafter edict.

HOLD: Keep Syr Konrad, Eternal Witness, Plaguecrafter and Invasion. Save Scalding Tarn for next turn's land drop. Block every attacker aimed at us. Wurm blocks the biggest, Braids and Doc block the mid-sized ones, and Barrin blocks last.

REPLAN IF: Scarab God's upkeep drain puts us at 3 or less, Wurm is removed, or P3 lands Vito.
PILOT OVERRULED FORGE (action, UPKEEP): chose [Youthful Valkyrie [P2, 3/5]] instead of Forge's [The Scarab God [P1, 5/5]]
ESCALATION (p=0.82): we lost: Binding the Old Gods
PILOT OVERRULED FORGE (action, MAIN1): chose [activate Barrin, Master Wizard (from Battlefield): {2}, Sacrifice a permanent: Return targ] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN1): chose [activate Barrin, Master Wizard (from Battlefield): {2}, Sacrifice a permanent: Return targ] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN1): chose [activate Barrin, Master Wizard (from Battlefield): {2}, Sacrifice a permanent: Return targ] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
- US cast Assassin's Trophy targeting [Youthful Valkyrie]
- left battlefield: Youthful Valkyrie was put into Graveyard from Battlefield.
- US triggered Binding the Old Gods
- left battlefield: Binding the Old Gods was put into Graveyard from Battlefield.
- left battlefield: Bloodstained Mire was put into Graveyard from Battlefield.
- US activated Bloodstained Mire
- left battlefield: Bayou was put into Graveyard from Battlefield.
- US activated Barrin, Master Wizard targeting [Teval, the Balanced Scale]
- left battlefield: Overgrown Tomb was put into Graveyard from Battlefield.
- US activated Barrin, Master Wizard targeting [Edgar Markov]
- left battlefield: Tropical Island was put into Graveyard from Battlefield.
- US activated Barrin, Master Wizard targeting [The Scarab God]
- US triggered Braids, Arisen Nightmare
- left battlefield: Sol Ring was put into Graveyard from Battlefield.

## Turn 36 (P1, round 9)
MEMO (executor escalation: we lost: Sol Ring):
THIS TURN: We have 1 mana (Zagoth) and nothing castable, so this turn is only about blocks. If P1's Muldrotha attacks us, chump it with Barrin. Barrin needs {2} and we won't untap before our turn, so it is our most expendable body. If Kaya's Ghostform is enchanting one of our creatures, chump with that creature instead, since it will return. On P2's and P3's turns, block every ground attacker aimed at us so we survive. Giada flies in for 3 and we can't block her. Tap nothing.

TARGET: Next turn, crack Scalding Tarn for the basic Island (pay 1 life). Then cast Massacre Wurm with Zagoth, Underground Sea and Watery Grave for BBB, plus Otawara, Breeding Pool and Island. That is exactly 6. In the end step, Braids sacrifices Kaya's Ghostform: P2 and P3 lose 2 each and we draw. Muldrotha (8 mana with tax) comes the turn after.

WIN PATH: Wurm drains, Braids drains 2 each end step, Syr Konrad pings. This is a long clock. P3 is the fastest opponent, and survival comes first.

THREATS & ANSWERS: 1) P3's wide board and Edgar recast: Wurm. 2) P1's Muldrotha, which has shroud from Greaves: answer later with Plaguecrafter or Sheoldred edicts. 3) Giada, hexproof and flying: an edict. 4) Scarab God and Teval being recast: Invasion of Innistrad if they aren't shrouded.

HOLD: Keep Glen Elendra, Hostage Taker, Plaguecrafter, Invasion and Syr Konrad in hand. Save Scalding Tarn for our land drop.

REPLAN IF: We fall to 3 life or less, Edgar or Vito lands, Wurm gets countered or removed, or P1's Muldrotha attacks someone else and we keep Barrin.
ESCALATION (p=0.64): we lost: Sol Ring
PILOT OVERRULED FORGE (block, COMBAT_DECLARE_BLOCKERS): chose [no block (take the damage)] instead of Forge's [k-1]
- attack: P1 assigned Muldrotha, the Gravetide to attack US.
- attack: US assigned Barrin, Master Wizard to block Muldrotha, the Gravetide.
- left battlefield: Barrin, Master Wizard was put into Graveyard from Battlefield.
- P1 cast Hedge Shredder
- P1 cast Sakura-Tribe Elder
- left battlefield: Sakura-Tribe Elder was put into Graveyard from Battlefield.
- P1 activated Sakura-Tribe Elder

## Turn 37 (P2, round 10)
- P2 cast Farewell
- left battlefield: Vanquisher's Banner was put into Exile from Battlefield.
- left battlefield: Swiftfoot Boots was put into Exile from Battlefield.
- left battlefield: Cryogen Relic was put into Exile from Battlefield.
- left battlefield: Lightning Greaves was put into Exile from Battlefield.
- left battlefield: Hedge Shredder was put into Exile from Battlefield.
- left battlefield: Giada, Font of Hope was put into Exile from Battlefield.
- left battlefield: Starnheim Aspirant was put into Exile from Battlefield.
- left battlefield: Vampire of the Dire Moon was put into Exile from Battlefield.
- left battlefield: Champion of Dusk was put into Exile from Battlefield.
- left battlefield: Braids, Arisen Nightmare was put into Exile from Battlefield.
- left battlefield: Doc Aurlock, Grizzled Genius was put into Exile from Battlefield.
- left battlefield: Six was put into Exile from Battlefield.
- left battlefield: Shigeki, Jukai Visionary was put into Exile from Battlefield.
- left battlefield: Muldrotha, the Gravetide was put into Exile from Battlefield.
- left battlefield: Animate Dead was put into Exile from Battlefield.
- left battlefield: Kaya's Ghostform was put into Exile from Battlefield.
- US triggered Kaya's Ghostform
- US triggered Animate Dead
- US triggered Cryogen Relic
- P2 cast Herald's Horn

## Turn 38 (P3, round 10)
- P3 cast Edgar Markov
- P3 cast Master of Dark Rites
- P3 triggered Edgar Markov
- P3 cast Cruel Celebrant
- P3 triggered Edgar Markov
- attack: P3 assigned Edgar Markov to attack US.
- P3 triggered Edgar Markov
- attack: US assigned Braids, Arisen Nightmare to block Edgar Markov.
- left battlefield: Braids, Arisen Nightmare was put into Graveyard from Battlefield.

## Turn 39 (OUR TURN, round 10) | life: P1 25, P2 30, P3 18, US 2
Our hand: Syr Konrad, the Grim, Massacre Wurm, Scalding Tarn, Plaguecrafter, Invasion of Innistrad, Hostage Taker, Glen Elendra Archmage, Nurturing Peatland, Swamp
Our graveyard (1): Braids, Arisen Nightmare
Board P1: 9 lands; no nonland permanents
Board P2: 10 lands; Herald's Horn
Board P3: 10 lands; Edgar Markov 5/5 {[P1P1]} (tapped 1), Vampire Token 2/2 [token] {[P1P1]} x2, Master of Dark Rites 2/2 {[P1P1]}, Cruel Celebrant 2/3 {[P1P1]}
Board US: 5 lands; no nonland permanents
MEMO (start of our turn):
THIS TURN: Play Swamp, not Tarn or Peatland, since both cost life and we are at 5. Tap all six lands for Massacre Wurm (BBB from Swamp, Underground Sea and Watery Grave; generic from Zagoth, Otawara and Breeding Pool). The -2/-2 kills P3's two tokens and Master of Dark Rites, so P3 loses 6. Edgar and Cruel Celebrant survive. Celebrant's three triggers drop us to about 2. On P3's turn, block with Wurm. If one creature attacks, block it. If Edgar and Celebrant both attack, block Edgar (6 first-strike damage beats Wurm's 5 toughness; we lose Wurm but survive only if Celebrant alone is unblocked and we're above 3). Otherwise block whichever leaves unblocked damage below our life. We have no instant mana this cycle.

TARGET: Wurm on board and Muldrotha out (8 mana, the turn after next), with Braids recast from the graveyard for end-step drains. Tutor targets: Gray Merchant, Toxic Deluge.

WIN PATH: Wurm plus Syr Konrad and Braids drains. P3 is at about 18 and is the fastest opponent. Survival comes first.

THREATS & ANSWERS: 1) Cruel Celebrant, which drains us with every death: Invasion of Innistrad (4) next turn, before any more kills. 2) Edgar, whose eminence makes a token per Vampire cast: Hostage Taker to steal it, or Plaguecrafter. 3) Giada recast: Plaguecrafter edict. 4) P1's Teval: Invasion.

HOLD: Keep Invasion, Hostage Taker, Plaguecrafter, Glen Elendra and Syr Konrad in hand. Save Tarn and Peatland as future land drops, and crack them only at 4+ life.

REPLAN IF: Wurm is removed or countered, P3 lands Vito or Exquisite Blood, or we survive at 3+ life.
PILOT OVERRULED FORGE (action, MAIN1): chose [play land Swamp (from Hand): Play land] instead of Forge's [play land Nurturing Peatland (from Hand): Play land]
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Massacre Wurm (from Hand): Massacre Wurm - Creature 6 / 5 [Forge's heuristic AI would] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
- US cast Massacre Wurm
- US triggered Massacre Wurm
- left battlefield: Master of Dark Rites was put into Graveyard from Battlefield.
- US triggered Massacre Wurm
- US triggered Massacre Wurm
- US triggered Massacre Wurm
- P3 triggered Cruel Celebrant
- P3 triggered Cruel Celebrant
- P3 triggered Cruel Celebrant

## Turn 40 (P1, round 10)
- P1 cast Teval, the Balanced Scale
- P1 cast The Scarab God

## Turn 41 (P2, round 11)
- P2 triggered Herald's Horn
- P2 cast Angel of Destiny
- P2 cast Angelic Accord
- P2 cast Luminarch Ascension

## Turn 42 (P3, round 11) | life: P1 15, P2 26, P3 30, US -2
- P3 cast Malakir Bloodwitch
- P3 triggered Edgar Markov
- P3 triggered Malakir Bloodwitch
- P3 cast Cordial Vampire
- P3 triggered Edgar Markov
- attack: P3 assigned Edgar Markov to attack P1.
- P3 triggered Edgar Markov
- P3 cast Sol Ring

## Turn 43 (P1, round 11)
- P1 triggered The Scarab God
- P1 activated The Scarab God targeting [Master of Dark Rites]
- P1 cast Tatyova, Benthic Druid
- P2 triggered Luminarch Ascension

## Turn 44 (P2, round 11)
- P2 triggered Herald's Horn
- P2 cast Giada, Font of Hope

## Turn 45 (P3, round 12) | life: P1 15, P2 -36, P3 92, US -2
- P3 cast Olivia's Wrath
- left battlefield: Teval, the Balanced Scale was put into Graveyard from Battlefield.
- left battlefield: The Scarab God was put into Graveyard from Battlefield.
- left battlefield: Master of Dark Rites was put into Graveyard from Battlefield.
- left battlefield: Tatyova, Benthic Druid was put into Graveyard from Battlefield.
- left battlefield: Angel of Destiny was put into Graveyard from Battlefield.
- left battlefield: Giada, Font of Hope was put into Graveyard from Battlefield.
- P3 triggered Cordial Vampire
- P3 triggered Cordial Vampire
- P3 triggered Cordial Vampire
- P3 triggered Cordial Vampire
- P3 triggered Cordial Vampire
- P3 triggered Cordial Vampire
- P1 triggered The Scarab God
- attack: P3 assigned Edgar Markov, Malakir Bloodwitch, Cruel Celebrant, Vampire Token, Vampire Token and Cordial Vampire to attack P2.
- P3 triggered Edgar Markov
- P3 activated Vault of the Archangel
- P3 cast Phyrexian Arena
- P1 triggered The Scarab God

## Turn 46 (P1, round 12)
- P1 cast Colossal Grave-Reaver
- P1 triggered Colossal Grave-Reaver
- P1 triggered Colossal Grave-Reaver
- P1 triggered Sidisi, Brood Tyrant
- P1 cast Life from the Loam targeting [Opulent Palace, Swamp]

## Turn 47 (P3, round 12) | life: P1 -83, P2 -36, P3 91, US -2
- P3 triggered Phyrexian Arena
- P3 cast Bloodletter of Aclazotz
- P3 triggered Edgar Markov
- P3 cast Markov Baron
- P3 triggered Edgar Markov
- P3 cast Demonic Tutor
- attack: P3 assigned Edgar Markov, Malakir Bloodwitch, Cruel Celebrant, Vampire Token, Vampire Token and Cordial Vampire to attack P1.
- P3 triggered Edgar Markov
- attack: P1 assigned Sidisi, Brood Tyrant to block Edgar Markov.
- left battlefield: Sidisi, Brood Tyrant was put into Graveyard from Battlefield.
- P3 triggered Cordial Vampire
- Game Outcome: P1 has lost because life total reached 0
- Game Outcome: P2 has lost because life total reached 0
- Game Outcome: P3 has won because all opponents have lost
- Game Outcome: US has lost because life total reached 0