# pod02-g4: we are P4; opponents P1 Teval, the Balanced Scale, P2 Hearthhull, the Worldseed, P3 Giada, Font of Hope
Result: Turn 16; P1 has won because all opponents have lost; P2 has lost because life total reached 0; P3 has lost because life total reached 0; US has lost because life total reached 0

## Turn 1 (P1, round 1)

## Turn 2 (P2, round 1)

## Turn 3 (P3, round 1)

## Turn 4 (OUR TURN, round 1) | life: US 39
Our hand: Farseek, Birds of Paradise, Baleful Strix, Hostage Taker, Vrock, Talisman of Dominance, Marsh Flats, Invasion of Innistrad
Our graveyard (0): 
Board P1: 1 lands; no nonland permanents
Board P2: 1 lands; no nonland permanents
Board P3: 1 lands; no nonland permanents
Board US: 0 lands; no nonland permanents
MEMO (start of our turn):
THIS TURN: Play Marsh Flats and crack it now (pay 1 life) for Bayou; fall back to Overgrown Tomb untapped (pay 2) if needed. Tap it for G and cast Birds of Paradise. Nothing is castable on opponents' turns.

TARGET: Next turn: land drop if drawn. Then Farseek for Zagoth Triome (or Underground Sea), or Talisman of Dominance, whichever uses all the mana. Turn 3: Baleful Strix plus Talisman, or Hostage Taker. Muldrotha on turn 4-5 with Strix, Vrock and a Seal or Capsule stocking the graveyard. Tutor targets later: Claws of Gix, Executioner's Capsule, Seal of Doom.

WIN PATH: Vrock plus a sacrifice each turn drains 9 per round. Gray Merchant and Syr Konrad add reach. Our clock is roughly turns 10-12. Opponents' clocks: P2 turns 6-8, P3 turns 6-8, P1 turns 7-9.

THREATS & ANSWERS: 1) Giada (P3), cheap and snowballing: flash Invasion of Innistrad at end of turn, or chump or trade with deathtouch Strix. 2) Hearthhull (P2), a noncreature artifact below 8 counters: Hostage Taker exiles it and lets us cast it. 3) Teval (P1): Invasion -13/-13 (Teval is black, and Invasion has no colour restriction). Don't give P1 fatties to reanimate.

HOLD: Keep Invasion of Innistrad in hand as instant-speed removal. Don't deploy Vrock before Muldrotha unless a wipe has already been spent. Hold Hostage Taker for Hearthhull, Giada or an Angel, not a mana creature.

REPLAN IF: Giada or Hearthhull resolves early (race removal to it). Birds dies (prioritise Farseek and Talisman). A wipe appears in someone's hand. P1 mills hard with Hedron Crab.
PILOT OVERRULED FORGE (search, MAIN1): chose [Bayou — Land - Swamp Forest — ({T}: Add {B} or {G}.)] instead of Forge's [Zagoth Triome — Land - Swamp Forest Island — ({T}: Add {B}, {G}, or {U}.) Zagoth Triome en]
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Birds of Paradise (from Hand): Birds of Paradise - Creature 0 / 1 [Forge's heuristic ] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
- left battlefield: Marsh Flats was put into Graveyard from Battlefield.
- US activated Marsh Flats
- US cast Birds of Paradise

## Turn 5 (P1, round 2)
- P1 cast Farseek

## Turn 6 (P2, round 2)
- P2 cast Zuran Orb

## Turn 7 (P3, round 2)
- P3 cast Giada, Font of Hope

## Turn 8 (OUR TURN, round 2)
Our hand: Farseek, Baleful Strix, Hostage Taker, Vrock, Talisman of Dominance, Invasion of Innistrad, The Coming of Galactus
Our graveyard (1): Marsh Flats
Board P1: 3 lands; no nonland permanents
Board P2: 2 lands; Zuran Orb
Board P3: 2 lands; Giada, Font of Hope 2/2
Board US: 1 lands; Birds of Paradise 0/1
MEMO (start of our turn):
THIS TURN: Cast Farseek (Bayou and Birds, 2 mana) for Zagoth Triome, which enters tapped and gives B/G/U. We have no land in hand, so the land matters more than Talisman. Nothing else is castable. We have no instant-speed plays on opponents' turns yet.

TARGET: Next turn we have 3 mana (Bayou, Triome, Birds), or 4 with a land draw.
- With 4: cast Hostage Taker on Giada if she's still P3's best creature; otherwise cast Talisman plus Baleful Strix.
- With 3: cast Talisman plus 1 spare, then Strix next turn.
- Muldrotha comes in about 2 turns (6 mana), with Strix and a Capsule or Seal already in the graveyard.
- Later tutor targets: Claws of Gix, Executioner's Capsule, Seal of Doom.

WIN PATH: Vrock plus one sacrifice per turn drains 9 each round. Coming of Galactus drains 4 over its chapters, then its 16/16 flier and Gray Merchant finish. Our clock is roughly turns 12-14. P2's and P3's clocks are turns 6-8 of their decks, so we must answer them.

THREATS & ANSWERS:
1) Giada (P3), snowballing Angels: Hostage Taker, or flash Invasion of Innistrad at P3's end step once we have 4 mana.
2) Hearthhull (P2, 4 mana; P2 has 2 lands plus Zuran Orb): Coming of Galactus chapter I, or Hostage Taker, since it's an artifact while under 8 counters.
3) Teval (P1): Invasion -13/-13.
Don't give P1 dead fatties to reanimate.

HOLD: Hold Invasion as flash removal for the biggest Angel or Teval. Hold Vrock until Muldrotha is out or a wipe has been spent. Hold Galactus until 5 mana and a real target (Hearthhull or a big Angel).

REPLAN IF: Birds dies (cast Talisman first). Hearthhull resolves (use Galactus or Hostage Taker on it next). An Angel lands onto Giada. Someone reveals a wipe. P1 starts milling heavily.
PILOT OVERRULED FORGE (search, MAIN1): chose [Zagoth Triome — Land - Swamp Forest Island — ({T}: Add {B}, {G}, or {U}.) Zagoth Triome en] instead of Forge's [Breeding Pool — Land - Forest Island — ({T}: Add {G} or {U}.) As Breeding Pool enters, you]
- US cast Farseek

## Turn 9 (P1, round 3)
- P1 cast Teval, the Balanced Scale

## Turn 10 (P2, round 3)
- P2 cast Evendo Brushrazer

## Turn 11 (P3, round 3)
- P3 cast Angel of Vitality

## Turn 12 (OUR TURN, round 3)
Our hand: Baleful Strix, Hostage Taker, Vrock, Talisman of Dominance, Invasion of Innistrad, The Coming of Galactus, Nurturing Peatland
Our graveyard (2): Marsh Flats, Farseek
Board P1: 4 lands; Teval, the Balanced Scale 4/4
Board P2: 3 lands; Zuran Orb, Evendo Brushrazer 2/2
Board P3: 2 lands; Giada, Font of Hope 2/2 (tapped 1), Angel of Vitality 5/5 {[P1P1]}
Board US: 2 lands; Birds of Paradise 0/1
MEMO (start of our turn):
THIS TURN: Play Nurturing Peatland (untapped, 4 mana total). Cast Talisman of Dominance first (Bayou and Birds). Then cast Baleful Strix with Triome for U and Talisman for B, and draw a card. The 1 mana left (Peatland) has no use. Nothing to do on opponents' turns. Block Angel of Vitality or Teval with Strix only if the trade kills the attacker (deathtouch). Never chump-block.

TARGET: Next turn we have 5 sources plus any land drawn. Cast The Coming of Galactus (5 mana). Chapter I destroys Hearthhull if it resolved; otherwise Giada. Then Muldrotha the turn after. Stock the lanes: Strix and Peatland (sacrifice it for {1} to draw) become recastable. Tutor targets later: Claws of Gix, Executioner's Capsule, Seal of Doom.

WIN PATH: Vrock plus one permanent leaving each turn drains 9 per round. A Peatland sacrifice counts, and Muldrotha replays it. Galactus drains 4, then the 16/16 flier finishes. Aim to close around turns 16-18. P2 and P3 threaten around turns 14-15.

THREATS & ANSWERS:
1) Hearthhull (P2). It can come down next turn: 3 lands, plus Brushrazer sacrificing a land for RR. Answer with Galactus chapter I, or Hostage Taker (it's an artifact below 8 counters).
2) Giada and Angel of Vitality (P3). Answer with Galactus I, or flash Invasion on the biggest Angel at P3's end step.
3) Teval (P1): Invasion -13/-13.
Don't feed Evendo Brushrazer or Zuran Orb. Don't give P1 fatties to reanimate.

HOLD: Hold Vrock until Muldrotha is out or a wipe is spent. Hold Hostage Taker for Hearthhull or a stealable Angel. Hold Invasion as flash removal.

REPLAN IF: Hearthhull resolves (it becomes the Galactus target). Blasphemous Act or Farewell is revealed. Strix is removed. Someone gets a huge Angel.
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Baleful Strix (from Hand): Baleful Strix - Creature 1 / 1 [Forge's heuristic AI would] instead of Forge's [cast Hostage Taker (from Hand): Hostage Taker - Creature 2 / 3]
PILOT OVERRULED FORGE (action, MAIN1): chose [activate Nurturing Peatland (from Battlefield): {1}, {T}, Sacrifice Nurturing Peatland: Dr] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
- US cast Baleful Strix
- US triggered Baleful Strix
- left battlefield: Nurturing Peatland was put into Graveyard from Battlefield.
- US activated Nurturing Peatland

## Turn 13 (P1, round 4)
- P1 cast The Gitrog Monster

## Turn 14 (P2, round 4) | life: P2 39, US 39
- left battlefield: Verdant Catacombs was put into Graveyard from Battlefield.
- P2 activated Verdant Catacombs
- P2 triggered Evendo Brushrazer
- P2 cast Ramunap Excavator
- left battlefield: Sulfurous Springs was put into Graveyard from Battlefield.
- P2 activated Festering Thicket
- P2 triggered Evendo Brushrazer

## Turn 15 (P3, round 4) | life: P1 35, P2 39, US 39
- attack: P3 assigned Angel of Vitality to attack P1.
- P3 cast Righteous Valkyrie

## Turn 16 (OUR TURN, round 4)
Our hand: Hostage Taker, Vrock, Talisman of Dominance, Invasion of Innistrad, The Coming of Galactus, Darkslick Shores, Executioner's Capsule, Plaguecrafter
Our graveyard (3): Marsh Flats, Farseek, Nurturing Peatland
Board P1: 6 lands; Teval, the Balanced Scale 4/4, The Gitrog Monster 6/6
Board P2: 3 lands; Zuran Orb, Evendo Brushrazer 2/2 (tapped 1), Ramunap Excavator 2/3
Board P3: 2 lands; Giada, Font of Hope 2/2 (tapped 1), Angel of Vitality 5/5 {[P1P1]} (tapped 1), Righteous Valkyrie 4/6 {[P1P1 x 2]}
Board US: 2 lands; Birds of Paradise 0/1, Baleful Strix 1/1
MEMO (start of our turn):
THIS TURN: Play Darkslick Shores first; it enters untapped because we have only 2 other lands. That gives 4 sources. Cast Talisman of Dominance with Bayou and Birds. Cast Executioner's Capsule with Talisman (B). Leave Triome and Darkslick untapped for Capsule's {1}{B} activation. On P3's turn, activate Capsule on Righteous Valkyrie in response to P3's first Angel or Cleric spell, so there's no lifegain trigger. If P3 casts nothing, activate at P3's beginning of combat. Block an attacking Angel with Strix (deathtouch). Never chump with Birds.

TARGET: Next turn we have 5 sources, 6 if we draw a land. If Hearthhull is on the battlefield, cast The Coming of Galactus and aim chapter I at Hearthhull. Otherwise cast Muldrotha at 6 mana, or Galactus at 5 with chapter I on Giada or Angel of Vitality. With Muldrotha out, replay Marsh Flats and Nurturing Peatland from the graveyard and recast Capsule every turn. Tutor targets: Claws of Gix, Seal of Doom, Gray Merchant.

WIN PATH: Vrock plus one permanent leaving per turn (Capsule, fetchland, Peatland) drains 9 per round. Galactus drains 4, then a 16/16 flier. Close by turns 24-28. P3 is fastest: 11 flying power now, and a +2/+2 anthem at 47 life.

THREATS & ANSWERS:
1) P3: Valkyrie gets Capsule; the next Angel gets flash Invasion of Innistrad. Never give P3 life.
2) P2 Hearthhull: Galactus chapter I. Zuran Orb: Hostage Taker (steal it, cast it free for our Vrock).
3) P1 Gitrog and Teval (black): Invasion or Plaguecrafter. Capsule can't hit them.

HOLD: Hold Invasion for P3's Angels. Hold Hostage Taker for Zuran Orb or Hearthhull. Hold Vrock until Muldrotha is on the battlefield. Hold Plaguecrafter.

REPLAN IF: P3 reaches 47 life, a wipe is cast, Capsule is fizzled by Flawless Maneuver, or Hearthhull stations.
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Executioner's Capsule (from Hand): Executioner's Capsule] instead of Forge's [cast Hostage Taker (from Hand): Hostage Taker - Creature 2 / 3]
PILOT OVERRULED FORGE (action, MAIN1): chose [Righteous Valkyrie [P3, 4/6]] instead of Forge's [Angel of Vitality [P3, 5/5, tapped]]
PILOT OVERRULED FORGE (attack, COMBAT_DECLARE_ATTACKERS): chose [don't attack with it] instead of Forge's [attack P3 (40 life)]
- US cast Executioner's Capsule
- left battlefield: Executioner's Capsule was put into Graveyard from Battlefield.
- US activated Executioner's Capsule targeting [Righteous Valkyrie]
- left battlefield: Righteous Valkyrie was put into Graveyard from Battlefield.

## Turn 17 (P1, round 5) | life: P1 35, P2 39, P3 30, US 39
- P1 triggered The Gitrog Monster
- left battlefield: Forest was put into Graveyard from Battlefield.
- P1 triggered The Gitrog Monster
- attack: P1 assigned Teval, the Balanced Scale and The Gitrog Monster to attack P3.
- P1 triggered Teval, the Balanced Scale
- P1 triggered The Gitrog Monster
- P1 triggered Teval, the Balanced Scale
- P1 cast Kheru Goldkeeper
- P1 cast Sol Ring

## Turn 18 (P2, round 5) | life: P1 35, P2 37, P3 30, US 39
- P2 cast Farseek
- left battlefield: Stomping Ground was put into Graveyard from Battlefield.
- P2 cast Hearthhull, the Worldseed
- P2 triggered Evendo Brushrazer
- P2 activated Hearthhull, the Worldseed

## Turn 19 (P3, round 5) | life: P1 30, P2 37, P3 30, US 39
- P3 cast Stroke of Midnight targeting [The Gitrog Monster]
- left battlefield: The Gitrog Monster was put into Graveyard from Battlefield.
- attack: P3 assigned Angel of Vitality to attack P1.

## Turn 20 (OUR TURN, round 5)
Our hand: Hostage Taker, Vrock, Talisman of Dominance, Invasion of Innistrad, The Coming of Galactus, Plaguecrafter, Mind Stone
Our graveyard (4): Marsh Flats, Farseek, Nurturing Peatland, Executioner's Capsule
Board P1: 6 lands; Teval, the Balanced Scale 4/4 (tapped 1), Zombie Druid Token 2/2 [token], Kheru Goldkeeper 3/3, Sol Ring, Human Token 1/1 [token]
Board P2: 4 lands; Zuran Orb, Evendo Brushrazer 2/2 (tapped 1), Ramunap Excavator 2/3 (tapped 1), Hearthhull, the Worldseed {[CHARGE x 2]}
Board P3: 3 lands; Giada, Font of Hope 2/2, Angel of Vitality 5/5 {[P1P1]} (tapped 1)
Board US: 3 lands; Birds of Paradise 0/1, Baleful Strix 1/1
MEMO (start of our turn):
THIS TURN: No land in hand. Cast Talisman of Dominance with Bayou and Birds; it enters untapped. Cast Mind Stone with Talisman and Zagoth Triome. That is all 4 mana spent on permanent ramp that survives creature wipes. Next turn we have 6 sources for Muldrotha (tax 0). Keep Baleful Strix home as a deathtouch blocker for Angel of Vitality or Teval. Never block with Birds.

TARGET: Next turn cast Muldrotha (6). Play Marsh Flats from the graveyard and crack it for Watery Grave or Underground Sea untapped. Use that mana to recast Executioner's Capsule from the graveyard. The turn after, cast The Coming of Galactus with chapter I on Hearthhull, then Vrock. Tutor targets: Claws of Gix, Gray Merchant, Seal of Doom.

WIN PATH: Vrock plus a fetch or Capsule leaving each turn drains 9 per round. Galactus adds 4 drain, then a 16/16 flier. Close by turns 28-32. P2 and P3 are the fastest clocks.

THREATS & ANSWERS: 1) P2 Hearthhull (2 charge counters; 8 makes it a hasty flier that drains): Galactus chapter I, or Hostage Taker, which can take it as an artifact. 2) P3: Giada and Angel of Vitality 5/5. Answer their next big Angel with Invasion of Innistrad; Capsule handles the nonblack ones. Never give P3 life. 3) P1 Teval and Kheru (black, so Capsule can't hit them): Invasion or Plaguecrafter.

HOLD: Invasion for P3's Angels or Teval. Hostage Taker for Hearthhull or Zuran Orb. Vrock until Muldrotha has landed. Plaguecrafter.

REPLAN IF: Hearthhull reaches 6+ counters: next turn Hostage Taker it before casting Muldrotha. Also replan if a wipe hits, our rocks are destroyed, or P3 gains to 40+.
PILOT OVERRULED FORGE (trigger-target, MAIN1): chose [Hearthhull, the Worldseed [P2, commander]] instead of Forge's [Teval, the Balanced Scale [P1, 4/4, commander, tapped]]
- US cast Hostage Taker
- US triggered Hostage Taker targeting [Hearthhull, the Worldseed]
- left battlefield: Hearthhull, the Worldseed was put into Exile from Battlefield.

## Turn 21 (P1, round 6) | life: P1 30, P2 37, P3 21, US 39
- P1 cast Rampant Growth
- attack: P1 assigned Teval, the Balanced Scale, Kheru Goldkeeper and Zombie Druid Token to attack P3.
- P1 triggered Teval, the Balanced Scale
- P1 triggered Field of the Dead
- P1 triggered Teval, the Balanced Scale
- P1 triggered Kheru Goldkeeper
- P1 cast Ob Nixilis, the Fallen

## Turn 22 (P2, round 6) | life: P1 30, P2 34, P3 21, US 39
- left battlefield: Verdant Catacombs was put into Graveyard from Battlefield.
- P2 activated Verdant Catacombs
- P2 triggered Evendo Brushrazer
- left battlefield: Sheltered Thicket was put into Graveyard from Battlefield.
- P2 cast Crop Rotation
- P2 triggered Evendo Brushrazer
- left battlefield: Karplusan Forest was put into Graveyard from Battlefield.
- P2 cast Rampaging Baloths
- P2 triggered Evendo Brushrazer

## Turn 23 (P3, round 6) | life: P1 25, P2 34, P3 21, US 39
- attack: P3 assigned Angel of Vitality and Giada, Font of Hope to attack P1.
- P3 cast Serra Paragon

## Turn 24 (OUR TURN, round 6)
Our hand: Vrock, Talisman of Dominance, Invasion of Innistrad, The Coming of Galactus, Plaguecrafter, Mind Stone, Underground Sea
Our graveyard (4): Marsh Flats, Farseek, Nurturing Peatland, Executioner's Capsule
Board P1: 8 lands; Teval, the Balanced Scale 4/4 (tapped 1), Zombie Druid Token 2/2 [token] x2 (tapped 1), Kheru Goldkeeper 3/3 (tapped 1), Sol Ring (tapped 1), Human Token 1/1 [token], Treasure Token [token], Zombie Token 2/2 [token], Ob Nixilis, the Fallen 3/3
Board P2: 4 lands; Zuran Orb, Evendo Brushrazer 2/2 (tapped 1), Ramunap Excavator 2/3, Rampaging Baloths 6/6
Board P3: 3 lands; Giada, Font of Hope 2/2 (tapped 1), Angel of Vitality 3/3 {[P1P1]} (tapped 1), Serra Paragon 5/6 {[P1P1 x 2]}
Board US: 3 lands; Birds of Paradise 0/1, Baleful Strix 1/1, Hostage Taker 2/3
MEMO (start of our turn):
THIS TURN: 1) Play Underground Sea. 2) Cast Talisman of Dominance with Bayou and Darkslick Shores (2). 3) Right away, cast Hearthhull from exile through Hostage Taker (4; any mana type works) with Triome, Underground Sea, Birds and Talisman. If Hostage Taker dies first, Hearthhull goes back to P2, so casting it now secures it. 4) Station Hearthhull by tapping Hostage Taker (2 counters). Keep Baleful Strix untapped to block fliers. Never block with Birds.

TARGET: Next turn: Muldrotha (6 sources, no tax). Station with Muldrotha (+6, reaching 8; summoning sickness doesn't stop station). Then play Marsh Flats from the graveyard and crack it for Watery Grave: at 8 counters each opponent loses 2. Recast Executioner's Capsule. Attack with Hearthhull, a hasty 6/7 flier. Tutor targets: Claws of Gix, Gray Merchant.

WIN PATH: Each turn, fetch or Peatland sacrifices drain 2 each through Hearthhull, Vrock drains 3, and Hearthhull swings for 6 in the air. Galactus adds 4 drain. Aim to close in 4-5 turns. P1 is fastest (Ob plus Field).

THREATS & ANSWERS: 1) P1's Ob Nixilis (3 per land, black): Invasion or Galactus chapter I. 2) P3's fliers (10 power): Capsule on Serra Paragon. Never give P3 life. 3) P2's Baloths: Capsule. Plaguecrafter is weak into tokens.

HOLD: Invasion for Ob Nixilis or Teval. Galactus and Vrock for the turn after Muldrotha. Mind Stone and Plaguecrafter.

REPLAN IF: Hostage Taker dies before Hearthhull is cast, or Hearthhull is removed. A wipe hits. Ob Nixilis reaches 9+ power.
PILOT OVERRULED FORGE (attack, COMBAT_DECLARE_ATTACKERS): chose [don't attack with it] instead of Forge's [attack P1 (25 life)]
- US cast Vrock

## Turn 25 (P1, round 7) | life: P1 25, P2 31, P3 15, US 39
- P1 triggered Ob Nixilis, the Fallen targeting [P2]
- P1 triggered Field of the Dead
- attack: P1 assigned Ob Nixilis, the Fallen to attack P3.
- P1 cast Tatyova, Benthic Druid
- P1 cast Cauldron of Essence
- P1 cast Aftermath Analyst
- P1 triggered Aftermath Analyst

## Turn 26 (P2, round 7) | life: P1 25, P2 28, P3 15, US 39
- P2 triggered Rampaging Baloths
- left battlefield: Vernal Fen was put into Graveyard from Battlefield.
- P2 cast Omnath, Locus of Rage
- P2 triggered Evendo Brushrazer

## Turn 27 (P3, round 7)
- P3 cast Righteous Valkyrie

## Turn 28 (OUR TURN, round 7) | life: P1 22, P2 25, P3 12, US 39
Our hand: Talisman of Dominance, Invasion of Innistrad, The Coming of Galactus, Plaguecrafter, Mind Stone, Swamp
Our graveyard (4): Marsh Flats, Farseek, Nurturing Peatland, Executioner's Capsule
Board P1: 9 lands; Teval, the Balanced Scale 4/4, Zombie Druid Token 2/2 [token] x2, Kheru Goldkeeper 3/3, Sol Ring (tapped 1), Human Token 1/1 [token], Treasure Token [token], Zombie Token 2/2 [token] x2, Ob Nixilis, the Fallen 6/6 {[P1P1 x 3]} (tapped 1), Tatyova, Benthic Druid 3/3, Cauldron of Essence, Aftermath Analyst 1/3
Board P2: 4 lands; Zuran Orb, Evendo Brushrazer 2/2 (tapped 1), Ramunap Excavator 2/3, Rampaging Baloths 6/6, Beast Token 4/4 [token], Omnath, Locus of Rage 5/5
Board P3: 4 lands; Giada, Font of Hope 2/2, Angel of Vitality 3/3 {[P1P1]}, Serra Paragon 5/6 {[P1P1 x 2]}, Righteous Valkyrie 5/7 {[P1P1 x 3]}
Board US: 4 lands; Birds of Paradise 0/1, Baleful Strix 1/1, Hostage Taker 2/3, Vrock 3/3
MEMO (start of our turn):
THIS TURN: 1) Play Swamp (6 sources). 2) Cast Talisman of Dominance with 2 lands. 3) Cast The Coming of Galactus (5) with the 3 remaining lands, Birds (G) and Talisman. Point chapter I at P1's Ob Nixilis, which is black, so Capsule can't touch it and it grows every land. Don't attack. Keep Baleful Strix and Vrock untapped to block P3's fliers, and Hostage Taker to block ground. Never block with Birds.

TARGET: Next turn: cast Muldrotha (6; tax 0 unless told otherwise). Then play Marsh Flats from the graveyard and crack it for Watery Grave. That turns Vrock on and nets mana. Recast Executioner's Capsule (B), then Mind Stone. Tutor targets: Claws of Gix, Gray Merchant, Pernicious Deed.

WIN PATH: Galactus chapters II and III (2 each), plus Vrock (3 each whenever a permanent of ours leaves), then a 16/16 flying Galactus. Each Galactus attack must destroy OUR recurrable land (a fetch or Peatland). After chapter IV, recast the Saga through Muldrotha. P3 (15 life) dies first, in about 3 turns. P1 is the fastest opponent.

THREATS & ANSWERS: 1) Ob Nixilis: Galactus chapter I now. 2) P2's Omnath plus Baloths land army: Capsule on Omnath (it deals 3 on death), Invasion as backup. 3) P3's fliers (15 power): Capsule on Serra Paragon. Never give P3 life.

HOLD: Invasion (flash, 4) for Teval, Omnath or a surprise Angel on opponents' turns once mana allows. Plaguecrafter is weak into tokens. Hold Muldrotha until next turn, since P2 (5 cards) may hold Blasphemous Act.

REPLAN IF: Galactus is removed or countered. A wipe hits. Ob survives or returns via Cauldron. We fall below 20.
PILOT OVERRULED FORGE (action, MAIN1): chose [cast The Coming of Galactus (from Hand): The Coming of Galactus [Forge's heuristic AI woul] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN2): chose [cast Mind Stone (from Hand): Mind Stone] instead of Forge's [cast Plaguecrafter (from Hand): Plaguecrafter - Creature 3 / 2]
- US cast The Coming of Galactus
- P1 cast An Offer You Can't Refuse targeting [The Coming of Galactus]
- US cast Mind Stone
- US cast Talisman of Dominance
- US triggered Vrock

## Turn 29 (P1, round 8) | life: P1 28, P2 1, P3 0, US 36
- P1 activated Timeless Witness
- P1 triggered Teval, the Balanced Scale
- P1 triggered Kheru Goldkeeper
- P1 triggered Timeless Witness targeting [The Gitrog Monster]
- P1 triggered Teval, the Balanced Scale
- P1 triggered Kheru Goldkeeper
- attack: P1 assigned Teval, the Balanced Scale, Ob Nixilis, the Fallen, Kheru Goldkeeper, Tatyova, Benthic Druid, Zombie Druid Token, Zombie Druid Token, Zombie Token, Zombie Token, Human Token and Aftermath Analyst to attack P3.
- P1 triggered Teval, the Balanced Scale
- P1 triggered Ob Nixilis, the Fallen targeting [P2]
- P1 triggered Tatyova, Benthic Druid
- P1 triggered Field of the Dead
- P1 triggered Teval, the Balanced Scale
- P1 triggered Kheru Goldkeeper
- P1 triggered Teval, the Balanced Scale
- P1 triggered Kheru Goldkeeper
- left battlefield: Aftermath Analyst was put into Graveyard from Battlefield.
- P1 activated Aftermath Analyst
- P1 triggered Cauldron of Essence
- P1 triggered Ob Nixilis, the Fallen targeting [P2]
- P1 triggered Tatyova, Benthic Druid
- P1 triggered Ob Nixilis, the Fallen targeting [P2]
- P1 triggered Tatyova, Benthic Druid
- P1 triggered Ob Nixilis, the Fallen targeting [P2]
- P1 triggered Tatyova, Benthic Druid
- P1 triggered Golgari Rot Farm
- P1 triggered Field of the Dead
- P1 triggered Field of the Dead
- P1 triggered Field of the Dead
- P1 triggered Teval, the Balanced Scale
- P1 triggered Kheru Goldkeeper
- attack: P3 assigned Angel of Vitality to block Teval, the Balanced Scale.
- left battlefield: Kheru Goldkeeper was put into Graveyard from Battlefield.
- left battlefield: Tatyova, Benthic Druid was put into Graveyard from Battlefield.
- left battlefield: Giada, Font of Hope was put into Graveyard from Battlefield.
- left battlefield: Angel of Vitality was put into Graveyard from Battlefield.
- P1 triggered Cauldron of Essence
- P1 triggered Cauldron of Essence
- P1 triggered Ob Nixilis, the Fallen targeting [P2]
- P1 triggered Field of the Dead
- P1 cast The Gitrog Monster
- P1 triggered Ob Nixilis, the Fallen targeting [P2]
- P1 triggered Field of the Dead
- left battlefield: Verdant Catacombs was put into Graveyard from Battlefield.
- P1 activated Verdant Catacombs
- P1 triggered The Gitrog Monster
- P1 triggered Ob Nixilis, the Fallen targeting [P2]
- P1 triggered Field of the Dead

## Turn 30 (P2, round 8)
- P2 triggered Rampaging Baloths
- P2 triggered Omnath, Locus of Rage
- left battlefield: Swamp was put into Graveyard from Battlefield.
- P2 cast Hearthhull, the Worldseed
- P2 triggered Evendo Brushrazer
- P1 cast Counterspell targeting [Hearthhull, the Worldseed]

## Turn 31 (OUR TURN, round 8) | life: P1 25, P2 -2, P3 0, US 35
Our hand: Invasion of Innistrad, Plaguecrafter, Shriekmaw
Our graveyard (5): Marsh Flats, Farseek, Nurturing Peatland, Executioner's Capsule, The Coming of Galactus
Board P1: 14 lands; Teval, the Balanced Scale 4/4 (tapped 1), Zombie Druid Token 2/2 [token] x7 (tapped 2), Sol Ring (tapped 1), Human Token 1/1 [token] (tapped 1), Zombie Token 2/2 [token] x9 (tapped 2), Ob Nixilis, the Fallen 27/27 {[P1P1 x 24]} (tapped 1), Cauldron of Essence, Timeless Witness 4/4 [token], The Gitrog Monster 6/6
Board P2: 4 lands; Zuran Orb, Evendo Brushrazer 2/2 (tapped 1), Ramunap Excavator 2/3, Rampaging Baloths 6/6, Beast Token 4/4 [token] x2, Omnath, Locus of Rage 5/5, Elemental Token 5/5 [token]
Board US: 5 lands; Birds of Paradise 0/1, Baleful Strix 1/1, Hostage Taker 2/3, Vrock 3/3, Mind Stone, Talisman of Dominance
MEMO (start of our turn):
THIS TURN: No attacks; keep every creature untapped as a blocker. 1) Cast Muldrotha for 6 (tax 0; if tax >0, skip steps 1–4 and hold Invasion instead). Pay with Bayou (G), Underground Sea (U), Swamp (B), Mind Stone, Talisman, Darkslick Shores. 2) Land lane: play Marsh Flats from the graveyard and crack it for a basic Swamp. That is a permanent leaving, so Vrock drains each opponent 3 at end step. 3) Artifact lane: recast Executioner's Capsule (B). 4) Keep Triome and Birds up to activate Capsule ({1}{B}) on a green/red P2 attacker (Baloths first). Capsule can't hit P1's black creatures.

TARGET: Next turn, recast The Coming of Galactus from the graveyard (5). Chapter I destroys Ob Nixilis, or Cauldron of Essence if Ob already died. Replay Peatland via the land lane. Find Demonic Tutor for Massacre Wurm or Pernicious Deed (X=3 kills tokens, Cauldron and Sol Ring).

WIN PATH: Vrock drains 3 each turn and Galactus chapters II–III drain 2 each. Once Cauldron is gone, Massacre Wurm on P1's ~17 tokens costs P1 34 life. P1 threatens us now.

THREATS & ANSWERS: 1) P1's Ob Nixilis 27/27 plus ~74 total power; we're at 36. Block Ob with Baleful Strix (deathtouch). Muldrotha blocks Timeless Witness or a Zombie, never Gitrog. Vrock chumps only if needed. 2) P2's Omnath and Baloths: use Capsule. Omnath's death deals 3 to a target of P2's choice.

HOLD: Invasion and Shriekmaw (black-immune P1 makes Shriekmaw weak). Plaguecrafter only once tokens are gone.

REPLAN IF: Muldrotha is countered or wiped, Living Death resolves, P2 dies, Ob dies to the Strix block, or we fall below 15.
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Muldrotha, the Gravetide (from Command): Muldrotha, the Gravetide - Creature 6 / 6 [F] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN1): chose [play land Marsh Flats (from Graveyard): Play land by Muldrotha, the Gravetide (403) (Land)] instead of Forge's [play land Nurturing Peatland (from Graveyard): Play land by Muldrotha, the Gravetide (403)]
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Executioner's Capsule (from Graveyard): Executioner's Capsule by Muldrotha, the Grave] instead of Forge's [activate Marsh Flats (from Battlefield): {T}, Pay 1 life, Sacrifice Marsh Flats: Search yo]
PILOT OVERRULED FORGE (search, MAIN1): chose [Watery Grave — Land - Island Swamp — ({T}: Add {U} or {B}.) As Watery Grave enters, you ma] instead of Forge's [Overgrown Tomb — Land - Swamp Forest — ({T}: Add {B} or {G}.) As Overgrown Tomb enters, yo]
- US cast Muldrotha, the Gravetide
- US cast Executioner's Capsule
- left battlefield: Marsh Flats was put into Graveyard from Battlefield.
- US activated Marsh Flats
- US triggered Vrock

## Turn 32 (P1, round 8) | life: P1 25, P2 -2, P3 0, US -10
- P1 triggered The Gitrog Monster
- left battlefield: Swamp was put into Graveyard from Battlefield.
- P1 triggered The Gitrog Monster
- left battlefield: Island was put into Graveyard from Battlefield.
- P1 cast Harrow
- P1 triggered The Gitrog Monster
- P1 triggered Ob Nixilis, the Fallen targeting [P4]
- P1 triggered Ob Nixilis, the Fallen targeting [P4]
- P1 triggered Field of the Dead
- P1 triggered Field of the Dead
- P1 triggered Ob Nixilis, the Fallen targeting [P4]
- P1 triggered Underground Mortuary
- P1 triggered Field of the Dead
- P1 triggered The Gitrog Monster
- attack: P1 assigned Ob Nixilis, the Fallen, The Gitrog Monster, Teval, the Balanced Scale, Timeless Witness, Zombie Druid Token, Zombie Druid Token, Zombie Token, Zombie Token, Zombie Druid Token, Zombie Druid Token, Zombie Druid Token, Zombie Token, Zombie Druid Token, Zombie Druid Token, Zombie Token, Zombie Token, Zombie Token, Zombie Token, Zombie Token, Zombie Token and Human Token to attack US.
- P1 triggered Teval, the Balanced Scale
- P1 triggered Ob Nixilis, the Fallen targeting [P4]
- P1 triggered Field of the Dead
- P1 triggered Teval, the Balanced Scale
- attack: US assigned Baleful Strix to block Ob Nixilis, the Fallen.
- Game Outcome: P1 has won because all opponents have lost
- Game Outcome: P2 has lost because life total reached 0
- Game Outcome: P3 has lost because life total reached 0
- Game Outcome: US has lost because life total reached 0
Damage to US this turn: Zombie Druid Token (combat) 14, Zombie Token (combat) 18, Human Token (combat) 1