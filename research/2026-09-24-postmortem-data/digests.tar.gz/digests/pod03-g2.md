# pod03-g2: we are P4; opponents P1 Teval, the Balanced Scale, P2 Giada, Font of Hope, P3 Edgar Markov
Result: Turn 25; P1 has lost because life total reached 0; P2 has won because all opponents have lost; P3 has lost because life total reached 0; US has lost because life total reached 0

## Turn 1 (P1, round 1)
- P1 cast Gravecrawler

## Turn 2 (P2, round 1)
- P2 cast Serra Ascendant

## Turn 3 (P3, round 1)
- P3 cast Sol Ring

## Turn 4 (OUR TURN, round 1)
Our hand: Boseiju, Who Endures, Syr Konrad, the Grim, Vrock, Swamp, Waterlogged Grove, Seal of Primordium, Swamp, Kaya's Ghostform
Our graveyard (0): 
Board P1: 1 lands; Gravecrawler 2/1
Board P2: 1 lands; Serra Ascendant 6/6
Board P3: 1 lands; Sol Ring
Board US: 0 lands; no nonland permanents
MEMO (start of our turn):
THIS TURN: Play Swamp. Cast nothing, since Kaya's Ghostform has no target. Pass holding everything. Next turn: Boseiju, then Seal of Primordium (1G). The turn after: Swamp, then Waterlogged Grove as land 4.

TARGET: Muldrotha out by around turn 6, with Seal of Primordium plus a recurring creature answer (Executioner's Capsule, Shriekmaw, Plaguecrafter) cycling through the graveyard. Kaya's Ghostform goes on Muldrotha. We need ramp (Sol Ring, Arcane Signet, Farseek, Nature's Lore) and creature removal; we hold none now. Demonic Tutor targets: Executioner's Capsule early, Survival of the Fittest later.

WIN PATH: Syr Konrad or Vrock (5 mana, BB) at land 5, then Muldrotha recursion feeding Vrock's 3 per turn to each opponent and Konrad pings. Gray Merchant closes. P2 and P3 race at turns 6-8, so we must answer threats before we race.

THREATS & ANSWERS: 1) P2 Serra Ascendant, a 6/6 lifelink flier. We have no answer yet; our first drawn Capsule or Shriekmaw kills it. Don't chump it. 2) P3: any Skullclamp or Exquisite Blood gets Seal of Primordium immediately. Boseiju's channel (1G) is the backup. Sol Ring is the Seal target only if nothing better shows by our turn 4. 3) P1's Teval engine: kill Teval's Judgment and Insidious Roots with Seal or Boseiju.

HOLD: Boseiju as a land drop. Only channel it for Exquisite Blood, Skullclamp or Smothering Tithe. Hold Ghostform until Muldrotha or Konrad is out. Don't dump Vrock and Konrad together into P2's or P3's wrath (Farewell, Olivia's Wrath).

REPLAN IF: P3 lands Vito, Clamp or Blood. P2 casts Giada plus angels. P1 stacks its graveyard for Living Death. We draw ramp or creature removal.
PILOT OVERRULED FORGE (action, MAIN1): chose [play land Swamp (from Hand): Play land] instead of Forge's [play land Swamp (from Hand): Play land]

## Turn 5 (P1, round 2)
- P1 cast Sol Ring

## Turn 6 (P2, round 2) | life: P1 34, P2 46
- attack: P2 assigned Serra Ascendant to attack P1.
- P2 cast Giada, Font of Hope

## Turn 7 (P3, round 2)

## Turn 8 (OUR TURN, round 2)
Our hand: Boseiju, Who Endures, Syr Konrad, the Grim, Vrock, Swamp, Waterlogged Grove, Seal of Primordium, Kaya's Ghostform, Overgrown Tomb
Our graveyard (0): 
Board P1: 2 lands; Gravecrawler 2/1, Sol Ring
Board P2: 2 lands; Serra Ascendant 6/6 (tapped 1), Giada, Font of Hope 2/2
Board P3: 2 lands; Sol Ring
Board US: 1 lands; no nonland permanents
MEMO (start of our turn):
THIS TURN: Play Overgrown Tomb and pay 2 life so it enters untapped. Cast Seal of Primordium (1G, from Tomb G + Swamp) and leave it on the battlefield. Sacrifice it at instant speed on any turn, with priority: Skullclamp, then Exquisite Blood, then Smothering Tithe, then Teval's Judgment or Insidious Roots. Pass. Next turn: Swamp (3 lands). The turn after: Waterlogged Grove (4 lands). Then Boseiju as land 5.

TARGET: Muldrotha out with Seal and a recurring creature answer cycling through the graveyard. Candidates are Executioner's Capsule, Shriekmaw and Plaguecrafter. Kaya's Ghostform goes on Muldrotha. Missing: ramp (Sol Ring, Arcane Signet, Farseek, Nature's Lore) and creature removal. If Demonic Tutor is drawn, fetch Executioner's Capsule.

WIN PATH: At land 5, cast Vrock or Syr Konrad (BB). Muldrotha then re-fires Seal and Capsule each turn, turning on Vrock's 3 life loss per opponent. Gray Merchant closes. P2 and P3 threaten to win around turns 6-8, so we answer threats before racing.

THREATS & ANSWERS:
1) P2's Serra Ascendant, a 6/6 lifelink flier. Seal can't touch it. Our first drawn Capsule, Shriekmaw or Hostage Taker kills it. Never chump-block it.
2) P2's Giada plus Angels. Kill Giada with our first creature removal if Ascendant is gone.
3) P3's Skullclamp, Exquisite Blood or Vito. Seal handles Clamp and Blood. Boseiju's channel (1G) is the backup.
4) P1's Teval engine: Judgment and Roots get Seal or Boseiju.

HOLD: Seal on board for the targets above. Don't spend it on a Sol Ring unless it's still unused by our land-5 turn. Hold Ghostform until Muldrotha or Konrad is on the battlefield. Don't cast Vrock and Konrad together into Farewell or Olivia's Wrath.

REPLAN IF: P3 lands Vito, Clamp or Blood. P2 adds Angels. P1 stacks its graveyard for Living Death. We draw ramp or creature removal. Seal gets destroyed.
PILOT OVERRULED FORGE (action, MAIN1): chose [play land Overgrown Tomb (from Hand): Play land] instead of Forge's [play land Waterlogged Grove (from Hand): Play land]

## Turn 9 (P1, round 3) | life: P1 34, P2 44
- P1 cast Nature's Lore
- attack: P1 assigned Gravecrawler to attack P2.

## Turn 10 (P2, round 3) | life: P1 26, P2 50
- attack: P2 assigned Serra Ascendant and Giada, Font of Hope to attack P1.
- P2 cast Gisela, the Broken Blade

## Turn 11 (P3, round 3)
- P3 cast Yahenni, Undying Partisan
- P3 triggered Edgar Markov

## Turn 12 (OUR TURN, round 3)
Our hand: Boseiju, Who Endures, Syr Konrad, the Grim, Vrock, Swamp, Waterlogged Grove, Seal of Primordium, Kaya's Ghostform, Grist, the Hunger Tide
Our graveyard (0): 
Board P1: 4 lands; Gravecrawler 2/1 (tapped 1), Sol Ring (tapped 1)
Board P2: 3 lands; Serra Ascendant 6/6 (tapped 1), Giada, Font of Hope 2/2 (tapped 1), Gisela, the Broken Blade 5/4 {[P1P1]}
Board P3: 3 lands; Sol Ring (tapped 1), Vampire Token 1/1 [token], Yahenni, Undying Partisan 2/2
Board US: 2 lands; no nonland permanents
MEMO (start of our turn):
THIS TURN: Play Swamp (land 3). Cast Grist, the Hunger Tide (1BG: Tomb for G, both Swamps for B and generic). Use Grist's +1: make an Insect, mill a card, and repeat if an Insect is milled. Pass with nothing open. If P2's fliers attack Grist, let them: that damage isn't hitting us, and Grist goes to the graveyard for Muldrotha later. The Insect can't block fliers. Use it only on Yahenni or the Vampire token, and only to protect Grist.

TARGET: Next turn, play Waterlogged Grove (4 lands, gives U). Grist −2, sacrificing the Insect, destroys Serra Ascendant. Also cast Seal of Primordium (1G) and keep it on the battlefield. Land 5 is Boseiju: cast Syr Konrad or Vrock. Land 6: Muldrotha, then Kaya's Ghostform on her. Missing pieces: ramp, Executioner's Capsule, Gray Merchant.

WIN PATH: Muldrotha recurs Grist, Seal and our removal creatures every turn. Vrock drains each opponent for 3 per turn. Konrad adds pings, and Gray Merchant finishes. Our clock is about 5 turns. P2's fliers are faster, so answer them first.

THREATS & ANSWERS:
1. P2: Serra Ascendant (6/6 lifelink flier). Answer with Grist −2.
2. P2: Giada, Gisela and further Angels. Answer with Grist −2 again, or later removal creatures.
3. P3: Skullclamp, Exquisite Blood or Vito. Answer with Seal, with Boseiju's channel as backup.
4. P1: Teval's Judgment or Insidious Roots. Answer with Seal or Boseiju.

Never chump-block for P3: a creature dying feeds its drain payoffs. Give P2 no lifegain.

HOLD: Boseiju in hand until land 5 so its channel stays available. Hold Ghostform until Muldrotha is on the battlefield (Konrad if needed). Don't cast Vrock and Konrad on the same turn into Farewell or Olivia's Wrath.

REPLAN IF: Grist survives at 4 or more loyalty, or dies. P3 lands Vito, Clamp or Blood. P2 casts a wrath or another Angel. We draw ramp or Capsule.
PILOT OVERRULED FORGE (action, MAIN1): chose [play land Swamp (from Hand): Play land] instead of Forge's [play land Waterlogged Grove (from Hand): Play land]
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Grist, the Hunger Tide (from Hand): Grist, the Hunger Tide [Forge's heuristic AI woul] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN1): chose [activate Grist, the Hunger Tide (from Battlefield): -2: You may sacrifice a creature. When] instead of Forge's [activate Grist, the Hunger Tide (from Battlefield): +1: Create a 1/1 black and green Insec]
- US cast Grist, the Hunger Tide
- US activated Grist, the Hunger Tide

## Turn 13 (P1, round 4)
- attack: P1 assigned Gravecrawler to attack Grist, the Hunger Tide.
- left battlefield: Grist, the Hunger Tide was put into Graveyard from Battlefield.
- P1 cast Teval, the Balanced Scale
- P1 cast Sakura-Tribe Elder
- left battlefield: Sakura-Tribe Elder was put into Graveyard from Battlefield.
- P1 activated Sakura-Tribe Elder
- P3 triggered Yahenni, Undying Partisan
- P1 cast Hedron Crab

## Turn 14 (P2, round 4) | life: P1 13, P2 61
- P2 cast Generous Gift targeting [Teval, the Balanced Scale]
- left battlefield: Teval, the Balanced Scale was put into Graveyard from Battlefield.
- P3 triggered Yahenni, Undying Partisan
- attack: P2 assigned Serra Ascendant, Gisela, the Broken Blade and Giada, Font of Hope to attack P1.

## Turn 15 (P3, round 4) | life: P1 13, P2 57
- P3 cast Vito, Thorn of the Dusk Rose
- P3 triggered Edgar Markov
- attack: P3 assigned Yahenni, Undying Partisan to attack P2.

## Turn 16 (OUR TURN, round 4) | life: P1 13, P2 57, US 39
Our hand: Boseiju, Who Endures, Syr Konrad, the Grim, Vrock, Waterlogged Grove, Seal of Primordium, Kaya's Ghostform, Pernicious Deed
Our graveyard (1): Grist, the Hunger Tide
Board P1: 6 lands; Gravecrawler 2/1 (tapped 1), Sol Ring (tapped 1), Hedron Crab 0/2, Elephant Token 3/3 [token]
Board P2: 4 lands; Serra Ascendant 6/6 (tapped 1), Giada, Font of Hope 2/2, Gisela, the Broken Blade 5/4 {[P1P1]} (tapped 1)
Board P3: 3 lands; Sol Ring (tapped 1), Vampire Token 1/1 [token] x2, Yahenni, Undying Partisan 4/4 {[P1P1 x 2]} (tapped 1), Vito, Thorn of the Dusk Rose 1/3
Board US: 3 lands; no nonland permanents
MEMO (start of our turn):
THIS TURN: Play Waterlogged Grove as the land drop. Cast Pernicious Deed (1BG: Tomb for G, Swamp for B, Swamp for generic). Keep Grove up. Don't activate Deed on opponents' turns just because they attack. Fire it at X=1 (Grove) only in response to something removing or exiling it (Generous Gift, Anguished Unmaking, Trophy, Farewell). X=1 still kills Serra Ascendant, tokens, Crab, Gravecrawler and Sol Rings. No blocks (no creatures).

TARGET: Next turn play land 5 (a drawn land if possible; else Boseiju). Activate Deed at X=4 (X=5 if P3 has landed Exquisite Blood or Sanguine Bond). That kills Gisela, Giada, Ascendant, Vito, Yahenni (unless he sacrifices for indestructible), and all tokens and Sol Rings. The turn after, land 6: Muldrotha (6). Then Ghostform on her, and recast Deed, Seal and Grist from the graveyard. Missing: Gray Merchant, Executioner's Capsule, Sol Ring/ramp.

WIN PATH: Muldrotha loops Grist (−2) and the Deed/Seal sacrifices. Vrock drains 3 per opponent each end step. Syr Konrad cast before a Deed pings once per creature that dies. P1 at 13 falls first. Our clock is about 5 turns. P2's fliers deal about 13 per turn, so wipe next turn.

THREATS & ANSWERS:
1. P2's fliers (Ascendant, Gisela, Giada): Deed X=4.
2. P3: Vito plus Exquisite Blood or Sanguine Bond. Answers are Deed at X=5, Seal, or Boseiju channel (1G, instant).
3. P1: Judgment or Roots, answered by Seal.

Never chump-block, and give P2 no lifegain.

HOLD: Seal, Vrock, Konrad and Ghostform until after the wipe.

REPLAN IF: Deed is removed or countered. P3 assembles a Vito combo. P2 wipes. We draw Sol Ring or Gray Merchant.
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Pernicious Deed (from Hand): Pernicious Deed [Forge's heuristic AI would not do this:] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
- US cast Pernicious Deed
- left battlefield: Pernicious Deed was put into Graveyard from Battlefield.
- US activated Pernicious Deed
- left battlefield: Gravecrawler was put into Graveyard from Battlefield.
- left battlefield: Sol Ring was put into Graveyard from Battlefield.
- left battlefield: Hedron Crab was put into Graveyard from Battlefield.
- left battlefield: Serra Ascendant was put into Graveyard from Battlefield.
- left battlefield: Sol Ring was put into Graveyard from Battlefield.
- P3 triggered Yahenni, Undying Partisan
- P3 triggered Yahenni, Undying Partisan
- P3 triggered Yahenni, Undying Partisan
- P3 triggered Yahenni, Undying Partisan

## Turn 17 (P1, round 5)
- P1 cast Teval, the Balanced Scale

## Turn 18 (P2, round 5) | life: P1 13, P2 62, P3 33, US 39
- attack: P2 assigned Gisela, the Broken Blade and Giada, Font of Hope to attack P3.
- P2 cast Vanquisher's Banner

## Turn 19 (P3, round 5) | life: P1 13, P2 54, P3 33, US 39
- attack: P3 assigned Yahenni, Undying Partisan to attack P2.
- P3 cast Mavren Fein, Dusk Apostle
- P3 triggered Edgar Markov

## Turn 20 (OUR TURN, round 5)
Our hand: Boseiju, Who Endures, Syr Konrad, the Grim, Vrock, Seal of Primordium, Kaya's Ghostform, Zagoth Triome
Our graveyard (2): Grist, the Hunger Tide, Pernicious Deed
Board P1: 6 lands; Teval, the Balanced Scale 4/4
Board P2: 5 lands; Giada, Font of Hope 3/3, Gisela, the Broken Blade 6/5 {[P1P1]} (tapped 1), Vanquisher's Banner
Board P3: 3 lands; Yahenni, Undying Partisan 8/8 {[P1P1 x 6]} (tapped 1), Vito, Thorn of the Dusk Rose 1/3, Vampire Token 1/1 [token], Mavren Fein, Dusk Apostle 2/2
Board US: 4 lands; no nonland permanents
MEMO (start of our turn):
THIS TURN: Play Zagoth Triome as the land drop. It enters tapped, and playing it now means Boseiju comes in untapped next turn for exactly 6 mana for Muldrotha. Cast Seal of Primordium (Tomb for G, Swamp for 1) and leave it on the battlefield as an instant-speed answer. Keep Swamp and Grove up. Sacrifice Seal on an opponent's turn only on: Exquisite Blood, Sanguine Bond, Teval's Judgment, Insidious Roots, Skullclamp. If Seal is targeted, sacrifice it in response on Vanquisher's Banner. We have no creatures, so no blocks.

TARGET: Next turn play Boseiju and cast Muldrotha (6, no tax). If we draw Sol Ring, Signet, Talisman or Mind Stone, cast it first and add Kaya's Ghostform on Muldrotha. The turn after, Ghostform her, then cast Syr Konrad, then recast Deed from the graveyard at X=4. Deed kills Giada, Gisela, Vito, Mavren and tokens. Then Grist −2 on Yahenni. Missing: ramp, Gray Merchant, Executioner's Capsule.

WIN PATH: Recur Deed, Seal and Grist, then Vrock drains 3 each end step and Konrad pings on each death. P1 at 13 falls first. Our clock is about 5 turns. P3 and P2 threaten roughly 25 combined per cycle, and we're at 39, so the wipe must land within two turns.

THREATS & ANSWERS: 1. P3 Vito plus a drain enchantment: Seal, backup Boseiju channel (1G). 2. P2 Gisela and Giada fliers: Deed X=4. 3. P3 Yahenni 8/8: Grist −2 after the Deed forces his sacrifices. 4. P1 Teval: Grist or Deed later. Give no lifegain; never chump.

HOLD: Boseiju in hand; channel it only to stop a Vito combo, since it is next turn's 6th land. Hold Vrock, Konrad and Ghostform.

REPLAN IF: Seal is used or removed, P3 lands a combo piece, a wipe happens, or we fall below 20 life.
PILOT OVERRULED FORGE (action, MAIN1): chose [play land Zagoth Triome (from Hand): Play land] instead of Forge's [play land Boseiju, Who Endures (from Hand): Play land]
PILOT OVERRULED FORGE (action, MAIN2): chose [activate Waterlogged Grove (from Battlefield): {1}, {T}, Sacrifice Waterlogged Grove: Draw] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
- US cast Seal of Primordium
- left battlefield: Seal of Primordium was put into Graveyard from Battlefield.
- US activated Seal of Primordium targeting [Vanquisher's Banner]
- left battlefield: Vanquisher's Banner was put into Graveyard from Battlefield.
- left battlefield: Waterlogged Grove was put into Graveyard from Battlefield.
- US activated Waterlogged Grove

## Turn 21 (P1, round 6)
- P1 cast Afterlife from the Loam targeting [Grist, the Hunger Tide, Sakura-Tribe Elder, Serra Ascendant]
- P1 activated Grist, the Hunger Tide
- left battlefield: Serra Ascendant was put into Graveyard from Battlefield.
- P1 triggered Grist, the Hunger Tide targeting [Gisela, the Broken Blade]
- P3 triggered Yahenni, Undying Partisan
- left battlefield: Gisela, the Broken Blade was put into Graveyard from Battlefield.
- P3 triggered Yahenni, Undying Partisan
- P1 cast Kheru Goldkeeper

## Turn 22 (P2, round 6)
- P2 cast Wrath of God
- left battlefield: Vito, Thorn of the Dusk Rose was put into Graveyard from Battlefield.
- P3 activated Yahenni, Undying Partisan
- left battlefield: Giada, Font of Hope was put into Graveyard from Battlefield.
- left battlefield: Mavren Fein, Dusk Apostle was put into Graveyard from Battlefield.
- left battlefield: Teval, the Balanced Scale was put into Graveyard from Battlefield.
- left battlefield: Kheru Goldkeeper was put into Graveyard from Battlefield.
- P3 triggered Yahenni, Undying Partisan
- P3 triggered Yahenni, Undying Partisan
- P3 triggered Yahenni, Undying Partisan

## Turn 23 (P3, round 6) | life: P1 0, P2 54, P3 33, US 39
- P3 cast Clavileño, First of the Blessed
- P3 triggered Edgar Markov
- attack: P3 assigned Yahenni, Undying Partisan to attack P1.
- P3 triggered Clavileño, First of the Blessed targeting [Yahenni, Undying Partisan]
- left battlefield: Grist, the Hunger Tide was put into Exile from Battlefield.

## Turn 24 (OUR TURN, round 6)
Our hand: Boseiju, Who Endures, Syr Konrad, the Grim, Vrock, Kaya's Ghostform, Executioner's Capsule, Breeding Pool
Our graveyard (3): Pernicious Deed, Seal of Primordium, Waterlogged Grove
Board P2: 5 lands; no nonland permanents
Board P3: 3 lands; Yahenni, Undying Partisan 13/13 {[P1P1 x 11]} (tapped 1), Vampire Token 1/1 [token], Clavileño, First of the Blessed 2/2
Board US: 4 lands; no nonland permanents
MEMO (start of our turn):
THIS TURN: Both opponents are tapped out (P2 has only War Room, which gives colourless, so no Swords or Path). Use the window. Play Breeding Pool and pay 2 life so it enters untapped (39 to 37). Cast Syr Konrad using Swamp and Swamp for BB, plus Tomb, Triome and Pool. Blocks: never block Yahenni. Konrad may block a 1/1 token or Clavileño only if that creature is not the one Clavileño turned into a Demon.

TARGET: Next turn, play Boseiju and cast Muldrotha (6, no tax). The turn after, play Waterlogged Grove from the graveyard as our land (7 mana). Then cast Kaya's Ghostform on Muldrotha (1) and recast Pernicious Deed from the graveyard (3). Activate Deed at X=3 (3): it kills the token, Clavileño and Yahenni, and Konrad pings each opponent per death. Missing pieces: Hostage Taker, Plaguecrafter, Toxic Deluge (Yahenni answers), Gray Merchant.

WIN PATH: Loop Deed, Seal and Capsule with Muldrotha. Konrad pings on every death, and Vrock drains 3 from each opponent every end step once something of ours has left. P3 at 33 falls first. Our clock is about 6 turns. Yahenni hits for 13 per swing, so answer it within 2 turns.

THREATS & ANSWERS:
1. Yahenni 13/13 is black, so Capsule can't hit it, and it goes indestructible by sacrificing another creature. Plan: Deed X=3 strips its other creatures, then Plaguecrafter or Hostage Taker, or Toxic Deluge.
2. P3's Vito plus Exquisite Blood: channel Boseiju, which costs only {G} with Konrad out.
3. P2's Giada or Angels: Executioner's Capsule (nonblack only), then Deed.
Give P2 no lifegain.

HOLD: Keep Boseiju in hand for next turn's land drop (channel only against a combo piece). Hold Capsule until there is a nonblack target, and hold Vrock until something can leave the battlefield that turn.

REPLAN IF: Konrad is removed or wiped (recast him later with Muldrotha), P3 lands Vito or a drain enchantment, we drop below 20 life, or Yahenni gets exiled.
PILOT OVERRULED FORGE (action, MAIN1): chose [play land Breeding Pool (from Hand): Play land] instead of Forge's [play land Boseiju, Who Endures (from Hand): Play land]
- US cast Executioner's Capsule

## Turn 25 (P2, round 7)
MEMO (executor escalation: P3: nonland permanents 3→0 (-3); P3: creatures 3→0 (-3)):
THIS TURN: Farewell wiped every board. Opponents have no creatures, so we are safe until our turn. On P3's turn, channel Boseiju ({1}{G}, Tomb plus Triome) only on Skullclamp, Exquisite Blood or Bloodthirsty Conqueror's enabler. Otherwise keep it. Our turn: play Boseiju as the land (6 mana). Cast Syr Konrad (Swamp, Swamp, Tomb, Triome, Pool), then Kaya's Ghostform on Konrad (Boseiju can't pay B, so cast Ghostform with Swamp and Konrad with Tomb, Triome, Pool, Swamp and Boseiju). Do not block with Konrad.

TARGET: Next turn cast Muldrotha (6, no tax). Spend spare mana on Konrad's {1}{B} mill to stock the graveyard. Each creature card milled pings both opponents, and milled permanents feed the lanes. Want: Massacre Wurm, Toxic Deluge, Gray Merchant, Pernicious Deed, fetch lands (fetches enable Vrock).

WIN PATH: Konrad pings, then Vrock drains 3 from each opponent per end step once fetches or Capsule-style sacrifices are recurring, then Muldrotha grinds. P3 at 33 is the priority. Our clock is about 6 or more turns. P3 rebuilds fastest (5 cards plus Edgar eminence).

THREATS & ANSWERS:
1. P3 Vito, Exquisite Blood or Skullclamp: Boseiju channel.
2. P3 token swarm: Massacre Wurm, Deed or Deluge when drawn.
3. P2 Giada or Angels: Capsule, Seals when drawn.
Give no lifegain to P2.

HOLD: Keep Vrock until something of ours can leave the battlefield that turn (a fetch, a sacrificed artifact). Keep Muldrotha's 6 mana for next turn. Don't cast Konrad without Ghostform, because both opponents run Swords and Path.

REPLAN IF: P3 casts Vito or Exquisite Blood, P2 lands Giada plus Angels, Konrad is exiled with Ghostform gone, or we draw a wipe.
ESCALATION (p=0.83): P3: nonland permanents 3→0 (-3); P3: creatures 3→0 (-3)
- P2 cast Farewell
- left battlefield: Executioner's Capsule was put into Exile from Battlefield.
- left battlefield: Yahenni, Undying Partisan was put into Exile from Battlefield.
- left battlefield: Clavileño, First of the Blessed was put into Exile from Battlefield.

## Turn 26 (P3, round 7)
- P3 cast Twilight Prophet
- P3 triggered Edgar Markov

## Turn 27 (OUR TURN, round 7)
Our hand: Boseiju, Who Endures, Syr Konrad, the Grim, Vrock, Kaya's Ghostform, Gray Merchant of Asphodel
Our graveyard (0): 
Board P2: 6 lands; no nonland permanents
Board P3: 4 lands; Vampire Token 1/1 [token], Twilight Prophet 2/4
Board US: 5 lands; no nonland permanents
MEMO (start of our turn):
THIS TURN: Both opponents are tapped out, so nothing can answer us now. Play Boseiju as the land (6 mana). Cast Syr Konrad with Swamp (B), Tomb (B), Triome, Pool and Boseiju. Then cast Kaya's Ghostform on Konrad with the other Swamp. We have 0 mana left, so there are no instant plays on opponents' turns. Don't block with Konrad; we're at 39 and nothing threatens us.

TARGET: Next turn, cast Muldrotha (6 mana, no tax). With 8 or more mana, also use Konrad's {1}{B} mill to stock the lanes. The turn after, cast Gray Merchant into devotion 6 (Konrad 2, Ghostform 1, Muldrotha 1, Merchant 2). Tutor wants: Massacre Wurm, Toxic Deluge, Pernicious Deed, fetch lands, Executioner's Capsule, Seal of Primordium.

WIN PATH: Gray Merchant drains (recast through Muldrotha once it can die), plus Konrad pings on every creature death, plus Vrock's 3 per end step. P3 (33 life) dies first. Our clock is about 5 turns. P3 rebuilds fastest (4 cards plus Edgar eminence).

THREATS & ANSWERS: 1) P3 Vito, Exquisite Blood, Bloodthirsty Conqueror, Skullclamp: dig for Assassin's Trophy, Seal of Primordium or Vraska. 2) P3 token swarm: Massacre Wurm, Deed or Deluge. 3) P2 Giada or Angels: Capsule, Seal. Give P2 no lifegain.

HOLD: Keep Vrock until a permanent of ours has already left that turn (fetch, sacrificed artifact). Keep Gray Merchant for when devotion is 5 or more. Don't cast Muldrotha this turn; our graveyard is empty.

REPLAN IF: Konrad is removed and Ghostform returns it (Ghostform then goes to the graveyard). P3 lands Vito or Exquisite Blood. P2 lands Giada. We draw a fetch (Vrock goes live) or a wipe.
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Syr Konrad, the Grim (from Hand): Syr Konrad, the Grim - Creature 5 / 4 [Forge's heur] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
- US cast Syr Konrad, the Grim
- US cast Kaya's Ghostform targeting [Syr Konrad, the Grim]

## Turn 28 (P2, round 7)
- P2 cast The Book of Exalted Deeds
- P2 cast Folk Hero

## Turn 29 (P3, round 8) | life: P1 0, P2 54, P3 33, US 37
- attack: P3 assigned Twilight Prophet to attack US.
- P3 cast Vampire Socialite
- P3 triggered Edgar Markov
- P3 triggered Vampire Socialite
Damage to US this turn: Twilight Prophet (combat) 2

## Turn 30 (OUR TURN, round 8) | life: P1 0, P2 47, P3 26, US 37
Our hand: Vrock, Gray Merchant of Asphodel, Walking Ballista
Our graveyard (0): 
Board P2: 6 lands; The Book of Exalted Deeds, Folk Hero
Board P3: 4 lands; Vampire Token 2/2 [token] {[P1P1]} x2, Twilight Prophet 3/5 {[P1P1]} (tapped 1), Vampire Socialite 2/2
Board US: 6 lands; Syr Konrad, the Grim 5/4, Kaya's Ghostform
MEMO (start of our turn):
THIS TURN: No land in hand. 1) Cast Walking Ballista with X=0 for free. It dies at once: Konrad pings each opponent for 1, Ballista goes to our graveyard for Muldrotha, and a permanent of ours has now left the battlefield, which turns on Vrock. 2) Cast Vrock ({3}{B}{B}) with Swamp, Swamp, Overgrown Tomb, Zagoth Triome and Breeding Pool. At our end step each opponent loses 3. 3) Keep Boseiju untapped.

TARGET: Next turn cast Muldrotha (6 mana). Recast Ballista at X=0 from the graveyard twice, once through the artifact lane and once through the creature lane. Each cast gives 2 Konrad pings (it leaves the graveyard, then it dies) and keeps Vrock live. Tutor wants: a fetch land, Massacre Wurm, Toxic Deluge, Assassin's Trophy.

WIN PATH: This turn deals 4 to each opponent (P3 to 29). Next turn deals 7 (4 pings plus Vrock 3). The turn after, Gray Merchant drains about 8 (devotion 8) plus 7 more, so P3 dies in about 3 turns. P2 at 54 takes longer.

THREATS & ANSWERS: 1) P3 Captivating Vampire: P3 already has 4 Vampires and could steal Konrad. Answer: Ballista pings or a Capsule. 2) P3 Vito or Exquisite Blood, Skullclamp: Boseiju channel costs only {G} while Konrad is out. 3) P2 Book of Exalted Deeds on an Angel: Boseiju. Never chump-block. Vrock must not block Twilight Prophet.

HOLD: Keep Gray Merchant until Muldrotha and Vrock are on board. Keep Boseiju up for channel.

REPLAN IF: A wipe hits (recast Vrock and Konrad through Muldrotha's creature lane, Ballista through the artifact lane). Captivating Vampire or Vito lands. We draw a land (then Muldrotha plus Ballista next turn still fits).
MEMO (executor escalation: P3: nonland permanents 4→2 (-2); we lost: Kaya's Ghostform):
THIS TURN: No mana is open, but Muldrotha's lanes are unused. 1) Cast Walking Ballista from the graveyard at X=0 through the ARTIFACT lane. Konrad pings twice: once as it leaves the graveyard, once when it dies. 2) Cast it again at X=0 through the CREATURE lane for 2 more pings. That is 4 to each opponent (P2 to 47, P3 to 26). Pass. On opponents' turns: Muldrotha may block a ground Vampire it kills. Never chump-block, and don't block with Konrad.

TARGET: Next turn, with 6 lands:
- Kaya's Ghostform ({B}, enchantment lane) on Muldrotha.
- Ballista at X=0 twice (4 pings; this also turns on Vrock).
- Vrock ({3}{B}{B}).
- Attack P2 with Muldrotha and Konrad while P2 has no creatures.
Wanted from draws: lands, Seal of Primordium, Assassin's Trophy, Massacre Wurm.

WIN PATH: Next turn deals 7 to each opponent plus 11 combat to P2. The turn after, Gray Merchant drains about 8 (devotion 8), plus Ballista 4 and Vrock 3. P3 dies in about 3 turns, P2 in about 4. Spare mana goes to Konrad {1}{B} mills.

THREATS & ANSWERS:
1) P3 Vito or Exquisite Blood: answer Vito with Ballista at X≥3 (6 mana). We have no enchantment answer yet.
2) Captivating Vampire (P3 has only 2 Vampires now): answer with Ballista pings.
3) P2 Book plus an Angel: race it.
Boseiju is on the battlefield, so its channel ability is NOT available.

HOLD: Keep Vrock and Gray Merchant in hand as the rebuild after a wipe (P2 Austere Command or Wrath, P3 Olivia's Wrath).

REPLAN IF:
- A wipe hits: recast Konrad through Muldrotha's lanes, or recast Muldrotha (tax +2).
- Vito, Exquisite Blood or Captivating Vampire lands.
- An Angel appears.
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Walking Ballista (from Hand): Walking Ballista - Creature 0 / 0 (X=0) [Forge's heuris] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Muldrotha, the Gravetide (from Command): Muldrotha, the Gravetide - Creature 6 / 6 [F] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (attack, COMBAT_DECLARE_ATTACKERS): chose [attack P3 (32 life)] instead of Forge's [don't attack with it]
ESCALATION (p=0.61): P3: nonland permanents 4→2 (-2); we lost: Kaya's Ghostform
PILOT OVERRULED FORGE (action, MAIN2): chose [cast Walking Ballista (from Graveyard): Walking Ballista - Creature 0 / 0 (X=0) by Muldrot] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN2): chose [cast Walking Ballista (from Graveyard): Walking Ballista - Creature 0 / 0 (X=0) by Muldrot] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
- US cast Walking Ballista
- left battlefield: Walking Ballista was put into Graveyard from Battlefield.
- US triggered Syr Konrad, the Grim
- US cast Muldrotha, the Gravetide
- attack: US assigned Syr Konrad, the Grim to attack P3.
- attack: P3 assigned Vampire Token and Vampire Socialite to block Syr Konrad, the Grim.
- left battlefield: Syr Konrad, the Grim was put into Graveyard from Battlefield.
- left battlefield: Vampire Socialite was put into Graveyard from Battlefield.
- left battlefield: Kaya's Ghostform was put into Graveyard from Battlefield.
- US triggered Kaya's Ghostform
- US triggered Syr Konrad, the Grim
- US triggered Syr Konrad, the Grim
- US cast Walking Ballista
- US triggered Syr Konrad, the Grim
- left battlefield: Walking Ballista was put into Graveyard from Battlefield.
- US triggered Syr Konrad, the Grim
- US cast Walking Ballista
- US triggered Syr Konrad, the Grim
- left battlefield: Walking Ballista was put into Graveyard from Battlefield.
- US triggered Syr Konrad, the Grim

## Turn 31 (P2, round 8) | life: P1 0, P2 45, P3 24, US 37
- P2 cast Stroke of Midnight targeting [Muldrotha, the Gravetide]
- left battlefield: Muldrotha, the Gravetide was put into Graveyard from Battlefield.
- US triggered Syr Konrad, the Grim
- US triggered Syr Konrad, the Grim
- P2 cast Enlightened Tutor

## Turn 32 (P3, round 8) | life: P1 0, P2 45, P3 24, US 34
- attack: P3 assigned Twilight Prophet to attack US.
- P3 cast Forerunner of the Legion
- P3 triggered Edgar Markov
- P3 triggered Forerunner of the Legion
Damage to US this turn: Twilight Prophet (combat) 3

## Turn 33 (OUR TURN, round 9) | life: P1 0, P2 40, P3 19, US 34
Our hand: Vrock, Gray Merchant of Asphodel, Farseek
Our graveyard (2): Kaya's Ghostform, Walking Ballista
Board P2: 6 lands; The Book of Exalted Deeds, Folk Hero
Board P3: 4 lands; Twilight Prophet 3/5 {[P1P1]} (tapped 1), Vampire Token 2/2 [token] {[P1P1]}, Vampire Token 1/1 [token], Forerunner of the Legion 2/2
Board US: 6 lands; Syr Konrad, the Grim 5/4, Human Token 1/1 [token]
MEMO (start of our turn):
THIS TURN (6 mana, Muldrotha is in the command zone at 8, which we can't afford):
1) Pay {1}{B} with Swamp and Breeding Pool: Syr Konrad mill. This mills P3's Forerunner-tutored Vampire and P2's Enlightened Tutor card off the top. Each creature card milled pings each opponent for 1.
2) Farseek ({1}{G}, Boseiju and Overgrown Tomb) for Underground Sea (Watery Grave if Sea is gone).
3) Hold Swamp and Triome for another {1}{B} mill. Fire it in response to any new put-on-top tutor, otherwise at the end of P3's turn.
4) Blocks: Konrad may block one ground token or Forerunner with power 3 or less. Never chump with the Human token.

TARGET: 8 lands, then Muldrotha (8). Through the lanes: Ghostform on Muldrotha, Ballista X=0 twice (4 pings, turns on Vrock), then Vrock. Want Sol Ring, Arcane Signet, lands, Massacre Wurm, Seal of Doom.

WIN PATH: Next turn, with 8 mana cast Muldrotha. Otherwise cast Gray Merchant (drain 4) plus a Konrad mill. Then cast Vrock and recur Ballista and Gray Merchant every turn, about 10 per turn each. P3 (24) dies in about 3 turns, P2 (45) later. P3's clock is slower unless Vito lands.

THREATS & ANSWERS:
1) P3 Vito, Exquisite Blood or Bloodthirsty Conqueror: Ballista X≥3 once Muldrotha is back. Nothing for Exquisite Blood yet.
2) Twilight Prophet if P3 reaches 10 permanents (at 8 now): Ballista.
3) P2 Book or a new Angel: race it.

HOLD: Vrock and Gray Merchant stay in hand as the rebuild after a wipe. Keep the {1}{B} mill open.

REPLAN IF: A land is drawn (cast Muldrotha next turn), Vito or Exquisite Blood lands, a wipe hits Konrad, or an Angel appears.
PILOT OVERRULED FORGE (action, MAIN1): chose [activate Syr Konrad, the Grim (from Battlefield): {1}{B}: Each player mills a card. [Forge] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN1): chose [activate Syr Konrad, the Grim (from Battlefield): {1}{B}: Each player mills a card. [Forge] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
- US cast Farseek
- US activated Syr Konrad, the Grim
- US triggered Syr Konrad, the Grim
- US activated Syr Konrad, the Grim
- US triggered Syr Konrad, the Grim
- US triggered Syr Konrad, the Grim
- attack: US assigned Syr Konrad, the Grim to attack P3.
- attack: P3 assigned Vampire Token and Forerunner of the Legion to block Syr Konrad, the Grim.
- left battlefield: Syr Konrad, the Grim was put into Graveyard from Battlefield.
- left battlefield: Forerunner of the Legion was put into Graveyard from Battlefield.
- US triggered Syr Konrad, the Grim
- US triggered Syr Konrad, the Grim

## Turn 34 (P2, round 9)
- P2 cast Pearl Medallion
- P2 cast Giada, Font of Hope

## Turn 35 (P3, round 9) | life: P1 0, P2 37, P3 19, US 34
- attack: P3 assigned Twilight Prophet to attack P2.
- P3 cast Elenda, the Dusk Rose
- P3 triggered Edgar Markov

## Turn 36 (OUR TURN, round 9)
Our hand: Vrock, Gray Merchant of Asphodel, The Death of Gwen Stacy
Our graveyard (6): Kaya's Ghostform, Walking Ballista, Farseek, Forest, The Coming of Galactus, Syr Konrad, the Grim
Board P2: 6 lands; The Book of Exalted Deeds, Folk Hero, Pearl Medallion, Giada, Font of Hope 2/2
Board P3: 4 lands; Twilight Prophet 3/5 {[P1P1]} (tapped 1), Vampire Token 1/1 [token] x2, Elenda, the Dusk Rose 1/1
Board US: 7 lands; Human Token 1/1 [token]
MEMO (start of our turn):
THIS TURN: No land in hand, and Muldrotha costs 8, so she can't be cast. Cast The Death of Gwen Stacy ({2}{B}: Swamp, Swamp, Underground Sea). Chapter I destroys Twilight Prophet: P3 is at 8 permanents, and at 10 the Prophet drains every upkeep. The last 4 mana has no use; Boseiju can't channel from the battlefield. Don't block with the Human token.

TARGET: An 8th mana source, then Muldrotha. Through the lanes: Syr Konrad (creature), The Coming of Galactus (enchantment, kills a nonland permanent), Walking Ballista (artifact). Muldrotha's 8 mana fills that turn; the lanes start the turn after. Want lands, Sol Ring, Arcane Signet, Mind Stone and Massacre Wurm.

WIN PATH: Next turn, Gwen chapter II: we lose 3 rather than discard. Without a land, cast Gray Merchant (devotion 3, drains 3 each). The turn after, chapter III: exile only P2's and P3's graveyards, never ours. The saga then leaves, so cast Vrock that turn for 3 each at end step. P3 (19) dies in about 3-4 turns, then Muldrotha grinds P2 (37).

THREATS & ANSWERS:
1) Vito, Exquisite Blood, Skullclamp, Bloodthirsty Conqueror: Galactus chapter I via Muldrotha; Ballista for the creatures. Nothing in hand answers them now.
2) P2's Book activated on an Angel stops us winning. Kill that Angel: Giada dies to Ballista X=2.
3) Elenda grows with every death, so avoid trading creatures.

HOLD: Vrock and Gray Merchant stay in hand as the post-wipe rebuild and the drain plan.

REPLAN IF: A land or ramp is drawn (cast Muldrotha instead of Merchant). Vito, Exquisite Blood or Skullclamp lands. P2 uses the Book. A wipe comes.
PILOT OVERRULED FORGE (action, MAIN1): chose [cast The Death of Gwen Stacy (from Hand): The Death of Gwen Stacy [Forge's heuristic AI wo] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
- US cast The Death of Gwen Stacy
- US triggered The Death of Gwen Stacy targeting [Twilight Prophet]
- left battlefield: Twilight Prophet was put into Graveyard from Battlefield.
- P3 triggered Elenda, the Dusk Rose

## Turn 37 (P2, round 10) | life: P1 0, P2 36, P3 17, US 34
- attack: P2 assigned Giada, Font of Hope to attack P3.
- P2 activated War Room
- P2 cast Oketra's Monument

## Turn 38 (P3, round 10)
- P3 cast Legion Lieutenant
- P3 triggered Edgar Markov

## Turn 39 (OUR TURN, round 10) | life: P1 0, P2 33, P3 17, US 34
Our hand: Vrock, Gray Merchant of Asphodel, Ratchet Bomb
Our graveyard (6): Kaya's Ghostform, Walking Ballista, Farseek, Forest, The Coming of Galactus, Syr Konrad, the Grim
Board P2: 7 lands; The Book of Exalted Deeds, Folk Hero, Pearl Medallion, Giada, Font of Hope 2/2, Oketra's Monument
Board P3: 4 lands; Vampire Token 2/2 [token] x3, Elenda, the Dusk Rose 3/3 {[P1P1]}, Legion Lieutenant 2/2
Board US: 7 lands; Human Token 1/1 [token], The Death of Gwen Stacy {[LORE x 2]}
MEMO (start of our turn):
THIS TURN: Gwen chapter II is on the stack. Don't discard; take the 3 life (34→31). Then cast Vrock ({3}{B}{B}) and Ratchet Bomb ({2}), which uses all 7 lands. Leave Ratchet Bomb untapped at 0 counters as an instant-speed token wipe. On P3's turn, pop it after attackers are declared if tokens attack. If they don't attack, pop it at P3's end step, so any tokens made that turn die too. The Human token dies too, which is fine. Don't chump-block, since every death grows Elenda.

TARGET: An 8th mana source, then Muldrotha (8 total). Then recur through the lanes: Ratchet Bomb and Walking Ballista (artifact lane), The Coming of Galactus (enchantment lane), Syr Konrad (creature lane). Wanted draws: any land, Sol Ring, Arcane Signet, Mind Stone, Hostage Taker (exiles Elenda), Massacre Wurm.

WIN PATH: Next turn, Gwen chapter III exiles only P2's and P3's graveyards, never ours. The saga then leaves, so Vrock drains 3 each at end step. If we draw no land, cast Gray Merchant next turn: devotion 4 drains 4 each. P3 goes 17 → dead in about 3 turns, then Muldrotha grinds P2 down.

THREATS & ANSWERS:
1) P3's Vito, Exquisite Blood, Skullclamp or Bloodthirsty Conqueror: Galactus chapter I via Muldrotha; Ballista for the creatures.
2) Elenda grows with each death and splits into tokens when she dies. She needs exile: Hostage Taker.
3) P2 using the Book on Giada means we can't win. Kill Giada first: Ballista X=2, Galactus I, or Ratchet Bomb at 2.

HOLD: Gray Merchant stays in hand as the rebuild after Olivia's Wrath, and as next turn's drain.

REPLAN IF: We draw a land or ramp (cast Muldrotha). Vito or Exquisite Blood lands. P2 activates the Book. A wipe kills Vrock.
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Vrock (from Hand): Vrock - Creature 3 / 3 [Forge's heuristic AI would not do this: Ca] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
- US triggered The Death of Gwen Stacy
- US cast Vrock

## Turn 40 (P2, round 10) | life: P1 0, P2 32, P3 15, US 34
- attack: P2 assigned Giada, Font of Hope to attack P3.
- P2 activated War Room
- P2 cast Resplendent Angel
- P2 triggered Giada, Font of Hope
- P2 triggered Oketra's Monument
- P2 cast Sol Ring

## Turn 41 (P3, round 11)
- P3 cast Knight of the Ebon Legion
- P3 triggered Edgar Markov
- P3 cast Cruel Celebrant
- P3 triggered Edgar Markov

## Turn 42 (OUR TURN, round 11) | life: P1 0, P2 25, P3 5, US 42
Our hand: Gray Merchant of Asphodel, Shriekmaw
Our graveyard (8): Kaya's Ghostform, Walking Ballista, Farseek, Forest, The Coming of Galactus, Syr Konrad, the Grim, Ratchet Bomb, The Death of Gwen Stacy
Board P2: 7 lands; The Book of Exalted Deeds, Folk Hero, Pearl Medallion, Giada, Font of Hope 2/2, Oketra's Monument, Warrior Token 1/1 [token], Resplendent Angel 4/4 {[P1P1]}, Sol Ring
Board P3: 5 lands; Vampire Token 2/2 [token] x5, Elenda, the Dusk Rose 3/3 {[P1P1]}, Legion Lieutenant 2/2, Knight of the Ebon Legion 2/3, Cruel Celebrant 2/3
Board US: 7 lands; Human Token 1/1 [token], Vrock 3/3
MEMO (start of our turn):
THIS TURN: 1) Cast Gray Merchant ({3}{B}{B}). Devotion is 4 (Vrock plus Gary), so it drains 4 each: P3 15→11, P2 32→28, and we gain 8. 2) Attack P3 with Vrock only. P3 has no flyers or reach, so P3 goes to 8. Keep the Human token home. 3) Gwen Stacy left the battlefield this turn, so Vrock's end-step trigger is on: P3 5, P2 25. Keep Shriekmaw in hand and leave 2 mana unused.

TARGET: An 8th mana source, then Muldrotha (8 mana). Then recur through the lanes: Ratchet Bomb (artifact), The Coming of Galactus (enchantment; chapter I on The Book of Exalted Deeds), Syr Konrad (creature). Wanted draws: any land, Sol Ring, Signet, Mind Stone.

WIN PATH: Next turn P3 should be at about 5. Evoke Shriekmaw ({1}{B}) on Resplendent Angel. Shriekmaw being sacrificed turns on Vrock. Then Vrock attacks P3 for 3, and Vrock's end step deals 3 more, killing P3. Do this even if we draw a land; Muldrotha waits a turn. After that, Muldrotha grinds P2 down.

THREATS & ANSWERS: 1) P3's Vito, Exquisite Blood or Bloodthirsty Conqueror: race it, since Shriekmaw can't hit black creatures. 2) P2 using the Book on an Angel means they can't lose: Shriekmaw that Angel. Later, Galactus I on the Book. 3) Resplendent Angel making lifelink tokens: Shriekmaw next turn. Every death grows Elenda, so don't chump-block.

HOLD: Shriekmaw. It is next turn's Vrock enabler and the answer to an enlightened Angel.

REPLAN IF: A wipe kills Vrock (then cast Muldrotha or Shriekmaw for value). P3 gains enough life to stay above 6. P2 uses the Book: Shriekmaw that Angel immediately. Vito lands.
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Gray Merchant of Asphodel (from Hand): Gray Merchant of Asphodel - Creature 2 / 4 [Fo] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
- US triggered The Death of Gwen Stacy targeting [P3]
- left battlefield: The Death of Gwen Stacy was put into Graveyard from Battlefield.
- US cast Gray Merchant of Asphodel
- US triggered Gray Merchant of Asphodel
- attack: US assigned Vrock to attack P3.
- US cast Shriekmaw
- US triggered Shriekmaw targeting [Resplendent Angel]
- US triggered Shriekmaw
- left battlefield: Shriekmaw was put into Graveyard from Battlefield.
- P3 triggered Elenda, the Dusk Rose
- left battlefield: Resplendent Angel was put into Graveyard from Battlefield.
- P3 triggered Elenda, the Dusk Rose
- US triggered Vrock

## Turn 43 (P2, round 11) | life: P1 0, P2 25, P3 3, US 42
- attack: P2 assigned Giada, Font of Hope to attack P3.
- P2 cast Bruna, the Fading Light
- P2 triggered Bruna, the Fading Light targeting [Resplendent Angel]
- P2 triggered Giada, Font of Hope
- P2 triggered Oketra's Monument
- P2 cast Herald of War
- P2 triggered Oketra's Monument

## Turn 44 (P3, round 11)
- P3 cast Edgar Markov

## Turn 45 (OUR TURN, round 12) | life: P1 0, P2 21, P3 3, US 41
Our hand: Command Tower
Our graveyard (9): Kaya's Ghostform, Walking Ballista, Farseek, Forest, The Coming of Galactus, Syr Konrad, the Grim, Ratchet Bomb, The Death of Gwen Stacy, Shriekmaw
Board P2: 7 lands; The Book of Exalted Deeds, Folk Hero, Pearl Medallion, Giada, Font of Hope 2/2, Oketra's Monument, Warrior Token 1/1 [token] x3, Sol Ring (tapped 1), Resplendent Angel 4/4 {[P1P1]}, Bruna, the Fading Light 7/9 {[P1P1 x 2]}, Herald of War 6/6 {[P1P1 x 3]}
Board P3: 6 lands; Vampire Token 2/2 [token] x5, Elenda, the Dusk Rose 5/5 {[P1P1 x 3]}, Legion Lieutenant 2/2, Knight of the Ebon Legion 2/3, Cruel Celebrant 2/3, Edgar Markov 5/5
Board US: 7 lands; Human Token 1/1 [token], Vrock 3/3, Gray Merchant of Asphodel 2/4
MEMO (start of our turn):
THIS TURN: 1) Play Command Tower (8 mana). 2) Attack P3 with Vrock only. It has 3 flying power and P3 has no flyers or reach, so P3 (life 3) dies. Nothing of ours dies first, so Cruel Celebrant can't gain P3 life. 3) In main phase 2, cast Muldrotha with all 8 mana (6 + 2 tax). P3 is tapped out, and P2 has only War Room (colourless) plus Giada (Angel-only mana), so nothing can stop it.

TARGET: Next turn, Muldrotha recasts through the lanes and we play Forest from the graveyard. Draws we want: Sol Ring, Signet, Mind Stone, Mishra's Bauble.

WIN PATH: With 9 mana next turn:
- Evoke Shriekmaw ({1}{B}) on Herald of War. This also turns on Vrock.
- Cast The Death of Gwen Stacy (3) on Bruna.
- Cast Walking Ballista for X=2 (4) and ping Giada twice.
Vrock then drains P2 at the end step. Following turns: The Coming of Galactus on the Book, Syr Konrad, and Gray Merchant loops. P2 is at 25, so roughly a 4-5 turn clock.

THREATS & ANSWERS: 1) P2's air force (about 20 flying power) plus Akroma's Will (double strike and protection) could deal 46, which beats our 42. Answer: next turn's three kills above. Block with Muldrotha and Vrock where we legally can. 2) The Book making an Angel unable to lose: Shriekmaw or Gwen Stacy on that Angel, or Galactus chapter I on the Book. 3) Farewell or Austere Command: we rebuild from the graveyard; Kaya's Ghostform on Muldrotha when mana allows.

HOLD: Nothing. All 8 mana goes to Muldrotha, and there are no cards left in hand.

REPLAN IF: P3 survives (lifegain or a flash blocker), then Vrock's end step needs something of ours to leave. Muldrotha gets removed: recast next turn at tax +4. Our graveyard gets exiled. P2 wipes the board.
MEMO (executor escalation: we lost: Gray Merchant of Asphodel):
THIS TURN: We have 0 mana and no hand. 1) Cast Walking Ballista from the graveyard with X=0 through the artifact lane (it costs 0). It enters as 0/0 and dies. That means a permanent of ours has left this turn, so Vrock triggers at end step: P3 goes 6→3 and P2 goes 24→21. 2) End the turn. On opponents' turns, Vrock stays tapped. Block ground attackers only: Muldrotha blocks the biggest ground attacker, and the Human token chumps a Warrior or Vampire only if the damage would otherwise be near-lethal.

TARGET: Next turn, with 9 mana (8 lands plus Forest from the graveyard):
- Play Forest from the graveyard.
- Cast The Death of Gwen Stacy ({2}{B}) and kill P2's biggest flyer. Kill an Angel with an enlightened counter first, if one exists.
- Cast Gray Merchant ({3}{B}{B}). Devotion is 6 (Muldrotha 1, Vrock 2, Gwen 1, Merchant 2), so each opponent loses 6. That kills P3.
- Recast Ballista at X=0 again so Vrock triggers.

WIN PATH: The Merchant plus Vrock loop drains 9 a turn. P2 goes about 21→12→3→dead over roughly 3 turns. P2's flyers (about 20 power, about 40 with Akroma's Will) are the race we must survive.

THREATS & ANSWERS: 1) P2's air force and the Book's "can't lose" counter: Gwen Stacy's chapter I now, Galactus's chapter I in later turns. 2) P3's Elenda lifelink swings: Merchant next turn plus Ballista pings. 3) Farewell: rebuild from the graveyard.

HOLD: No cards in hand. Save mana next turn for Merchant before anything else.

REPLAN IF: P3 gains life above 6 (for example, Elenda attacks), so cast Ballista with the spare mana and ping P3. Our graveyard is exiled. Muldrotha dies. We drop below 25 life, so prioritise killing flyers over draining.
PILOT OVERRULED FORGE (action, MAIN1): chose [play land Command Tower (from Hand): Play land] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Muldrotha, the Gravetide (from Command): Muldrotha, the Gravetide - Creature 6 / 6 [F] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (attack, COMBAT_DECLARE_ATTACKERS): chose [don't attack with it] instead of Forge's [attack P3 (3 life)]
ESCALATION (p=0.61): we lost: Gray Merchant of Asphodel
PILOT OVERRULED FORGE (action, MAIN2): chose [cast Walking Ballista (from Graveyard): Walking Ballista - Creature 0 / 0 (X=0) by Muldrot] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN2): chose [cast Walking Ballista (from Graveyard): Walking Ballista - Creature 0 / 0 (X=0) by Muldrot] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
- US cast Muldrotha, the Gravetide
- attack: US assigned Vrock and Gray Merchant of Asphodel to attack P3.
- left battlefield: Gray Merchant of Asphodel was put into Graveyard from Battlefield.
- P3 triggered Cruel Celebrant
- P3 triggered Elenda, the Dusk Rose
- P3 triggered Elenda, the Dusk Rose
- US cast Walking Ballista
- left battlefield: Walking Ballista was put into Graveyard from Battlefield.
- P3 triggered Elenda, the Dusk Rose
- US cast Walking Ballista
- left battlefield: Walking Ballista was put into Graveyard from Battlefield.
- P3 triggered Elenda, the Dusk Rose
- US triggered Vrock

## Turn 46 (P2, round 12) | life: P1 0, P2 27, P3 -19, US 41
- attack: P2 assigned Bruna, the Fading Light, Herald of War, Resplendent Angel, Giada, Font of Hope, Warrior Token, Warrior Token and Warrior Token to attack P3.
- P2 triggered Herald of War
- P2 activated Resplendent Angel
- P2 triggered The Book of Exalted Deeds
- P2 triggered Resplendent Angel

## Turn 47 (OUR TURN, round 12) | life: P1 0, P2 15, P3 -19, US 40
Our hand: Polluted Delta
Our graveyard (10): Kaya's Ghostform, Farseek, Forest, The Coming of Galactus, Syr Konrad, the Grim, Ratchet Bomb, The Death of Gwen Stacy, Shriekmaw, Gray Merchant of Asphodel, Walking Ballista
Board P2: 7 lands; The Book of Exalted Deeds, Folk Hero, Pearl Medallion, Giada, Font of Hope 2/2, Oketra's Monument, Sol Ring (tapped 1), Resplendent Angel 4/4 {[P1P1]} (tapped 1), Bruna, the Fading Light 7/9 {[P1P1 x 2]}, Herald of War 7/7 {[P1P1 x 4]} (tapped 1), Angel Token 8/8 [token] {[P1P1 x 4]}, Angel Token 8/8 [token] {[P1P1 x 5]}
Board US: 8 lands; Human Token 1/1 [token], Vrock 3/3, Muldrotha, the Gravetide 6/6
MEMO (start of our turn):
**THIS TURN:** P3 is gone; only P2 remains (27 life, about 36 flying power). Remove their air force, then drain. 1) Play Polluted Delta, crack it (pay 1 life) and fetch a basic Swamp, for 9 mana. 2) Cast Ratchet Bomb from the graveyard (artifact lane, {2}). Immediately tap and sacrifice it at 0 counters: both 8/8 Angel tokens die, along with our Human token. 3) Evoke Shriekmaw ({1}{B}, creature lane) and kill Herald of War. 4) Cast The Coming of Galactus ({2}{B}{B}{G}, enchantment lane); chapter I destroys Bruna. 5) Attack P2 with Muldrotha only; Vrock stays home as our flying blocker. 6) At end step Vrock drains 3.

**TARGET:** Next turn, with 10 mana (Forest from the graveyard): Gray Merchant ({3}{B}{B}, drains 7 with Galactus on board), Ratchet Bomb recast (Vrock trigger, kills new Warriors), and Death of Gwen Stacy to kill Giada or an enlightened Angel.

**WIN PATH:** Galactus II/III drain 2 each. Merchant 7 plus Vrock 3 per turn puts P2 at about 18, then about 6, then dead in 2-3 turns. On chapter IV the 16/16 Galactus finishes; aim its land trigger at our own replayable land. Their remaining clock is about 6 power against our 40 life.

**THREATS & ANSWERS:** 1) Book of Exalted Deeds enlightened counter: kill that Angel with Shriekmaw or Gwen. 2) Giada making future Angels bigger: Shriekmaw next time the creature lane is free. 3) A Bruna recast returning Angels: Gwen chapter III, targeting P2's graveyard only. 4) Farewell or Austere Command: rebuild from the graveyard.

**HOLD:** Nothing is left to hold; spend all 9 mana.

**REPLAN IF:** An Angel gets an enlightened counter (kill it first), we are wiped or our graveyard is exiled, or we fall below 20 life (removal before drain).
MEMO (executor escalation: P2: nonland permanents 11→8 (-3); P2: creatures 6→3 (-3)):
THIS TURN: No hand, and the land, artifact, creature and enchantment lanes are all spent. The 3 open mana (Triome, Breeding Pool, Command Tower) has no use. Attack P2 with Muldrotha and Vrock. Only Giada (2/2 flier) can block, and trading her away is good for us. Expect 9 damage, putting P2 at 18. At end step, Vrock drains 3 (Delta, Ratchet and Shriekmaw left this turn), putting P2 at about 15.

TARGET: Next turn we have 10 mana (replay Forest from the graveyard). Play these in order:
1) Evoke Shriekmaw ({1}{B}) and kill Herald of War. This also turns on Vrock.
2) Cast Gray Merchant ({3}{B}{B}). Devotion 6 drains 6.
3) Cast Ratchet Bomb ({2}) and pop it at 0 to kill the Warrior tokens.
4) Attack.

WIN PATH: About 15 minus 6 (Merchant) minus 3 (Vrock) leaves about 6, and combat or the following turn's Merchant plus Vrock finishes. Our clock is 2 turns. P2 has about 14 flying power against our 40 life, so we are safe for 2 or more turns. Galactus ({2}{B}{B}{G}) is the backup removal plus drain.

THREATS & ANSWERS:
1) Book of Exalted Deeds enlightened counter (sorcery speed, WWW): P2 can't lose while that Angel lives. Kill it first with Shriekmaw, Gwen Stacy, Galactus chapter I or Ballista pings.
2) Herald of War 7/7 plus cost cuts: Shriekmaw.
3) Giada: Gwen Stacy or Galactus chapter I.
4) Farewell or Austere Command: rebuild from the graveyard. Kaya's Ghostform returns Muldrotha.

HOLD: Nothing castable. Leave the 3 mana open.

REPLAN IF:
- An Angel gets the enlightened counter: removal before drain.
- Farewell exiles our graveyard: switch to topdecks plus Vrock.
- P2 goes above 20 life through lifegain.
- We drop below 20.
PILOT OVERRULED FORGE (action, MAIN1): chose [play land Polluted Delta (from Hand): Play land] instead of Forge's [cast Kaya's Ghostform (from Graveyard): Kaya's Ghostform by Muldrotha, the Gravetide (403)]
PILOT OVERRULED FORGE (search, MAIN1): chose [Watery Grave — Land - Island Swamp — ({T}: Add {U} or {B}.) As Watery Grave enters, you ma] instead of Forge's [Tropical Island — Land - Forest Island — ({T}: Add {G} or {U}.)]
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Ratchet Bomb (from Graveyard): Ratchet Bomb by Muldrotha, the Gravetide (403) (Artifa] instead of Forge's [cast Kaya's Ghostform (from Graveyard): Kaya's Ghostform by Muldrotha, the Gravetide (403)]
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Shriekmaw (from Graveyard): Evoke {1}{B} (You may cast this spell for its evoke cost.] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
ESCALATION (p=0.79): P2: nonland permanents 11→8 (-3); P2: creatures 6→3 (-3)
- left battlefield: Polluted Delta was put into Graveyard from Battlefield.
- US activated Polluted Delta
- US cast Ratchet Bomb
- left battlefield: Ratchet Bomb was put into Graveyard from Battlefield.
- US activated Ratchet Bomb
- US cast Kaya's Ghostform targeting [Muldrotha, the Gravetide]
- US cast Shriekmaw
- US triggered Shriekmaw targeting [Bruna, the Fading Light]
- US triggered Shriekmaw
- left battlefield: Shriekmaw was put into Graveyard from Battlefield.
- left battlefield: Bruna, the Fading Light was put into Graveyard from Battlefield.
- attack: US assigned Vrock and Muldrotha, the Gravetide to attack P2.
- US triggered Vrock

## Turn 48 (P2, round 12) | life: P1 0, P2 21, P3 -19, US 24
- attack: P2 assigned Herald of War, Resplendent Angel and Giada, Font of Hope to attack US.
- P2 triggered Herald of War
- P2 activated Resplendent Angel
- P2 cast Angel of Destiny
- P2 triggered Giada, Font of Hope
- P2 triggered Oketra's Monument
- P2 triggered The Book of Exalted Deeds
- P2 triggered Resplendent Angel
Damage to US this turn: Herald of War (combat) 8, Resplendent Angel (combat) 6, Giada, Font of Hope (combat) 2

## Turn 49 (OUR TURN, round 13) | life: P1 0, P2 21, P3 -19, US 23
Our hand: Secrets of the Dead
Our graveyard (10): Farseek, Forest, The Coming of Galactus, Syr Konrad, the Grim, The Death of Gwen Stacy, Gray Merchant of Asphodel, Walking Ballista, Polluted Delta, Ratchet Bomb, Shriekmaw
Board P2: 8 lands; The Book of Exalted Deeds, Folk Hero, Pearl Medallion, Giada, Font of Hope 2/2, Oketra's Monument, Sol Ring (tapped 1), Resplendent Angel 4/4 {[P1P1]} (tapped 1), Herald of War 8/8 {[P1P1 x 5]} (tapped 1), Warrior Token 1/1 [token], Angel of Destiny 5/9 {[P1P1 x 3]}, Angel Token 8/8 [token] {[P1P1 x 4]}, Angel Token 8/8 [token] {[P1P1 x 5]}
Board US: 9 lands; Vrock 3/3, Muldrotha, the Gravetide 6/6, Kaya's Ghostform
MEMO (start of our turn):
THIS TURN (10 mana)
1) Cast Secrets of the Dead from hand ({2}{U}).
2) Play Polluted Delta from the graveyard and crack it for a basic Swamp (untapped).
3) Cast Ratchet Bomb from the graveyard ({2}). Pop it at 0 counters. This kills both 8/8 Angel tokens and the Warrior.
4) Evoke Shriekmaw ({1}{B}) and kill Herald of War.
5) Cast The Death of Gwen Stacy ({2}{B}) and kill Angel of Destiny.
6) Attack P2 with Muldrotha and Vrock.
7) Vrock drains 3 at end step, putting P2 at about 9–18.
If Flawless Maneuver resolves, don't pop Ratchet; pop it in P2's upkeep instead.

TARGET: P2's flying board shrinks to Giada and Resplendent Angel. Secrets draws about 3 cards a turn. Galactus goes on the battlefield for devotion.

WIN PATH: Next turn, play Delta or Forest from the graveyard (11 mana).
1) Cast The Coming of Galactus ({2}{B}{B}{G}). Chapter I kills the best threat, or any Angel carrying an enlightened counter.
2) Cast Gray Merchant ({3}{B}{B}). Devotion 9 drains 9.
3) Vrock adds 3 more. That is about 12 total, likely lethal.
Without this turn's kills, P2's roughly 41 flying power kills us next turn.

THREATS & ANSWERS
1) Angel of Destiny (10 double-strike flying damage): Gwen Stacy.
2) Herald of War: Shriekmaw.
3) The tokens: Ratchet Bomb.
4) An enlightened counter from the Book (P2 can't lose): Galactus chapter I, or Shriekmaw next turn, before the drain.
5) Giada and free Flawless Maneuver: expect it in response to Ratchet.
Gwen chapter II: we discard if we can.
Gwen chapter III: target only P2's graveyard.

HOLD: Kaya's Ghostform stays on Muldrotha. No other mana to hold; removal comes first.

REPLAN IF:
- Maneuver saves their board.
- Farewell exiles our graveyard.
- P2 gains a lot of life.
- An Angel gets the enlightened counter.
- We fall below 15.
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Secrets of the Dead (from Hand): Secrets of the Dead [Forge's heuristic AI would not ] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN1): chose [play land Polluted Delta (from Graveyard): Play land by Muldrotha, the Gravetide (403) (La] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (attack, COMBAT_DECLARE_ATTACKERS): chose [attack P2 (21 life)] instead of Forge's [don't attack with it]
PILOT OVERRULED FORGE (attack, COMBAT_DECLARE_ATTACKERS): chose [attack P2 (21 life)] instead of Forge's [don't attack with it]
- US cast Secrets of the Dead
- left battlefield: Polluted Delta was put into Graveyard from Battlefield.
- US activated Polluted Delta
- attack: US assigned Vrock and Muldrotha, the Gravetide to attack P2.
- attack: P2 assigned Angel of Destiny to block Vrock.
- left battlefield: Vrock was put into Graveyard from Battlefield.
- left battlefield: Muldrotha, the Gravetide was put into Graveyard from Battlefield.
- left battlefield: Kaya's Ghostform was put into Graveyard from Battlefield.
- US triggered Kaya's Ghostform

## Turn 50 (P2, round 13) | life: P1 0, P2 32, P3 -19, US -16
- P2 cast Firemane Commando
- P2 triggered Giada, Font of Hope
- P2 triggered Oketra's Monument
- attack: P2 assigned Herald of War, Angel Token, Angel Token, Angel of Destiny, Resplendent Angel, Giada, Font of Hope and Warrior Token to attack US.
- P2 triggered Firemane Commando
- P2 triggered Herald of War
- P2 activated Resplendent Angel
- P2 triggered Angel of Destiny
- Game Outcome: P1 has lost because life total reached 0
- Game Outcome: P2 has won because all opponents have lost
- Game Outcome: P3 has lost because life total reached 0
- Game Outcome: US has lost because life total reached 0
Damage to US this turn: Angel of Destiny (combat) 10, Herald of War (combat) 9, Angel Token (combat) 16, Resplendent Angel (combat) 6, Giada, Font of Hope (combat) 2, Warrior Token (combat) 1