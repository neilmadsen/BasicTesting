# pod01-g1: we are P4; opponents P1 Sauron, the Dark Lord, P2 Sephiroth, Fabled SOLDIER, P3 Y'shtola, Night's Blessed
Result: Turn 22; P1 has lost because life total reached 0; P2 has won because all opponents have lost; P3 has lost because life total reached 0; US has lost because life total reached 0

## Turn 1 (OUR TURN, round 1)
Our hand: The Coming of Galactus, Wayfarer's Bauble, Seal of Primordium, Spore Frog, Doc Aurlock, Grizzled Genius, Underground Sea, Overgrown Tomb, Kaya's Ghostform
Our graveyard (0): 
Board P1: 0 lands; no nonland permanents
Board P2: 0 lands; no nonland permanents
Board P3: 0 lands; no nonland permanents
Board US: 0 lands; no nonland permanents
MEMO (start of our turn):
THIS TURN: Play Underground Sea, then cast Wayfarer's Bauble (1). Nothing else happens this turn. Next turn, play Overgrown Tomb untapped (pay 2 life). Tap Sea and Tomb and crack Bauble for a basic Swamp, which enters tapped. Turn 3: cast Doc Aurlock (GU) and Spore Frog (G), or Seal of Primordium if a target exists.

TARGET: Muldrotha cast on turn 5–6, with Doc Aurlock out so graveyard casts cost 2 less. Galactus, Seal and Bauble loop through their lanes. Missing pieces to draw or tutor: Executioner's Capsule, Sol Ring or Arcane Signet, and more lands (we hold only 2).

WIN PATH: The Coming of Galactus is our clock. Cast it, let it resolve and sacrifice itself, then recast it via Muldrotha: each cycle kills a permanent, drains 4 per opponent, and makes a 16/16 flier. We close around turn 10–12. Sephiroth (combo turns 5–7) and Sauron (turns 6–8) are faster, so spend removal on them first.

THREATS & ANSWERS: 1) Sephiroth, P2: Galactus chapter I kills it before it gets 4 deaths in a turn. Seal of Primordium hits Ashnod's Altar or Grave Pact. 2) Sauron, P1: target him with Galactus chapter I and pay the ward by sacrificing Doc Aurlock, a legendary creature. Seal hits Call of the Ring. Spore Frog fogs the Army attacks. 3) Y'shtola, P3: slow, handle later. Don't cast many small spells into Sauron. Don't chump-block while Sephiroth is out.

HOLD: Kaya's Ghostform goes only on Muldrotha. Seal of Primordium waits for a real Altar, Pact, Call, Propaganda, Skullclamp or Bitterblossom. Seal cannot hit The One Ring, which is indestructible.

REPLAN IF: A fast Sol Ring, Altar or Skullclamp appears. We draw no land by turn 3. Anyone casts an early Grave Pact or Pitiless Plunderer.
- US cast Wayfarer's Bauble

## Turn 2 (P1, round 1)

## Turn 3 (P2, round 1)
- P2 cast Skullclamp

## Turn 4 (P3, round 1)

## Turn 5 (OUR TURN, round 2)
Our hand: The Coming of Galactus, Seal of Primordium, Spore Frog, Doc Aurlock, Grizzled Genius, Overgrown Tomb, Kaya's Ghostform, Grist, the Hunger Tide
Our graveyard (0): 
Board P1: 1 lands; no nonland permanents
Board P2: 1 lands; Skullclamp
Board P3: 1 lands; no nonland permanents
Board US: 1 lands; Wayfarer's Bauble
MEMO (start of our turn):
THIS TURN: Play Overgrown Tomb untapped and pay 2 life. Tap Underground Sea and Tomb for {2}, then tap and sacrifice Wayfarer's Bauble to fetch a basic Forest, which enters tapped. That is all our mana. Cast nothing else and pass. We have no instant-speed plays.

TARGET: Next turn we have 3 mana (Sea, Tomb, Forest). Cast Grist ({1}{B}{G}) and use +1 for an Insect. If we draw a land, also cast Spore Frog. The turn after, cast Doc Aurlock ({G}{U}) and Seal of Primordium ({1}{G}). Then cast The Coming of Galactus, then Muldrotha around turn 5–6 of ours. Missing pieces: lands, Sol Ring or Arcane Signet, and Executioner's Capsule.

WIN PATH: Galactus loops through Muldrotha. Each cycle kills a permanent, drains 4 per opponent and makes a 16/16 flier. Grist's −5 adds reach. We close around our turns 10–12. P2 can combo on turns 5–7 and P1 attacks on turns 6–8, so remove their threats first.

THREATS & ANSWERS: 1) P2 Sephiroth and Skullclamp. Save Grist's −2 or Galactus chapter I for Sephiroth. Seal of Primordium takes Skullclamp once P2 has fodder, or a better target: Ashnod's Altar or Grave Pact. 2) P1 Sauron. Galactus chapter I kills him; pay the ward by sacrificing Doc Aurlock or Grist in creature form. Seal answers Call of the Ring. 3) P3 Y'shtola: deal with her later. Don't chump-block while Sephiroth is out.

HOLD: Kaya's Ghostform goes only on Muldrotha. Spore Frog is for real Army attacks.

REPLAN IF: A fast Sol Ring or Altar appears, Pitiless Plunderer or Grave Pact lands, or Sauron is cast early.

## Turn 6 (P1, round 2)

## Turn 7 (P2, round 2)

## Turn 8 (P3, round 2)

## Turn 9 (OUR TURN, round 3)
Our hand: The Coming of Galactus, Seal of Primordium, Spore Frog, Doc Aurlock, Grizzled Genius, Kaya's Ghostform, Grist, the Hunger Tide
Our graveyard (0): 
Board P1: 2 lands; no nonland permanents
Board P2: 2 lands; Skullclamp
Board P3: 2 lands; no nonland permanents
Board US: 2 lands; Wayfarer's Bauble
MEMO (start of our turn):
THIS TURN: Hold everything (no targets anywhere). If you draw a land, play it first. Tap Underground Sea plus the new land (or Tomb if no land drawn) for {2}, then tap and sacrifice Wayfarer's Bauble to fetch a basic Forest, which enters tapped. If a green source is still untapped (Tomb), cast Spore Frog ({G}). Otherwise pass. No instant-speed plays.

TARGET: Hit a land every turn, since our hand has none. Next turn (3–4 lands): cast Grist ({1}{B}{G}) and +1, and add Spore Frog if we have 4. Then cast Doc Aurlock and Seal of Primordium, then The Coming of Galactus ({2}{B}{B}{G}: Sea and Tomb make BB, Forest makes G). Then Muldrotha at 6 lands. Missing: lands, Sol Ring, Arcane Signet, Executioner's Capsule.

WIN PATH: Loop Galactus via Muldrotha: kill a permanent, drain 4 per opponent, make a 16/16 flier. Grist −5 adds reach. Aim to close in 10–12 of our turns. P2 can combo around their turns 5–7; P1 is the next fastest.

THREATS & ANSWERS: 1) P2 Sephiroth and Skullclamp: Grist −2 or Galactus chapter I on Sephiroth. Seal takes Skullclamp once P2 has fodder, or Ashnod's Altar or Grave Pact first. 2) P1 Sauron: Galactus chapter I, paying ward with Doc or Grist-as-creature. Seal hits Call of the Ring. 3) P3 Y'shtola: later. No chump blocks while Sephiroth lives.

HOLD: Seal of Primordium until a real target appears. Kaya's Ghostform only on Muldrotha. Spore Frog's sacrifice only for a real Army or big attack.

REPLAN IF: Any opponent casts their commander, Sol Ring or Altar appears, Pitiless Plunderer or Grave Pact lands, or we miss land drops two turns running (then cast Doc and Seal instead).
PILOT OVERRULED FORGE (search, UPKEEP): chose [Forest — Basic Land - Forest — ({T}: Add {G}.)] instead of Forge's [Island — Basic Land - Island — ({T}: Add {U}.)]
- left battlefield: Wayfarer's Bauble was put into Graveyard from Battlefield.
- US activated Wayfarer's Bauble

## Turn 10 (P1, round 3)
- P1 cast Orcish Siegemaster

## Turn 11 (P2, round 3)
- P2 cast Warren Soultrader
- left battlefield: Warren Soultrader was put into Graveyard from Battlefield.
- P2 cast Flare of Malice
- left battlefield: Orcish Siegemaster was put into Graveyard from Battlefield.

## Turn 12 (P3, round 3)
- P3 cast Talisman of Progress

## Turn 13 (OUR TURN, round 4)
Our hand: The Coming of Galactus, Seal of Primordium, Spore Frog, Doc Aurlock, Grizzled Genius, Kaya's Ghostform, Grist, the Hunger Tide, Baleful Strix, Arcane Signet
Our graveyard (1): Wayfarer's Bauble
Board P1: 3 lands; no nonland permanents
Board P2: 3 lands; Skullclamp
Board P3: 3 lands; Talisman of Progress
Board US: 3 lands; no nonland permanents
MEMO (start of our turn):
THIS TURN: 1) If you drew a land, play it. 2) Tap Overgrown Tomb and Forest to cast Arcane Signet ({2}). 3) Tap Underground Sea for {U} and Signet for {B} to cast Baleful Strix and draw a card. 4) If Strix draws a land and no land has been played yet, play it. If that land is untapped and makes G, cast Spore Frog. 5) Pass with 7 cards in hand. There are no instant-speed plays on opponents' turns.

TARGET: Next turn we have 5 mana (4 lands plus Signet). Cast The Coming of Galactus if a real permanent is worth chapter I; otherwise cast Grist (+1) and Doc Aurlock. The turn after, cast Muldrotha (6 mana) with Kaya's Ghostform on it. Missing pieces: lands, Executioner's Capsule, Sol Ring.

WIN PATH: Galactus drains 2 per opponent twice, then makes a 16/16 flier; Muldrotha recasts it. Grist −5 adds reach. Aim to close about 5 of our turns from now. P2's combo is the fastest clock but hasn't started.

THREATS & ANSWERS: 1) P2 Sephiroth, Skullclamp, Altar or Grave Pact: Galactus chapter I or Grist −2 for Sephiroth; Seal of Primordium for Altar, Pact, or Skullclamp once they have fodder. 2) P1 Sauron: Galactus chapter I, paying ward with Doc. Seal for Call of the Ring. 3) P3 Y'shtola: later. Don't chump-block while Sephiroth is out.

HOLD: Seal until a real target lands. Kaya's Ghostform only for Muldrotha. Spore Frog's sacrifice only against a real attack. Don't cast Grist and Galactus in the same turn, because of wipes.

REPLAN IF: A commander, Altar, Plunderer, Grave Pact or Call of the Ring appears; Strix gets countered; or we miss our land drop again (then cast Grist next turn).
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Baleful Strix (from Hand): Baleful Strix - Creature 1 / 1 [Forge's heuristic AI would] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
- US cast Baleful Strix
- US triggered Baleful Strix
- US cast Spore Frog

## Turn 14 (P1, round 4)
- P1 cast Nazgûl
- P1 triggered Nazgûl
- P1 triggered Nazgûl

## Turn 15 (P2, round 4)
- P2 cast Sephiroth, Fabled SOLDIER
- P2 triggered Sephiroth, Fabled SOLDIER
- P2 activated Skullclamp targeting [Sephiroth, Fabled SOLDIER]

## Turn 16 (P3, round 4) | life: P3 37
- P3 cast Fell the Profane targeting [Sephiroth, Fabled SOLDIER]
- left battlefield: Sephiroth, Fabled SOLDIER was put into Graveyard from Battlefield.
- P2 triggered Skullclamp

## Turn 17 (OUR TURN, round 5) | life: P3 37, US 39
Our hand: The Coming of Galactus, Seal of Primordium, Doc Aurlock, Grizzled Genius, Kaya's Ghostform, Grist, the Hunger Tide, Arcane Signet, Shriekmaw, Waterlogged Grove
Our graveyard (1): Wayfarer's Bauble
Board P1: 4 lands; Nazgûl 2/3 {[P1P1]}
Board P2: 4 lands; Skullclamp
Board P3: 4 lands; Talisman of Progress (tapped 1)
Board US: 3 lands; Baleful Strix 1/1, Spore Frog 1/1
MEMO (start of our turn):
THIS TURN: 1) Play Waterlogged Grove. 2) Tap Overgrown Tomb and Forest to cast Arcane Signet. 3) Tap Signet for B, Grove for G (pay 1 life) and Underground Sea for the generic to cast Grist, the Hunger Tide. Use +1 (Insect token, mill). This is a safe window: P2 is tapped out and P3 has at most 1 mana. 4) Pass with Galactus, Seal, Doc, Ghostform and Shriekmaw in hand. On opponents' turns, block Nazgûl with Strix if it attacks Grist. Sacrifice Spore Frog only to stop a real attack.

TARGET: Next turn, with a land drop we have 6 mana, so cast Muldrotha. Without one we have 5, so cast The Coming of Galactus. Then add Doc Aurlock and Ghostform on Muldrotha. Missing pieces: lands, Executioner's Capsule, Sol Ring, Gray Merchant.

WIN PATH: Galactus drains 2 per opponent twice, then brings a 16/16 flier. Grist −5 and Muldrotha recasting Galactus close the game. P2's combo is the fastest clock, and it is due now.

THREATS & ANSWERS: 1) P2 recasting Sephiroth (5 mana with tax): on our turn, Grist −2, sacrificing the Insect token. Galactus chapter I is the backup. 2) P2 Skullclamp: Seal of Primordium once P2 has fodder, or earlier if Seal is cast. Seal also answers Ashnod's Altar and Grave Pact. 3) P1 Sauron: Galactus chapter I. Shriekmaw can't hit Nazgûl or Sauron (both black). 4) P3: later. Don't chump-block while Sephiroth is out.

HOLD: Seal until a real target appears (Skullclamp with fodder, Altar, Pact). Kaya's Ghostform only for Muldrotha. Shriekmaw for a nonblack creature.

REPLAN IF: Sephiroth, Sauron or Y'shtola resolves, Grist is killed or countered, or a wipe hits.
PILOT OVERRULED FORGE (attack, COMBAT_DECLARE_ATTACKERS): chose [don't attack with it] instead of Forge's [attack P1 (40 life)]
- US cast Kaya's Ghostform targeting [Baleful Strix]
- US cast Grist, the Hunger Tide
- US activated Grist, the Hunger Tide

## Turn 18 (P1, round 5)
- P1 cast March from the Black Gate
- P1 triggered March from the Black Gate

## Turn 19 (P2, round 5) | life: P2 37, P3 37, US 39
PILOT OVERRULED FORGE (sacrifice, MAIN2): chose [Insect Token [ours, 1/1, token]] instead of Forge's [Baleful Strix [ours, 1/1]]
- P2 cast Reanimate targeting [Warren Soultrader]
- P2 activated Skullclamp targeting [Warren Soultrader]
- P2 cast Demon's Disciple
- P2 triggered Demon's Disciple
- left battlefield: Demon's Disciple was put into Graveyard from Battlefield.

## Turn 20 (P3, round 5)
- P3 cast Vindicate targeting [Grist, the Hunger Tide]
- left battlefield: Grist, the Hunger Tide was put into Graveyard from Battlefield.
- P3 cast Talisman of Hierarchy

## Turn 21 (OUR TURN, round 6) | life: P2 37, P3 37, US 38
Our hand: The Coming of Galactus, Seal of Primordium, Doc Aurlock, Grizzled Genius, Arcane Signet, Shriekmaw, Woodland Cemetery
Our graveyard (3): Wayfarer's Bauble, Verdant Catacombs, Grist, the Hunger Tide
Board P1: 5 lands; Nazgûl 2/3 {[P1P1]}, March from the Black Gate
Board P2: 5 lands; Skullclamp, Warren Soultrader 4/2
Board P3: 5 lands; Talisman of Progress (tapped 1), Talisman of Hierarchy
Board US: 4 lands; Baleful Strix 1/1, Spore Frog 1/1, Kaya's Ghostform
MEMO (start of our turn):
THIS TURN: 1) Play Woodland Cemetery (it enters untapped). 2) Tap Forest and Cemetery to cast Arcane Signet. 3) Tap Signet for U and Overgrown Tomb for G to cast Doc Aurlock. 4) Tap Waterlogged Grove for G (pay 1 life) and Underground Sea to cast Seal of Primordium. Leave the Seal on the battlefield. Destroy Skullclamp in response to its next equip, to an Ashnod's Altar or Grave Pact, or at the end of P3's turn at the latest, so Muldrotha can recast it.

TARGET: Next turn, play Verdant Catacombs from the graveyard (land lane) and fetch. That gives 7 mana: Muldrotha (6), Seal from the graveyard ({G} with Doc), Wayfarer's Bauble from the graveyard (free). The turn after, cast Grist from the graveyard for {B}{G}, then The Coming of Galactus. Tutor targets: Gray Merchant, Executioner's Capsule, Sol Ring.

WIN PATH: Galactus drains 2 per opponent twice, then brings a 16/16 flier. After that, Muldrotha recurs Grist, Gray Merchant and Galactus. We close in roughly 4 turns. P2's Sephiroth drain loop is the fastest clock.

THREATS & ANSWERS:
1) P2 recasting Sephiroth (5 mana, Nykthos is up): Galactus chapter I, or Grist −2 once recurred. Don't chump-block or sacrifice creatures while Sephiroth is out.
2) P2 Skullclamp and Soultrader: the Seal takes Skullclamp.
3) P1 Sauron (6 mana): Galactus chapter I, paying the ward by sacrificing Doc (a legendary creature); or Plaguecrafter.
Shriekmaw has no legal target now; everything the opponents have is black.

HOLD: Galactus. Don't cast it into P1's 3 open and P3's 2 open counter mana. Hold Shriekmaw for a nonblack creature.

REPLAN IF: Sephiroth or Sauron resolves, Doc or the Seal is countered or killed, a wipe hits, or P2 finds a Pitiless Plunderer or Altar loop.
PILOT OVERRULED FORGE (attack, COMBAT_DECLARE_ATTACKERS): chose [don't attack with it] instead of Forge's [attack P2 (37 life)]
- US cast The Coming of Galactus
- US triggered The Coming of Galactus targeting [Warren Soultrader]
- left battlefield: Warren Soultrader was put into Graveyard from Battlefield.
- P2 triggered Skullclamp

## Turn 22 (P1, round 6)
- P1 cast Sauron, the Dark Lord

## Turn 23 (P2, round 6)
- P2 cast Zodiark, Umbral God
- P1 triggered Sauron, the Dark Lord
- P2 triggered Zodiark, Umbral God
- left battlefield: Spore Frog was put into Graveyard from Battlefield.
- P2 triggered Zodiark, Umbral God
- P2 triggered Zodiark, Umbral God
- P2 activated Skullclamp targeting [Zodiark, Umbral God]

## Turn 24 (P3, round 6) | life: P2 37, P3 35, US 38
- P3 cast Y'shtola, Night's Blessed
- P3 triggered Path of Ancestry
- P1 triggered Sauron, the Dark Lord
- P3 cast Papalymo Totolymo
- P1 triggered Sauron, the Dark Lord

## Turn 25 (OUR TURN, round 7) | life: P1 38, P2 35, P3 33, US 38
Our hand: Seal of Primordium, Doc Aurlock, Grizzled Genius, Arcane Signet, Shriekmaw, Executioner's Capsule
Our graveyard (4): Wayfarer's Bauble, Verdant Catacombs, Grist, the Hunger Tide, Spore Frog
Board P1: 6 lands; Nazgûl 2/3 {[P1P1]}, March from the Black Gate, Sauron, the Dark Lord 7/6, Orc Army Token 2/2 [token] {[P1P1 x 2]}
Board P2: 6 lands; Skullclamp, Zodiark, Umbral God 8/6 {[P1P1 x 2]}
Board P3: 5 lands; Talisman of Progress (tapped 1), Talisman of Hierarchy (tapped 1), Y'shtola, Night's Blessed 2/4, Papalymo Totolymo 1/2
Board US: 5 lands; Baleful Strix 1/1, Kaya's Ghostform, The Coming of Galactus {[LORE x 2]}
MEMO (start of our turn):
THIS TURN: Every opponent is tapped out, so this is the safe window. 1) Tap Forest and Woodland Cemetery to cast Arcane Signet. 2) Tap Signet for U and Overgrown Tomb for G to cast Doc Aurlock. 3) Tap Waterlogged Grove for G (pay 1 life) and Underground Sea to cast Seal of Primordium. Sacrifice it at once to destroy P2's Skullclamp, so the Seal is in the graveyard for recasting next turn. On opponents' turns, Baleful Strix blocks Sauron if he attacks us; deathtouch kills him. Never chump-block Zodiark.

TARGET: Next turn: Muldrotha (5 lands + Signet = 6). Play Verdant Catacombs from the graveyard and fetch Bayou (untapped). Cast Wayfarer's Bauble from the graveyard (free with Doc). Recast the Seal for {G} with Bayou's mana. The turn after: Grist for {B}{G}, and Galactus becomes a 16/16. Tutor targets: Plaguecrafter, Toxic Deluge, Invasion of Innistrad, Gray Merchant.

WIN PATH: Chapter III drains each opponent 2 next turn. Galactus (16/16 flying, trample) swings from the turn after. Aim its land-destroy trigger at our own Verdant Catacombs or Waterlogged Grove, then replay the land. Close in about 4-5 turns, before P2's Sephiroth loop.

THREATS & ANSWERS:
1) P2 Zodiark (indestructible, only creature): Plaguecrafter edict, Toxic Deluge or Invasion's -13/-13. No destroy effects.
2) P1 Sauron: Grist -2, paying ward by sacrificing Doc; or a Strix block.
3) Sephiroth recast, Altar or Plunderer: Seal or Grist.
4) P3 Y'shtola: Grist -2 later.
Every spell we cast grows P1's Army, so cast only what advances the plan.

HOLD: Executioner's Capsule and Shriekmaw. Every opposing creature is black, so they have no targets. Keep Strix home as the anti-Sauron blocker.

REPLAN IF: Doc or Signet dies, a wipe hits, Galactus is removed, Sephiroth returns, or a nonblack creature appears (Capsule or Shriekmaw target).
PILOT OVERRULED FORGE (attack, COMBAT_DECLARE_ATTACKERS): chose [don't attack with it] instead of Forge's [attack P1 (38 life)]
PILOT OVERRULED FORGE (action, MAIN2): chose [cast Arcane Signet (from Hand): Arcane Signet] instead of Forge's [cast Doc Aurlock, Grizzled Genius (from Hand): Doc Aurlock, Grizzled Genius - Creature 2 /]
PILOT OVERRULED FORGE (action, MAIN2): chose [cast Seal of Primordium (from Hand): Seal of Primordium] instead of Forge's [cast Doc Aurlock, Grizzled Genius (from Hand): Doc Aurlock, Grizzled Genius - Creature 2 /]
PILOT OVERRULED FORGE (action, MAIN2): chose [Skullclamp [P2]] instead of Forge's [March from the Black Gate [P1]]
- US triggered The Coming of Galactus
- US cast Executioner's Capsule
- P1 triggered Sauron, the Dark Lord
- US cast Arcane Signet
- P1 triggered Sauron, the Dark Lord
- US cast Seal of Primordium
- P1 triggered Sauron, the Dark Lord
- left battlefield: Seal of Primordium was put into Graveyard from Battlefield.
- US activated Seal of Primordium targeting [Skullclamp]
- left battlefield: Skullclamp was put into Graveyard from Battlefield.

## Turn 26 (P1, round 7) | life: P1 38, P2 35, P3 18, US 38
- attack: P1 assigned Sauron, the Dark Lord, Orc Army Token and Nazgûl to attack P3.
- P1 triggered March from the Black Gate
- P1 triggered Sauron, the Dark Lord
- P1 triggered Sauron, the Dark Lord
- P1 triggered Nazgûl
- P1 cast The Mouth of Sauron
- P1 triggered The Mouth of Sauron targeting [P2]
- P3 triggered Y'shtola, Night's Blessed

## Turn 27 (P2, round 7) | life: P1 31, P2 35, P3 18, US 38
- attack: P2 assigned Zodiark, Umbral God to attack P1.
- P2 cast Sephiroth, Fabled SOLDIER
- P1 triggered Sauron, the Dark Lord
- P2 triggered Sephiroth, Fabled SOLDIER
- P2 cast Jadar, Ghoulcaller of Nephalia
- P1 triggered Sauron, the Dark Lord
- P2 triggered Jadar, Ghoulcaller of Nephalia
- P3 triggered Y'shtola, Night's Blessed

## Turn 28 (P3, round 7) | life: P1 31, P2 36, P3 17, US 38
- left battlefield: Papalymo Totolymo was put into Graveyard from Battlefield.
- P3 activated Papalymo Totolymo
- P2 triggered Sephiroth, Fabled SOLDIER targeting [P3]
- P2 triggered Zodiark, Umbral God

## Turn 29 (OUR TURN, round 8) | life: P1 29, P2 34, P3 15, US 36
Our hand: Doc Aurlock, Grizzled Genius, Shriekmaw, Walking Ballista
Our graveyard (5): Wayfarer's Bauble, Verdant Catacombs, Grist, the Hunger Tide, Spore Frog, Seal of Primordium
Board P1: 7 lands; Nazgûl 3/4 {[P1P1 x 2]} (tapped 1), March from the Black Gate, Sauron, the Dark Lord 7/6 (tapped 1), Orc Army Token 10/10 [token] {[P1P1 x 10]} (tapped 1), The Mouth of Sauron 3/4
Board P2: 7 lands; Zodiark, Umbral God 8/8 {[P1P1 x 3]} (tapped 1), Sephiroth, Fabled SOLDIER 3/3, Jadar, Ghoulcaller of Nephalia 1/1, Zombie Token 2/2 [token]
Board P3: 5 lands; Talisman of Progress, Talisman of Hierarchy, Y'shtola, Night's Blessed 2/4
Board US: 5 lands; Baleful Strix 1/1, Kaya's Ghostform, The Coming of Galactus {[LORE x 3]}, Executioner's Capsule, Arcane Signet
MEMO (start of our turn):
THIS TURN: 1) Tap all six sources (5 lands + Signet) to cast Muldrotha. If commander tax makes her cost more than 6, cast Doc ({G}{U}) instead and hold the rest. 2) Play Verdant Catacombs from the graveyard as our land drop. Crack it (pay 1 life) for Bayou, untapped. 3) With Bayou's G, cast Spore Frog from the graveyard (creature lane). On opponents' turns, sacrifice Frog if P1 swings the Army at us. Otherwise Baleful Strix blocks the Orc Army: deathtouch kills it, and Ghostform returns Strix. Never block Zodiark.

TARGET: Next turn Galactus IV makes the 16/16 flier. Cast Doc (2), then use the discounted graveyard lanes: Grist for {B}{G}, Seal for {G}, Wayfarer's Bauble free, Frog again. Tutor targets: Toxic Deluge, Plaguecrafter, Gray Merchant.

WIN PATH: Galactus swings the turn after it appears. Hit P3 (15) first for a kill, then P1. Aim the land-destroy trigger at our own Waterlogged Grove (sacrifice it to draw in response) and replay it from the graveyard. Walking Ballista adds reach. Close in about 3-4 turns.

THREATS & ANSWERS:
1) P1's growing 10/10 Army and Sauron: Frog, Strix block, Grist -2 on the Army (no ward).
2) P2's Sephiroth: Grist -2 next turn, sacrificing Frog.
3) Zodiark (indestructible): Toxic Deluge or Plaguecrafter only.
4) Y'shtola: Grist later.
Every spell grows P1's Army, so cast nothing extra.

HOLD: Shriekmaw and Executioner's Capsule, since every opposing creature is black. Doc waits for next turn's discounted casts. Keep Ballista as a mana sink for finishing damage and pings.

REPLAN IF: Muldrotha is countered or removed, Galactus is destroyed before IV, a wipe hits, Sephiroth gets Ashnod's Altar or Pitiless Plunderer (Seal first), or a nonblack creature appears.
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Muldrotha, the Gravetide (from Command): Muldrotha, the Gravetide - Creature 6 / 6 [F] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN1): chose [play land Verdant Catacombs (from Graveyard): Play land by Muldrotha, the Gravetide (403) ] instead of Forge's [play land Verdant Catacombs (from Graveyard): Play land by Muldrotha, the Gravetide (403) ]
PILOT OVERRULED FORGE (search, MAIN1): chose [Bayou — Land - Swamp Forest — ({T}: Add {B} or {G}.)] instead of Forge's [Zagoth Triome — Land - Swamp Forest Island — ({T}: Add {B}, {G}, or {U}.) Zagoth Triome en]
PILOT OVERRULED FORGE (attack, COMBAT_DECLARE_ATTACKERS): chose [don't attack with it] instead of Forge's [attack P1 (29 life)]
- US triggered The Coming of Galactus
- US cast Muldrotha, the Gravetide
- P1 triggered Sauron, the Dark Lord
- left battlefield: Verdant Catacombs was put into Graveyard from Battlefield.
- US activated Verdant Catacombs
- US cast Spore Frog
- P1 triggered Sauron, the Dark Lord

## Turn 30 (P1, round 8) | life: P1 29, P2 39, P3 10, US 33
PILOT OVERRULED FORGE (block, COMBAT_DECLARE_BLOCKERS): chose [block with Spore Frog 1/1] instead of Forge's [k-1]
PILOT OVERRULED FORGE (block, COMBAT_DECLARE_BLOCKERS): chose [block with Muldrotha, the Gravetide 6/6] instead of Forge's [no block (take the damage)]
PILOT OVERRULED FORGE (block, COMBAT_DECLARE_BLOCKERS): chose [block with Spore Frog 1/1] instead of Forge's [no block (take the damage)]
- attack: P1 assigned Orc Army Token, Sauron, the Dark Lord and Nazgûl to attack US.
- P1 triggered March from the Black Gate
- P1 triggered The Ring
- attack: US assigned Baleful Strix and Spore Frog to block Orc Army Token.
- left battlefield: Sauron, the Dark Lord was put into Graveyard from Battlefield.
- left battlefield: Baleful Strix was put into Graveyard from Battlefield.
- left battlefield: Muldrotha, the Gravetide was put into Graveyard from Battlefield.
- left battlefield: Spore Frog was put into Graveyard from Battlefield.
- left battlefield: Kaya's Ghostform was put into Graveyard from Battlefield.
- P2 triggered Sephiroth, Fabled SOLDIER targeting [P3]
- P2 triggered Sephiroth, Fabled SOLDIER targeting [P3]
- P2 triggered Sephiroth, Fabled SOLDIER targeting [P3]
- P2 triggered Sephiroth, Fabled SOLDIER targeting [P3]
- P2 triggered Sephiroth, Fabled SOLDIER targeting [P3]
- US triggered Kaya's Ghostform
- US triggered Baleful Strix
- P1 cast Nazgûl
- P1 triggered Nazgûl
- P1 triggered Nazgûl
- P1 triggered Nazgûl
- P3 triggered Y'shtola, Night's Blessed
Damage to US this turn: Nazgûl (combat) 3

## Turn 31 (P2, round 8) | life: P1 16, P2 39, P3 10, US 33
- attack: P2 assigned Sephiroth, One-Winged Angel and Zodiark, Umbral God to attack P1.
- P2 triggered Sephiroth, One-Winged Angel
- P2 cast Pitiless Plunderer
- P1 cast Counterspell targeting [Pitiless Plunderer - Creature 1 / 4]
- P2 cast Bitterblossom
- P3 triggered Y'shtola, Night's Blessed

## Turn 32 (P3, round 8) | life: P1 14, P2 35, P3 11, US 31
- left battlefield: Polluted Delta was put into Graveyard from Battlefield.
- P3 activated Polluted Delta
- P3 cast Irenicus's Vile Duplication targeting [Y'shtola, Night's Blessed]
- P3 triggered Y'shtola, Night's Blessed
- attack: P3 assigned Y'shtola, Night's Blessed to attack P2.
- P3 triggered Y'shtola, Night's Blessed
- P3 triggered Y'shtola, Night's Blessed
Damage to US this turn: Y'shtola, Night's Blessed (non-combat) 2

## Turn 33 (OUR TURN, round 9) | life: P1 14, P2 35, P3 11, US 29
Our hand: Doc Aurlock, Grizzled Genius, Shriekmaw, Walking Ballista, Eternal Witness, Bloodstained Mire
Our graveyard (7): Wayfarer's Bauble, Grist, the Hunger Tide, Seal of Primordium, Verdant Catacombs, Spore Frog, Kaya's Ghostform, The Coming of Galactus
Board P1: 7 lands; Nazgûl 5/6 {[P1P1 x 4]} (tapped 1), March from the Black Gate, The Mouth of Sauron 3/4, Nazgûl 3/4 {[P1P1 x 2]}
Board P2: 8 lands; Zodiark, Umbral God 8/8 {[P1P1 x 3]} (tapped 1), Sephiroth, One-Winged Angel 5/5 (tapped 1), Jadar, Ghoulcaller of Nephalia 1/1, Zombie Token 2/2 [token], Bitterblossom
Board P3: 6 lands; Talisman of Progress, Talisman of Hierarchy, Y'shtola, Night's Blessed 2/4, Y'shtola, Night's Blessed 2/4 [token]
Board US: 6 lands; Executioner's Capsule, Arcane Signet, Baleful Strix 1/1, Galactus 16/16 [token]
MEMO (start of our turn):
THIS TURN: 1) Play Bloodstained Mire from hand and crack it (1 life) for a basic Swamp, untapped. That gives 8 mana. 2) Tap all 8 for Muldrotha (6 + tax 2). Nothing else this turn. Galactus was made this turn and can't attack. Strix stays home. Opponents' turns: Galactus blocks Zodiark (it survives). Strix (deathtouch) blocks Sephiroth or a Nazgûl. Never block a Nazgûl (deathtouch) with Galactus or Muldrotha.

TARGET: Next turn: play Verdant Catacombs from the graveyard and leave it uncracked. Cast Doc ({G}{U}). Then recast from the graveyard with Doc's discount: The Coming of Galactus (3) with chapter I on Sephiroth, Grist (1) with -2 sacrificing a Grist Insect on Nazgûl 5/6, and Spore Frog ({G}). Tutor targets: Toxic Deluge (for Zodiark), Gray Merchant, Demonic Tutor.

WIN PATH: Next turn Galactus (16 flying trample) swings at P3 (11), which is lethal. Aim its land-destroy trigger at the uncracked Catacombs and crack it in response. Then Galactus kills P1 (14). Recast saga chapters II and III drain 2 each. Walking Ballista adds reach. P2 (35) is last, in about 3 turns.

THREATS & ANSWERS: 1) P3: two Y'shtolas and 7 cards. Every 3+ MV noncreature spell hits us for 4. Galactus kills it. 2) P2: Sephiroth (emblem already made; every death drains us) and Zodiark (indestructible, answered only by Toxic Deluge or Plaguecrafter). 3) P1: Nazgûls. Answer with Grist and Strix blocks. Shriekmaw and Capsule have no targets, since every opposing creature is black.

HOLD: Shriekmaw, Ballista, Eternal Witness, Doc.

REPLAN IF: Galactus is removed (then recast the saga and lean on Ballista reach), Muldrotha dies (recast only with Ghostform backup), Sauron returns, or a nonblack creature appears.
PILOT OVERRULED FORGE (attack, COMBAT_DECLARE_ATTACKERS): chose [don't attack with it] instead of Forge's [attack P2 (35 life)]
PILOT OVERRULED FORGE (action, MAIN2): chose [cast Doc Aurlock, Grizzled Genius (from Hand): Doc Aurlock, Grizzled Genius - Creature 2 /] instead of Forge's [cast Walking Ballista (from Hand): Walking Ballista - Creature 0 / 0 (X=0)]
PILOT OVERRULED FORGE (action, MAIN2): chose [cast Eternal Witness (from Hand): Eternal Witness - Creature 2 / 1] instead of Forge's [cast Walking Ballista (from Hand): Walking Ballista - Creature 0 / 0 (X=0)]
PILOT OVERRULED FORGE (trigger-target, MAIN2): chose [Verdant Catacombs [ours, in graveyard]] instead of Forge's [Grist, the Hunger Tide [ours, 1/1, loyalty 0, in graveyard]]
- US triggered The Coming of Galactus
- left battlefield: The Coming of Galactus was put into Graveyard from Battlefield.
- left battlefield: Bloodstained Mire was put into Graveyard from Battlefield.
- US activated Bloodstained Mire
- US cast Doc Aurlock, Grizzled Genius
- US cast Eternal Witness
- US triggered Eternal Witness targeting [Verdant Catacombs]
- US cast Walking Ballista

## Turn 34 (P1, round 9)

## Turn 35 (P2, round 9) | life: P1 14, P2 34, P3 11, US 29
- P2 triggered Bitterblossom
- P2 cast Dreadhorde Invasion
- P1 activated Minas Morgul, Dark Fortress targeting [Nazgûl]

## Turn 36 (P3, round 9) | life: P1 10, P2 30, P3 15, US 25
- P3 cast Dancer's Chakrams
- P3 triggered Y'shtola, Night's Blessed
- P3 triggered Y'shtola, Night's Blessed
- P3 triggered Dancer's Chakrams
- P3 cast Vito, Thorn of the Dusk Rose
- P3 triggered Y'shtola, Night's Blessed
- P3 triggered Y'shtola, Night's Blessed
Damage to US this turn: Y'shtola, Night's Blessed (non-combat) 4

## Turn 37 (OUR TURN, round 10) | life: P1 10, P2 33, P3 0, US 24
Our hand: Shriekmaw, Verdant Catacombs
Our graveyard (7): Wayfarer's Bauble, Grist, the Hunger Tide, Seal of Primordium, Spore Frog, Kaya's Ghostform, The Coming of Galactus, Bloodstained Mire
Board P1: 7 lands; Nazgûl 5/6 {[P1P1 x 4, Shadow]}, March from the Black Gate, The Mouth of Sauron 3/4, Nazgûl 3/4 {[P1P1 x 2]}
Board P2: 9 lands; Zodiark, Umbral God 8/8 {[P1P1 x 3]}, Sephiroth, One-Winged Angel 5/5, Jadar, Ghoulcaller of Nephalia 1/1, Zombie Token 2/2 [token], Bitterblossom, Faerie Rogue Token 1/1 [token], Dreadhorde Invasion
Board P3: 7 lands; Talisman of Progress (tapped 1), Talisman of Hierarchy (tapped 1), Y'shtola, Night's Blessed 4/6, Y'shtola, Night's Blessed 2/4 [token], Dancer's Chakrams, Hero Token 3/3 [token], Vito, Thorn of the Dusk Rose 1/3
Board US: 7 lands; Executioner's Capsule, Arcane Signet, Baleful Strix 1/1, Galactus 16/16 [token], Doc Aurlock, Grizzled Genius 2/3, Eternal Witness 2/1, Walking Ballista 1/1 {[P1P1]}
MEMO (start of our turn):
THIS TURN: 1) Play Verdant Catacombs and don't crack it. 2) Attack P3 with Galactus only. They are at 15 with no flyers, so 16 flying trample is lethal. Aim the land-destroy trigger at Catacombs, then crack it in response for an untapped Forest. 3) If P3 survives at 1–2, finish them with Ballista pings. 4) Main 2: cast Muldrotha with 8 sources (6 + 2 tax), tapping Grove last. 5) Forest {G} casts Spore Frog from the graveyard; Wayfarer's Bauble is free with Doc. On opponents' turns: sacrifice Frog to Fog P2's attack. Strix blocks Sephiroth. Never block a Nazgûl with Muldrotha or Galactus.

TARGET: Muldrotha online with Doc recasting every turn: Grist (BG, -2 sacrificing Frog kills Sephiroth or the 5/6 shadow Nazgûl), Ghostform (B) on Muldrotha, Frog each turn. Tutor or dig for Toxic Deluge (it kills Zodiark), Gray Merchant and Demonic Tutor.

WIN PATH: P3 dies now. Next turn Galactus kills P1 (at 10, no flyers). P2 (30) falls in about 2 more Galactus swings plus a Coming of Galactus recast (BBG) and Ballista pings.

THREATS & ANSWERS: 1) P3: two Y'shtolas plus Vito drain up to ~8 per spell and could kill us on their turn. Galactus kills them now. 2) P2: Zodiark, flying Sephiroth, emblem. Frog Fog; Grist on Sephiroth; Deluge for Zodiark. 3) P1: unblockable shadow Nazgûl. Grist -2; Galactus kills P1 next turn.

HOLD: Shriekmaw (no nonblack targets), Ballista counter, Seal of Primordium in the graveyard for Call of the Ring.

REPLAN IF: Galactus is exiled or P3 survives. Then recast the saga, Ballista-ping, and keep the Frog up for P3's turn. Also replan if Muldrotha is countered or Sauron is recast.
MEMO (executor escalation: P3: life 15→2 (-13)):
THIS TURN: 1) Let the emblem trigger resolve, which puts P3 at 1. 2) Pay {4} with Signet plus non-Grove lands to put a counter on Walking Ballista (it goes to 2/2). Then remove one counter to ping P3 for 1. P3 is dead and Ballista stays 1/1. 3) Keep the last 2 mana; there is nothing to cast. Don't crack Waterlogged Grove, since we need all 8 sources for Muldrotha next turn. Blocks on opponents' turns (Galactus is tapped): Strix blocks Sephiroth (deathtouch kills it). Witness chumps Zodiark. Doc blocks only the Zombie token. Take the shadow Nazgûl's damage; don't chump P1 with Doc.

TARGET: Muldrotha plus Doc, recasting Spore Frog (G), Ghostform (B) on Muldrotha and Grist (BG) each turn. Library wants: Gray Merchant, Demonic Tutor, Massacre Wurm, Swan Song.

WIN PATH: Next turn, cast nothing before combat so Sauron gets no amass triggers. Galactus attacks P1 (10 life, no flyers), which is lethal. Point the land trigger at P1's land. Main 2: Muldrotha with exactly 8 sources, tapping Grove last. Play Forest from the graveyard, then cast Spore Frog with {G}; Bauble is free. After that, P2 (31) takes Galactus swings, Coming of Galactus recasts (BBG) and Ballista pings: about 3 turns.

THREATS & ANSWERS: 1) P2: Zodiark (indestructible) is answered by Toxic Deluge with X=8+ or chump blocks. Sephiroth is answered by Strix block or Grist -2. Every creature death drains us 1, so minimize deaths. 2) P1: shadow Nazgûl is answered by Grist -2; P1 dies to Galactus next turn.

HOLD: Shriekmaw: never cast it. Its ETB is mandatory and the only legal targets are our Doc or Witness. Hold Toxic Deluge; right now it drains us about 17 via the emblem.

REPLAN IF: Galactus is removed, we fall below 12, P2 adds flying chump blockers, Muldrotha is countered, or Sauron is recast.
PILOT OVERRULED FORGE (action, MAIN1): chose [play land Verdant Catacombs (from Hand): Play land] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (attack, COMBAT_DECLARE_ATTACKERS): chose [don't attack with it] instead of Forge's [attack P3 (14 life)]
PILOT OVERRULED FORGE (attack, COMBAT_DECLARE_ATTACKERS): chose [don't attack with it] instead of Forge's [attack P3 (14 life)]
PILOT OVERRULED FORGE (attack, COMBAT_DECLARE_ATTACKERS): chose [don't attack with it] instead of Forge's [attack P3 (14 life)]
PILOT OVERRULED FORGE (attack, COMBAT_DECLARE_ATTACKERS): chose [don't attack with it] instead of Forge's [attack P3 (14 life)]
PILOT OVERRULED FORGE (trigger-target, COMBAT_DECLARE_ATTACKERS): chose [Forest [ours, tapped]] instead of Forge's [Nykthos, Shrine to Nyx [P2, tapped]]
ESCALATION (p=0.7): P3: life 15→2 (-13)
- left battlefield: Executioner's Capsule was put into Graveyard from Battlefield.
- US activated Executioner's Capsule targeting [Hero Token]
- P2 triggered Emblem — Sephiroth, One-Winged Angel targeting [P3]
- left battlefield: Verdant Catacombs was put into Graveyard from Battlefield.
- US activated Verdant Catacombs
- attack: US assigned Galactus to attack P3.
- US triggered Galactus targeting [Forest]
- left battlefield: Forest was put into Graveyard from Battlefield.
- attack: P3 assigned Y'shtola, Night's Blessed to block Galactus.
- left battlefield: Y'shtola, Night's Blessed was put into Graveyard from Battlefield.
- P2 triggered Emblem — Sephiroth, One-Winged Angel targeting [P3]
- US activated Walking Ballista targeting [P3]
- left battlefield: Walking Ballista was put into Graveyard from Battlefield.
- P2 triggered Emblem — Sephiroth, One-Winged Angel targeting [P3]

## Turn 38 (P1, round 10) | life: P1 10, P2 37, P3 0, US 15
MEMO (executor escalation: we lost: Walking Ballista):
THIS TURN: No instant plays; our hand is Shriekmaw and a sorcery. Shadow Nazgûl can't be blocked, so take 5. If Mouth or the 3/4 Nazgûl also attack, don't block; save Strix and Doc for P2. P2's turn: Strix blocks Sephiroth (deathtouch). Witness chumps Zodiark. Doc blocks the Zombie token only. Take the Faerie and Jadar.

TARGET: Muldrotha plus Doc, recasting Spore Frog (G), Bauble (free) and Ghostform (B) each turn, then Grist and Coming of Galactus. Tutor wants: Gray Merchant, Swan Song, Demonic Tutor.

WIN PATH: Our turn: attack with Galactus alone first; P1 has 10 life and no flyers, so this is lethal. Point its mandatory land trigger at P1's land. Main 2: play Forest from the graveyard (9 sources). Muldrotha costs 8 with tax. Spore Frog {G} from the graveyard. Wayfarer's Bauble for 0. Then Galactus swings each turn at P2 (33); trample goes over chumps, backed by Coming of Galactus drains. About 3 turns.

THREATS & ANSWERS: 1) P2's emblem means every creature death drains us 1. Minimize deaths. Frog fogs Zodiark (indestructible) and Sephiroth's 5 in the air; Grist -2 kills Sephiroth later. 2) P1: dies to Galactus. If Galactus is removed, Grist -2 the shadow Nazgûl.

HOLD: Shriekmaw, never cast: all enemy creatures are black, so it would kill our own. Toxic Deluge: the emblem drains us about 15+. Keep the fetches in the graveyard for later land drops.

REPLAN IF: Galactus is removed or chumped by a new flyer, we drop below 10, Muldrotha is countered, Sauron is recast, or P2 goes wide with flyers.
ESCALATION (p=0.81): we lost: Walking Ballista
- attack: P1 assigned Nazgûl to attack US.
- P1 triggered The Ring
- P1 cast Too Greedily, Too Deep targeting [Pitiless Plunderer]
- left battlefield: Jadar, Ghoulcaller of Nephalia was put into Graveyard from Battlefield.
- left battlefield: Baleful Strix was put into Graveyard from Battlefield.
- left battlefield: Eternal Witness was put into Graveyard from Battlefield.
- P2 triggered Emblem — Sephiroth, One-Winged Angel targeting [P4]
- P2 triggered Emblem — Sephiroth, One-Winged Angel targeting [P4]
- P2 triggered Emblem — Sephiroth, One-Winged Angel targeting [P4]
- P2 triggered Emblem — Sephiroth, One-Winged Angel targeting [P4]
Damage to US this turn: Nazgûl (combat) 5

## Turn 39 (P2, round 10) | life: P1 10, P2 36, P3 0, US 9
MEMO (executor escalation: us: life 24→15 (-9); us: nonland permanents 5→3 (-2); we lost: Baleful Strix, Eternal Witness):
THIS TURN: P2's turn. We have no instant plays. Do NOT sacrifice Waterlogged Grove, because we need all 8 sources for Muldrotha. Galactus is tapped, so Doc is our only blocker. If Zodiark attacks us, Doc chumps Zodiark; Zodiark has no trample, and unblocked we'd take 15 (lethal). Otherwise Doc blocks the Zombie token. Sephiroth's 5 in the air goes unblocked.
Our turn: attack first with Galactus alone at P1. P1 has 10 life, is tapped out and has no flyers, so this is lethal. Point the land trigger at a P1 land. Then tap all 7 lands plus Signet to cast Muldrotha (8). Play Forest from the graveyard, then cast Spore Frog (G) and Wayfarer's Bauble (free).

TARGET: Muldrotha with Kaya's Ghostform (B), Doc, and Frog every turn. Coming of Galactus (BBG with Doc) chapter I destroys Sephiroth. Then Grist and Ballista. Wants: Gray Merchant (drain plus lifegain), Heroic Intervention, Syr Konrad.

WIN PATH: With P1 dead, Galactus hits P2 (37) for 16 each turn, trampling over chumps. Coming adds 4 drain. About 3 turns. P2 grinds us with drains, so stabilize before racing.

THREATS & ANSWERS: 1) Once P1 is dead, P2's emblem drains only us, 1 per creature death, theirs included. Minimize deaths. Frog fogs their combat. Coming chapter I kills Sephiroth to end the attack-sacrifices. 2) Zodiark is indestructible: Frog or chump it.

HOLD: Never cast Shriekmaw; its ETB would be forced onto Doc or Frog. Never cast Toxic Deluge; the drains are lethal. Keep the fetches in the graveyard for later land drops.

REPLAN IF: P1 is already dead before our turn: keep Galactus home as a blocker and still cast Muldrotha, Forest, Frog. Also replan if we're at 5 or less, Doc or Galactus is removed, or Sephiroth leaves.
ESCALATION (p=0.88): us: life 24→15 (-9); us: nonland permanents 5→3 (-2); we lost: Baleful Strix, Eternal Witness
PILOT OVERRULED FORGE (action, END_OF_TURN): chose [Do nothing now; let it resolve / let the turn pass (this skips o0, the play Forge's AI wou] instead of Forge's [activate Waterlogged Grove (from Battlefield): {1}, {T}, Sacrifice Waterlogged Grove: Draw]
- P2 triggered Bitterblossom
- P2 triggered Dreadhorde Invasion
- attack: P2 assigned Sephiroth, One-Winged Angel and Zodiark, Umbral God to attack US.
- P2 triggered Sephiroth, One-Winged Angel
- left battlefield: Doc Aurlock, Grizzled Genius was put into Graveyard from Battlefield.
- P2 triggered Emblem — Sephiroth, One-Winged Angel targeting [P4]
Damage to US this turn: Sephiroth, One-Winged Angel (combat) 5

## Turn 40 (OUR TURN, round 10) | life: P1 -6, P2 36, P3 0, US 8
Our hand: Shriekmaw, Toxic Deluge, Marsh Flats
Our graveyard (14): Wayfarer's Bauble, Grist, the Hunger Tide, Seal of Primordium, Spore Frog, Kaya's Ghostform, The Coming of Galactus, Bloodstained Mire, Executioner's Capsule, Verdant Catacombs, Forest, Walking Ballista, Baleful Strix, Eternal Witness, Doc Aurlock, Grizzled Genius
Board P1: 8 lands; Nazgûl 5/6 {[P1P1 x 4, Shadow]} (tapped 1), March from the Black Gate, The Mouth of Sauron 3/4, Nazgûl 3/4 {[P1P1 x 2]}, Pitiless Plunderer 1/4
Board P2: 10 lands; Zodiark, Umbral God 8/8 {[P1P1 x 3]} (tapped 1), Sephiroth, One-Winged Angel 5/5 (tapped 1), Zombie Token 2/2 [token], Bitterblossom, Dreadhorde Invasion, Zombie Army Token 1/1 [token] {[P1P1]}, Faerie Rogue Token 1/1 [token]
Board US: 7 lands; Arcane Signet, Galactus 16/16 [token]
MEMO (start of our turn):
THIS TURN: 1) Go straight to combat. Attack P1 with Galactus alone. P1 has 10 life, every land tapped, and no flyers or reach, so 16 flying is lethal. Point Galactus's land trigger at a P1 land. 2) Main 2: tap all 7 lands plus Signet for 8 mana (Grove costs 1 life) and cast Muldrotha. 3) Play Forest from the graveyard as our land drop, not Marsh Flats. Tap it for G and cast Spore Frog from the graveyard. On P2's turn, let Sephiroth's attack-sacrifice triggers resolve, then sacrifice Frog before damage to prevent all combat damage. Never block with Muldrotha: Zodiark is indestructible and every death drains us.

TARGET: Next turn we have 10 mana (9 sources plus Marsh Flats fetching a Swamp). Cast Coming of Galactus from the graveyard (5); chapter I destroys Sephiroth. Recast Frog (G), Grist (1BG) and Wayfarer's Bauble (1). Later: Doc, Kaya's Ghostform on Muldrotha. Tutor wants: Gray Merchant, Heroic Intervention.

WIN PATH: P2 is at 36 and gains life off drains. Galactus tramples for 16 a turn, Coming's chapters II and III drain 4, and Grist's -5 and Ballista finish. About 3 turns, and we must fog every P2 combat to survive it.

THREATS & ANSWERS: 1) The Sephiroth emblem drains us 1 per creature death once P1 is gone. Answer: Coming chapter I on Sephiroth, and minimise deaths. 2) Zodiark is indestructible: answer it with Frog fogs only. 3) A P2 wipe or edicts could drain us to death. Don't feed it extra creatures.

HOLD: Never cast Toxic Deluge or Shriekmaw. Every creature left is black except ours, so Shriekmaw's kill would hit our Frog. Keep Marsh Flats for next turn's land drop.

REPLAN IF: P1 survives combat. Frog is removed before P2's combat. We drop to 4 or less. P2 casts a wipe. Sephiroth leaves.
PILOT OVERRULED FORGE (attack, COMBAT_DECLARE_ATTACKERS): chose [attack P1 (10 life)] instead of Forge's [don't attack with it]
PILOT OVERRULED FORGE (trigger-target, COMBAT_DECLARE_ATTACKERS): chose [Sulfur Falls [P1, tapped]] instead of Forge's [Nykthos, Shrine to Nyx [P2, tapped]]
PILOT OVERRULED FORGE (action, MAIN2): chose [cast Spore Frog (from Graveyard): Spore Frog - Creature 1 / 1 by Muldrotha, the Gravetide ] instead of Forge's [cast Spore Frog (from Graveyard): Spore Frog - Creature 1 / 1 by Muldrotha, the Gravetide ]
- attack: US assigned Galactus to attack P1.
- US triggered Galactus targeting [Sulfur Falls]
- left battlefield: Sulfur Falls was put into Graveyard from Battlefield.
- left battlefield: Pitiless Plunderer was put into Exile from Battlefield.
- US cast Muldrotha, the Gravetide
- US cast Spore Frog

## Turn 41 (P2, round 11) | life: P1 -6, P2 35, P3 0, US 7
PILOT OVERRULED FORGE (action, COMBAT_DECLARE_ATTACKERS): chose [activate Spore Frog (from Battlefield): Sacrifice Spore Frog: Prevent all combat damage th] instead of Forge's [Do nothing now; let it resolve / let the turn pass]
- P2 triggered Bitterblossom
- P2 triggered Dreadhorde Invasion
- attack: P2 assigned Sephiroth, One-Winged Angel, Zodiark, Umbral God and Faerie Rogue Token to attack US.
- P2 triggered Sephiroth, One-Winged Angel
- left battlefield: Spore Frog was put into Graveyard from Battlefield.
- US activated Spore Frog
- P2 triggered Emblem — Sephiroth, One-Winged Angel targeting [P4]
- P2 triggered Zodiark, Umbral God

## Turn 42 (OUR TURN, round 11) | life: P1 -6, P2 20, P3 0, US 5
Our hand: Shriekmaw, Toxic Deluge, Marsh Flats, Breeding Pool
Our graveyard (13): Wayfarer's Bauble, Grist, the Hunger Tide, Seal of Primordium, Kaya's Ghostform, The Coming of Galactus, Bloodstained Mire, Executioner's Capsule, Verdant Catacombs, Walking Ballista, Baleful Strix, Eternal Witness, Doc Aurlock, Grizzled Genius, Spore Frog
Board P2: 10 lands; Zodiark, Umbral God 9/9 {[P1P1 x 4]} (tapped 1), Sephiroth, One-Winged Angel 5/5 (tapped 1), Zombie Token 2/2 [token], Bitterblossom, Dreadhorde Invasion, Zombie Army Token 2/2 [token] {[P1P1 x 2]}, Faerie Rogue Token 1/1 [token] x2 (tapped 1)
Board US: 8 lands; Arcane Signet, Galactus 16/16 [token], Muldrotha, the Gravetide 6/6
MEMO (start of our turn):
THIS TURN: 1) Play Breeding Pool tapped, with no life paid. Don't tap Waterlogged Grove, since it costs life. The other 8 sources are free. 2) From the graveyard, cast The Coming of Galactus (5). Chapter I destroys Bitterblossom, not a creature: the Sephiroth emblem drains us 1 for every creature death. 3) Cast Spore Frog (G) and Wayfarer's Bauble (1) from the graveyard. 4) Attack P2 with Galactus only; its land trigger destroys Nykthos. Muldrotha stays home, because attacking invites an Army chump, and a dead Army is replaced next upkeep. On P2's turn, block nothing. After attackers and Sephiroth's sacrifice triggers resolve, sacrifice Frog to fog.

TARGET: Next turn has 10 mana. Cast Doc Aurlock (GU) first, then Frog again, then Walking Ballista through the artifact lane at X=4. Coming chapter II drains 2. Gray Merchant (lifegain) is the missing piece and is not reachable yet.

WIN PATH: P2 drops from 35 to about 20 after Galactus, then gains back 4-5 from drains. Next turn: chapter II 2, Galactus 16, Ballista 4 at face, Muldrotha 6 if unblocked. That is about lethal. P2 kills us next turn if it finds any extra death or sacrifice beyond its fodder.

THREATS & ANSWERS: 1) The emblem drains us per death. Answer: fewer bodies (Bitterblossom dies now) and no chump blocks. 2) Zodiark and Sephiroth attacks: Frog fog. 3) A wipe or edict: no answer, so keep our creature count low.

HOLD: Never cast Toxic Deluge or Shriekmaw. All their creatures are black, and Deluge drains us per death. Keep Marsh Flats, since fetching costs life. No Ballista or Grist this turn: every creature we control is a drain in a wipe.

REPLAN IF: we drop to 3 or less, Sephiroth leaves or is recast (the front face doubles drains), P2 wipes, Frog is removed, or P2 is under 25 on our turn (go for lethal).
MEMO (executor escalation: P2: life 35→20 (-15)):
THIS TURN: 1) Cast Spore Frog from the graveyard (creature lane), paying G from Zagoth Triome. 2) Pay {1} from Arcane Signet and sacrifice Waterlogged Grove to draw. Cast the drawn card only if it costs 0. Never tap Grove for mana. On P2's turn, block nothing. Sacrifice Frog (fog) in response to Sephiroth being cast, or any edict, sacrifice or Blood Artist-type spell. Frog then dies before Sephiroth doubles the drains. Otherwise sacrifice it after attackers are declared.

TARGET: Next turn: Marsh Flats fetches a Swamp (1 life) for 10 mana. Skip the fetch if we're at 1 life. Chapter II drains 2. Attack P2 with Galactus and Muldrotha; Galactus's trigger destroys a P2 Swamp. After combat, cast Walking Ballista (artifact lane). If P2 is at 5 or less, use X=5 on P2's face; otherwise X=4 plus Spore Frog.

WIN PATH: 2 + 16 trample + 6 + Ballista 4-5 ≈ 28 against P2's ~21. We close next turn. P2 kills us on its turn with a wipe or 5+ deaths.

THREATS & ANSWERS: 1) Sephiroth emblem: every creature death costs us 1, or 2 once Sephiroth's front face returns. No answer, so never kill their creatures. 2) Zodiark 9/9 indestructible: only the Frog fog. 3) Sephiroth recast: handled by sacrificing Frog first.

HOLD: Toxic Deluge, Shriekmaw and Capsule. All their creatures are black, and deaths drain us. Remove Ballista's last counter only as the lethal ping, since its death drains us. No Grist.

REPLAN IF: We're at 1-2 life. Then any faerie chump or death kills us, so attack or ping only if that same damage kills P2. Also replan if P2 doesn't attack (its blockers stay untapped), P2 wipes, or Galactus is removed.
PILOT OVERRULED FORGE (action, MAIN1): chose [play land Breeding Pool (from Hand): Play land] instead of Forge's [play land Marsh Flats (from Hand): Play land]
PILOT OVERRULED FORGE (action, MAIN1): chose [cast The Coming of Galactus (from Graveyard): The Coming of Galactus by Muldrotha, the Gra] instead of Forge's [cast Kaya's Ghostform (from Graveyard): Kaya's Ghostform by Muldrotha, the Gravetide (403)]
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Executioner's Capsule (from Graveyard): Executioner's Capsule by Muldrotha, the Grave] instead of Forge's [cast Executioner's Capsule (from Graveyard): Executioner's Capsule by Muldrotha, the Grave]
PILOT OVERRULED FORGE (attack, COMBAT_DECLARE_ATTACKERS): chose [attack P2 (36 life)] instead of Forge's [don't attack with it]
ESCALATION (p=0.78): P2: life 35→20 (-15)
PILOT OVERRULED FORGE (action, MAIN2): chose [P2 (20 life)] instead of Forge's [Faerie Rogue Token [P2, 1/1, token]]
- US cast The Coming of Galactus
- US triggered The Coming of Galactus targeting [Sephiroth, One-Winged Angel]
- left battlefield: Sephiroth, One-Winged Angel was put into Graveyard from Battlefield.
- P2 triggered Emblem — Sephiroth, One-Winged Angel targeting [P4]
- US cast Executioner's Capsule
- attack: US assigned Galactus to attack P2.
- US triggered Galactus targeting [Nykthos, Shrine to Nyx]
- left battlefield: Nykthos, Shrine to Nyx was put into Graveyard from Battlefield.
- US cast Walking Ballista
- US activated Walking Ballista targeting [P2]
- left battlefield: Walking Ballista was put into Graveyard from Battlefield.
- P2 triggered Emblem — Sephiroth, One-Winged Angel targeting [P4]

## Turn 43 (P2, round 11) | life: P1 -6, P2 18, P3 0, US -2
- P2 triggered Bitterblossom
- P2 triggered Dreadhorde Invasion
- attack: P2 assigned Zodiark, Umbral God, Zombie Army Token, Zombie Token, Faerie Rogue Token and Faerie Rogue Token to attack US.
- P2 triggered Zombie Token
- attack: US assigned Muldrotha, the Gravetide to block Zodiark, Umbral God.
- Game Outcome: P1 has lost because life total reached 0
- Game Outcome: P2 has won because all opponents have lost
- Game Outcome: P3 has lost because life total reached 0
- Game Outcome: US has lost because life total reached 0
Damage to US this turn: Zombie Army Token (combat) 3, Zombie Token (combat) 2, Faerie Rogue Token (combat) 2