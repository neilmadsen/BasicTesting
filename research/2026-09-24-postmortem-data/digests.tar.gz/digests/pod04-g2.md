# pod04-g2: we are P1; opponents P2 Giada, Font of Hope, P3 Edgar Markov, P4 Sephiroth, Fabled SOLDIER
Result: Turn 22; US has lost because life total reached 0; P2 has won because all opponents have lost; P3 has lost because life total reached 0; P4 has lost because life total reached 0

## Turn 1 (OUR TURN, round 1) | life: US 39
Our hand: Bloodstained Mire, Shriekmaw, The Coming of Galactus, Seal of Primordium, Braids, Arisen Nightmare, Swamp, The Death of Gwen Stacy, Baleful Strix
Our graveyard (0): 
Board US: 0 lands; no nonland permanents
Board P2: 0 lands; no nonland permanents
Board P3: 0 lands; no nonland permanents
Board P4: 0 lands; no nonland permanents
MEMO (start of our turn):
THIS TURN: Play Bloodstained Mire. Crack it now (pay 1 life) and fetch Zagoth Triome. It enters tapped, which costs nothing because we have no 1-drop. Triome gives B, G and U, which fixes Strix, Seal and Galactus. If the Triome is somehow missing, fetch Underground Sea instead, then Bayou. Pass with 7 cards. No instant plays on opponents' turns.

TARGET: Turn 2: Swamp, then Baleful Strix (UB) as a blocker that draws a card. Turn 3: Braids (1BB), or hold The Death of Gwen Stacy (2B) for a real threat. Turn 5: The Coming of Galactus (2BBG). Turn 6+: Muldrotha (3BGU, 6 mana), recasting Shriekmaw (evoke, 1B) and the Seal every turn. Needed from the library: ramp (Arcane Signet, Talisman of Dominance, Farseek, Sakura-Tribe Elder), Claws of Gix and Executioner's Capsule.

WIN PATH: Grind with recurring removal. Close with Galactus chapters II and III (drain 2 each), the 16/16 token, Braids drains, and later Gray Merchant or Syr Konrad. Opponents' clock is turns 5-8, with P4's loop fastest.

THREATS & ANSWERS: 1) P4 Sephiroth, Pitiless Plunderer, Ashnod's Altar or Grave Pact. Answer creatures with Gwen Stacy (Sephiroth is black, so Shriekmaw can't touch him) and Altar or Pact with Seal of Primordium. 2) P3 Vito, Exquisite Blood or Skullclamp. Answer Blood or Clamp with the Seal and Vito with Gwen Stacy (Vito is black). 3) P2 Giada or Archangel of Thune. Answer with Shriekmaw evoke (both white and nonblack). Don't kill creatures needlessly while Sephiroth or Blood Artist effects are live.

HOLD: Seal and Gwen Stacy until a kill-on-sight card appears. Don't dump creatures into Toxic Deluge or Olivia's Wrath.

REPLAN IF: P4 has a turn-2 Sephiroth or Plunderer, or P2 has a turn-2 Giada: spend removal early.
PILOT OVERRULED FORGE (action, MAIN1): chose [play land Bloodstained Mire (from Hand): Play land] instead of Forge's [play land Swamp (from Hand): Play land]
PILOT OVERRULED FORGE (search, MAIN1): chose [Zagoth Triome — Land - Swamp Forest Island — ({T}: Add {B}, {G}, or {U}.) Zagoth Triome en] instead of Forge's [Watery Grave — Land - Island Swamp — ({T}: Add {U} or {B}.) As Watery Grave enters, you ma]
- left battlefield: Bloodstained Mire was put into Graveyard from Battlefield.
- US activated Bloodstained Mire

## Turn 2 (P2, round 1)

## Turn 3 (P3, round 1)
- P3 cast Sol Ring

## Turn 4 (P4, round 1)
- P4 cast Dark Ritual
- P4 cast Sephiroth, Fabled SOLDIER
- P4 triggered Sephiroth, Fabled SOLDIER

## Turn 5 (OUR TURN, round 2)
Our hand: Shriekmaw, The Coming of Galactus, Seal of Primordium, Braids, Arisen Nightmare, Swamp, The Death of Gwen Stacy, Baleful Strix, Glen Elendra Archmage
Our graveyard (1): Bloodstained Mire
Board US: 1 lands; no nonland permanents
Board P2: 1 lands; no nonland permanents
Board P3: 1 lands; Sol Ring
Board P4: 1 lands; Sephiroth, Fabled SOLDIER 3/3
MEMO (start of our turn):
THIS TURN: Play Swamp. Cast Baleful Strix (U from Triome, B from Swamp) and draw a card. That uses both mana. Evoking Shriekmaw is useless now because every live target is black (Sephiroth). On opponents' turns, if Sephiroth attacks us, block with Strix. Deathtouch kills him, and trading a 2-mana cantrip for their commander is great. Accept the 1 drain.

TARGET: Next turn (3 mana): The Death of Gwen Stacy (2B) to kill Sephiroth, unless Pitiless Plunderer or Vito lands first; then kill that instead. At 4 lands, cast Glen Elendra or Braids plus Seal. At 5, The Coming of Galactus. At 6, Muldrotha, looping Shriekmaw evoke, Seal and Strix. Missing pieces: ramp (Arcane Signet, Talisman of Dominance, Farseek, Sakura-Tribe Elder), Claws of Gix and Executioner's Capsule.

WIN PATH: Grind with recurring removal, then close with Galactus drains and the 16/16, Braids drains, and later Gray Merchant or Syr Konrad. The fastest opponent is P4's loop, around turns 5-7.

THREATS & ANSWERS: 1) P4: Sephiroth → Gwen Stacy or a Strix block. Ashnod's Altar or Grave Pact → Seal. 2) P3: Vito → Gwen Stacy or Galactus I. Exquisite Blood or Skullclamp → Seal. 3) P2: Giada or Thune → Shriekmaw evoke. Avoid killing creatures while Sephiroth or Blood Artist is out.

HOLD: Seal of Primordium for Altar, Pact, Blood or Clamp, not Sol Ring. Keep Gwen Stacy for Sephiroth. Don't commit more than one creature into Toxic Deluge or Olivia's Wrath.

REPLAN IF: we miss our next land drop (then cast Gwen Stacy only if we have 3 mana, otherwise Seal or Strix-level plays). Also replan if Plunderer, Vito or Giada appears, or if a wipe hits.
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Baleful Strix (from Hand): Baleful Strix - Creature 1 / 1 [Forge's heuristic AI would] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
- US cast Baleful Strix
- US triggered Baleful Strix

## Turn 6 (P2, round 2)
- P2 cast Giada, Font of Hope

## Turn 7 (P3, round 2)

## Turn 8 (P4, round 2) | life: P2 37, US 39
- attack: P4 assigned Sephiroth, Fabled SOLDIER to attack P2.
- P4 triggered Sephiroth, Fabled SOLDIER
- P4 cast Gravecrawler

## Turn 9 (OUR TURN, round 3) | life: P2 37, P4 42, US 37
Our hand: Shriekmaw, The Coming of Galactus, Seal of Primordium, Braids, Arisen Nightmare, The Death of Gwen Stacy, Glen Elendra Archmage, Boseiju, Who Endures, Breeding Pool
Our graveyard (1): Bloodstained Mire
Board US: 2 lands; Baleful Strix 1/1
Board P2: 2 lands; Giada, Font of Hope 2/2
Board P3: 2 lands; Sol Ring
Board P4: 2 lands; Sephiroth, Fabled SOLDIER 3/3 (tapped 1), Gravecrawler 2/1
MEMO (start of our turn):
THIS TURN: Play Breeding Pool, paying 2 life so it enters untapped. That gives 3 mana. Cast The Death of Gwen Stacy ({2}{B}: B from Swamp, the rest from Triome and Pool). Chapter I destroys Sephiroth, which is black but legal here. Sephiroth dying doesn't trigger his own drain. On opponents' turns, block only something that threatens real damage with Strix, and never chump into a drain trigger.

TARGET: Next turn, at 4 lands, evoke Shriekmaw ({1}{B}) on Giada, then cast Seal of Primordium ({1}{G}). At 5, cast The Coming of Galactus or Braids. At 6, cast Muldrotha and loop Shriekmaw evoke, Seal and Strix. Missing: ramp (Arcane Signet, Talisman of Dominance, Farseek, Sakura-Tribe Elder), Claws of Gix, Executioner's Capsule.

WIN PATH: Grind with recurring removal. Close with Galactus drains and the 16/16, Braids drains, then Gray Merchant or Syr Konrad. The fastest threat is P4's combo, turns 5-7, so Sephiroth dies now.

THREATS & ANSWERS: 1) P4: Sephiroth → Gwen Stacy now. Pitiless Plunderer → Shriekmaw only if it's nonblack, else Galactus I. Ashnod's Altar or Grave Pact → Seal or Boseiju channel. 2) P2: Giada or Thune → Shriekmaw evoke. 3) P3: Vito → Galactus I. Exquisite Blood or Skullclamp → Seal or Boseiju.

HOLD: Boseiju in hand as a channel answer; don't play it as a land while we have another. Seal is for Altar, Pact, Blood or Clamp, not Sol Ring. When Gwen reaches chapter III, target only opponents' graveyards, never ours. At chapter II, discard a spare land rather than lose 3.

REPLAN IF: Vito, Plunderer or Thune lands; a wipe hits; or we miss our 4th land.
PILOT OVERRULED FORGE (action, MAIN1): chose [play land Breeding Pool (from Hand): Play land] instead of Forge's [play land Boseiju, Who Endures (from Hand): Play land]
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Shriekmaw (from Hand): Evoke {1}{B} (You may cast this spell for its evoke cost. If y] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (attack, COMBAT_DECLARE_ATTACKERS): chose [don't attack with it] instead of Forge's [attack P4 (42 life)]
- US cast Shriekmaw
- US triggered Shriekmaw targeting [Giada, Font of Hope]
- US triggered Shriekmaw
- left battlefield: Shriekmaw was put into Graveyard from Battlefield.
- P4 triggered Sephiroth, Fabled SOLDIER targeting [P1]
- left battlefield: Giada, Font of Hope was put into Graveyard from Battlefield.
- P4 triggered Sephiroth, Fabled SOLDIER targeting [P1]

## Turn 10 (P2, round 3)
- P2 cast Bishop of Wings

## Turn 11 (P3, round 3)
- P3 cast Cruel Celebrant
- P3 triggered Edgar Markov

## Turn 12 (P4, round 3) | life: P2 37, P3 37, P4 43, US 36
- attack: P4 assigned Sephiroth, Fabled SOLDIER and Gravecrawler to attack P3.
- P4 triggered Sephiroth, Fabled SOLDIER
- left battlefield: Gravecrawler was put into Graveyard from Battlefield.
- P4 triggered Sephiroth, Fabled SOLDIER targeting [P1]
- P4 cast Blood Artist

## Turn 13 (OUR TURN, round 4) | life: P2 37, P3 37, P4 44, US 35
Our hand: The Coming of Galactus, Seal of Primordium, Braids, Arisen Nightmare, The Death of Gwen Stacy, Glen Elendra Archmage, Boseiju, Who Endures, Cryogen Relic
Our graveyard (2): Bloodstained Mire, Shriekmaw
Board US: 3 lands; Baleful Strix 1/1
Board P2: 3 lands; Bishop of Wings 1/4
Board P3: 3 lands; Sol Ring, Vampire Token 1/1 [token], Cruel Celebrant 1/2
Board P4: 2 lands; Sephiroth, Fabled SOLDIER 3/3 (tapped 1), Blood Artist 0/1
MEMO (start of our turn):
THIS TURN: Play Boseiju as our land. We have no other land, and after Gwen we couldn't pay its {1}{G} channel anyway, so the land drop is worth more. Cast The Death of Gwen Stacy ({2}{B}: Swamp for B, plus Boseiju and Breeding Pool). Chapter I destroys Sephiroth. Blood Artist will drain 1, which is fine. Triome stays open but has no use this turn. On opponents' turns, block with Strix only if an attacker threatens real damage. Every creature death feeds Blood Artist and Cruel Celebrant.

TARGET: 4 lands plus our draw next turn. At 4 mana: Seal of Primordium plus Cryogen Relic, or Glen Elendra. At 5 mana: The Coming of Galactus. At 6 mana: Muldrotha, then evoke Shriekmaw from the graveyard every turn. Missing pieces: ramp (Arcane Signet, Talisman of Dominance, Farseek), Claws of Gix, Executioner's Capsule, Gray Merchant.

WIN PATH: Galactus chapters II and III drain 6 per opponent, then the 16/16 flyer. Braids end-step drains, then Gray Merchant or Syr Konrad. This is roughly 5+ turns out. P4's combo is the fastest threat, which is why Sephiroth dies now.

THREATS & ANSWERS:
1) P4: Pitiless Plunderer, Ashnod's Altar, Grave Pact. Answer with Galactus chapter I, or Seal for Altar and Pact.
2) P3: Vito goes to Galactus chapter I. Exquisite Blood and Skullclamp go to Seal.
3) P2: Thune or Giada recast goes to Shriekmaw once Muldrotha is out.
Don't give P2 lifegain.

HOLD: Seal is for Altar, Pact, Blood or Clamp, never Sol Ring. Gwen chapter II: discard a spare land, or Braids, which is recastable later; otherwise lose 3. Gwen chapter III: exile only opponents' graveyards, P4's first (Gravecrawler), never ours.

REPLAN IF: Vito, Exquisite Blood, Plunderer, Altar or Thune lands. A wipe hits. We miss land 5 by next turn.
PILOT OVERRULED FORGE (attack, COMBAT_DECLARE_ATTACKERS): chose [don't attack with it] instead of Forge's [attack P4 (43 life)]
PILOT OVERRULED FORGE (action, MAIN2): chose [cast The Death of Gwen Stacy (from Hand): The Death of Gwen Stacy] instead of Forge's [cast Glen Elendra Archmage (from Hand): Glen Elendra Archmage - Creature 2 / 2]
- US cast The Death of Gwen Stacy
- US triggered The Death of Gwen Stacy targeting [Sephiroth, Fabled SOLDIER]
- left battlefield: Sephiroth, Fabled SOLDIER was put into Graveyard from Battlefield.
- P4 triggered Blood Artist targeting [P1]

## Turn 14 (P2, round 4)
- left battlefield: Myriad Landscape was put into Graveyard from Battlefield.
- P2 activated Myriad Landscape

## Turn 15 (P3, round 4) | life: P2 37, P3 33, P4 44, US 35
- P3 cast Anguished Unmaking targeting [Baleful Strix]
- left battlefield: Baleful Strix was put into Exile from Battlefield.
- left battlefield: Bloodstained Mire was put into Graveyard from Battlefield.
- P3 activated Bloodstained Mire

## Turn 16 (P4, round 4)

## Turn 17 (OUR TURN, round 5)
Our hand: The Coming of Galactus, Seal of Primordium, Braids, Arisen Nightmare, Glen Elendra Archmage, Cryogen Relic, Pernicious Deed
Our graveyard (2): Bloodstained Mire, Shriekmaw
Board US: 4 lands; The Death of Gwen Stacy {[LORE x 2]}
Board P2: 4 lands; Bishop of Wings 1/4
Board P3: 4 lands; Sol Ring (tapped 1), Vampire Token 1/1 [token], Cruel Celebrant 1/2
Board P4: 2 lands; Blood Artist 0/1
MEMO (start of our turn):
THIS TURN: Gwen chapter II: discard nothing and take 3 (35→32). Every card in hand is live and we have no spare land. Cast Cryogen Relic ({1}{U}: Breeding Pool + Boseiju) and draw.
- If we draw an untapped land, play it. Cast Braids ({1}{B}{B}: Swamp + Triome + new land). At end step, Braids sacrifices Relic: Relic draws 1, and each opponent sacrifices an artifact or loses 2 while we draw.
- Otherwise cast Seal of Primordium ({1}{G}: Triome G + Swamp). Keep Seal on board as an instant-speed answer.

TARGET: Land 5 lets us cast The Coming of Galactus (chapter I kills the best nonland permanent). Land 6 lets us cast Muldrotha, then evoke Shriekmaw every turn and recast Relic or Seal. Needed: lands, Arcane Signet, Talisman of Dominance, Claws of Gix, Executioner's Capsule, Gray Merchant.

WIN PATH: Galactus drains 4 per opponent, then the 16/16 flyer. Braids drains at end step, then Gray Merchant or Syr Konrad close. We are about 5 turns out. Opponents are slow (P4 has 2 lands), so we are not racing yet.

THREATS & ANSWERS:
1) P3: Vito or Bloodthirsty Conqueror → Galactus chapter I; Exquisite Blood or Skullclamp → Seal.
2) P4 recasting Sephiroth, Plunderer, Altar or Grave Pact → Galactus I; Altar or Pact → Seal.
3) P2 recasting Giada, or Thune → Galactus I or Pernicious Deed.
Pernicious Deed with X=2 clears the small creatures, but Blood Artist and Celebrant drain us for each one, so use it only when 3 or more real threats are out. Don't gain P2 life.

HOLD: Pernicious Deed and Glen Elendra in hand. Seal is never spent on Sol Ring. Next turn Gwen chapter III exiles P4's and P3's graveyards only.

REPLAN IF: Vito, Exquisite Blood, Plunderer, Altar or Thune lands; a wipe hits; we are still on 4 lands next turn (then cast Glen Elendra, or Deed with X held).
PILOT OVERRULED FORGE (discard, MAIN1): chose [Pernicious Deed [ours, in hand]] instead of Forge's [The Coming of Galactus [ours, in hand]]
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Cryogen Relic (from Hand): Cryogen Relic [Forge's heuristic AI would not do this: Can] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN1): chose [activate Cryogen Relic (from Battlefield): {1}{U}, Sacrifice this artifact: Put a stun cou] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN1): chose [play land Nurturing Peatland (from Hand): Play land] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
- US triggered The Death of Gwen Stacy
- US cast Cryogen Relic
- US triggered Cryogen Relic
- left battlefield: Cryogen Relic was put into Graveyard from Battlefield.
- US activated Cryogen Relic targeting []
- US triggered Cryogen Relic

## Turn 18 (P2, round 5) | life: P2 41, P3 33, P4 44, US 35
- P2 cast Archangel of Tithes
- P2 triggered Bishop of Wings
- P2 cast Land Tax

## Turn 19 (P3, round 5) | life: P2 41, P3 32, P4 44, US 35
- left battlefield: Marsh Flats was put into Graveyard from Battlefield.
- P3 activated Marsh Flats
- P3 cast Edgar Markov

## Turn 20 (P4, round 5)
- P4 cast Skullclamp

## Turn 21 (OUR TURN, round 6) | life: P2 40, P3 33, P4 44, US 32
Our hand: The Coming of Galactus, Seal of Primordium, Braids, Arisen Nightmare, Glen Elendra Archmage, Vraska, Golgari Queen, Kokusho, the Evening Star
Our graveyard (5): Bloodstained Mire, Shriekmaw, Pernicious Deed, Cryogen Relic, The Death of Gwen Stacy
Board US: 5 lands; no nonland permanents
Board P2: 5 lands; Bishop of Wings 1/4, Archangel of Tithes 3/5, Land Tax
Board P3: 5 lands; Sol Ring (tapped 1), Vampire Token 1/1 [token], Cruel Celebrant 1/2, Edgar Markov 4/4
Board P4: 2 lands; Blood Artist 0/1, Skullclamp
MEMO (start of our turn):
THIS TURN: No land in hand. Cast The Coming of Galactus for all 5 mana: B from Swamp, B from Peatland (pay 1 life), G from Boseiju, generic from Triome and Breeding Pool. Chapter I destroys Edgar Markov. He is P3's biggest attacker, and his recast costs 8, which eats P3's whole turn. We have no plays on opponents' turns. No one can kill us this cycle (at most about 13 combat damage).

TARGET: Muldrotha on board, then Seal, Braids, Glen Elendra and Kokusho from hand, with graveyard casts of Shriekmaw evoke, Deed, Relic and Gwen Stacy each turn. Missing: a 6th land (any), Claws of Gix, Executioner's Capsule, Gray Merchant.

WIN PATH: Galactus chapters II and III drain each opponent 2 twice, then a 16/16 flyer arrives in 3 turns. Braids drains at end step, and Kokusho drains 5 per death. Our clock is about 5 turns; P3 and P4 are about 3 turns from being dangerous.

THREATS & ANSWERS:
1) P4 Skullclamp: Seal of Primordium next turn.
2) P3 Vito or Bloodthirsty Conqueror: Vraska −3. Exquisite Blood: Seal.
3) P4 Pitiless Plunderer: Vraska −3. Ashnod's Altar or Grave Pact: Seal.
4) P2 Giada or Thune: Shriekmaw evoke once Muldrotha is out.
Don't feed life to P2. Avoid creature deaths while Blood Artist and Celebrant live.

HOLD: Glen Elendra and Kokusho until Muldrotha is out. Next turn: with a 6th land, cast Muldrotha. Without one, cast Seal and pop it on Skullclamp, then cast Braids and let her sacrifice nothing (never a land).

REPLAN IF: Galactus is removed. A wipe resolves. Vito, Exquisite Blood, Plunderer, Altar or Grave Pact lands. P3 recasts Edgar with more Vampires going wide (then Deed after Muldrotha).
PILOT OVERRULED FORGE (action, MAIN1): chose [cast The Coming of Galactus (from Hand): The Coming of Galactus [Forge's heuristic AI woul] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
- US triggered The Death of Gwen Stacy targeting [P4]
- left battlefield: The Death of Gwen Stacy was put into Graveyard from Battlefield.
- US cast The Coming of Galactus
- US triggered The Coming of Galactus targeting [Edgar Markov]
- left battlefield: Edgar Markov was put into Graveyard from Battlefield.
- P3 triggered Cruel Celebrant
- P4 triggered Blood Artist targeting [P1]

## Turn 22 (P2, round 6) | life: P2 44, P3 30, P4 44, US 32
- attack: P2 assigned Archangel of Tithes to attack P3.
- P2 cast Serra Paragon
- P2 triggered Bishop of Wings

## Turn 23 (P3, round 6) | life: P2 39, P3 30, P4 44, US 32
- P3 cast Edgar Markov
- attack: P3 assigned Edgar Markov to attack P2.
- P3 triggered Edgar Markov

## Turn 24 (P4, round 6)

## Turn 25 (OUR TURN, round 7) | life: P2 37, P3 28, P4 42, US 30
Our hand: Seal of Primordium, Braids, Arisen Nightmare, Glen Elendra Archmage, Vraska, Golgari Queen, Kokusho, the Evening Star, Verdant Catacombs
Our graveyard (5): Bloodstained Mire, Shriekmaw, Pernicious Deed, Cryogen Relic, The Death of Gwen Stacy
Board US: 5 lands; The Coming of Galactus {[LORE x 2]}
Board P2: 6 lands; Bishop of Wings 1/4, Archangel of Tithes 3/5 (tapped 1), Land Tax, Serra Paragon 3/4
Board P3: 6 lands; Sol Ring (tapped 1), Vampire Token 2/2 [token] {[P1P1]}, Cruel Celebrant 2/3 {[P1P1]}, Edgar Markov 5/5 {[P1P1]} (tapped 1)
Board P4: 2 lands; Blood Artist 0/1, Skullclamp
MEMO (start of our turn):
THIS TURN: Play Verdant Catacombs and crack it for Bayou (1 life). Cast Muldrotha for 6: B from Swamp, G from Boseiju, U from Breeding Pool, generic from Triome, Bayou and Peatland (1 life). That uses all our mana, so we have no plays on opponents' turns. No one can kill us this cycle (about 12 combat damage at most; we're at 30).

TARGET: Next turn, play Bloodstained Mire from the graveyard (7 lands). Cast Pernicious Deed from the graveyard and pop it at X=2 (5 mana total). That kills Blood Artist, Cruel Celebrant, Bishop, the token, Skullclamp, Land Tax and Sol Ring, but not Galactus or Muldrotha. Then evoke Shriekmaw (2) on Serra Paragon. The turn after: Glen Elendra with U open, then Kokusho. Missing: Claws of Gix, Gray Merchant.

WIN PATH: Galactus chapter III drains 2 each next turn, then a 16/16 flier the turn after. Aim it at P3, then P4. Its attack trigger must destroy one of our own replayable lands. Kokusho and Braids drain after that. Our clock is about 4 turns; P3's is about 3.

THREATS & ANSWERS:
1) P3 Vito or Bloodthirsty Conqueror: Vraska −3. Exquisite Blood: Seal.
2) P4 Skullclamp and Blood Artist: Deed X=2. Plunderer: Vraska −3. Altar or Grave Pact: Seal.
3) P2 Giada or Paragon: Shriekmaw evoke. Archangel of Thune: Shriekmaw. Never give P2 life.
Avoid chump blocks while Artist and Celebrant live.

HOLD: Kokusho and Glen Elendra until Deed has cleared the drainers. Hold Vraska for Vito or Plunderer. Hold Seal for Exquisite Blood, Altar or Grave Pact.

REPLAN IF: Muldrotha is removed (recast costs 8; do Seal plus Braids instead). A wipe resolves. Vito, Exquisite Blood, Plunderer or Grave Pact lands. Giada is cast.
PILOT OVERRULED FORGE (search, MAIN1): chose [Bayou — Land - Swamp Forest — ({T}: Add {B} or {G}.)] instead of Forge's [Tropical Island — Land - Forest Island — ({T}: Add {G} or {U}.)]
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Muldrotha, the Gravetide (from Command): Muldrotha, the Gravetide - Creature 6 / 6 [F] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
- US triggered The Coming of Galactus
- left battlefield: Verdant Catacombs was put into Graveyard from Battlefield.
- US activated Verdant Catacombs
- US cast Muldrotha, the Gravetide

## Turn 26 (P2, round 7) | life: P2 39, P3 22, P4 42, US 30
- left battlefield: Myriad Landscape was put into Graveyard from Battlefield.
- P2 activated Myriad Landscape
- P2 triggered Myriad Landscape
- attack: P2 assigned Archangel of Tithes and Serra Paragon to attack P3.
- P2 cast The Book of Exalted Deeds

## Turn 27 (P3, round 7) | life: P2 33, P3 22, P4 42, US 30
- attack: P3 assigned Edgar Markov to attack P2.
- P3 triggered Edgar Markov

## Turn 28 (P4, round 7) | life: P2 32, P3 23, P4 45, US 25
- P3 activated Voldaren Estate
- P4 cast Demon's Disciple
- P4 triggered Demon's Disciple
- left battlefield: Blood Artist was put into Graveyard from Battlefield.
- left battlefield: Muldrotha, the Gravetide was put into Graveyard from Battlefield.
- left battlefield: Bishop of Wings was put into Graveyard from Battlefield.
- P4 triggered Blood Artist targeting [P1]
- P4 triggered Blood Artist targeting [P1]
- P4 triggered Blood Artist targeting [P1]
- P4 triggered Blood Artist targeting [P1]
- P3 triggered Cruel Celebrant

## Turn 29 (OUR TURN, round 8) | life: P2 30, P3 21, P4 43, US 24
Our hand: Seal of Primordium, Braids, Arisen Nightmare, Glen Elendra Archmage, Vraska, Golgari Queen, Kokusho, the Evening Star, Doc Aurlock, Grizzled Genius
Our graveyard (6): Bloodstained Mire, Shriekmaw, Pernicious Deed, Cryogen Relic, The Death of Gwen Stacy, Verdant Catacombs
Board US: 6 lands; The Coming of Galactus {[LORE x 3]}
Board P2: 8 lands; Archangel of Tithes 3/5 (tapped 1), Land Tax, Serra Paragon 3/4 (tapped 1), The Book of Exalted Deeds
Board P3: 6 lands; Sol Ring (tapped 1), Cruel Celebrant 3/4 {[P1P1 x 2]}, Edgar Markov 6/6 {[P1P1 x 2]} (tapped 1), Blood Token [token]
Board P4: 3 lands; Skullclamp, Demon's Disciple 3/1
MEMO (start of our turn):
THIS TURN: Muldrotha is in the command zone and costs 8, which we can't reach. Cast Glen Elendra Archmage ({3}{U}): U from Zagoth Triome, generic from Swamp, Bayou and Nurturing Peatland (pay 1 life). Keep Breeding Pool (U) and Boseiju up for one Glen counter this cycle. Counter only: a wipe, removal aimed at The Coming of Galactus saga (Farewell, Austere Command, Feed the Swarm, Anguished Unmaking, Generous Gift), Exquisite Blood, Grave Pact or Ashnod's Altar. Don't counter removal aimed at Glen; persist returns it. Don't block with Glen.

TARGET: Next turn chapter IV makes Galactus. Cast Seal of Primordium (2) and Braids (3), and keep Breeding Pool's U up for Glen. At Braids' end step, sacrifice Glen: it persists back, and each opponent sacrifices a creature or loses 2 while we draw. Glen and Braids soak edicts meant for Galactus. Missing: ramp to 8 for Muldrotha (Sol Ring, Arcane Signet), Claws of Gix, Gray Merchant.

WIN PATH: Galactus swings the turn after it arrives, at P3 (21 life, no fliers): 21 to 5. Target its land trigger at Nurturing Peatland, then sacrifice Peatland in response to draw so the trigger fizzles. Kokusho's death drain of 5 each finishes P3. Clock is about 3 turns; P3 and P4 are similar.

THREATS & ANSWERS:
1. P3 Vito: Vraska −3. Exquisite Blood: Glen counter, else Seal.
2. P4 Skullclamp: Seal, fired in response to an equip. Grave Pact or Altar: Seal. Plunderer: Vraska −3.
3. P2 Book of Exalted Deeds: Seal before P2 has WWW at sorcery speed. Don't give P2 life.

HOLD: Kokusho until Galactus resolves (6 mana next-next turn). Vraska for Vito, Plunderer or Celebrant. Doc Aurlock until Muldrotha returns.

REPLAN IF: the Galactus saga is destroyed, a wipe resolves, Vito or Exquisite Blood lands, we draw ramp (then Muldrotha), or we drop to 12 life or less.
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Glen Elendra Archmage (from Hand): Glen Elendra Archmage - Creature 2 / 2 [Forge's he] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN2): chose [cast Seal of Primordium (from Hand): Seal of Primordium] instead of Forge's [cast Doc Aurlock, Grizzled Genius (from Hand): Doc Aurlock, Grizzled Genius - Creature 2 /]
- US triggered The Coming of Galactus
- US cast Glen Elendra Archmage
- US cast Seal of Primordium
- left battlefield: Seal of Primordium was put into Graveyard from Battlefield.
- US activated Seal of Primordium targeting [The Book of Exalted Deeds]
- left battlefield: The Book of Exalted Deeds was put into Graveyard from Battlefield.

## Turn 30 (P2, round 8) | life: P2 30, P3 15, P4 43, US 24
- P2 cast Serra's Emissary
- attack: P2 assigned Archangel of Tithes and Serra Paragon to attack P3.
- P2 cast Bishop of Wings
- P3 activated Blood Token

## Turn 31 (P3, round 8)

## Turn 32 (P4, round 8)
- P3 activated Voldaren Estate
- P4 cast Ophiomancer

## Turn 33 (OUR TURN, round 9) | life: P2 30, P3 15, P4 43, US 23
Our hand: Braids, Arisen Nightmare, Vraska, Golgari Queen, Kokusho, the Evening Star, Doc Aurlock, Grizzled Genius
Our graveyard (7): Bloodstained Mire, Shriekmaw, Pernicious Deed, Cryogen Relic, The Death of Gwen Stacy, Verdant Catacombs, Seal of Primordium
Board US: 6 lands; The Coming of Galactus {[LORE x 3]}, Glen Elendra Archmage 2/2
Board P2: 9 lands; Archangel of Tithes 3/5 (tapped 1), Land Tax, Serra Paragon 3/4 (tapped 1), Serra's Emissary 7/7, Bishop of Wings 1/4
Board P3: 7 lands; Sol Ring (tapped 1), Cruel Celebrant 3/4 {[P1P1 x 2]}, Edgar Markov 6/6 {[P1P1 x 2]}, Blood Token [token]
Board P4: 3 lands; Skullclamp, Demon's Disciple 3/1, Ophiomancer 2/2
MEMO (start of our turn):
THIS TURN: At lore IV, Galactus (16/16 flying trample) arrives and the saga is sacrificed. Galactus can't attack this turn. Main 1: cast Braids ({1}{B}{B}) using Swamp, Bayou and Boseiju. Keep Zagoth U, Breeding Pool U and Peatland up, so Glen can counter twice (sacrifice, persist, sacrifice again). Braids' end step: sacrifice nothing, because we keep our bodies as edict fodder. Play any land we draw. Don't attack.

TARGET: Galactus plus the fodder bodies Glen and Braids, then Vraska. Missing: ramp to 8 for Muldrotha (Sol Ring, Arcane Signet, Mind Stone). Muldrotha later recasts The Coming of Galactus from the graveyard.

WIN PATH: Next turn Galactus swings at P3 (15 life, no fliers) for lethal. Aim its land trigger at Nurturing Peatland, then sacrifice Peatland in response to draw. Then Kokusho, whose death drains 5 each, plus Galactus on P4. P2 is likely unhittable if Serra's Emissary chose creature, so drain P2 out. Clock: P3 next turn, the table in about 4.

THREATS & ANSWERS:
1. Edicts on Galactus (P4 Marauders, Disciple): sacrifice Glen (it persists) or Braids. Glen counters Toxic Deluge, Feed the Swarm, Grave Pact and Ashnod's Altar.
2. P2's fliers plus Akroma's Will could kill us: keep Galactus home untapped as a blocker and Glen-counter the Will. Give P2 no life.
3. P3 Swords, Path, Anguished Unmaking or Olivia's Wrath on Galactus: Glen counters. Vito or Exquisite Blood: Glen, then Vraska −3.

HOLD: UU for Glen. Vraska for Skullclamp, Cruel Celebrant or Vito. Kokusho until after the Galactus attack. Doc until Muldrotha.

REPLAN IF: Galactus dies, P3 gains above 16 life, we draw ramp, or Emissary's chosen type is revealed.
MEMO (executor escalation: we lost: The Coming of Galactus):
THIS TURN: No land in hand. Combat first, holding all 6 mana. Galactus attacks P3 (15 life, no fliers) for 16, which is lethal. Aim Galactus' mandatory land trigger at a P3 land, since P3 is dying anyway. If P3 casts Swords, Path or Unmaking on Galactus, counter it with Glen ({U}, sacrifice; it persists and can do it once more). Postcombat, cast Vraska with Swamp, Bayou, Boseiju and Peatland, then −3 on P4's Skullclamp. Zagoth and Breeding Pool stay untapped as UU for Glen through P2's and P4's turns.

TARGET: P3 gone. Galactus plus Braids, Doc and Survival online. Reach 8 mana for Muldrotha; tutor Sakura-Tribe Elder with Survival.

WIN PATH: After P3, P2 (30) is the fastest threat. If Serra's Emissary is protected from creatures, Galactus can't damage P2, so drain P2 instead: Kokusho (5 per death), Gray Merchant, and Braids. Galactus kills P4 (43) in 3 swings. Clock: about 4 turns.

THREATS & ANSWERS:
1. P2 fliers (13 power, 26 with Akroma's Will) against our 24 life: counter the Will with Glen. Never give P2 life.
2. P4 edicts: sacrifice Glen (persists) or Braids, never Galactus. Glen counters Feed the Swarm, Toxic Deluge and Grave Pact.
3. Later Galactus land triggers: target our Peatland, then sacrifice it in response to draw.

HOLD: UU for Glen at all times. Kokusho, Doc and Survival until next turn: Braids + Survival + discard Kokusho → Sakura-Tribe Elder.

REPLAN IF: P3 survives, Galactus is removed, Emissary's chosen type is revealed, or we draw ramp or a land.
ESCALATION (p=0.9): we lost: The Coming of Galactus
PILOT OVERRULED FORGE (action, MAIN2): chose [cast Vraska, Golgari Queen (from Hand): Vraska, Golgari Queen] instead of Forge's [cast Kokusho, the Evening Star (from Hand): Kokusho, the Evening Star - Creature 5 / 5]
PILOT OVERRULED FORGE (action, MAIN2): chose [Skullclamp [P4]] instead of Forge's [Bishop of Wings [P2, 1/4]]
PILOT OVERRULED FORGE (action, MAIN2): chose [cast Survival of the Fittest (from Hand): Survival of the Fittest] instead of Forge's [cast Doc Aurlock, Grizzled Genius (from Hand): Doc Aurlock, Grizzled Genius - Creature 2 /]
- P4 triggered Ophiomancer
- US triggered The Coming of Galactus
- left battlefield: The Coming of Galactus was put into Graveyard from Battlefield.
- US cast Vraska, Golgari Queen
- US activated Vraska, Golgari Queen targeting [Skullclamp]
- left battlefield: Skullclamp was put into Graveyard from Battlefield.
- US cast Survival of the Fittest

## Turn 34 (P2, round 9) | life: P2 38, P3 15, P4 43, US 16
- attack: P2 assigned Archangel of Tithes, Serra Paragon and Bishop of Wings to attack US.
- left battlefield: Vraska, Golgari Queen was put into Graveyard from Battlefield.
- P2 cast The Book of Exalted Deeds
- P2 cast Urza's Incubator
- P2 cast Giada, Font of Hope
- P2 triggered Bishop of Wings
- P2 cast Folk Hero
- P2 triggered The Book of Exalted Deeds
- P2 triggered Bishop of Wings
Damage to US this turn: Archangel of Tithes (combat) 3, Serra Paragon (combat) 3, Bishop of Wings (combat) 1

## Turn 35 (P3, round 9)
- P3 cast Olivia's Wrath
- left battlefield: Demon's Disciple was put into Graveyard from Battlefield.
- left battlefield: Ophiomancer was put into Graveyard from Battlefield.
- left battlefield: Glen Elendra Archmage was put into Graveyard from Battlefield.
- left battlefield: Giada, Font of Hope was put into Graveyard from Battlefield.
- US triggered Glen Elendra Archmage
- P2 triggered Bishop of Wings
- P3 cast Sanctum Seeker
- P3 triggered Edgar Markov

## Turn 36 (P4, round 9)
- P4 triggered Bojuka Bog targeting [P1]
- P4 cast Nine-Lives Familiar

## Turn 37 (OUR TURN, round 10) | life: P2 36, P3 -1, P4 41, US 15
Our hand: Braids, Arisen Nightmare, Kokusho, the Evening Star, Doc Aurlock, Grizzled Genius, Polluted Delta
Our graveyard (0): 
Board US: 6 lands; Galactus 16/16 [token], Survival of the Fittest, Glen Elendra Archmage 1/1 {[M1M1]}
Board P2: 10 lands; Archangel of Tithes 3/5 (tapped 1), Land Tax, Serra Paragon 3/4 (tapped 1), Serra's Emissary 7/7 (tapped 1), Bishop of Wings 1/4 (tapped 1), The Book of Exalted Deeds, Urza's Incubator, Folk Hero, Angel Token 7/7 [token] {[P1P1 x 4]}, Spirit Token 1/1 [token]
Board P3: 7 lands; Sol Ring (tapped 1), Cruel Celebrant 3/4 {[P1P1 x 2]}, Edgar Markov 6/6 {[P1P1 x 2]}, Blood Token [token], Vampire Token 1/1 [token], Sanctum Seeker 3/4
Board P4: 4 lands; Nine-Lives Familiar 1/1 {[REVIVAL x 8]}
MEMO (start of our turn):
THIS TURN: Everyone is tapped out, so no one can respond. Go to combat first: Galactus attacks P3 (15 life, no fliers) for 16, which is lethal. Aim Galactus' mandatory land trigger at Voldaren Estate. Postcombat, play Polluted Delta, pay 1 life and fetch Underground Sea (untapped). Then:
- Survival, paying G from Boseiju and discarding Kokusho: fetch Spore Frog. Cast it with G from Bayou.
- Survival again, paying G from Breeding Pool and discarding Doc: fetch Birds of Paradise. Cast it with G from Zagoth.

On P2's turn, after attackers are declared at us, sacrifice Frog to prevent all combat damage. P2's fliers have 21 power, and we're at 15.

TARGET: Next turn, 7 lands plus Birds gives 8 mana for Muldrotha. Replay Delta from the graveyard, fetch, and recast Frog from the graveyard for G. After that: Doc, Braids, and Kokusho recast from the graveyard each turn.

WIN PATH: Galactus kills P4 (43) in 3 swings. Drain P2 (38) with Kokusho sacrificed at Braids' end step (5 each plus we gain) and Gray Merchant. Frog recurs every turn to blank P2's fliers. Clock is about 5 turns.

THREATS & ANSWERS:
1. P2's flying board: Spore Frog every turn, recurred by Muldrotha. Glen covers Farewell, Akroma's Will and Austere Command. Never give P2 life.
2. P2's Book of Exalted Deeds activation (an Angel that stops them losing): answer with Assassin's Trophy or Seal of Primordium when found.
3. P4 edicts and Toxic Deluge: counter Deluge with Glen. Sacrifice Frog (if already used, Glen) to edicts. Never sacrifice Galactus or Birds.

HOLD: Keep Underground Sea's U up for Glen, which has one last counter because it already persisted. Save it for a wipe first. Hold Braids until Muldrotha is out.

REPLAN IF: Emissary's type is revealed as not creature, P3 survives, Frog is removed before P2's combat, Book is activated, or we draw a land.
PILOT OVERRULED FORGE (search, MAIN1): chose [Underground Sea — Land - Island Swamp — ({T}: Add {U} or {B}.)] instead of Forge's [Tropical Island — Land - Forest Island — ({T}: Add {G} or {U}.)]
PILOT OVERRULED FORGE (action, MAIN1): chose [activate Survival of the Fittest (from Battlefield): {G}, Discard a creature card: Search ] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (search, MAIN1): chose [Spore Frog — Creature - Frog — Sacrifice Spore Frog: Prevent all combat damage that would ] instead of Forge's [Massacre Wurm — Creature - Phyrexian Wurm — When Massacre Wurm enters, creatures your oppo]
PILOT OVERRULED FORGE (attack, COMBAT_DECLARE_ATTACKERS): chose [attack P3 (15 life)] instead of Forge's [don't attack with it]
PILOT OVERRULED FORGE (trigger-target, COMBAT_DECLARE_ATTACKERS): chose [Voldaren Estate [P3, tapped]] instead of Forge's [Minas Tirith [P2, tapped]]
PILOT OVERRULED FORGE (action, MAIN2): chose [cast Spore Frog (from Hand): Spore Frog - Creature 1 / 1] instead of Forge's [cast Kokusho, the Evening Star (from Hand): Kokusho, the Evening Star - Creature 5 / 5]
- left battlefield: Polluted Delta was put into Graveyard from Battlefield.
- US activated Polluted Delta
- US activated Survival of the Fittest
- attack: US assigned Galactus to attack P3.
- US triggered Galactus targeting [Voldaren Estate]
- left battlefield: Voldaren Estate was put into Graveyard from Battlefield.
- US cast Spore Frog
- US cast Braids, Arisen Nightmare
- US triggered Braids, Arisen Nightmare
- left battlefield: Swamp was put into Graveyard from Battlefield.

## Turn 38 (P2, round 10) | life: P2 44, P3 -1, P4 41, US 15
- attack: P2 assigned Serra's Emissary, Angel Token, Archangel of Tithes, Serra Paragon, Bishop of Wings and Spirit Token to attack US.
- left battlefield: Spore Frog was put into Graveyard from Battlefield.
- US activated Spore Frog
- P2 cast Herald of War
- P2 triggered Bishop of Wings
- P2 cast Giada, Font of Hope
- P2 triggered Bishop of Wings
- left battlefield: The Book of Exalted Deeds was put into Exile from Battlefield.
- P2 activated The Book of Exalted Deeds targeting [Serra's Emissary]

## Turn 39 (P4, round 10)
- P4 cast Sheoldred's Edict
- left battlefield: Galactus was put into Graveyard from Battlefield.
- left battlefield: Nurturing Peatland was put into Graveyard from Battlefield.
- US activated Nurturing Peatland

## Turn 40 (OUR TURN, round 10) | life: P2 42, P3 -1, P4 39, US 15
Our hand: Kokusho, the Evening Star, Dalek Drone, Vrock, Swamp, Sol Ring
Our graveyard (5): Polluted Delta, Doc Aurlock, Grizzled Genius, Swamp, Spore Frog, Nurturing Peatland
Board US: 5 lands; Survival of the Fittest, Glen Elendra Archmage 1/1 {[M1M1]}, Braids, Arisen Nightmare 3/3
Board P2: 10 lands; Archangel of Tithes 3/5 (tapped 1), Land Tax, Serra Paragon 3/4 (tapped 1), Serra's Emissary 7/7 {[ENLIGHTENED]} (tapped 1), Bishop of Wings 1/4 (tapped 1), Urza's Incubator, Folk Hero, Angel Token 7/7 [token] {[P1P1 x 4]} (tapped 1), Herald of War 3/3, Giada, Font of Hope 2/2
Board P4: 4 lands; Nine-Lives Familiar 1/1 {[REVIVAL x 8]}
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
- US cast Dalek Drone
- US triggered Dalek Drone targeting [Nine-Lives Familiar]
- left battlefield: Nine-Lives Familiar was put into Graveyard from Battlefield.
- P4 cast Deadly Dispute
- P4 triggered Nine-Lives Familiar
- US cast Sol Ring
- US triggered Braids, Arisen Nightmare
- P4 triggered Nine-Lives Familiar
- left battlefield: Sol Ring was put into Graveyard from Battlefield.

## Turn 41 (P2, round 11) | life: P2 57, P3 -1, P4 39, US -12
- P2 cast Angel of Vitality
- P2 triggered Giada, Font of Hope
- P2 triggered Bishop of Wings
- P2 cast Linvala, Keeper of Silence
- P2 triggered Bishop of Wings
- attack: P2 assigned Serra's Emissary, Angel Token, Archangel of Tithes, Serra Paragon, Herald of War, Giada, Font of Hope and Bishop of Wings to attack US.
- P2 triggered Herald of War
- P2 activated Minas Tirith
- P2 cast Serra the Benevolent
- P2 activated Serra the Benevolent
- P2 triggered Bishop of Wings
Damage to US this turn: Serra's Emissary (combat) 7, Angel Token (combat) 7, Archangel of Tithes (combat) 3, Serra Paragon (combat) 3, Herald of War (combat) 4, Giada, Font of Hope (combat) 2, Bishop of Wings (combat) 1

## Turn 42 (P4, round 11)
- P4 cast Yawgmoth, Thran Physician

## Turn 43 (P2, round 11) | life: P2 57, P3 -1, P4 -30, US -12
- P2 activated Serra the Benevolent
- attack: P2 assigned Angel Token, Angel of Vitality, Linvala, Keeper of Silence, Serra's Emissary, Angel Token, Herald of War, Archangel of Tithes, Serra Paragon, Giada, Font of Hope and Bishop of Wings to attack P4.
- P2 triggered Herald of War
- Game Outcome: US has lost because life total reached 0
- Game Outcome: P2 has won because all opponents have lost
- Game Outcome: P3 has lost because life total reached 0
- Game Outcome: P4 has lost because life total reached 0