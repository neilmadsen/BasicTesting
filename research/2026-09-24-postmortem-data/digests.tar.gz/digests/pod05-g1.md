# pod05-g1: we are P2; opponents P1 Pantlaza, Sun-Favored, P3 Sauron, the Dark Lord, P4 Teval, the Balanced Scale
Result: Turn 24; P1 has lost because life total reached 0; US has lost because life total reached 0; P3 has lost because life total reached 0; P4 has won because all opponents have lost

## Turn 1 (P4, round 1)
- P4 cast Deathrite Shaman

## Turn 2 (P1, round 1)

## Turn 3 (OUR TURN, round 1)
Our hand: Woodland Cemetery, Kaya's Ghostform, Dalek Drone, Zagoth Triome, Seal of Primordium, Demonic Tutor, Syr Konrad, the Grim, Baba Lysaga, Night Witch
Our graveyard (0): 
Board P1: 1 lands; no nonland permanents
Board US: 0 lands; no nonland permanents
Board P3: 0 lands; no nonland permanents
Board P4: 1 lands; Deathrite Shaman 1/2
MEMO (start of our turn):
THIS TURN: Play Zagoth Triome. It enters tapped, and we have no mana this turn. Woodland Cemetery would also enter tapped now, so save it; next turn the Triome's Swamp and Forest types make it enter untapped. Cast nothing, pass.

TARGET: Next turn, play Cemetery and cast Demonic Tutor ({1}{B}) for Sol Ring. The turn after, cast Sol Ring, then Baba Lysaga ({1}{B}{G}) or Seal of Primordium. Then Muldrotha on 4 lands plus Sol Ring. Missing pieces: lands (only 2 in hand), Sol Ring, Claws of Gix, Executioner's Capsule.

WIN PATH: Muldrotha recurs Dalek Drone (kill a creature, drain 3) and the Seals each turn. Syr Konrad and Baba Lysaga drain to close. Fastest opponent clock is turns 6-8 (P1, P3). We aim to lock the board around turn 7 and close by turn 10.

THREATS & ANSWERS: 1) P1 Pantlaza: Dalek Drone kills it; Seal of Primordium for Rhythm of the Wild. 2) P3 Sauron: every spell we cast grows his Army, so cast fewer, bigger spells. Ward means Dalek Drone can't easily target him; answer with a Demonic Tutor–found edict or wipe later. 3) P4 Teval: Deathrite Shaman exiles our graveyard creatures, so don't count on graveyard creatures while it lives. Drone is a fine target for it if nothing is bigger.

HOLD: Seal of Primordium for Rhythm of the Wild, Call of the Ring or Teval's Judgment. Kaya's Ghostform goes on Muldrotha once she lands, not before.

REPLAN IF: We draw a third land (then consider Seal next turn and Demonic Tutor later). Someone lands Pantlaza or Sauron early. P4's yard gets exiled by us.
PILOT OVERRULED FORGE (action, MAIN1): chose [play land Zagoth Triome (from Hand): Play land] instead of Forge's [play land Woodland Cemetery (from Hand): Play land]

## Turn 4 (P3, round 1)

## Turn 5 (P4, round 2) | life: P3 39
- attack: P4 assigned Deathrite Shaman to attack P3.

## Turn 6 (P1, round 2)

## Turn 7 (OUR TURN, round 2)
Our hand: Woodland Cemetery, Kaya's Ghostform, Dalek Drone, Seal of Primordium, Demonic Tutor, Syr Konrad, the Grim, Baba Lysaga, Night Witch, Takenuma, Abandoned Mire
Our graveyard (0): 
Board P1: 2 lands; no nonland permanents
Board US: 1 lands; no nonland permanents
Board P3: 1 lands; no nonland permanents
Board P4: 2 lands; Deathrite Shaman 1/2 (tapped 1)
MEMO (start of our turn):
THIS TURN: Play Woodland Cemetery. It enters untapped because Zagoth Triome is a Swamp Forest. Cast Demonic Tutor ({1}{B}: Triome plus Cemetery) and fetch Sol Ring. Pass. We have no instant-speed plays.

TARGET: Next turn, play Takenuma (3 lands) and cast Sol Ring ({1}). With the 4 mana left, cast Baba Lysaga ({1}{B}{G}), keeping {1} spare, or cast Seal of Primordium if Rhythm of the Wild or Call of the Ring has appeared. The turn after, 4 lands plus Sol Ring gives 6 mana for Muldrotha, with Kaya's Ghostform ({B}) on her as soon as mana allows. Missing: more lands, Claws of Gix, Executioner's Capsule.

WIN PATH: Muldrotha recasts Dalek Drone each turn (kill a creature, drain 3) plus the Seals. Syr Konrad pings on every death. Baba Lysaga saccing a land, an artifact creature and one more type drains 3 and draws 3. The fastest opponents (P1, P3) kill around turns 6-8, and all three are behind on lands. Lock the board by our turn 9 and close by 12.

THREATS & ANSWERS: 1) P1 Pantlaza: Dalek Drone; Seal for Rhythm of the Wild or Wrathful Raptors (a creature, so Drone). 2) P3 Sauron: his ward blocks targeting; answer with a wipe or edict later (Toxic Deluge or Plaguecrafter). 3) P4 Deathrite Shaman exiles our graveyard creatures and drains 2 per instant or sorcery in our yard. It is not worth the Drone yet.

HOLD: Seal of Primordium for Rhythm of the Wild, Call of the Ring or Teval's Judgment. Hold Dalek Drone for Pantlaza or Teval. Hold Syr Konrad until after Muldrotha.

REPLAN IF: Pantlaza or Sauron lands early; someone destroys our lands; we draw Sol Ring or a fast mana source.
PILOT OVERRULED FORGE (action, MAIN2): chose [cast Demonic Tutor (from Hand): Search your library for a card, put that card into your ha] instead of Forge's [cast Seal of Primordium (from Hand): Seal of Primordium]
PILOT OVERRULED FORGE (search, MAIN2): chose [Sol Ring — Artifact — {T}: Add {C}{C}.] instead of Forge's [Kokusho, the Evening Star — Legendary Creature - Dragon Spirit — Flying When Kokusho, the ]
- US cast Demonic Tutor

## Turn 8 (P3, round 2)

## Turn 9 (P4, round 3) | life: P1 39, P3 39
- attack: P4 assigned Deathrite Shaman to attack P1.

## Turn 10 (P1, round 3)

## Turn 11 (OUR TURN, round 3)
Our hand: Kaya's Ghostform, Dalek Drone, Seal of Primordium, Syr Konrad, the Grim, Baba Lysaga, Night Witch, Takenuma, Abandoned Mire, Sol Ring, The One Ring
Our graveyard (1): Demonic Tutor
Board P1: 3 lands; no nonland permanents
Board US: 2 lands; no nonland permanents
Board P3: 2 lands; no nonland permanents
Board P4: 3 lands; Deathrite Shaman 1/2 (tapped 1)
MEMO (start of our turn):
THIS TURN: Play Takenuma (3 lands). Tap Takenuma {B} for Sol Ring. Tap Sol Ring {C}{C}, Triome and Cemetery for The One Ring ({4}). We get protection from everything until our next turn. Tap the Ring now to draw 1. We end fully tapped with no instant plays; that's fine under protection.

TARGET: Next turn, with a land drop (4 lands + Sol Ring = 6), cast Muldrotha. Without one (5 mana), cast Baba Lysaga ({1}{B}{G}) plus Seal of Primordium ({1}{G}), or Dalek Drone if Pantlaza or Teval is out. The turn after, add Kaya's Ghostform ({B}) on Muldrotha and start graveyard recasts. Missing: lands, Claws of Gix (one Ring reset only), Executioner's Capsule, Pernicious Deed. The Ring digs for them.

WIN PATH: Muldrotha recasts Dalek Drone (kill + drain 3) and the Seals each turn. Syr Konrad pings on every death. Baba Lysaga sacs land + artifact creature + a third type to drain 3 and draw 3. The table is slow (2–3 lands each). Lock by about turn 15, close in 3–4 turns after.

THREATS & ANSWERS: 1) Pantlaza: Dalek Drone. 2) Rhythm of the Wild, Call of the Ring, Teval's Judgment: Seal of Primordium. 3) Sauron has sac-legendary ward: needs Toxic Deluge or a Plaguecrafter edict later. 4) Deathrite Shaman exiles our graveyard creatures: Drone it once Muldrotha can recast the Drone.

HOLD: Dalek Drone for Pantlaza or Teval. Syr Konrad until after Muldrotha. Seal for the enchantments above.

REPLAN IF: The Ring is removed or exiled (Generous Gift, Trophy); Sauron or Pantlaza lands; burden life loss exceeds 3 per upkeep without Claws.
PILOT OVERRULED FORGE (action, MAIN2): chose [cast Sol Ring (from Hand): Sol Ring] instead of Forge's [cast Baba Lysaga, Night Witch (from Hand): Baba Lysaga, Night Witch - Creature 3 / 3]
- US cast Sol Ring
- US cast Baba Lysaga, Night Witch
- P4 cast Counterspell targeting [Baba Lysaga, Night Witch - Creature 3 / 3]

## Turn 12 (P3, round 3)

## Turn 13 (P4, round 4) | life: P1 39, P3 39, US 39
- attack: P4 assigned Deathrite Shaman to attack US.
Damage to US this turn: Deathrite Shaman (combat) 1

## Turn 14 (P1, round 4)

## Turn 15 (OUR TURN, round 4)
Our hand: Kaya's Ghostform, Dalek Drone, Seal of Primordium, Syr Konrad, the Grim, The One Ring, Swamp
Our graveyard (2): Demonic Tutor, Baba Lysaga, Night Witch
Board P1: 4 lands; no nonland permanents
Board US: 3 lands; Sol Ring
Board P3: 3 lands; no nonland permanents
Board P4: 4 lands; Deathrite Shaman 1/2 (tapped 1)
MEMO (start of our turn):
THIS TURN: Play Swamp (6 mana). Cast The One Ring ({4}: Sol Ring {C}{C} + Takenuma + Swamp). If P4 counters it, fine: Muldrotha recasts it from the graveyard later. If it resolves, tap it at once to draw 1. Then cast Seal of Primordium ({1}{G}: Woodland Cemetery {G} + Zagoth Triome). Sacrifice Seal at instant speed only for the KILL ON SIGHT enchantments or artifacts below.

TARGET: Next turn cast Muldrotha ({3}{B}{G}{U}, tax 0): Swamp B, Takenuma B, Cemetery G, Triome U, Sol Ring 2. If the Ring draws a land (7 mana), add Kaya's Ghostform ({B}) on Muldrotha. The turn after, recast Baba Lysaga from the graveyard, cast Dalek Drone, then Syr Konrad. Missing: lands, Claws of Gix, Executioner's Capsule, Pernicious Deed, Toxic Deluge.

WIN PATH: Drain with recurring Dalek Drone (3 each), Baba Lysaga (3 each, sacrificing land + artifact creature + a third type) and Syr Konrad pings. Everyone is at 39–40 with thin boards; no one threatens lethal soon. Aim to close in about 6–8 turns.

THREATS & ANSWERS: 1) Pantlaza: Dalek Drone. 2) Rhythm of the Wild, Call of the Ring, Teval's Judgment, Wrathful Raptors (creature, so Drone): Seal. 3) Deathrite Shaman exiles Baba or Demonic Tutor from our graveyard: accept this. Drone it after Muldrotha is out. 4) Sauron (sacrifice-legendary ward): Toxic Deluge or Plaguecrafter later.

HOLD: Dalek Drone and Syr Konrad until Muldrotha is out. Hold Ghostform for Muldrotha only.

REPLAN IF: The Ring is countered or exiled. Pantlaza or Teval resolves (Drone it next turn instead of Muldrotha). P4 keeps UU open next turn: cast Drone as bait before Muldrotha.
PILOT OVERRULED FORGE (action, MAIN1): chose [cast The One Ring (from Hand): The One Ring [Forge's heuristic AI would not do this: CantP] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
- US cast The One Ring
- P3 cast An Offer You Can't Refuse targeting [The One Ring]
- US cast Seal of Primordium

## Turn 16 (P3, round 4) | life: P1 39, P3 38, US 39
- P3 cast Feed the Swarm targeting [Deathrite Shaman]
- left battlefield: Deathrite Shaman was put into Graveyard from Battlefield.

## Turn 17 (P4, round 5)
- P4 cast Teval, the Balanced Scale
- P3 cast Counterspell targeting [Teval, the Balanced Scale - Creature 4 / 4]

## Turn 18 (P1, round 5)

## Turn 19 (OUR TURN, round 5)
Our hand: Kaya's Ghostform, Dalek Drone, Syr Konrad, the Grim, Doc Aurlock, Grizzled Genius
Our graveyard (3): Demonic Tutor, Baba Lysaga, Night Witch, The One Ring
Board P1: 5 lands; no nonland permanents
Board US: 4 lands; Sol Ring, Treasure Token [token] x2, Seal of Primordium
Board P3: 4 lands; no nonland permanents
Board P4: 5 lands; no nonland permanents
MEMO (start of our turn):
THIS TURN: No land in hand. The table is open: P3 is fully tapped and P4 has only Command Beacon (colourless), so no counterspell is possible. Cast Muldrotha ({3}{B}{G}{U}, tax 0) using Swamp B, Cemetery G, Triome U, Takenuma and Sol Ring for the generic. Then cast Doc Aurlock ({G}{U}) with both Treasures. Don't cast Dalek Drone: no opponent has a creature, so it would drain nothing.

TARGET: Next turn (6 mana, Doc making graveyard casts 2 cheaper): The One Ring from the graveyard ({2}, Sol Ring), tap it to draw. Baba Lysaga from the graveyard ({B}{G}). Kaya's Ghostform ({B}) on Muldrotha. Then build toward Syr Konrad and a looping Dalek Drone. Missing: lands, Executioner's Capsule, Claws of Gix, Toxic Deluge, Gray Merchant.

WIN PATH: Baba sacrifices a land, Dalek Drone (artifact creature, counts as 2 types) and one more type, then Muldrotha replays them: 3 drain per cycle plus Syr Konrad pings. Opponents' clocks are turns 6-8 but every board is empty. Aim to close in about 5-7 turns.

THREATS & ANSWERS: 1) Pantlaza (P1 has 5 lands, 7 cards): Dalek Drone at once, before Ring or Baba. 2) Teval recast (Command Beacon): Drone. 3) Rhythm of the Wild, Call of the Ring, Teval's Judgment, Insidious Roots: sacrifice Seal of Primordium. 4) Sauron: an edict or Deluge later.

HOLD: Seal for the enchantments above. Syr Konrad until the Drone and Baba loop is online. Ghostform is for Muldrotha only.

REPLAN IF: Muldrotha is Pathed or killed (recast for 8 and Ghostform it). Pantlaza or Teval resolves (Drone first). An opponent shows graveyard exile.
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Muldrotha, the Gravetide (from Command): Muldrotha, the Gravetide - Creature 6 / 6 [F] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
- US cast Muldrotha, the Gravetide
- US cast Kaya's Ghostform targeting [Muldrotha, the Gravetide]

## Turn 20 (P3, round 5)
- P3 cast Saruman, the White Hand

## Turn 21 (P4, round 6)
- P4 cast Icetill Explorer
- P4 triggered Icetill Explorer
- P4 triggered Field of the Dead

## Turn 22 (P1, round 6) | life: P1 38, P3 38, US 39
- P1 cast Generous Gift targeting [Muldrotha, the Gravetide]
- left battlefield: Muldrotha, the Gravetide was put into Graveyard from Battlefield.
- left battlefield: Kaya's Ghostform was put into Graveyard from Battlefield.
- US triggered Kaya's Ghostform
- left battlefield: Wooded Foothills was put into Graveyard from Battlefield.
- P1 activated Wooded Foothills

## Turn 23 (OUR TURN, round 6) | life: P1 38, P3 35, US 40
Our hand: Dalek Drone, Syr Konrad, the Grim, Doc Aurlock, Grizzled Genius, Claws of Gix
Our graveyard (4): Demonic Tutor, Baba Lysaga, Night Witch, The One Ring, Kaya's Ghostform
Board P1: 6 lands; no nonland permanents
Board US: 4 lands; Sol Ring, Treasure Token [token], Seal of Primordium, Elephant Token 3/3 [token]
Board P3: 4 lands; Saruman, the White Hand 2/5
Board P4: 7 lands; Icetill Explorer 2/4, Zombie Token 2/2 [token]
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
PILOT OVERRULED FORGE (trigger-target, MAIN1): chose [Saruman, the White Hand [P3, 2/5]] instead of Forge's [Icetill Explorer [P4, 2/4]]
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Claws of Gix (from Hand): Claws of Gix] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN1): chose [activate Claws of Gix (from Battlefield): {1}, Sacrifice a permanent: You gain 1 life. [Fo] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
- US cast Dalek Drone
- US triggered Dalek Drone targeting [Saruman, the White Hand]
- left battlefield: Saruman, the White Hand was put into Graveyard from Battlefield.
- US cast Claws of Gix
- left battlefield: Claws of Gix was put into Graveyard from Battlefield.
- US activated Claws of Gix

## Turn 24 (P3, round 6)

## Turn 25 (P4, round 7) | life: P1 38, P3 35, US 19
MEMO (executor escalation: us: life 39→19 (-20)):
You've hit your session limit · resets 6:40pm (UTC)
ESCALATION (p=0.86): us: life 39→19 (-20)
- P4 triggered Icetill Explorer
- P4 triggered Field of the Dead
- P4 cast Craterhoof Behemoth
- P4 triggered Craterhoof Behemoth
- attack: P4 assigned Craterhoof Behemoth, Icetill Explorer and Zombie Token to attack US.
Damage to US this turn: Craterhoof Behemoth (combat) 9, Icetill Explorer (combat) 6, Zombie Token (combat) 6

## Turn 26 (P1, round 7)
- P1 cast Wrathful Raptors

## Turn 27 (OUR TURN, round 7)
Our hand: Syr Konrad, the Grim, Doc Aurlock, Grizzled Genius, Cabal Pit
Our graveyard (5): Demonic Tutor, Baba Lysaga, Night Witch, The One Ring, Kaya's Ghostform, Claws of Gix
Board P1: 7 lands; Wrathful Raptors 5/5
Board US: 4 lands; Sol Ring, Treasure Token [token], Seal of Primordium, Elephant Token 3/3 [token], Dalek Drone 3/3
Board P3: 4 lands; no nonland permanents
Board P4: 8 lands; Icetill Explorer 2/4 (tapped 1), Zombie Token 2/2 [token] x2 (tapped 1), Craterhoof Behemoth 5/5 (tapped 1)
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
PILOT OVERRULED FORGE (action, MAIN1): chose [play land Cabal Pit (from Hand): Play land] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (attack, COMBAT_DECLARE_ATTACKERS): chose [don't attack with it] instead of Forge's [attack P4 (40 life)]
PILOT OVERRULED FORGE (attack, COMBAT_DECLARE_ATTACKERS): chose [don't attack with it] instead of Forge's [attack P4 (40 life)]
PILOT OVERRULED FORGE (action, MAIN2): chose [cast Syr Konrad, the Grim (from Hand): Syr Konrad, the Grim - Creature 5 / 4] instead of Forge's [cast Muldrotha, the Gravetide (from Command): Muldrotha, the Gravetide - Creature 6 / 6]
- US cast Syr Konrad, the Grim
- US cast Doc Aurlock, Grizzled Genius

## Turn 28 (P3, round 7)
- P3 cast Orcish Siegemaster

## Turn 29 (P4, round 8) | life: P1 37, P3 34, P4 39, US 19
PILOT OVERRULED FORGE (block, COMBAT_DECLARE_BLOCKERS): chose [no block (take the damage)] instead of Forge's [k-1]
- attack: P4 assigned Craterhoof Behemoth to attack US.
- attack: US assigned Syr Konrad, the Grim to block Craterhoof Behemoth.
- left battlefield: Craterhoof Behemoth was put into Graveyard from Battlefield.
- left battlefield: Syr Konrad, the Grim was put into Graveyard from Battlefield.
- US triggered Syr Konrad, the Grim
- P4 cast Teval, the Balanced Scale

## Turn 30 (P1, round 8) | life: P1 37, P3 34, P4 34, US 19
MEMO (executor escalation: P1: nonland permanents 1→5 (+4); P1: creatures 1→5 (+4)):
You've hit your session limit · resets 6:40pm (UTC)
ESCALATION (p=0.65): P1: nonland permanents 1→5 (+4); P1: creatures 1→5 (+4)
- attack: P1 assigned Wrathful Raptors to attack P4.
- P1 cast Etali, Primal Conqueror
- P1 triggered Etali, Primal Conqueror
- P1 cast Regisaur Alpha
- P1 cast Sauron's Ransom
- P1 cast Gravecrawler
- P1 triggered Regisaur Alpha

## Turn 31 (OUR TURN, round 8) | life: P1 34, P3 34, P4 34, US 19
Our hand: Professor Dellian Fel
Our graveyard (6): Demonic Tutor, Baba Lysaga, Night Witch, The One Ring, Kaya's Ghostform, Claws of Gix, Syr Konrad, the Grim
Board P1: 8 lands; Wrathful Raptors 5/5 (tapped 1), Etali, Primal Conqueror 7/7, Gravecrawler 2/1, Regisaur Alpha 4/4, Dinosaur Token 3/3 [token]
Board US: 5 lands; Sol Ring, Seal of Primordium, Elephant Token 3/3 [token], Dalek Drone 3/3, Doc Aurlock, Grizzled Genius 2/3
Board P3: 4 lands; Orcish Siegemaster 0/5
Board P4: 8 lands; Icetill Explorer 2/4, Zombie Token 2/2 [token] x2, Teval, the Balanced Scale 4/4
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
- attack: US assigned Dalek Drone to attack P1.
- US cast Professor Dellian Fel
- US activated Professor Dellian Fel targeting [Etali, Primal Conqueror]
- left battlefield: Etali, Primal Conqueror was put into Graveyard from Battlefield.

## Turn 32 (P3, round 8)

## Turn 33 (P4, round 9)
PILOT OVERRULED FORGE (action, COMBAT_DAMAGE): chose [Teval, the Balanced Scale [P4, 4/4, commander, tapped]] instead of Forge's [Gravecrawler [P1, 2/1]]
- attack: P4 assigned Teval, the Balanced Scale to attack Professor Dellian Fel.
- P4 triggered Teval, the Balanced Scale
- P4 triggered Icetill Explorer
- P4 triggered Field of the Dead
- P4 triggered Teval, the Balanced Scale
- left battlefield: Professor Dellian Fel was put into Graveyard from Battlefield.
- left battlefield: Cabal Pit was put into Graveyard from Battlefield.
- US activated Cabal Pit targeting [Teval, the Balanced Scale]
- P4 cast Conduit of Worlds
- P3 cast Saruman's Trickery targeting [Conduit of Worlds]
- P4 cast Awaken the Honored Dead
- P4 triggered Awaken the Honored Dead targeting [Wrathful Raptors]
- left battlefield: Seal of Primordium was put into Graveyard from Battlefield.
- US activated Seal of Primordium targeting [Awaken the Honored Dead]
- left battlefield: Awaken the Honored Dead was put into Graveyard from Battlefield.
- left battlefield: Wrathful Raptors was put into Graveyard from Battlefield.

## Turn 34 (P1, round 9) | life: P1 34, P3 34, P4 28, US 19
- P1 cast Earthshaker Dreadmaw
- P1 triggered Earthshaker Dreadmaw
- attack: P1 assigned Earthshaker Dreadmaw and Regisaur Alpha to attack P4.
- left battlefield: Regisaur Alpha was put into Graveyard from Battlefield.
- left battlefield: Icetill Explorer was put into Graveyard from Battlefield.

## Turn 35 (OUR TURN, round 9) | life: P1 34, P3 34, P4 25, US 19
Our hand: Hinterland Harbor
Our graveyard (9): Demonic Tutor, Baba Lysaga, Night Witch, The One Ring, Kaya's Ghostform, Claws of Gix, Syr Konrad, the Grim, Professor Dellian Fel, Cabal Pit, Seal of Primordium
Board P1: 9 lands; Gravecrawler 2/1, Dinosaur Token 3/3 [token], Earthshaker Dreadmaw 6/6 (tapped 1)
Board US: 4 lands; Sol Ring, Elephant Token 3/3 [token], Dalek Drone 3/3, Doc Aurlock, Grizzled Genius 2/3
Board P3: 4 lands; Orcish Siegemaster 0/5, Orc Army Token 1/1 [token] {[P1P1]}
Board P4: 9 lands; Zombie Token 2/2 [token] x3, Teval, the Balanced Scale 4/4 (tapped 1), Zombie Druid Token 2/2 [token]
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
PILOT OVERRULED FORGE (action, MAIN1): chose [play land Hinterland Harbor (from Hand): Play land] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
- attack: US assigned Dalek Drone to attack P4.

## Turn 36 (P3, round 9)
- P3 cast Summons of Saruman
- attack: P3 assigned Orcish Siegemaster to attack P1.
- P3 triggered Orcish Siegemaster
- attack: P1 assigned Dinosaur Token to block Orcish Siegemaster.
- P3 cast Dark Ritual

## Turn 37 (P4, round 10) | life: P1 -22, P3 34, P4 17, US 19
- P4 cast Reanimate targeting [Craterhoof Behemoth]
- P4 triggered Craterhoof Behemoth
- P4 triggered Teval, the Balanced Scale
- attack: P4 assigned Craterhoof Behemoth, Teval, the Balanced Scale, Zombie Token, Zombie Token, Zombie Druid Token and Zombie Token to attack P1.
- P4 triggered Teval, the Balanced Scale
- P4 triggered Field of the Dead
- P4 triggered Teval, the Balanced Scale
- attack: P1 assigned Dinosaur Token to block Craterhoof Behemoth.
- left battlefield: Gravecrawler was put into Exile from Battlefield.
- P4 cast Skull Prophet
- P4 cast Insidious Roots

## Turn 38 (OUR TURN, round 10) | life: P1 -22, P3 34, P4 14, US 19
Our hand: The Death of Gwen Stacy
Our graveyard (9): Demonic Tutor, Baba Lysaga, Night Witch, The One Ring, Kaya's Ghostform, Claws of Gix, Syr Konrad, the Grim, Professor Dellian Fel, Cabal Pit, Seal of Primordium
Board US: 5 lands; Sol Ring, Elephant Token 3/3 [token], Dalek Drone 3/3, Doc Aurlock, Grizzled Genius 2/3
Board P3: 4 lands; Orcish Siegemaster 0/5 (tapped 1), Orc Army Token 1/1 [token] {[P1P1]}
Board P4: 10 lands; Zombie Token 2/2 [token] x4 (tapped 3), Teval, the Balanced Scale 4/4 (tapped 1), Zombie Druid Token 2/2 [token] x3 (tapped 1), Craterhoof Behemoth 5/5 (tapped 1), Skull Prophet 3/1, Insidious Roots
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
PILOT OVERRULED FORGE (attack, COMBAT_DECLARE_ATTACKERS): chose [attack P4 (17 life)] instead of Forge's [don't attack with it]
- attack: US assigned Dalek Drone to attack P4.
- US cast The Death of Gwen Stacy
- US triggered The Death of Gwen Stacy targeting [Craterhoof Behemoth]
- left battlefield: Craterhoof Behemoth was put into Graveyard from Battlefield.

## Turn 39 (P3, round 10)

## Turn 40 (P4, round 10) | life: P1 -22, P3 34, P4 14, US 15
- attack: P4 assigned Teval, the Balanced Scale to attack US.
- P4 triggered Teval, the Balanced Scale
- P4 triggered Field of the Dead
- P4 triggered Teval, the Balanced Scale
Damage to US this turn: Teval, the Balanced Scale (combat) 4

## Turn 41 (OUR TURN, round 11) | life: P1 -22, P3 34, P4 11, US 15
Our hand: 
Our graveyard (10): Demonic Tutor, Baba Lysaga, Night Witch, The One Ring, Kaya's Ghostform, Claws of Gix, Syr Konrad, the Grim, Professor Dellian Fel, Cabal Pit, Seal of Primordium, Survival of the Fittest
Board US: 5 lands; Sol Ring, Elephant Token 3/3 [token], Dalek Drone 3/3, Doc Aurlock, Grizzled Genius 2/3, The Death of Gwen Stacy {[LORE x 2]}
Board P3: 4 lands; Orcish Siegemaster 0/5, Orc Army Token 1/1 [token] {[P1P1]}
Board P4: 11 lands; Zombie Token 2/2 [token] x5, Teval, the Balanced Scale 4/4 (tapped 1), Zombie Druid Token 2/2 [token] x4, Skull Prophet 3/1, Insidious Roots
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
PILOT OVERRULED FORGE (attack, COMBAT_DECLARE_ATTACKERS): chose [attack P4 (14 life)] instead of Forge's [don't attack with it]
- US triggered The Death of Gwen Stacy
- attack: US assigned Dalek Drone to attack P4.

## Turn 42 (P3, round 11)
- P4 activated Skull Prophet

## Turn 43 (P4, round 11) | life: P1 -22, P3 34, P4 11, US -189
- P4 triggered Field of the Dead
- left battlefield: Memorial to Folly was put into Graveyard from Battlefield.
- P4 activated Memorial to Folly targeting [Craterhoof Behemoth]
- P4 triggered Teval, the Balanced Scale
- P4 triggered Insidious Roots
- P4 cast Craterhoof Behemoth
- P4 triggered Craterhoof Behemoth
- attack: P4 assigned Craterhoof Behemoth, Teval, the Balanced Scale, Skull Prophet, Zombie Token, Zombie Token, Zombie Druid Token, Zombie Token, Zombie Druid Token, Zombie Druid Token, Zombie Token, Zombie Druid Token and Zombie Token to attack US.
- P4 triggered Teval, the Balanced Scale
- P4 triggered Field of the Dead
- P4 triggered Teval, the Balanced Scale
- attack: US assigned Elephant Token to block Craterhoof Behemoth.
Damage to US this turn: Craterhoof Behemoth (combat) 17, Teval, the Balanced Scale (combat) 19, Skull Prophet (combat) 15, Zombie Token (combat) 85, Zombie Druid Token (combat) 68

## Turn 44 (P3, round 11)
- P3 cast Summons of Saruman

## Turn 45 (P4, round 12) | life: P1 -22, P3 2, P4 11, US -189
- left battlefield: Memorial to Folly was put into Graveyard from Battlefield.
- P4 activated Memorial to Folly targeting [Syr Konrad, the Grim]
- P4 triggered Teval, the Balanced Scale
- P4 triggered Insidious Roots
- attack: P4 assigned Teval, the Balanced Scale, Craterhoof Behemoth, Skull Prophet, Zombie Token, Zombie Token, Zombie Druid Token, Zombie Token, Zombie Druid Token, Zombie Druid Token, Zombie Token, Zombie Druid Token, Zombie Token, Zombie Token, Plant Token, Zombie Druid Token, Zombie Druid Token and Zombie Token to attack P3.
- P4 triggered Teval, the Balanced Scale
- P4 triggered Field of the Dead
- P4 triggered Teval, the Balanced Scale
- left battlefield: Swamp was put into Graveyard from Battlefield.
- left battlefield: Forest was put into Graveyard from Battlefield.
- P4 activated Jarad, Golgari Lich Lord
- P4 triggered Teval, the Balanced Scale
- P4 triggered Insidious Roots
- P4 cast Syr Konrad, the Grim

## Turn 46 (P3, round 12) | life: P1 -22, P3 1, P4 10, US -189
- P3 cast Sauron, the Dark Lord
- P4 activated Syr Konrad, the Grim
- P4 triggered Syr Konrad, the Grim

## Turn 47 (P4, round 12) | life: P1 -22, P3 0, P4 10, US -189
- attack: P4 assigned Craterhoof Behemoth, Syr Konrad, the Grim, Teval, the Balanced Scale, Skull Prophet, Plant Token, Zombie Token, Zombie Token, Zombie Druid Token, Zombie Token, Zombie Druid Token, Zombie Druid Token, Zombie Token, Zombie Druid Token, Zombie Token, Zombie Token, Zombie Druid Token, Zombie Druid Token, Zombie Token, Plant Token, Zombie Druid Token, Zombie Druid Token, Zombie Token, Zombie Druid Token and Plant Token to attack P3.
- P4 triggered Teval, the Balanced Scale
- P4 triggered Syr Konrad, the Grim
- P4 triggered Syr Konrad, the Grim
- P4 triggered Syr Konrad, the Grim
- P4 triggered Golgari Rot Farm
- P4 triggered Field of the Dead
- P4 triggered Teval, the Balanced Scale
- Game Outcome: P1 has lost because life total reached 0
- Game Outcome: US has lost because life total reached 0
- Game Outcome: P3 has lost because life total reached 0
- Game Outcome: P4 has won because all opponents have lost