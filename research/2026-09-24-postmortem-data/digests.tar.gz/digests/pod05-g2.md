# pod05-g2: we are P2; opponents P1 Pantlaza, Sun-Favored, P3 Sauron, the Dark Lord, P4 Teval, the Balanced Scale
Result: Turn 19; P1 has won because all opponents have lost; US has lost because life total reached 0; P3 has lost because life total reached 0; P4 has lost because life total reached 0

## Turn 1 (P1, round 1)

## Turn 2 (OUR TURN, round 1)
Our hand: Takenuma, Abandoned Mire, Kokusho, the Evening Star, Shriekmaw, Mulldrifter, Otawara, Soaring City, Forest, Forest, Misty Rainforest
Our graveyard (0): 
Board P1: 1 lands; no nonland permanents
Board US: 0 lands; no nonland permanents
Board P3: 0 lands; no nonland permanents
Board P4: 0 lands; no nonland permanents
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)

## Turn 3 (P3, round 1)

## Turn 4 (P4, round 1)
- left battlefield: Forest was put into Graveyard from Battlefield.
- P4 cast Crop Rotation

## Turn 5 (P1, round 2)

## Turn 6 (OUR TURN, round 2) | life: US 39
Our hand: Kokusho, the Evening Star, Shriekmaw, Mulldrifter, Otawara, Soaring City, Forest, Forest, Misty Rainforest, Hinterland Harbor
Our graveyard (0): 
Board P1: 2 lands; no nonland permanents
Board US: 1 lands; no nonland permanents
Board P3: 1 lands; no nonland permanents
Board P4: 1 lands; no nonland permanents
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
PILOT OVERRULED FORGE (action, MAIN1): chose [play land Misty Rainforest (from Hand): Play land] instead of Forge's [play land Hinterland Harbor (from Hand): Play land]
PILOT OVERRULED FORGE (search, MAIN1): chose [Zagoth Triome — Land - Swamp Forest Island — ({T}: Add {B}, {G}, or {U}.) Zagoth Triome en] instead of Forge's [Watery Grave — Land - Island Swamp — ({T}: Add {U} or {B}.) As Watery Grave enters, you ma]
- left battlefield: Misty Rainforest was put into Graveyard from Battlefield.
- US activated Misty Rainforest

## Turn 7 (P3, round 2)

## Turn 8 (P4, round 2)
- P4 cast Sol Ring

## Turn 9 (P1, round 3) | life: P1 39, US 39
- left battlefield: Wooded Foothills was put into Graveyard from Battlefield.
- P1 activated Wooded Foothills
- P1 cast Sol Ring

## Turn 10 (OUR TURN, round 3)
Our hand: Kokusho, the Evening Star, Shriekmaw, Mulldrifter, Otawara, Soaring City, Forest, Forest, Hinterland Harbor, Vrock
Our graveyard (1): Misty Rainforest
Board P1: 3 lands; Sol Ring
Board US: 2 lands; no nonland permanents
Board P3: 2 lands; no nonland permanents
Board P4: 2 lands; Sol Ring
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
- US cast Mulldrifter
- US triggered Mulldrifter
- US triggered Mulldrifter
- P1 activated Trumpeting Carnosaur targeting [Mulldrifter]
- left battlefield: Mulldrifter was put into Graveyard from Battlefield.

## Turn 11 (P3, round 3) | life: P1 39, P3 34, US 39
- P3 cast Reanimate targeting [Trumpeting Carnosaur]
- P3 triggered Trumpeting Carnosaur

## Turn 12 (P4, round 3)

## Turn 13 (P1, round 4)
- P1 cast Pantlaza, Sun-Favored
- P3 cast Arcane Denial targeting [Pantlaza, Sun-Favored - Creature 4 / 4]

## Turn 14 (OUR TURN, round 4)
Our hand: Kokusho, the Evening Star, Shriekmaw, Otawara, Soaring City, Forest, Vrock, The Death of Gwen Stacy, Bojuka Bog, Massacre Wurm
Our graveyard (3): Misty Rainforest, Mulldrifter, Forest
Board P1: 4 lands; Sol Ring (tapped 1)
Board US: 3 lands; no nonland permanents
Board P3: 3 lands; Trumpeting Carnosaur 7/6
Board P4: 3 lands; Sol Ring
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Shriekmaw (from Hand): Evoke {1}{B} (You may cast this spell for its evoke cost. If y] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
- P3 triggered Arcane Denial
- P3 triggered Arcane Denial
- US cast Shriekmaw
- US triggered Shriekmaw targeting [Trumpeting Carnosaur]
- US triggered Shriekmaw
- left battlefield: Shriekmaw was put into Graveyard from Battlefield.
- left battlefield: Trumpeting Carnosaur was put into Graveyard from Battlefield.

## Turn 15 (P3, round 4)
- P3 cast Nazgûl
- P3 triggered Nazgûl
- P3 triggered Nazgûl

## Turn 16 (P4, round 4)

## Turn 17 (P1, round 5)
- P1 cast Bronzebeak Foragers
- P1 triggered Bronzebeak Foragers targeting [Nazgûl, Sol Ring]
- left battlefield: Nazgûl was put into Exile from Battlefield.
- left battlefield: Sol Ring was put into Exile from Battlefield.

## Turn 18 (OUR TURN, round 5)
Our hand: Kokusho, the Evening Star, Forest, Vrock, The Death of Gwen Stacy, Bojuka Bog, Massacre Wurm, Soul-Guide Lantern
Our graveyard (4): Misty Rainforest, Mulldrifter, Forest, Shriekmaw
Board P1: 4 lands; Sol Ring (tapped 1), Bronzebeak Foragers 3/4
Board US: 4 lands; no nonland permanents
Board P3: 4 lands; no nonland permanents
Board P4: 4 lands; no nonland permanents
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
- US cast Vrock

## Turn 19 (P3, round 5)
- P3 cast Nazgûl
- P3 triggered Nazgûl
- P3 triggered Nazgûl

## Turn 20 (P4, round 5)

## Turn 21 (P1, round 6)
- P1 cast Ghalta and Mavren

## Turn 22 (OUR TURN, round 6) | life: P1 36, P3 28, P4 37, US 39
Our hand: Kokusho, the Evening Star, The Death of Gwen Stacy, Bojuka Bog, Massacre Wurm, Soul-Guide Lantern, Plaguecrafter
Our graveyard (4): Misty Rainforest, Mulldrifter, Forest, Shriekmaw
Board P1: 5 lands; Sol Ring (tapped 1), Bronzebeak Foragers 3/4, Ghalta and Mavren 12/12
Board US: 5 lands; Vrock 3/3
Board P3: 5 lands; Nazgûl 2/3 {[P1P1]}
Board P4: 5 lands; no nonland permanents
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
PILOT OVERRULED FORGE (action, MAIN1): chose [play land Bojuka Bog (from Hand): Play land] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (attack, COMBAT_DECLARE_ATTACKERS): chose [attack P3 (34 life)] instead of Forge's [attack P1 (39 life)]
- US triggered Bojuka Bog targeting [P1]
- attack: US assigned Vrock to attack P3.
- US cast The Death of Gwen Stacy
- US triggered The Death of Gwen Stacy targeting [Ghalta and Mavren]
- left battlefield: Ghalta and Mavren was put into Graveyard from Battlefield.
- US cast Soul-Guide Lantern
- US triggered Soul-Guide Lantern targeting [Ghalta and Mavren]
- left battlefield: Soul-Guide Lantern was put into Graveyard from Battlefield.
- US activated Soul-Guide Lantern
- US triggered Vrock

## Turn 23 (P3, round 6) | life: P1 34, P3 28, P4 37, US 39
- attack: P3 assigned Nazgûl to attack P1.
- P3 triggered The Ring
- P3 cast Sauron, the Dark Lord

## Turn 24 (P4, round 6)
- left battlefield: Terramorphic Expanse was put into Graveyard from Battlefield.
- P4 activated Terramorphic Expanse

## Turn 25 (P1, round 7)
- P1 cast Pantlaza, Sun-Favored
- P3 triggered Sauron, the Dark Lord
- P1 triggered Pantlaza, Sun-Favored
- P1 cast Thrashing Brontodon
- P3 triggered Sauron, the Dark Lord

## Turn 26 (OUR TURN, round 7) | life: P1 31, P3 22, P4 34, US 39
Our hand: Kokusho, the Evening Star, Massacre Wurm, Plaguecrafter, Braids, Arisen Nightmare
Our graveyard (5): Misty Rainforest, Mulldrifter, Forest, Shriekmaw, Soul-Guide Lantern
Board P1: 5 lands; Sol Ring (tapped 1), Bronzebeak Foragers 3/4, Pantlaza, Sun-Favored 4/4, Thrashing Brontodon 3/4
Board US: 6 lands; Vrock 3/3, The Death of Gwen Stacy {[LORE x 2]}
Board P3: 6 lands; Nazgûl 2/3 {[P1P1]} (tapped 1), Sauron, the Dark Lord 7/6, Orc Army Token 2/2 [token] {[P1P1 x 2]}
Board P4: 6 lands; no nonland permanents
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
PILOT OVERRULED FORGE (attack, COMBAT_DECLARE_ATTACKERS): chose [attack P3 (28 life)] instead of Forge's [attack P1 (34 life)]
PILOT OVERRULED FORGE (action, MAIN2): chose [cast Muldrotha, the Gravetide (from Command): Muldrotha, the Gravetide - Creature 6 / 6] instead of Forge's [cast Kokusho, the Evening Star (from Hand): Kokusho, the Evening Star - Creature 5 / 5]
PILOT OVERRULED FORGE (action, MAIN2): chose [play land Forest (from Graveyard): Play land by Muldrotha, the Gravetide (201) (Land)] instead of Forge's [play land Forest (from Graveyard): Play land by Muldrotha, the Gravetide (201) (Land)]
- US triggered The Death of Gwen Stacy
- attack: US assigned Vrock to attack P3.
- US cast Muldrotha, the Gravetide
- P3 triggered Sauron, the Dark Lord
- US cast Soul-Guide Lantern
- P3 triggered Sauron, the Dark Lord
- US triggered Soul-Guide Lantern targeting [Ghalta, Primal Hunger]
- left battlefield: Soul-Guide Lantern was put into Graveyard from Battlefield.
- US activated Soul-Guide Lantern
- US triggered Vrock

## Turn 27 (P3, round 7) | life: P1 29, P3 22, P4 34, US 39
- attack: P3 assigned Nazgûl to attack P1.
- P3 triggered The Ring
- P3 cast Orcish Siegemaster
- P3 cast Commander's Sphere

## Turn 28 (P4, round 7)

## Turn 29 (P1, round 8)
- left battlefield: Pantlaza, Sun-Favored was put into Graveyard from Battlefield.
- P1 cast Savage Order
- P3 triggered Sauron, the Dark Lord
- P3 cast Swan Song targeting [As an additional cost to cast this spell, sacrifice a creature with power 4 or greater.
- P1 cast Kinjalli's Sunwing
- P3 triggered Sauron, the Dark Lord

## Turn 30 (OUR TURN, round 8) | life: P1 24, P3 8, P4 31, US 39
Our hand: Kokusho, the Evening Star, Massacre Wurm, Braids, Arisen Nightmare, Woodland Cemetery
Our graveyard (6): Misty Rainforest, Mulldrifter, Shriekmaw, Plaguecrafter, Soul-Guide Lantern, The Death of Gwen Stacy
Board P1: 6 lands; Sol Ring (tapped 1), Bronzebeak Foragers 3/4, Thrashing Brontodon 3/4, Bird Token 2/2 [token], Kinjalli's Sunwing 2/3
Board US: 7 lands; Vrock 3/3, Muldrotha, the Gravetide 6/6
Board P3: 6 lands; Nazgûl 2/3 {[P1P1]} (tapped 1), Sauron, the Dark Lord 7/6, Orc Army Token 6/6 [token] {[P1P1 x 6]}, Orcish Siegemaster 0/5, Commander's Sphere (tapped 1)
Board P4: 6 lands; no nonland permanents
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Massacre Wurm (from Hand): Massacre Wurm - Creature 6 / 5 [Forge's heuristic AI would] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN2): chose [cast Shriekmaw (from Graveyard): Evoke {1}{B} (You may cast this spell for its evoke cost.] instead of Forge's [cast Shriekmaw (from Graveyard): Evoke {1}{B} (You may cast this spell for its evoke cost.]
- US triggered The Death of Gwen Stacy targeting [P1]
- left battlefield: The Death of Gwen Stacy was put into Graveyard from Battlefield.
- US cast Massacre Wurm
- P3 triggered Sauron, the Dark Lord
- US triggered Massacre Wurm
- US triggered Massacre Wurm
- attack: US assigned Vrock and Muldrotha, the Gravetide to attack P3.
- US cast Shriekmaw
- P3 triggered Sauron, the Dark Lord
- US triggered Shriekmaw targeting [Orcish Siegemaster]
- US triggered Shriekmaw
- left battlefield: Shriekmaw was put into Graveyard from Battlefield.
- left battlefield: Orcish Siegemaster was put into Graveyard from Battlefield.
- US triggered Massacre Wurm
- US triggered Vrock
- left battlefield: Commander's Sphere was put into Graveyard from Battlefield.
- P3 activated Commander's Sphere

## Turn 31 (P3, round 8) | life: P1 24, P3 8, P4 31, US 31
- attack: P3 assigned Orc Army Token to attack US.
- P3 triggered Sauron, the Dark Lord
- P3 triggered Sauron, the Dark Lord
- P3 triggered Nazgûl
- P3 cast Arcane Signet
Damage to US this turn: Orc Army Token (combat) 8

## Turn 32 (P4, round 8) | life: P1 24, P3 8, P4 30, US 31
- P4 cast Cultivate
- P3 triggered Sauron, the Dark Lord
- P4 cast Teval, the Balanced Scale
- P3 triggered Sauron, the Dark Lord

## Turn 33 (P1, round 9) | life: P1 24, P3 6, P4 30, US 31
- P1 cast Gishath, Sun's Avatar
- P3 triggered Sauron, the Dark Lord
- attack: P1 assigned Kinjalli's Sunwing to attack P3.

## Turn 34 (OUR TURN, round 9) | life: P1 21, P3 -1, P4 27, US 31
Our hand: Kokusho, the Evening Star, Braids, Arisen Nightmare, Watery Grave
Our graveyard (6): Misty Rainforest, Mulldrifter, Plaguecrafter, Soul-Guide Lantern, The Death of Gwen Stacy, Shriekmaw
Board P1: 7 lands; Sol Ring (tapped 1), Bronzebeak Foragers 3/4, Thrashing Brontodon 3/4, Kinjalli's Sunwing 2/3 (tapped 1), Gishath, Sun's Avatar 7/6
Board US: 8 lands; Vrock 3/3, Muldrotha, the Gravetide 6/6, Massacre Wurm 6/5
Board P3: 7 lands; Nazgûl 3/4 {[P1P1 x 2]}, Sauron, the Dark Lord 7/6, Orc Army Token 11/11 [token] {[P1P1 x 11]} (tapped 1), Arcane Signet
Board P4: 8 lands; Teval, the Balanced Scale 4/4 (tapped 1)
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
MEMO (executor escalation: us: nonland permanents 3→1 (-2); we lost: Massacre Wurm, Muldrotha, the Gravetide; our commander le):
You've hit your session limit · resets 6:40pm (UTC)
PILOT OVERRULED FORGE (action, MAIN1): chose [play land Watery Grave (from Hand): Play land] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
ESCALATION (p=0.93): us: nonland permanents 3→1 (-2); we lost: Massacre Wurm, Muldrotha, the Gravetide; our commander left the battlefield
PILOT OVERRULED FORGE (action, MAIN2): chose [cast Muldrotha, the Gravetide (from Command): Muldrotha, the Gravetide - Creature 6 / 6] instead of Forge's [cast Kokusho, the Evening Star (from Hand): Kokusho, the Evening Star - Creature 5 / 5]
- attack: US assigned Vrock, Muldrotha, the Gravetide and Massacre Wurm to attack P3.
- left battlefield: Muldrotha, the Gravetide was put into Graveyard from Battlefield.
- left battlefield: Massacre Wurm was put into Graveyard from Battlefield.
- left battlefield: Nazgûl was put into Graveyard from Battlefield.
- left battlefield: Sauron, the Dark Lord was put into Graveyard from Battlefield.
- US triggered Massacre Wurm
- US triggered Massacre Wurm
- P3 activated Barad-dûr
- US cast Muldrotha, the Gravetide
- US triggered Vrock

## Turn 35 (P4, round 9) | life: P1 17, P3 -1, P4 21, US 31
- P4 cast Reanimate targeting [Massacre Wurm]
- P4 triggered Massacre Wurm
- attack: P4 assigned Teval, the Balanced Scale to attack P1.
- P4 triggered Teval, the Balanced Scale
- P4 triggered Teval, the Balanced Scale

## Turn 36 (P1, round 9) | life: P1 29, P3 -1, P4 6, US 31
- attack: P1 assigned Bronzebeak Foragers, Thrashing Brontodon, Kinjalli's Sunwing and Gishath, Sun's Avatar to attack P4.
- P1 triggered Gishath, Sun's Avatar
- P1 triggered Vaultborn Tyrant
- P1 triggered Topiary Stomper
- P1 triggered Vaultborn Tyrant
- P1 triggered Vaultborn Tyrant
- P1 cast Zacama, Primal Calamity
- P1 triggered Vaultborn Tyrant
- P1 triggered Zacama, Primal Calamity
- P1 cast The Skullspore Nexus
- P1 cast Temple Altisaur

## Turn 37 (OUR TURN, round 10) | life: P1 29, P3 -1, P4 -3, US 30
Our hand: Kokusho, the Evening Star, Braids, Arisen Nightmare, Mind Stone
Our graveyard (6): Misty Rainforest, Mulldrifter, Plaguecrafter, Soul-Guide Lantern, The Death of Gwen Stacy, Shriekmaw
Board P1: 8 lands; Sol Ring (tapped 1), Bronzebeak Foragers 3/4 (tapped 1), Thrashing Brontodon 3/4 (tapped 1), Kinjalli's Sunwing 2/3 (tapped 1), Gishath, Sun's Avatar 7/6, Curious Altisaur 2/5, Scion of Calamity 5/5, Topiary Stomper 4/4, Vaultborn Tyrant 6/6, Zacama, Primal Calamity 9/9, The Skullspore Nexus, Temple Altisaur 3/4
Board US: 9 lands; Vrock 3/3, Muldrotha, the Gravetide 6/6
Board P4: 10 lands; Teval, the Balanced Scale 4/4 (tapped 1), Massacre Wurm 6/5 (tapped 1), Zombie Druid Token 2/2 [token] (tapped 1)
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
PILOT OVERRULED FORGE (action, MAIN1): chose [play land Misty Rainforest (from Graveyard): Play land by Muldrotha, the Gravetide (201) (] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (search, MAIN1): chose [Breeding Pool — Land - Forest Island — ({T}: Add {G} or {U}.) As Breeding Pool enters, you] instead of Forge's [Underground Sea — Land - Island Swamp — ({T}: Add {U} or {B}.)]
PILOT OVERRULED FORGE (attack, COMBAT_DECLARE_ATTACKERS): chose [attack P4 (6 life)] instead of Forge's [don't attack with it]
PILOT OVERRULED FORGE (attack, COMBAT_DECLARE_ATTACKERS): chose [attack P4 (6 life)] instead of Forge's [don't attack with it]
- left battlefield: Misty Rainforest was put into Graveyard from Battlefield.
- US activated Misty Rainforest
- attack: US assigned Vrock and Muldrotha, the Gravetide to attack P4.
- left battlefield: Massacre Wurm was put into Exile from Battlefield.
- US cast Mulldrifter
- US triggered Mulldrifter
- US cast The Death of Gwen Stacy
- US triggered The Death of Gwen Stacy targeting [Zacama, Primal Calamity]
- left battlefield: Zacama, Primal Calamity was put into Graveyard from Battlefield.
- P1 triggered The Skullspore Nexus
- P1 triggered Vaultborn Tyrant
- US cast Soul-Guide Lantern
- US triggered Soul-Guide Lantern targeting [Zacama, Primal Calamity]
- left battlefield: Soul-Guide Lantern was put into Graveyard from Battlefield.
- US activated Soul-Guide Lantern
- US triggered Vrock

## Turn 38 (P1, round 10) | life: P1 29, P3 -1, P4 -3, US -14
- P1 cast Nature's Lore
- attack: P1 assigned Fungus Dinosaur Token, Gishath, Sun's Avatar, Vaultborn Tyrant, Scion of Calamity, Topiary Stomper, Bronzebeak Foragers, Thrashing Brontodon, Temple Altisaur, Kinjalli's Sunwing and Curious Altisaur to attack US.
- P1 triggered Scion of Calamity
- Game Outcome: P1 has won because all opponents have lost
- Game Outcome: US has lost because life total reached 0
- Game Outcome: P3 has lost because life total reached 0
- Game Outcome: P4 has lost because life total reached 0
Damage to US this turn: Fungus Dinosaur Token (combat) 9, Gishath, Sun's Avatar (combat) 7, Vaultborn Tyrant (combat) 6, Scion of Calamity (combat) 5, Topiary Stomper (combat) 4, Bronzebeak Foragers (combat) 3, Thrashing Brontodon (combat) 3, Temple Altisaur (combat) 3, Kinjalli's Sunwing (combat) 2, Curious Altisaur (combat) 2