# pod02-g1: we are P4; opponents P1 Teval, the Balanced Scale, P2 Hearthhull, the Worldseed, P3 Giada, Font of Hope
Result: Turn 21; P1 has lost because life total reached 0; P2 has lost because life total reached 0; P3 has lost because life total reached 0; US has won because all opponents have lost

## Turn 1 (P3, round 1)
- P3 cast Sol Ring

## Turn 2 (OUR TURN, round 1)
Our hand: Twisted Embrace, Tropical Island, Barrin, Master Wizard, Counterspell, Woodland Cemetery, Plaguecrafter, Ratchet Bomb, Cryogen Relic
Our graveyard (0): 
Board P1: 0 lands; no nonland permanents
Board P2: 0 lands; no nonland permanents
Board P3: 1 lands; Sol Ring
Board US: 0 lands; no nonland permanents
MEMO (start of our turn):
THIS TURN: Play Tropical Island (it enters untapped). There are no 1-mana plays, so pass. Next turn, play Woodland Cemetery; it enters untapped because Trop is a Forest. Then cast Cryogen Relic ({1}{U}) to draw toward land 3. Only Trop makes blue, so Counterspell and Barrin (UU) can't be cast yet.

TARGET: Muldrotha out by turn 5-6, with Relic, Ratchet Bomb and Executioner's Capsule cycling through the artifact lane. Priority draws: a third and fourth land (a blue source for UU), Arcane Signet, Talisman of Dominance, Sakura-Tribe Elder, Farseek.

WIN PATH: Control the table, then close with Muldrotha plus Gray Merchant or Syr Konrad drains. That is roughly turn 12+. P2 and P3 clock turns 6-8, so our early job is only to slow them.

THREATS & ANSWERS:
1. P3 Giada (Sol Ring start). Plaguecrafter on our turn 3 if she's their only creature. Otherwise Twisted Embrace on Relic (turn 4). Ratchet Bomb ticked to 2 also hits her.
2. P2 Hearthhull (a noncreature artifact while under 8 counters). Ratchet Bomb ticked to 4, or later Assassin's Trophy or a Seal.
3. P1 Teval. Twisted Embrace or Plaguecrafter.
Don't give P3 any lifegain.

HOLD: Counterspell until we have two blue sources; then keep UU up for a wipe (Living Death, Blasphemous Act, Farewell) or Hearthhull. Keep Twisted Embrace for Giada, Teval or an Angel, not a mana dork. Deploy Ratchet Bomb early and tick it toward the best MV.

REPLAN IF: Giada gets protection (Greaves, Safekeeper), a second Angel lands, P1 or P2 ramp hard to 5+ mana by turn 3, or we miss land drop 3.

## Turn 3 (P1, round 1)

## Turn 4 (P2, round 1)
- P2 cast Zuran Orb
- P2 cast Sol Ring

## Turn 5 (P3, round 2)
- P3 cast Giada, Font of Hope

## Turn 6 (OUR TURN, round 2)
Our hand: Twisted Embrace, Barrin, Master Wizard, Counterspell, Woodland Cemetery, Plaguecrafter, Ratchet Bomb, Cryogen Relic, Marsh Flats
Our graveyard (0): 
Board P1: 1 lands; no nonland permanents
Board P2: 1 lands; Zuran Orb, Sol Ring
Board P3: 2 lands; Sol Ring (tapped 1), Giada, Font of Hope 2/2
Board US: 1 lands; no nonland permanents
MEMO (start of our turn):
THIS TURN: Play Woodland Cemetery (it enters untapped because Trop is a Forest). Cast Ratchet Bomb ({2}: Trop plus Cemetery) and tap it right away to put on charge counter 1. Artifacts have no summoning sickness. Next turn, play Marsh Flats and fetch Underground Sea (untapped, gives U and B). Then pop Bomb at 1, which kills both Sol Rings. Then cast Plaguecrafter ({2}{B}) if Giada is P3's only creature; P1 and P2 each discard.

TARGET: By turn 4-5: 5 lands, Muldrotha out, and Bomb, Relic and Executioner's Capsule cycling through the artifact lane. Missing pieces: lands (Zagoth Triome, Watery Grave), Arcane Signet, Talisman of Dominance, Sakura-Tribe Elder.

WIN PATH: Grind with recurring removal, then drain with Gray Merchant or Syr Konrad plus Muldrotha beats. That is roughly turn 12+. P2 and P3 clock turns 6-8, so we slow them now.

THREATS & ANSWERS:
1. P3 Giada: Plaguecrafter next turn, or Twisted Embrace ({2}{B}{B}, turn 4). Never give P3 life.
2. P2 Hearthhull (MV4, a noncreature artifact): Counterspell it if possible. Later, Assassin's Trophy or Seal of Primordium.
3. P2 Zuran Orb: the Bomb recast at 0 once Muldrotha is out.
4. P1 Teval: Twisted Embrace. Plaguecrafter only if Teval is their sole creature.

HOLD: Counterspell until we have UU (Trop plus Underground Sea). Save it for Hearthhull, Living Death, Blasphemous Act or Farewell. Keep Twisted Embrace for Giada, Teval or an Angel. Keep Cryogen Relic for Muldrotha's artifact lane.

REPLAN IF: A second Angel lands, or Giada gets Greaves or Safekeeper (then Embrace rather than Plaguecrafter). Also if P2 casts Hearthhull early, or if a new 1-drop makes popping the Bomb at 1 a bigger or smaller hit.
- US cast Ratchet Bomb
- US activated Ratchet Bomb

## Turn 7 (P1, round 2)
- P1 cast Nature's Lore

## Turn 8 (P2, round 2)
- left battlefield: Fabled Passage was put into Graveyard from Battlefield.
- P2 activated Fabled Passage
- P2 cast Ramunap Excavator

## Turn 9 (P3, round 3) | life: P2 37
- P3 cast Thraben Watcher
- attack: P3 assigned Giada, Font of Hope to attack P2.

## Turn 10 (OUR TURN, round 3) | life: P2 37, US 39
Our hand: Twisted Embrace, Barrin, Master Wizard, Counterspell, Plaguecrafter, Cryogen Relic, Marsh Flats, Forest
Our graveyard (0): 
Board P1: 3 lands; no nonland permanents
Board P2: 2 lands; Zuran Orb, Sol Ring (tapped 1), Ramunap Excavator 2/3
Board P3: 3 lands; Sol Ring (tapped 1), Giada, Font of Hope 3/3, Thraben Watcher 3/3 {[P1P1]}
Board US: 2 lands; Ratchet Bomb {[CHARGE]}
MEMO (start of our turn):
THIS TURN: 1) Play Marsh Flats, pay 1 life, fetch Underground Sea (untapped). 2) Tap and sacrifice Ratchet Bomb at 1 counter; it destroys both Sol Rings (P2, P3). 3) Cast Plaguecrafter ({2}{B}: Cemetery B plus Trop and Sea). P1 has no creature, so P1 discards. P2 loses Ramunap. P3 loses Watcher or Giada. We sacrifice Plaguecrafter itself. We are tapped out; no instant plans this round.

TARGET: Next turn play Forest and cast Cryogen Relic ({1}{U}) as a host. Then cast Twisted Embrace on Relic to kill Giada, Teval or an Angel. Muldrotha at 6 mana, recurring Bomb, Plaguecrafter and Relic. Missing pieces: lands (Zagoth Triome, Watery Grave), Arcane Signet, Talisman of Dominance, Executioner's Capsule.

WIN PATH: Grind with the recurring Bomb, Plaguecrafter and Capsule. Close with Gray Merchant, Syr Konrad or Massacre Wurm plus Muldrotha beats, around turn 14+. P2 and P3 clock turns 6-8, but losing their Sol Rings slows both.

THREATS & ANSWERS:
1. P3 Giada or any new Angel: Twisted Embrace. Never give P3 life.
2. P2 Hearthhull (noncreature artifact): Counterspell. Later Assassin's Trophy or Seal of Primordium. Zuran Orb (MV0): Bomb at 0 via Muldrotha.
3. P1 Teval (likely next turn): Twisted Embrace. Barrin can bounce it as a stopgap.

HOLD: Counterspell for Hearthhull, Living Death, Blasphemous Act or Farewell; keep UU (Trop plus Sea) open when possible. Twisted Embrace until we control a host and have {2}{B}{B}. Barrin as the outlet for Muldrotha turns.

REPLAN IF: P3 sacrifices Giada and keeps Watcher (Embrace the Watcher next). Also if Hearthhull or Teval resolves, a wipe hits, or someone plays 3+ tokens (then Bomb at 0).
PILOT OVERRULED FORGE (action, MAIN1): chose [play land Marsh Flats (from Hand): Play land] instead of Forge's [play land Forest (from Hand): Play land]
PILOT OVERRULED FORGE (action, MAIN1): chose [activate Ratchet Bomb (from Battlefield): {T}, Sacrifice Ratchet Bomb: Destroy each nonlan] instead of Forge's [activate Marsh Flats (from Battlefield): {T}, Pay 1 life, Sacrifice Marsh Flats: Search yo]
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Plaguecrafter (from Hand): Plaguecrafter - Creature 3 / 2 [Forge's heuristic AI would] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
- left battlefield: Ratchet Bomb was put into Graveyard from Battlefield.
- US activated Ratchet Bomb
- left battlefield: Sol Ring was put into Graveyard from Battlefield.
- left battlefield: Sol Ring was put into Graveyard from Battlefield.
- left battlefield: Marsh Flats was put into Graveyard from Battlefield.
- US activated Marsh Flats
- US cast Plaguecrafter
- US triggered Plaguecrafter
- left battlefield: Plaguecrafter was put into Graveyard from Battlefield.
- left battlefield: Ramunap Excavator was put into Graveyard from Battlefield.
- left battlefield: Thraben Watcher was put into Graveyard from Battlefield.

## Turn 11 (P1, round 3)
- P1 cast Assassin's Trophy targeting [Giada, Font of Hope]
- left battlefield: Giada, Font of Hope was put into Graveyard from Battlefield.

## Turn 12 (P2, round 3) | life: P2 38, US 39
- P2 triggered Maestros Theater
- left battlefield: Maestros Theater was put into Graveyard from Battlefield.
- P2 triggered Maestros Theater
- P2 cast Aftermath Analyst
- P2 triggered Aftermath Analyst

## Turn 13 (P3, round 4)
- P3 cast Gisela, the Broken Blade

## Turn 14 (OUR TURN, round 4)
Our hand: Twisted Embrace, Barrin, Master Wizard, Counterspell, Cryogen Relic, Forest, Assassin's Trophy
Our graveyard (3): Ratchet Bomb, Marsh Flats, Plaguecrafter
Board P1: 4 lands; no nonland permanents
Board P2: 3 lands; Zuran Orb, Aftermath Analyst 1/3
Board P3: 4 lands; Gisela, the Broken Blade 4/3
Board US: 3 lands; no nonland permanents
MEMO (start of our turn):
THIS TURN: 1) Cast Cryogen Relic first ({1}{U}: Tropical Island for U, Woodland Cemetery for the 1) and draw. 2) Play Forest as the land drop, or a better untapped dual you just drew. Keep Underground Sea (B) plus Forest (G) open for Assassin's Trophy. 3) If you drew Sol Ring, cast it with the spare mana. Otherwise pass with Trophy up. On opponents' turns, Trophy the first of: Hearthhull, Teval, Teval's Judgment, Archangel of Thune. Trophy cannot kill Avacyn (indestructible).

TARGET: Next turn: Twisted Embrace on Relic ({2}{B}{B}: Cemetery and Sea for BB) to kill Gisela or Teval. Then reach 6 mana for Muldrotha to recur Bomb, Plaguecrafter, Relic and Embrace. Missing pieces: 2 lands, or Sol Ring, Arcane Signet or Talisman of Dominance; also Executioner's Capsule.

WIN PATH: Recur removal to lock the board, then close with Gray Merchant, Syr Konrad or Massacre Wurm plus Muldrotha beats. We're slower than P2 and P3; our ramp lags.

THREATS & ANSWERS:
1. P2 Hearthhull (with Zuran Orb it drains 2 per land): Trophy now; Counterspell once we hold UU.
2. P1 Teval (4 lands, castable next turn): Trophy, or Embrace next turn.
3. P3 Gisela (4 flying lifelink) and new Angels: Embrace next turn. Never give P3 life.
- Zuran Orb: Ratchet Bomb at 0 once Muldrotha is out.

HOLD: Trophy mana (Sea plus Forest) through all three opponents' turns. Hold Barrin; he's the outlet for Muldrotha turns, and don't expose him to Blasphemous Act. Hold Counterspell for Living Death, Blasphemous Act, Farewell or Hearthhull.

REPLAN IF: Relic is countered. Hearthhull or Teval resolves and Trophy is spent. A wipe hits. Anyone makes 3+ tokens. Gisela melds into Brisela.
PILOT OVERRULED FORGE (action, DRAW): chose [Zuran Orb [P2]] instead of Forge's [Gisela, the Broken Blade [P3, 4/3]]
- US cast Assassin's Trophy targeting [Zuran Orb]
- left battlefield: Zuran Orb was put into Graveyard from Battlefield.
- US cast Cryogen Relic
- US triggered Cryogen Relic

## Turn 15 (P1, round 4)
- P1 triggered Golgari Rot Farm
- P1 cast Stitcher's Supplier
- P1 triggered Stitcher's Supplier

## Turn 16 (P2, round 4)
- P2 cast Tannuk, Memorial Ensign

## Turn 17 (P3, round 5) | life: P2 34, P3 45, US 39
- P3 cast Angel of Vitality
- attack: P3 assigned Gisela, the Broken Blade to attack P2.
- P3 cast Authority of the Consuls

## Turn 18 (OUR TURN, round 5) | life: P1 38, P2 32, P3 45, US 38
Our hand: Twisted Embrace, Barrin, Master Wizard, Counterspell, Wooded Foothills, Braids, Arisen Nightmare
Our graveyard (4): Ratchet Bomb, Marsh Flats, Plaguecrafter, Assassin's Trophy
Board P1: 4 lands; Stitcher's Supplier 1/1
Board P2: 4 lands; Aftermath Analyst 1/3, Tannuk, Memorial Ensign 2/4
Board P3: 4 lands; Gisela, the Broken Blade 4/3 (tapped 1), Angel of Vitality 4/4, Authority of the Consuls
Board US: 4 lands; Cryogen Relic
MEMO (start of our turn):
THIS TURN: 1) Crack Wooded Foothills (1 life) for Bayou, which enters untapped. 2) Cast Braids ({1}{B}{B}): Bayou B, Woodland Cemetery B, Forest 1. Authority makes Braids enter tapped and gains P3 1 life; accept it. 3) Keep Tropical Island and Underground Sea up for Counterspell. 4) End step: Braids sacrifices Cryogen Relic. Relic draws 1. No opponent has an artifact, so each loses 2 and we draw 3. Relic lands in the graveyard for Muldrotha.

TARGET: Next turn, land drop to reach 6 lands, then Muldrotha ({3}{B}{G}{U}). Recur Relic or Ratchet Bomb, Plaguecrafter and Marsh Flats each turn, with Braids sacrificing an artifact every end step. If we lack 6 lands, cast Twisted Embrace on Braids to kill Gisela. Missing: lands, Sol Ring, Arcane Signet, Talisman, Executioner's Capsule.

WIN PATH: The Braids artifact sacrifice drains about 6 a turn and draws 3. Add Gray Merchant, Syr Konrad and Muldrotha beats. Demonic Tutor finds Gray Merchant. Close in about 5 turns. The opponents' clocks are slower than ours right now.

THREATS & ANSWERS: 1) P1 Teval (castable now, 5 mana): Counterspell it, or Embrace. 2) P2 Hearthhull (an artifact, so Embrace can't hit it): Counterspell it, or Ratchet Bomb at 4 later. 3) P3 Gisela and Angel of Vitality: Embrace kills Gisela first. 4) Giada recast: Plaguecrafter or Embrace. Never give P3 life beyond Authority's triggers.

HOLD: Counterspell (UU) through all opponents' turns. Spend it on Teval, Hearthhull, Living Death, Blasphemous Act or Farewell, in that order of need. Hold Barrin and Embrace for next turn.

REPLAN IF: Braids is countered or removed. An opponent plays an artifact before our end step (then sacrifice Relic anyway). Counterspell gets spent. A wipe resolves. Gisela melds.
PILOT OVERRULED FORGE (search, MAIN1): chose [Bayou — Land - Swamp Forest — ({T}: Add {B} or {G}.)] instead of Forge's [Zagoth Triome — Land - Swamp Forest Island — ({T}: Add {B}, {G}, or {U}.) Zagoth Triome en]
- left battlefield: Wooded Foothills was put into Graveyard from Battlefield.
- US activated Wooded Foothills
- US cast Braids, Arisen Nightmare
- P3 triggered Authority of the Consuls
- US triggered Braids, Arisen Nightmare
- left battlefield: Cryogen Relic was put into Graveyard from Battlefield.
- US triggered Cryogen Relic

## Turn 19 (P1, round 5) | life: P1 38, P2 32, P3 47, US 38
- P1 cast Teval, the Balanced Scale
- P3 triggered Authority of the Consuls
- P1 cast Insidious Roots

## Turn 20 (P2, round 5) | life: P1 38, P2 32, P3 49, US 38
- P2 cast Mayhem Devil
- P3 triggered Authority of the Consuls

## Turn 21 (P3, round 6) | life: P1 38, P2 24, P3 58, US 38
- P3 cast Stroke of Midnight targeting [Teval, the Balanced Scale]
- left battlefield: Teval, the Balanced Scale was put into Graveyard from Battlefield.
- P3 triggered Authority of the Consuls
- P1 triggered Insidious Roots
- P3 triggered Authority of the Consuls
- attack: P3 assigned Gisela, the Broken Blade and Angel of Vitality to attack P2.

## Turn 22 (OUR TURN, round 6) | life: P1 36, P2 22, P3 56, US 39
Our hand: Twisted Embrace, Barrin, Master Wizard, Counterspell, Soul-Guide Lantern, Vraska, Golgari Queen, Otawara, Soaring City, Nature's Lore, Syr Konrad, the Grim
Our graveyard (6): Ratchet Bomb, Marsh Flats, Plaguecrafter, Assassin's Trophy, Wooded Foothills, Cryogen Relic
Board P1: 5 lands; Stitcher's Supplier 1/1, Insidious Roots, Human Token 1/1 [token] (tapped 1), Plant Token 1/2 [token] {[P1P1]} (tapped 1)
Board P2: 4 lands; Aftermath Analyst 1/3, Tannuk, Memorial Ensign 2/4, Mayhem Devil 3/3 (tapped 1)
Board P3: 4 lands; Gisela, the Broken Blade 4/3 (tapped 1), Angel of Vitality 4/4 (tapped 1), Authority of the Consuls
Board US: 5 lands; Braids, Arisen Nightmare 3/3
MEMO (start of our turn):
THIS TURN: 1) Play Otawara as the land drop. 2) Cast Nature's Lore (Forest + Bayou) and fetch Zagoth Triome. It enters tapped, which is fine and costs no life. 3) Cast Soul-Guide Lantern (Woodland Cemetery). Its enter trigger exiles Life from the Loam, Dread Return or a land from P1's yard. A creature card there only if it's a reanimation fatty, since that feeds Insidious Roots. Otherwise take a land from P2's yard. 4) Keep Tropical Island and Underground Sea up for Counterspell. 5) End step: Braids sacrifices Lantern. No opponent has an artifact, so each loses 2 and we draw 3. Mayhem Devil gets one ping; accept it.

TARGET: Next turn we have 7 lands plus Marsh Flats from the graveyard, so 8 mana. Cast Muldrotha (6), then Cryogen Relic or Lantern from the graveyard (1-2). Braids sacrifices an artifact every end step. After that: Plaguecrafter, Ratchet Bomb, Vraska. Missing: Executioner's Capsule, Gray Merchant, Sol Ring.

WIN PATH: Braids drains 6 and draws 3 per turn. Add Syr Konrad pings, Gray Merchant and Muldrotha beats. About 5 turns; no opponent is faster right now.

THREATS & ANSWERS:
1) P1 Teval recast (P1 has 7 mana and plays next): Counterspell. Insidious Roots: Vraska −3.
2) P3 Gisela plus Angel of Vitality, 8 flying: Twisted Embrace on Braids kills Gisela next turn. A Giada recast: Plaguecrafter.
3) P2 Mayhem Devil, which pings on every sacrifice: Vraska −3. Hearthhull: Counterspell if still up, or Ratchet Bomb at 4. Embrace can't hit Hearthhull.
Give P3 no lifegain.

HOLD: Counterspell (UU) for Teval, Living Death, Farewell or Blasphemous Act. Keep Barrin, Syr Konrad, Vraska and Embrace in hand, safe from a wipe.

REPLAN IF: Teval resolves, a wipe resolves, Counterspell is spent, an opponent plays an artifact before our end step, Braids dies, or Gisela melds.
PILOT OVERRULED FORGE (attack, COMBAT_DECLARE_ATTACKERS): chose [don't attack with it] instead of Forge's [attack P3 (58 life)]
PILOT OVERRULED FORGE (action, MAIN2): chose [activate Vraska, Golgari Queen (from Battlefield): +2: You may sacrifice another permanent] instead of Forge's [activate Vraska, Golgari Queen (from Battlefield): -3: Destroy target nonland permanent wi]
- US cast Nature's Lore
- US cast Vraska, Golgari Queen
- US activated Vraska, Golgari Queen
- left battlefield: Forest was put into Graveyard from Battlefield.
- P2 triggered Mayhem Devil targeting [Human Token]
- US triggered Braids, Arisen Nightmare
- left battlefield: Braids, Arisen Nightmare was put into Graveyard from Battlefield.
- P2 triggered Mayhem Devil targeting [Stitcher's Supplier]
- left battlefield: Stitcher's Supplier was put into Graveyard from Battlefield.
- P1 triggered Stitcher's Supplier

## Turn 23 (P1, round 6) | life: P1 36, P2 22, P3 58, US 39
- attack: P1 assigned Plant Token to attack Vraska, Golgari Queen.
- P1 cast Teval, the Balanced Scale
- P3 triggered Authority of the Consuls

## Turn 24 (P2, round 6) | life: P1 35, P2 22, P3 59, US 37
- P2 triggered Tannuk, Memorial Ensign
- attack: P2 assigned Aftermath Analyst to attack US.
- left battlefield: Vraska, Golgari Queen was put into Graveyard from Battlefield.
- P2 cast Scute Swarm
- P3 triggered Authority of the Consuls
Damage to US this turn: Tannuk, Memorial Ensign (non-combat) 1, Aftermath Analyst (combat) 1

## Turn 25 (P3, round 7) | life: P1 27, P2 22, P3 68, US 37
- P3 cast Generous Gift targeting [Teval, the Balanced Scale]
- left battlefield: Teval, the Balanced Scale was put into Graveyard from Battlefield.
- P3 triggered Authority of the Consuls
- P1 triggered Insidious Roots
- P3 triggered Authority of the Consuls
- attack: P3 assigned Gisela, the Broken Blade and Angel of Vitality to attack P1.

## Turn 26 (OUR TURN, round 7) | life: P1 27, P2 22, P3 70, US 37
Our hand: Twisted Embrace, Barrin, Master Wizard, Counterspell, Syr Konrad, the Grim, Hostage Taker, Invasion of Innistrad, Spore Frog, Overgrown Tomb
Our graveyard (12): Ratchet Bomb, Marsh Flats, Plaguecrafter, Assassin's Trophy, Wooded Foothills, Cryogen Relic, Nature's Lore, Forest, Braids, Arisen Nightmare, Boseiju, Who Endures, Soul-Guide Lantern, Vraska, Golgari Queen
Board P1: 5 lands; Insidious Roots, Plant Token 2/3 [token] {[P1P1 x 2]} (tapped 1), Elephant Token 3/3 [token] (tapped 1), Plant Token 1/2 [token] {[P1P1]} (tapped 1)
Board P2: 5 lands; Aftermath Analyst 1/3 (tapped 1), Tannuk, Memorial Ensign 2/4 (tapped 1), Mayhem Devil 3/3 (tapped 1), Scute Swarm 1/1 (tapped 1)
Board P3: 5 lands; Gisela, the Broken Blade 4/3 (tapped 1), Angel of Vitality 4/4 (tapped 1), Authority of the Consuls
Board US: 6 lands; no nonland permanents
MEMO (start of our turn):
THIS TURN: 1) Cast Muldrotha (6): Triome for U, Woodland Cemetery for B, Bayou for G, plus Tropical Island, Underground Sea and Otawara. She enters tapped (Authority) and P3 gains 1; accept that. 2) Land drop: Marsh Flats from our graveyard, then fetch a basic Swamp (1 life). Mayhem Devil pings; accept it. Keep Overgrown Tomb in hand. 3) Cast Soul-Guide Lantern from the graveyard using the Swamp. Exile Life from the Loam, Dread Return or a reanimation fatty from P1's yard; otherwise take a key land from P2's yard. No Counterspell mana this turn.

TARGET: Next turn we have 8 mana (7 lands plus Flats again). Cast Braids (3) and Vraska (4) from the graveyard, and use Vraska −3 on Mayhem Devil or Insidious Roots. Then Ratchet Bomb, and Embrace on Muldrotha. Missing: Executioner's Capsule, Gray Merchant, Claws of Gix, Sol Ring.

WIN PATH: Braids drains 6 per end step, plus Syr Konrad pings, Gray Merchant and Muldrotha beats. About 5 turns. P2's Scute Swarm is the fastest risk.

THREATS & ANSWERS:
1) Teval recast (costs 8; P1 has 9 with tokens): Invasion of Innistrad (flash, 4) or Hostage Taker. Roots: Vraska −3.
2) Scute Swarm goes exponential at P2's 6th land: Vraska −3 or Plaguecrafter now. Ratchet Bomb at 0 for insect tokens, at 3 for the Swarm copies, Devil and Tannuk.
3) Gisela plus Angel of Vitality: Twisted Embrace on Muldrotha, or Hostage Taker. Give P3 no lifegain.

HOLD: Lantern stays on board. Tap-sacrifice it at instant speed to exile opponents' graveyards against Living Death or Splendid Reclamation; never sacrifice it just to draw. Keep Counterspell, Syr Konrad, Hostage Taker, Barrin and Embrace in hand, away from Blasphemous Act or Farewell.

REPLAN IF: Muldrotha dies or is exiled, Teval resolves, a wipe resolves, P2 hits 6 lands with the Swarm, or Gisela melds.
- US cast Muldrotha, the Gravetide
- P3 triggered Authority of the Consuls

## Turn 27 (P1, round 7) | life: P1 27, P2 22, P3 66, US 37
- attack: P1 assigned Elephant Token, Plant Token and Plant Token to attack P3.
- P1 cast Ob Nixilis, the Fallen
- P3 triggered Authority of the Consuls

## Turn 28 (P2, round 7) | life: P1 19, P2 22, P3 68, US 37
- attack: P2 assigned Mayhem Devil, Tannuk, Memorial Ensign, Aftermath Analyst and Scute Swarm to attack P1.
- P2 cast Korvold, Fae-Cursed King
- P2 triggered Korvold, Fae-Cursed King
- P3 triggered Authority of the Consuls
- left battlefield: Aftermath Analyst was put into Graveyard from Battlefield.
- P2 triggered Mayhem Devil targeting [P1]
- P2 triggered Korvold, Fae-Cursed King

## Turn 29 (P3, round 8) | life: P1 11, P2 22, P3 73, US 37
- attack: P3 assigned Gisela, the Broken Blade and Angel of Vitality to attack P1.
- P3 cast Smothering Tithe

## Turn 30 (OUR TURN, round 8) | life: P1 0, P2 17, P3 72, US 37
Our hand: Twisted Embrace, Barrin, Master Wizard, Counterspell, Syr Konrad, the Grim, Hostage Taker, Invasion of Innistrad, Spore Frog, Baba Lysaga, Night Witch
Our graveyard (12): Ratchet Bomb, Marsh Flats, Plaguecrafter, Assassin's Trophy, Wooded Foothills, Cryogen Relic, Nature's Lore, Forest, Braids, Arisen Nightmare, Boseiju, Who Endures, Soul-Guide Lantern, Vraska, Golgari Queen
Board P1: 5 lands; Insidious Roots, Plant Token 2/3 [token] {[P1P1 x 2]} (tapped 1), Elephant Token 3/3 [token] (tapped 1), Plant Token 1/2 [token] {[P1P1]} (tapped 1), Ob Nixilis, the Fallen 3/3 (tapped 1)
Board P2: 5 lands; Tannuk, Memorial Ensign 2/4 (tapped 1), Mayhem Devil 3/3 (tapped 1), Scute Swarm 1/1 (tapped 1), Korvold, Fae-Cursed King 5/5 {[P1P1]} (tapped 1)
Board P3: 5 lands; Gisela, the Broken Blade 4/3 (tapped 1), Angel of Vitality 4/4 (tapped 1), Authority of the Consuls, Smothering Tithe
Board US: 7 lands; Muldrotha, the Gravetide 6/6
MEMO (start of our turn):
THIS TURN: P1 (11 life) is fully tapped out, so we have lethal. Decline the Tithe {2} (we need all 8 mana). 1) Land drop: Forest from our graveyard. 2) Attack P1 with Muldrotha: no untapped blockers, 6 damage, P1 goes to 5. 3) Postcombat: cast Syr Konrad ({3}{B}{B}). 4) Cast Plaguecrafter from our graveyard ({2}{B}). Leaving our graveyard pings 1. Everyone sacrifices a creature and we sacrifice Plaguecrafter: 4 deaths, 4 pings. That is 5 to each opponent and kills P1. Ignore Mayhem Devil pings and P3's Authority lifegain.

TARGET: Muldrotha, Konrad and Braids, with Vraska and Ratchet Bomb recast from the graveyard each turn. Missing: Gray Merchant and Executioner's Capsule (Demonic Tutor can find them).

WIN PATH: Kill P1 now. P2 drops to 17: close with Konrad pings, Braids drains and Baba Lysaga (sacrifice land + artifact + creature for 3 each), then Gray Merchant. P3 (68+) is the long game. P2's clock is fastest.

THREATS & ANSWERS: 1) Korvold: Twisted Embrace or Hostage Taker next turn, or Invasion at flash. 2) Mayhem Devil (it feeds on our sacrifices): Vraska −3 before any Baba or Braids loops. 3) Scute Swarm at 6 lands: Ratchet Bomb at 3 hits the Swarm copies, Devil, Tannuk and Angel of Vitality. 4) Gisela: Hostage Taker.

HOLD: Counterspell, Invasion, Embrace, Hostage Taker, Barrin, Baba, Spore Frog. No mana remains this turn anyway.

REPLAN IF: Muldrotha is removed in combat: cast Hostage Taker on Korvold and keep Counterspell up. Konrad is removed before Plaguecrafter resolves: P1 survives, so finish P1 next turn.
PILOT OVERRULED FORGE (action, MAIN1): chose [play land Forest (from Graveyard): Play land by Muldrotha, the Gravetide (403) (Land)] instead of Forge's [play land Boseiju, Who Endures (from Graveyard): Play land by Muldrotha, the Gravetide (40]
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Syr Konrad, the Grim (from Hand): Syr Konrad, the Grim - Creature 5 / 4 [Forge's heur] instead of Forge's [cast Hostage Taker (from Hand): Hostage Taker - Creature 2 / 3]
- P3 triggered Smothering Tithe
- US cast Syr Konrad, the Grim
- P3 triggered Authority of the Consuls
- attack: US assigned Muldrotha, the Gravetide to attack P1.
- US cast Plaguecrafter
- US triggered Syr Konrad, the Grim
- US triggered Plaguecrafter
- P3 triggered Authority of the Consuls
- left battlefield: Plaguecrafter was put into Graveyard from Battlefield.
- left battlefield: Scute Swarm was put into Graveyard from Battlefield.
- left battlefield: Angel of Vitality was put into Graveyard from Battlefield.
- US triggered Syr Konrad, the Grim
- US triggered Syr Konrad, the Grim
- US triggered Syr Konrad, the Grim
- US triggered Syr Konrad, the Grim
- P2 triggered Mayhem Devil targeting [P1]
- P2 triggered Mayhem Devil targeting [P1]
- P2 triggered Mayhem Devil targeting [P1]
- P2 triggered Mayhem Devil targeting [P1]
- P2 triggered Korvold, Fae-Cursed King
- P3 triggered Smothering Tithe

## Turn 31 (P2, round 8) | life: P1 0, P2 17, P3 57, US 33
- P3 triggered Smothering Tithe
- P2 cast Conduit of Worlds
- P2 triggered Tannuk, Memorial Ensign
- left battlefield: Fabled Passage was put into Graveyard from Battlefield.
- P2 activated Fabled Passage
- P2 triggered Mayhem Devil targeting [P4]
- P2 triggered Korvold, Fae-Cursed King
- P3 triggered Smothering Tithe
- P2 triggered Tannuk, Memorial Ensign
- P3 triggered Smothering Tithe
- P2 cast Tear Asunder targeting [Smothering Tithe] []
- left battlefield: Smothering Tithe was put into Exile from Battlefield.
- attack: P2 assigned Korvold, Fae-Cursed King, Mayhem Devil and Tannuk, Memorial Ensign to attack P3.
- P2 triggered Korvold, Fae-Cursed King
- left battlefield: Conduit of Worlds was put into Graveyard from Battlefield.
- P2 triggered Mayhem Devil targeting [P4]
- P2 triggered Korvold, Fae-Cursed King
Damage to US this turn: Tannuk, Memorial Ensign (non-combat) 2, Mayhem Devil (non-combat) 2

## Turn 32 (P3, round 8) | life: P1 0, P2 13, P3 61, US 31
- P3 cast Serra's Emissary
- P2 triggered Mayhem Devil targeting [P4]
- P2 triggered Mayhem Devil targeting [P4]
- attack: P3 assigned Gisela, the Broken Blade to attack P2.
Damage to US this turn: Mayhem Devil (non-combat) 2

## Turn 33 (OUR TURN, round 9) | life: P1 0, P2 -4, P3 57, US 28
Our hand: Twisted Embrace, Barrin, Master Wizard, Counterspell, Hostage Taker, Invasion of Innistrad, Spore Frog, Baba Lysaga, Night Witch, Mind Stone
Our graveyard (10): Ratchet Bomb, Marsh Flats, Assassin's Trophy, Wooded Foothills, Cryogen Relic, Nature's Lore, Braids, Arisen Nightmare, Soul-Guide Lantern, Vraska, Golgari Queen, Plaguecrafter
Board P2: 6 lands; Tannuk, Memorial Ensign 2/4 (tapped 1), Mayhem Devil 3/3 (tapped 1), Korvold, Fae-Cursed King 8/8 {[P1P1 x 4]} (tapped 1)
Board P3: 5 lands; Gisela, the Broken Blade 4/3 (tapped 1), Authority of the Consuls, Treasure Token [token] x3, Serra's Emissary 7/7
Board US: 9 lands; Muldrotha, the Gravetide 6/6, Syr Konrad, the Grim 5/4
MEMO (start of our turn):
THIS TURN: Lethal on P2 (13). All of P2's creatures and lands are tapped, so P2 cannot respond. Use 7 of our 8 lands and keep Otawara plus one more blue source untapped.
1) Cast Twisted Embrace ({2}{B}{B}) on Syr Konrad, making him 6/5, and destroy Serra's Emissary. If Emissary chose enchantment, cast Invasion on it instead. Death ping: P2 goes to 12.
2) Cast Plaguecrafter from the graveyard ({2}{B}). It leaves the graveyard, P2 sacrifices, P3 sacrifices Gisela, and we sacrifice Plaguecrafter: 4 pings, P2 goes to 8. Mayhem Devil does at most 3 damage to Konrad, so he survives.
3) Attack P2 with Muldrotha and Konrad for 11. P3 has no untapped blockers. P2 dies.
4) After combat, play Marsh Flats from the graveyard and fetch Watery Grave untapped (pay 2). Hold Counterspell (Watery Grave + Otawara).

TARGET: Heads-up against P3. Build Muldrotha, Konrad, Hostage Taker and Baba Lysaga, and recast Ratchet Bomb and Vraska from the graveyard. Missing: Gray Merchant and Massacre Wurm.

WIN PATH: Attack each turn. Baba Lysaga drains 3 (sacrifice a land, an artifact and a creature). Konrad pings. P3 is at 61, so this takes about 4-5 turns.

THREATS & ANSWERS: 1) P3's wipes (Farewell, Austere Command) and Akroma's Will: Counterspell. 2) Angels: Hostage Taker, Invasion at flash, Vraska −3 on Giada. 3) Swords/Path from Treasures: accept it.

HOLD: Counterspell, Invasion, Hostage Taker, Baba, Barrin and Spore Frog. Don't overcommit into Farewell.

REPLAN IF: Konrad is removed before step 2: kill Mayhem Devil instead and attack anyway. P3 sacrifices Emissary to Plaguecrafter: that Embrace/Invasion kill still pings P2.
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Twisted Embrace (from Hand): Twisted Embrace → target: Syr Konrad, the Grim [ours, 5/] instead of Forge's [cast Hostage Taker (from Hand): Hostage Taker - Creature 2 / 3]
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Plaguecrafter (from Graveyard): Plaguecrafter - Creature 3 / 2 by Muldrotha, the Grav] instead of Forge's [cast Hostage Taker (from Hand): Hostage Taker - Creature 2 / 3]
PILOT OVERRULED FORGE (action, MAIN2): chose [activate Ratchet Bomb (from Battlefield): {T}, Sacrifice Ratchet Bomb: Destroy each nonlan] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
- US cast Twisted Embrace targeting [Syr Konrad, the Grim]
- US triggered Twisted Embrace targeting [Serra's Emissary]
- left battlefield: Serra's Emissary was put into Graveyard from Battlefield.
- US triggered Syr Konrad, the Grim
- US cast Plaguecrafter
- US triggered Syr Konrad, the Grim
- US triggered Plaguecrafter
- P3 triggered Authority of the Consuls
- left battlefield: Plaguecrafter was put into Graveyard from Battlefield.
- left battlefield: Mayhem Devil was put into Graveyard from Battlefield.
- left battlefield: Gisela, the Broken Blade was put into Graveyard from Battlefield.
- US triggered Syr Konrad, the Grim
- US triggered Syr Konrad, the Grim
- US triggered Syr Konrad, the Grim
- P2 triggered Mayhem Devil targeting [P4]
- P2 triggered Mayhem Devil targeting [P4]
- P2 triggered Mayhem Devil targeting [P4]
- P2 triggered Korvold, Fae-Cursed King
- attack: US assigned Muldrotha, the Gravetide and Syr Konrad, the Grim to attack P2.
- US cast Ratchet Bomb
- left battlefield: Ratchet Bomb was put into Graveyard from Battlefield.
- US activated Ratchet Bomb
Damage to US this turn: Mayhem Devil (non-combat) 3

## Turn 34 (P3, round 9)
- P3 cast Vanquisher's Banner

## Turn 35 (OUR TURN, round 9) | life: P1 0, P2 -4, P3 47, US 27
Our hand: Barrin, Master Wizard, Counterspell, Hostage Taker, Invasion of Innistrad, Spore Frog, Baba Lysaga, Night Witch, Mind Stone, Watery Grave
Our graveyard (10): Marsh Flats, Assassin's Trophy, Wooded Foothills, Cryogen Relic, Nature's Lore, Braids, Arisen Nightmare, Soul-Guide Lantern, Vraska, Golgari Queen, Plaguecrafter, Ratchet Bomb
Board P3: 5 lands; Authority of the Consuls, Vanquisher's Banner
Board US: 9 lands; Muldrotha, the Gravetide 6/6, Syr Konrad, the Grim 6/5, Twisted Embrace
MEMO (start of our turn):
THIS TURN: P2 is dead. P3 is tapped out, so this is a free window; Counterspell covers their turn.
1) Land drop: play Wooded Foothills from the graveyard, pay 1 life, fetch a basic Forest. That gives 10 lands.
2) Cast Mind Stone ({2}) from hand; it taps for mana immediately.
3) Attack P3 with Muldrotha and Konrad for 12. They have no creatures.
4) Main 2: cast Baba Lysaga ({1}{B}{G}) from hand. Cast Braids ({1}{B}{B}) from the graveyard for 1 Konrad ping.
5) Cast Soul-Guide Lantern ({1}) from the graveyard. Exile P3's best graveyard Angel (Emissary or Gisela).
6) End step: Braids sacrifices Lantern. P3 either sacrifices Vanquisher's Banner or loses 2 and we draw.
Keep UU open (Underground Sea plus Watery Grave land or Otawara) for Counterspell.

TARGET: Muldrotha, Konrad and Braids, with Baba Lysaga firing every turn. Missing: Gray Merchant and Massacre Wurm.

WIN PATH: From next turn, Baba sacrifices a land, an artifact and a creature (a replayed fetch, Mind Stone or a recast artifact, Plaguecrafter). That drains 3 and draws 3. Add 12 combat, Braids 2 and Konrad pings: about 20 a turn. P3 goes 57 → ~44 this turn, dead in 3 more turns. P3 has no board, so their clock is slower.

THREATS & ANSWERS:
1) Farewell or Austere Command: Counterspell.
2) Giada recast: Vraska −3 from the graveyard, or Invasion.
3) Avacyn or a big Angel: Otawara channel ({1}{U}) or Hostage Taker.
4) Banner: Boseiju ({G}), only when P3 is tapped out. It ramps them.

HOLD: Counterspell with UU. Keep Invasion, Hostage Taker, Barrin, Spore Frog (fog vs flyers) and Boseiju.

REPLAN IF: Muldrotha is removed: recast her (tax +2) before other plays. P3 resolves a wipe: rebuild via the lanes. P3 lands an Angel: kill it before attacking.
PILOT OVERRULED FORGE (action, MAIN1): chose [play land Wooded Foothills (from Graveyard): Play land by Muldrotha, the Gravetide (403) (] instead of Forge's [play land Marsh Flats (from Graveyard): Play land by Muldrotha, the Gravetide (403) (Land)]
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Mind Stone (from Hand): Mind Stone [Forge's heuristic AI would not do this: CantPlayA] instead of Forge's [cast Hostage Taker (from Hand): Hostage Taker - Creature 2 / 3]
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Baba Lysaga, Night Witch (from Hand): Baba Lysaga, Night Witch - Creature 3 / 3 [Forg] instead of Forge's [cast Hostage Taker (from Hand): Hostage Taker - Creature 2 / 3]
PILOT OVERRULED FORGE (action, MAIN2): chose [cast Soul-Guide Lantern (from Graveyard): Soul-Guide Lantern by Muldrotha, the Gravetide (] instead of Forge's [cast Soul-Guide Lantern (from Graveyard): Soul-Guide Lantern by Muldrotha, the Gravetide (]
- left battlefield: Wooded Foothills was put into Graveyard from Battlefield.
- US activated Wooded Foothills
- US cast Mind Stone
- US cast Baba Lysaga, Night Witch
- P3 triggered Authority of the Consuls
- US cast Hostage Taker
- US triggered Hostage Taker targeting [Vanquisher's Banner]
- P3 triggered Authority of the Consuls
- left battlefield: Vanquisher's Banner was put into Exile from Battlefield.
- attack: US assigned Muldrotha, the Gravetide and Syr Konrad, the Grim to attack P3.
- US cast Soul-Guide Lantern
- US triggered Soul-Guide Lantern targeting [Serra's Emissary]
- left battlefield: Soul-Guide Lantern was put into Graveyard from Battlefield.
- US activated Soul-Guide Lantern

## Turn 36 (P3, round 9)
- P3 cast Serra Paragon

## Turn 37 (OUR TURN, round 10) | life: P1 0, P2 -4, P3 33, US 27
Our hand: Barrin, Master Wizard, Counterspell, Invasion of Innistrad, Spore Frog, Watery Grave, Kaya's Ghostform
Our graveyard (10): Marsh Flats, Assassin's Trophy, Cryogen Relic, Nature's Lore, Braids, Arisen Nightmare, Vraska, Golgari Queen, Plaguecrafter, Ratchet Bomb, Wooded Foothills, Soul-Guide Lantern
Board P3: 5 lands; Authority of the Consuls, Serra Paragon 3/4
Board US: 10 lands; Muldrotha, the Gravetide 6/6, Syr Konrad, the Grim 6/5, Twisted Embrace, Mind Stone, Baba Lysaga, Night Witch 3/3, Hostage Taker 2/3
MEMO (start of our turn):
THIS TURN: 12 mana with the land drop. P3 has only 1 Plains open (Swords/Path possible). Otawara and Boseiju are on the battlefield, so their channel abilities are unavailable.
1) Play Watery Grave, paying 2 life.
2) Kaya's Ghostform (Watery Grave B) on Muldrotha.
3) Vraska from the graveyard (Forest, Mind Stone, Boseiju, Bayou). Use −3 on Authority of the Consuls.
4) Plaguecrafter from the graveyard ({2}{B}). P3 sacrifices Serra Paragon; we sacrifice Vraska.
5) Baba taps and sacrifices the tapped Forest, Mind Stone and Plaguecrafter: drain 3, draw 3.
6) Cryogen Relic from the graveyard ({1}{U}): draw 1.
7) Attack P3 with Muldrotha, Konrad and Hostage Taker for 14. P3 goes 47 → ~27.
8) Keep Otawara and Breeding Pool untapped for Counterspell on P3's turn.

TARGET: Muldrotha, Konrad and Baba firing every turn, plus Braids. Missing: Gray Merchant (huge devotion drain), Demonic Tutor to find it, and Massacre Wurm.

WIN PATH: Next turn: replay a fetch, cast Braids from the graveyard, and Baba sacrifices a land, Cryogen Relic and Spore Frog. Add 14+ combat and pings: about 22–25. P3 is dead in 2 turns. P3 has no board, so their clock is 4+ turns.

THREATS & ANSWERS:
1) Wipes (Farewell, Austere Command, Wrath): Counterspell. Ghostform backs up Muldrotha.
2) Giada, Avacyn or Sunblast Angel: Invasion next turn (−13 kills indestructible creatures too), or Plaguecrafter.
3) Swords/Path on Muldrotha: Ghostform.
Don't sacrifice Hostage Taker; that returns Vanquisher's Banner to P3.

HOLD: Counterspell (UU), Invasion, Barrin, and Spore Frog (Baba fodder next turn or a fog).

REPLAN IF: We draw Gray Merchant or Demonic Tutor: cast Merchant now, still keeping UU. Muldrotha is exiled: Ghostform returns her; replay the lanes. P3 flashes in a blocker: Invasion it.
PILOT OVERRULED FORGE (action, MAIN1): chose [play land Watery Grave (from Hand): Play land] instead of Forge's [play land Marsh Flats (from Graveyard): Play land by Muldrotha, the Gravetide (403) (Land)]
PILOT OVERRULED FORGE (action, MAIN1): chose [activate Baba Lysaga, Night Witch (from Battlefield): {T}, Sacrifice up to three permanent] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN2): chose [cast Vraska, Golgari Queen (from Graveyard): Vraska, Golgari Queen by Muldrotha, the Grave] instead of Forge's [cast Vraska, Golgari Queen (from Graveyard): Vraska, Golgari Queen by Muldrotha, the Grave]
- US cast Kaya's Ghostform targeting [Muldrotha, the Gravetide]
- US activated Baba Lysaga, Night Witch
- attack: US assigned Muldrotha, the Gravetide and Syr Konrad, the Grim to attack P3.
- US cast Braids, Arisen Nightmare
- US triggered Syr Konrad, the Grim
- P3 triggered Authority of the Consuls
- US cast Vraska, Golgari Queen
- US activated Vraska, Golgari Queen targeting [Authority of the Consuls]
- left battlefield: Authority of the Consuls was put into Graveyard from Battlefield.
- US cast Cryogen Relic
- US triggered Cryogen Relic
- US triggered Braids, Arisen Nightmare
- left battlefield: Forest was put into Graveyard from Battlefield.

## Turn 38 (P3, round 10)
- attack: P3 assigned Serra Paragon to attack Vraska, Golgari Queen.
- left battlefield: Vraska, Golgari Queen was put into Graveyard from Battlefield.
- P3 cast Authority of the Consuls
- P3 cast Giada, Font of Hope

## Turn 39 (OUR TURN, round 10) | life: P1 0, P2 -4, P3 9, US 26
Our hand: Barrin, Master Wizard, Counterspell, Invasion of Innistrad, Spore Frog, Walking Ballista, Glen Elendra Archmage, Waterlogged Grove
Our graveyard (9): Marsh Flats, Assassin's Trophy, Nature's Lore, Plaguecrafter, Ratchet Bomb, Wooded Foothills, Soul-Guide Lantern, Forest, Vraska, Golgari Queen
Board P3: 6 lands; Serra Paragon 3/4 (tapped 1), Authority of the Consuls, Giada, Font of Hope 2/2
Board US: 10 lands; Muldrotha, the Gravetide 6/6, Syr Konrad, the Grim 6/5, Twisted Embrace, Mind Stone, Baba Lysaga, Night Witch 3/3, Hostage Taker 2/3, Kaya's Ghostform, Braids, Arisen Nightmare 3/3, Cryogen Relic
MEMO (start of our turn):
THIS TURN: We have 12 mana. Kill Giada before combat so Flawless Maneuver isn't free.
1) Play Wooded Foothills from the graveyard and crack it for a basic Forest.
2) Cast Vraska from the graveyard ({2}{B}{G}) and use −3 on Authority of the Consuls, so our creatures stop feeding P3 life.
3) Cast Spore Frog ({G}).
4) Tap Baba and sacrifice the tapped Forest, Twisted Embrace and Spore Frog. P3 loses 3, we draw 3, Konrad pings 1.
5) Cast Twisted Embrace from the graveyard ({2}{B}{B}) on Konrad and destroy Giada (Konrad pings).
6) Cast Plaguecrafter from the graveyard ({2}{B}). P3 sacrifices Paragon; we sacrifice Plaguecrafter (2 Konrad pings, plus 1 when it left the graveyard).
7) Cast Walking Ballista with X=0 from hand, then X=0 from the graveyard (+3 total).
8) Attack P3 with Muldrotha, Konrad, Hostage Taker and Braids (17).
9) End step: Braids sacrifices Baba. P3 has no creatures, so they lose 2, plus 1 Konrad ping.
Expected result: P3 goes from 33 to about 2.

TARGET: Muldrotha, Konrad, Braids and Baba recast each turn. Missing: Gray Merchant (Demonic Tutor for it).

WIN PATH: Next turn, cast Baba from the graveyard, then Baba, Braids and pings finish P3. P3 has no clock on us (we're at 27).

THREATS & ANSWERS: 1) A fresh Angel blocker: Invasion (flash, from hand). 2) Farewell: Ghostform returns Muldrotha. A creature wrath kills P3 through Konrad triggers. 3) Swords/Path on Muldrotha: Ghostform. Never sacrifice Hostage Taker; that returns Vanquisher's Banner to P3.

HOLD: Counterspell, Invasion, Barrin, Glen Elendra, Waterlogged Grove (next turn's land drop).

REPLAN IF: Baba draws Gray Merchant: skip Vraska and Frog and cast Merchant (devotion about 12, lethal). P3 removes Konrad before step 5: pings stop, so keep Plaguecrafter and hold UU for Counterspell instead. P3 already dead: stop.
MEMO (executor escalation: P3: nonland permanents 3→1 (-2)):
THIS TURN: P3 is at 30 with no creatures and one untapped Plains. Lanes left: artifact and battle.
1) Walking Ballista X=0 from hand. It dies: Konrad pings 1, and Authority gains P3 1.
2) Walking Ballista X=0 from the graveyard (artifact lane). Net −1 to P3.
3) Glen Elendra Archmage ({3}{U}) with Mind Stone, Tropical Island, Breeding Pool and Zagoth Triome. Keep Watery Grave untapped.
4) Attack P3 with Muldrotha, Konrad, Hostage Taker and Braids (17), taking P3 to about 13.
5) End step: Braids sacrifices Cryogen Relic. P3 has no artifacts, so they lose 2; we draw 2. P3 ends at about 11.
On P3's turn: Watery Grave's U plus sacrificing Glen counters a wipe or removal spell. Konrad pings when Glen dies, and it persists back.

TARGET: Same board plus Gray Merchant (Demonic Tutor if drawn). Keep Glen up as the counter shield.

WIN PATH: Next turn, 17 combat, Baba (land + artifact + creature = drain 3), Ballista pings and Braids 2 cover about 11. P3 has no clock on us (we're at 26).

THREATS & ANSWERS:
1) Wrath or Farewell: Glen counters it. If a creature wrath resolves anyway, Konrad pings for each creature that dies and Ghostform returns Muldrotha.
2) Avacyn or a big Angel: Invasion (−13/−13, flash from hand) or Barrin bounce next turn.
3) Swords or Path on Konrad: accept it.
Never sacrifice Hostage Taker.

HOLD: Counterspell, Invasion, Barrin, Spore Frog, Waterlogged Grove (next land drop). Keep Watery Grave's U open for Glen.

REPLAN IF: P3 flashes in a blocker (Restoration Angel): still attack; Konrad pings on any death. A wipe resolves: rebuild through Muldrotha lanes. P3 drops to 0: stop.
PILOT OVERRULED FORGE (action, MAIN1): chose [play land Wooded Foothills (from Graveyard): Play land by Muldrotha, the Gravetide (403) (] instead of Forge's [play land Waterlogged Grove (from Hand): Play land]
PILOT OVERRULED FORGE (action, MAIN1): chose [activate Baba Lysaga, Night Witch (from Battlefield): {T}, Sacrifice up to three permanent] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Vraska, Golgari Queen (from Graveyard): Vraska, Golgari Queen by Muldrotha, the Grave] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Plaguecrafter (from Graveyard): Plaguecrafter - Creature 3 / 2 by Muldrotha, the Grav] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
ESCALATION (p=0.77): P3: nonland permanents 3→1 (-2)
PILOT OVERRULED FORGE (action, MAIN2): chose [activate Walking Ballista (from Battlefield): Remove a +1/+1 counter from Walking Ballista] instead of Forge's [cast Soul-Guide Lantern (from Graveyard): Soul-Guide Lantern by Muldrotha, the Gravetide (]
PILOT OVERRULED FORGE (action, MAIN2): chose [activate Walking Ballista (from Battlefield): Remove a +1/+1 counter from Walking Ballista] instead of Forge's [cast Soul-Guide Lantern (from Graveyard): Soul-Guide Lantern by Muldrotha, the Gravetide (]
PILOT OVERRULED FORGE (action, MAIN2): chose [cast Soul-Guide Lantern (from Graveyard): Soul-Guide Lantern by Muldrotha, the Gravetide (] instead of Forge's [cast Soul-Guide Lantern (from Graveyard): Soul-Guide Lantern by Muldrotha, the Gravetide (]
- left battlefield: Wooded Foothills was put into Graveyard from Battlefield.
- US activated Wooded Foothills
- US activated Baba Lysaga, Night Witch
- US cast Vraska, Golgari Queen
- US activated Vraska, Golgari Queen targeting [Giada, Font of Hope]
- left battlefield: Giada, Font of Hope was put into Graveyard from Battlefield.
- US triggered Syr Konrad, the Grim
- US cast Plaguecrafter
- US triggered Syr Konrad, the Grim
- US triggered Plaguecrafter
- P3 triggered Authority of the Consuls
- left battlefield: Plaguecrafter was put into Graveyard from Battlefield.
- left battlefield: Serra Paragon was put into Graveyard from Battlefield.
- US triggered Syr Konrad, the Grim
- US triggered Syr Konrad, the Grim
- attack: US assigned Muldrotha, the Gravetide, Syr Konrad, the Grim, Hostage Taker and Braids, Arisen Nightmare to attack P3.
- US cast Walking Ballista
- P3 triggered Authority of the Consuls
- US activated Walking Ballista targeting [P3]
- US activated Walking Ballista targeting [P3]
- left battlefield: Walking Ballista was put into Graveyard from Battlefield.
- US triggered Syr Konrad, the Grim
- US cast Soul-Guide Lantern
- US triggered Soul-Guide Lantern targeting [Serra Paragon]
- left battlefield: Soul-Guide Lantern was put into Graveyard from Battlefield.
- US activated Soul-Guide Lantern
- US triggered Braids, Arisen Nightmare
- left battlefield: Forest was put into Graveyard from Battlefield.

## Turn 40 (P3, round 10)
- P3 cast Valkyrie Harbinger

## Turn 41 (OUR TURN, round 11) | life: P1 0, P2 -4, P3 -9, US 26
Our hand: Barrin, Master Wizard, Counterspell, Invasion of Innistrad, Spore Frog, Glen Elendra Archmage, Waterlogged Grove, Farseek, Sakura-Tribe Elder
Our graveyard (10): Marsh Flats, Assassin's Trophy, Nature's Lore, Ratchet Bomb, Forest, Wooded Foothills, Plaguecrafter, Walking Ballista, Soul-Guide Lantern, Forest
Board P3: 6 lands; Authority of the Consuls, Valkyrie Harbinger 4/5
Board US: 10 lands; Muldrotha, the Gravetide 6/6, Syr Konrad, the Grim 6/5, Twisted Embrace, Mind Stone, Baba Lysaga, Night Witch 3/3, Hostage Taker 2/3, Kaya's Ghostform, Braids, Arisen Nightmare 3/3, Cryogen Relic, Vraska, Golgari Queen {[LOYALTY]}
MEMO (start of our turn):
THIS TURN: This is lethal. P3 is at 9 with all six Plains tapped, and their only blocker is Valkyrie Harbinger.
1) Play Waterlogged Grove.
2) Cast Invasion of Innistrad ({2}{B}{B}) with Watery Grave, Underground Sea, Bayou and Woodland Cemetery. Target Valkyrie Harbinger with −13/−13. It dies and Konrad pings P3 to 8.
3) Activate Baba Lysaga: tap her and sacrifice Waterlogged Grove, Cryogen Relic and Twisted Embrace. That is three types (land, artifact, enchantment), so P3 loses 3 (to 5). We gain 3 and draw 4 (Relic's leave trigger plus Baba's 3).
4) Attack P3 with Muldrotha, Konrad, Hostage Taker and Braids: 6+5+2+3 = 16 into an empty board.
Keep Otawara, Breeding Pool or Tropical Island open for Counterspell throughout.

TARGET: The game ends this turn. If it somehow doesn't, keep the same board and add Gray Merchant.

WIN PATH: Invasion plus Konrad, then Baba's drain, then combat. We have about 11 points of surplus damage. P3 has no clock on us (we're at 26).

THREATS & ANSWERS: P3 has no untapped mana. A free spell is the only risk; Counterspell or Glen answers it. Don't cast creatures before combat, because Authority gains P3 1 life per creature. Never sacrifice Hostage Taker.

HOLD: Counterspell (UU up), Glen Elendra, Barrin, Spore Frog, Sakura-Tribe Elder and Farseek. None are needed for the kill.

REPLAN IF: Harbinger survives (for example, a free protection spell): attack anyway with everything. Its lifelink block only nets them a little, so let Konrad triggers and Braids at end step finish them next turn. If P3 somehow ends above 0, at end step Braids sacrifices Mind Stone: P3 loses 2 and we draw.
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Invasion of Innistrad (from Hand): Invasion of Innistrad [Forge's heuristic AI would ] instead of Forge's [cast Farseek (from Hand): Search your library for a Plains, Island, Swamp, or Mountain car]
PILOT OVERRULED FORGE (action, MAIN1): chose [activate Baba Lysaga, Night Witch (from Battlefield): {T}, Sacrifice up to three permanent] instead of Forge's [cast Farseek (from Hand): Search your library for a Plains, Island, Swamp, or Mountain car]
PILOT OVERRULED FORGE (action, MAIN1): chose [Take no further action this phase: hold remaining mana and cards (this skips o0, the play ] instead of Forge's [cast Farseek (from Hand): Search your library for a Plains, Island, Swamp, or Mountain car]
- US cast Invasion of Innistrad
- US triggered Invasion of Innistrad targeting [Valkyrie Harbinger]
- left battlefield: Valkyrie Harbinger was put into Graveyard from Battlefield.
- US triggered Syr Konrad, the Grim
- US activated Baba Lysaga, Night Witch
- attack: US assigned Muldrotha, the Gravetide, Syr Konrad, the Grim, Hostage Taker and Braids, Arisen Nightmare to attack P3.
- Game Outcome: P1 has lost because life total reached 0
- Game Outcome: P2 has lost because life total reached 0
- Game Outcome: P3 has lost because life total reached 0
- Game Outcome: US has won because all opponents have lost