# pod01-g2: we are P4; opponents P1 Sauron, the Dark Lord, P2 Sephiroth, Fabled SOLDIER, P3 Y'shtola, Night's Blessed
Result: Turn 25; P1 has lost because life total reached 0; P2 has lost because life total reached 0; P3 has won because all opponents have lost; US has lost because life total reached 0

## Turn 1 (P1, round 1)

## Turn 2 (P2, round 1)
- P2 cast Forsaken Miner

## Turn 3 (P3, round 1)

## Turn 4 (OUR TURN, round 1) | life: US 39
Our hand: Baleful Strix, Overgrown Tomb, Three Visits, Verdant Catacombs, Talisman of Dominance, Wooded Foothills, Hostage Taker, Doc Aurlock, Grizzled Genius
Our graveyard (0): 
Board P1: 1 lands; no nonland permanents
Board P2: 1 lands; Forsaken Miner 2/2
Board P3: 1 lands; no nonland permanents
Board US: 0 lands; no nonland permanents
MEMO (start of our turn):
THIS TURN: Play Wooded Foothills. Crack it now (1 life) for Zagoth Triome, which enters tapped anyway, so no tempo is lost. We have 0 mana and no instant plays; pass. Keep Verdant Catacombs and Overgrown Tomb for later turns.

TARGET: Next turn, play Overgrown Tomb untapped (pay 2 life) and cast Three Visits (2) for Tropical Island or Breeding Pool, untapped. Turn after, 4 mana: Hostage Taker on the best creature or artifact (Sol Ring or Relic of Sauron counts), else Doc Aurlock plus Baleful Strix. Then Talisman plus Muldrotha around our 4th turn. The first graveyard pieces we want are Executioner's Capsule and Seal of Doom.

WIN PATH: Lock the board by turns 7-9 with recurring removal, then drain with Gray Merchant, Syr Konrad or Vrock plus Muldrotha beats. P2's Sephiroth combo (turns 5-7) is the fastest clock; we must have removal online by then.

THREATS & ANSWERS: 1) P2 Sephiroth, Pitiless Plunderer, Ashnod's Altar: Hostage Taker steals a creature or Altar. Don't chump into Sephiroth drains. 2) P1 Sauron and mana rocks: Hostage Taker on Sol Ring or Relic. Sauron's ward needs an edict later. 3) P3 Y'shtola: slow; deal with it later. Forsaken Miner can't block and isn't worth removal.

HOLD: Baleful Strix as a deathtouch flying blocker and cantrip. Hold Hostage Taker for a real target, not the Miner. Hold Verdant Catacombs as next turn's fetch backup.

REPLAN IF: Sephiroth, Plunderer or Altar lands (Hostage Taker becomes top priority), a turn-2 Sol Ring appears, or a wipe or Bowmasters shows up.
PILOT OVERRULED FORGE (action, MAIN1): chose [play land Wooded Foothills (from Hand): Play land] instead of Forge's [play land Overgrown Tomb (from Hand): Play land]
PILOT OVERRULED FORGE (search, MAIN1): chose [Zagoth Triome — Land - Swamp Forest Island — ({T}: Add {B}, {G}, or {U}.) Zagoth Triome en] instead of Forge's [Breeding Pool — Land - Forest Island — ({T}: Add {G} or {U}.) As Breeding Pool enters, you]
- left battlefield: Wooded Foothills was put into Graveyard from Battlefield.
- US activated Wooded Foothills

## Turn 5 (P1, round 2)

## Turn 6 (P2, round 2) | life: US 37
- attack: P2 assigned Forsaken Miner to attack US.
- P2 triggered Bojuka Bog targeting [P4]
Damage to US this turn: Forsaken Miner (combat) 2

## Turn 7 (P3, round 2)
- P3 cast Fellwar Stone

## Turn 8 (OUR TURN, round 2) | life: US 36
Our hand: Baleful Strix, Overgrown Tomb, Three Visits, Verdant Catacombs, Talisman of Dominance, Hostage Taker, Doc Aurlock, Grizzled Genius, Boseiju, Who Endures
Our graveyard (0): 
Board P1: 2 lands; no nonland permanents
Board P2: 2 lands; Forsaken Miner 2/2 (tapped 1)
Board P3: 2 lands; Fellwar Stone
Board US: 1 lands; no nonland permanents
MEMO (start of our turn):
THIS TURN: Play Verdant Catacombs and crack it now (1 life) for Underground Sea. The fetch in our graveyard becomes a land Muldrotha can replay later. Tap Triome (G) and Sea for Three Visits and fetch Tropical Island untapped. Its 1 floating mana has no use, so pass. No instant plays this turn cycle.

TARGET: Next turn, play Overgrown Tomb untapped (2 life) for 4 mana. If Sephiroth, Pitiless Plunderer or a key rock is out, cast Hostage Taker on it; otherwise cast Talisman plus Baleful Strix. The turn after that, 6 mana for Muldrotha. Then Doc Aurlock, and get Executioner's Capsule and Seal of Doom into the graveyard (Survival of the Fittest or Demonic Tutor as tutor targets).

WIN PATH: Recurring Capsule/Seal removal locks the board. Close with Gray Merchant, Syr Konrad or Vrock drains plus Muldrotha beats. P2's Sephiroth loop is the fastest clock, so removal must be online the turn it lands.

THREATS & ANSWERS: 1) P2 Sephiroth, Plunderer, Ashnod's Altar: answer with Hostage Taker; Boseiju channel for the Altar. 2) P1 Sauron and rocks: Hostage Taker on Sol Ring or Relic; an edict later for Sauron. 3) P3 Y'shtola is slow; Hostage Taker it if nothing else. Ignore Forsaken Miner.

HOLD: Hostage Taker for a real target. Boseiju as a land drop or an answer to Altar, Grave Pact or One Ring (it only destroys, so no answer to One Ring). Overgrown Tomb for next turn's drop.

REPLAN IF: Sephiroth lands before our turn (Hostage Taker first next turn), a Sol Ring or Relic appears, or a wipe or Bowmasters shows up (cast fewer spells into P1).
PILOT OVERRULED FORGE (action, MAIN1): chose [play land Verdant Catacombs (from Hand): Play land] instead of Forge's [play land Boseiju, Who Endures (from Hand): Play land]
PILOT OVERRULED FORGE (search, MAIN1): chose [Underground Sea — Land - Island Swamp — ({T}: Add {U} or {B}.)] instead of Forge's [Bayou — Land - Swamp Forest — ({T}: Add {B} or {G}.)]
PILOT OVERRULED FORGE (search, MAIN1): chose [Tropical Island — Land - Forest Island — ({T}: Add {G} or {U}.)] instead of Forge's [Bayou — Land - Swamp Forest — ({T}: Add {B} or {G}.)]
- left battlefield: Verdant Catacombs was put into Graveyard from Battlefield.
- US activated Verdant Catacombs
- US cast Three Visits

## Turn 9 (P1, round 3)
- P1 cast Fellwar Stone

## Turn 10 (P2, round 3) | life: P3 38, US 36
- attack: P2 assigned Forsaken Miner to attack P3.
- P2 cast Warren Soultrader

## Turn 11 (P3, round 3) | life: P2 39, P3 38, US 36
- left battlefield: Forsaken Miner was put into Graveyard from Battlefield.
- P2 activated Warren Soultrader
- P3 cast Y'shtola, Night's Blessed

## Turn 12 (OUR TURN, round 3)
Our hand: Baleful Strix, Overgrown Tomb, Talisman of Dominance, Hostage Taker, Doc Aurlock, Grizzled Genius, Boseiju, Who Endures, Hinterland Harbor
Our graveyard (2): Verdant Catacombs, Three Visits
Board P1: 3 lands; Fellwar Stone
Board P2: 3 lands; Warren Soultrader 3/3, Treasure Token [token]
Board P3: 3 lands; Fellwar Stone (tapped 1), Y'shtola, Night's Blessed 2/4
Board US: 3 lands; no nonland permanents
MEMO (start of our turn):
THIS TURN: Every opponent is tapped out, so this is a free window. Play Hinterland Harbor, which enters untapped because we control Tropical Island. That gives 4 mana. Tap Triome and Harbor to cast Talisman of Dominance. Then tap Underground Sea (B) and Tropical Island (U) to cast Baleful Strix and draw a card. Keep Strix home as a deathtouch blocker against Warren Soultrader. No instant plays on opponents' turns.

TARGET: Next turn, play Overgrown Tomb untapped (2 life): 5 lands plus Talisman is 6 mana, enough for Muldrotha. The turn after, cast Hostage Taker and Doc Aurlock. Then tutor Executioner's Capsule and Seal of Doom into the graveyard with Survival of the Fittest or Demonic Tutor.

WIN PATH: Loop Capsule and Seal removal every turn, then close with Gray Merchant, Syr Konrad or Vrock drains plus Muldrotha beats. P2's Sephiroth sacrifice loop is the fastest clock (turns 5–7 pace), so our removal must answer Sephiroth the turn it lands.

THREATS & ANSWERS: 1) P2 Sephiroth or Pitiless Plunderer: Hostage Taker. Ashnod's Altar or Grave Pact: Boseiju channel. 2) P1 Sauron: edict or wipe later. Relic of Sauron or Call of the Ring: Boseiju. 3) P3 Y'shtola is slow; Hostage Taker it only if nothing better appears.

HOLD: Hostage Taker for Sephiroth, Plunderer or Sauron's key pieces. Boseiju in hand as removal (Overgrown Tomb is next turn's land drop). Doc stays in hand until Muldrotha is out.

REPLAN IF: Sephiroth or Plunderer lands before our next turn: cast Hostage Taker on it next turn and delay Muldrotha. Also replan if P1 shows a wipe, Bowmasters or Sauron, or if Strix dies.
PILOT OVERRULED FORGE (action, MAIN1): chose [play land Hinterland Harbor (from Hand): Play land] instead of Forge's [play land Boseiju, Who Endures (from Hand): Play land]
PILOT OVERRULED FORGE (action, MAIN2): chose [cast Baleful Strix (from Hand): Baleful Strix - Creature 1 / 1] instead of Forge's [cast Hostage Taker (from Hand): Hostage Taker - Creature 2 / 3]
- US cast Baleful Strix
- US triggered Baleful Strix
- US cast Doc Aurlock, Grizzled Genius

## Turn 13 (P1, round 4) | life: P1 38, P2 39, P3 38, US 36
- P1 cast Gothmog, Morgul Lieutenant
- P1 triggered Gothmog, Morgul Lieutenant
- P1 cast Reanimate targeting [Forsaken Miner]

## Turn 14 (P2, round 4) | life: P1 35, P2 39, P3 38, US 36
- P2 cast Deadly Rollick targeting [Gothmog, Morgul Lieutenant]
- left battlefield: Gothmog, Morgul Lieutenant was put into Exile from Battlefield.
- attack: P2 assigned Warren Soultrader to attack P1.

## Turn 15 (P3, round 4) | life: P1 33, P2 37, P3 40, US 34
- P3 cast Propaganda
- P3 triggered Y'shtola, Night's Blessed
Damage to US this turn: Y'shtola, Night's Blessed (non-combat) 2

## Turn 16 (OUR TURN, round 4)
Our hand: Overgrown Tomb, Talisman of Dominance, Hostage Taker, Boseiju, Who Endures, Otawara, Soaring City, Cryogen Relic
Our graveyard (2): Verdant Catacombs, Three Visits
Board P1: 4 lands; Fellwar Stone (tapped 1), Orc Army Token 1/1 [token] {[P1P1]}, Forsaken Miner 2/2
Board P2: 4 lands; Warren Soultrader 3/3 (tapped 1)
Board P3: 4 lands; Fellwar Stone (tapped 1), Y'shtola, Night's Blessed 2/4, Propaganda
Board US: 4 lands; Baleful Strix 1/1, Doc Aurlock, Grizzled Genius 2/3
MEMO (start of our turn):
THIS TURN: 1) Play Overgrown Tomb and pay 2 life so it enters untapped (5 lands). 2) Tap Triome and Harbor to cast Talisman of Dominance. 3) Tap Underground Sea, Tropical Island, Tomb and Talisman (1 damage) to cast Hostage Taker, exiling Warren Soultrader. That removes P2's sacrifice outlet before Sephiroth lands, and we keep the card. Don't target Y'shtola or any commander, since the owner just moves it to the command zone. Keep Strix and Doc home as blockers. We're tapped out afterwards, with no instant plays.

TARGET: Next turn, 5 lands plus Talisman makes exactly 6: cast Muldrotha, with no tax paid yet. After that, with Doc's discount, cast Soultrader from exile (1 mana after Doc; any colour works) as our outlet. Loop Strix and Cryogen Relic through the graveyard. Tutor Executioner's Capsule and Seal of Doom into the graveyard.

WIN PATH: Recurring removal, then Gray Merchant, Syr Konrad or Vrock drains plus Muldrotha beats. P2's Sephiroth drain is the fastest clock, so answer it on sight.

THREATS & ANSWERS: 1) P2 Sephiroth or Plunderer: Otawara channel costs {2}{U} with Doc out, and {U} once Muldrotha is also out. 2) P2 Ashnod's Altar or Grave Pact, P1 Call of the Ring or Relic, P3 Propaganda: Boseiju channel costs {G}. 3) Y'shtola: slow, so ignore it for now.

HOLD: Keep Boseiju and Otawara in hand as channel removal, not as land drops. Muldrotha can replay them from the graveyard as our land later. Hold Cryogen Relic until Muldrotha is out.

REPLAN IF: Hostage Taker dies (Soultrader returns to P2), Sephiroth lands, P1 casts Sauron or a wipe, or Muldrotha gets countered.
PILOT OVERRULED FORGE (action, MAIN1): chose [play land Overgrown Tomb (from Hand): Play land] instead of Forge's [play land Boseiju, Who Endures (from Hand): Play land]
PILOT OVERRULED FORGE (trigger-target, MAIN1): chose [Warren Soultrader [P2, 3/3, tapped]] instead of Forge's [Y'shtola, Night's Blessed [P3, 2/4, commander]]
- US cast Hostage Taker
- US triggered Hostage Taker targeting [Warren Soultrader]
- left battlefield: Warren Soultrader was put into Exile from Battlefield.

## Turn 17 (P1, round 5)
- P1 cast Sauron, the Dark Lord

## Turn 18 (P2, round 5)
- P2 cast Yawgmoth, Thran Physician
- P1 triggered Sauron, the Dark Lord

## Turn 19 (P3, round 5) | life: P1 31, P2 35, P3 42, US 32
- P3 cast Cleansing Nova
- P3 triggered Y'shtola, Night's Blessed
- P1 triggered Sauron, the Dark Lord
- left battlefield: Y'shtola, Night's Blessed was put into Graveyard from Battlefield.
- left battlefield: Baleful Strix was put into Graveyard from Battlefield.
- left battlefield: Doc Aurlock, Grizzled Genius was put into Graveyard from Battlefield.
- left battlefield: Hostage Taker was put into Graveyard from Battlefield.
- left battlefield: Sauron, the Dark Lord was put into Graveyard from Battlefield.
- left battlefield: Forsaken Miner was put into Graveyard from Battlefield.
- left battlefield: Yawgmoth, Thran Physician was put into Graveyard from Battlefield.
Damage to US this turn: Y'shtola, Night's Blessed (non-combat) 2

## Turn 20 (OUR TURN, round 5)
Our hand: Talisman of Dominance, Boseiju, Who Endures, Otawara, Soaring City, Cryogen Relic, Professor Dellian Fel
Our graveyard (5): Verdant Catacombs, Three Visits, Baleful Strix, Doc Aurlock, Grizzled Genius, Hostage Taker
Board P1: 5 lands; Fellwar Stone (tapped 1)
Board P2: 4 lands; Warren Soultrader 3/3
Board P3: 4 lands; Fellwar Stone (tapped 1), Propaganda
Board US: 5 lands; no nonland permanents
MEMO (start of our turn):
THIS TURN: Every opponent is tapped out, so this is our window for Muldrotha. 1) Play Otawara as our land drop (6 lands). 2) Tap all 6 lands to cast Muldrotha ({3}{B}{G}{U}, no tax yet). Nothing left after that, and no instant plays this turn cycle. Keep Talisman and Relic in hand.

TARGET: Muldrotha, Doc Aurlock and Hostage Taker on board, with Baleful Strix and Cryogen Relic looping each turn. Tutor Executioner's Capsule and Seal of Doom via Demonic Tutor or Survival of the Fittest. Next turn: play Verdant Catacombs from the graveyard as our land, fetch, and have 7 mana. Then cast Hostage Taker from the graveyard (4) on Soultrader or the best creature, plus Strix through the artifact lane ({U}{B}), plus 1 spare.

WIN PATH: Grind with recurring removal. Close with Gray Merchant, Syr Konrad and Muldrotha beats. P2's Sephiroth drain is the fastest clock.

THREATS & ANSWERS: 1) P2 Sephiroth plus Soultrader: Hostage Taker from the graveyard, or Dellian Fel's -3. 2) P2 Ashnod's Altar or Grave Pact, P1 Call of the Ring, P3 Propaganda (before attacking P3): Boseiju channel, which costs {G} at instant speed while Muldrotha is out. 3) P1 Sauron: his ward demands a legendary sacrifice, so never target him; use an edict or race. 4) P3: counter Exsanguinate later.

HOLD: Boseiju in hand as instant removal, never as a land drop. Hold Dellian Fel for Sephiroth or another must-kill creature. Next turn, lead with graveyard casts into open counter mana, not cards from hand.

REPLAN IF: Muldrotha is countered or dies (tax becomes 2), Sephiroth lands, Sauron is recast, or anyone casts Living Death or a wipe.
PILOT OVERRULED FORGE (action, MAIN1): chose [play land Otawara, Soaring City (from Hand): Play land] instead of Forge's [play land Boseiju, Who Endures (from Hand): Play land]
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Muldrotha, the Gravetide (from Command): Muldrotha, the Gravetide - Creature 6 / 6 [F] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
- US cast Muldrotha, the Gravetide

## Turn 21 (P1, round 6)
- P1 cast Claim the Precious targeting [Muldrotha, the Gravetide]
- left battlefield: Muldrotha, the Gravetide was put into Graveyard from Battlefield.
- P1 cast Nazgûl
- P1 triggered Nazgûl
- P1 triggered Nazgûl

## Turn 22 (P2, round 6) | life: P1 31, P2 35, P3 39, US 32
- attack: P2 assigned Warren Soultrader to attack P3.
- P2 cast Marionette Apprentice
- P2 triggered Marionette Apprentice

## Turn 23 (P3, round 6)
- P3 cast Y'shtola, Night's Blessed

## Turn 24 (OUR TURN, round 6) | life: P1 30, P2 35, P3 38, US 31
Our hand: Talisman of Dominance, Boseiju, Who Endures, Cryogen Relic, Professor Dellian Fel, Survival of the Fittest
Our graveyard (5): Verdant Catacombs, Three Visits, Baleful Strix, Doc Aurlock, Grizzled Genius, Hostage Taker
Board P1: 5 lands; Fellwar Stone (tapped 1), Nazgûl 2/3 {[P1P1]}
Board P2: 4 lands; Warren Soultrader 3/3 (tapped 1), Marionette Apprentice 1/2, Servo Token 1/1 [token]
Board P3: 5 lands; Fellwar Stone (tapped 1), Propaganda, Y'shtola, Night's Blessed 2/4
Board US: 6 lands; no nonland permanents
MEMO (start of our turn):
THIS TURN: Muldrotha died (tax +2, so she costs 8) and the Nova wiped our board. We can't reach 8 mana, so we use the tapped-out window for noncreature spells.
1) Talisman, paid with Otawara and Hinterland Harbor.
2) Cryogen Relic, paid with Talisman ({U}) and Tropical Island. Draw.
3) Land drop: an untapped land if Relic drew one, otherwise Boseiju.
4) Dellian Fel ({2}{B}{G}), paid with Underground Sea, Overgrown Tomb, Zagoth and the new land. Use −3 on Y'shtola.
No mana is left for opponents' turns.

TARGET: 8 mana next turn (7 lands plus Talisman) for Muldrotha. Then play Verdant Catacombs from the graveyard and fetch Bayou for 1 extra mana. The turn after: Doc Aurlock, Hostage Taker (costs 2 with Doc), and Strix, Fel and Relic looping each turn.

WIN PATH: Grind with recurring removal, then close with Gray Merchant, Syr Konrad and Muldrotha beats. No one threatens lethal soon (we're at 32). P2's Sephiroth loop is the fastest clock.

THREATS & ANSWERS:
1) P2 Sephiroth: Fel −3 if Fel survives and has the loyalty. Otherwise Hostage Taker via Muldrotha, or Relic's stun on a tapped creature.
2) P1 Living Death or Reanimate, and Nazgûl: Hostage Taker later.
3) P3 recasting Y'shtola costs 6 and taps them out before our turn. Good for us.
Fel dying is fine; Muldrotha recasts it.

HOLD: Survival of the Fittest (no creature to discard yet). Keep Boseiju unless Relic draws an untapped land. Next turn, cast Muldrotha before anything else.

REPLAN IF: Relic draws a land (then keep Boseiju for channel), Sephiroth lands with 4 deaths possible, someone casts Living Death, P3 keeps counter mana open on our turn, or the Relic draw changes our mana.
PILOT OVERRULED FORGE (action, MAIN2): chose [cast Talisman of Dominance (from Hand): Talisman of Dominance] instead of Forge's [cast Professor Dellian Fel (from Hand): Professor Dellian Fel]
PILOT OVERRULED FORGE (action, MAIN2): chose [cast Cryogen Relic (from Hand): Cryogen Relic] instead of Forge's [cast Professor Dellian Fel (from Hand): Professor Dellian Fel]
PILOT OVERRULED FORGE (action, MAIN2): chose [Warren Soultrader [P2, 3/3, tapped]] instead of Forge's [Y'shtola, Night's Blessed [P3, 2/4, commander]]
- US cast Talisman of Dominance
- US cast Cryogen Relic
- US triggered Cryogen Relic
- US cast Professor Dellian Fel
- US activated Professor Dellian Fel targeting [Warren Soultrader]
- left battlefield: Warren Soultrader was put into Graveyard from Battlefield.
- P2 triggered Marionette Apprentice

## Turn 25 (P1, round 7)
- P1 cast Ringsight
- P1 triggered Nazgûl
- attack: P1 assigned Nazgûl to attack Professor Dellian Fel.
- P1 triggered The Ring
- left battlefield: Professor Dellian Fel was put into Graveyard from Battlefield.
- P1 cast Orcish Siegemaster

## Turn 26 (P2, round 7)
- P2 cast Sephiroth, Fabled SOLDIER
- P2 triggered Sephiroth, Fabled SOLDIER

## Turn 27 (P3, round 7) | life: P1 28, P2 33, P3 40, US 27
- P3 cast Vito, Thorn of the Dusk Rose
- P3 cast Black Market Connections
- P3 triggered Y'shtola, Night's Blessed
- P3 triggered Vito, Thorn of the Dusk Rose targeting [P4]
- P3 triggered Y'shtola, Night's Blessed
Damage to US this turn: Y'shtola, Night's Blessed (non-combat) 2

## Turn 28 (OUR TURN, round 7) | life: P1 28, P2 33, P3 40, US 26
Our hand: Survival of the Fittest, Command Tower, Heroic Intervention
Our graveyard (6): Verdant Catacombs, Three Visits, Baleful Strix, Doc Aurlock, Grizzled Genius, Hostage Taker, Professor Dellian Fel
Board P1: 6 lands; Fellwar Stone (tapped 1), Nazgûl 3/4 {[P1P1 x 2]} (tapped 1), Orcish Siegemaster 0/5
Board P2: 4 lands; Marionette Apprentice 1/2, Servo Token 1/1 [token], Sephiroth, Fabled SOLDIER 3/3
Board P3: 5 lands; Fellwar Stone (tapped 1), Propaganda, Y'shtola, Night's Blessed 2/4, Vito, Thorn of the Dusk Rose 1/3, Black Market Connections
Board US: 7 lands; Talisman of Dominance, Cryogen Relic
MEMO (start of our turn):
THIS TURN: Everyone is nearly tapped out (P3 has 0 open, P1 and P2 have 1 each), so cast Muldrotha now.
1) Cast Muldrotha for 8, tapping all 7 lands plus Talisman. Take {C} from Talisman where possible to skip its ping.
2) Land lane: play Verdant Catacombs from the graveyard and fetch Bayou untapped. This keeps Command Tower in hand. The 1 floating mana has no use.
3) Do not attack.

TARGET: Next turn we have 10 mana (9 sources plus a land). Replay Catacombs every turn for a fetch.
1) Hostage Taker from the graveyard (4) on Y'shtola.
2) Dellian Fel (4), then −3 on Sephiroth.
3) Baleful Strix through the artifact lane (UB) to draw.
After that, add Doc Aurlock, then Survival to tutor Gray Merchant, Syr Konrad or Massacre Wurm.

WIN PATH: Lock the board with Relic, Fel, Strix and Taker loops. Close with Gray Merchant, Syr Konrad and Muldrotha beats, about 5 turns out. P2's Sephiroth drain is the fastest clock.

THREATS & ANSWERS:
1) P2 Sephiroth, 4 deaths in a turn from transforming: Fel −3. Relic's stun works if it is tapped.
2) P3 Y'shtola with Vito, a drain engine: Hostage Taker.
3) P1 Nazgûl and Siegemaster, and Sauron if it lands: Hostage Taker or Fel later. Massacre Wurm through Survival.
Don't feed Sephiroth: no chump blocks and no creature trades.

HOLD: Heroic Intervention and Command Tower. From next turn, keep 2 mana open for Heroic if P3 or P2 is holding mana. Survival waits until a creature card is in hand.

REPLAN IF: Muldrotha is removed (then recast is 10 with tax), Sephiroth reaches 3 deaths in a turn, Living Death or Sauron is cast, or P3 holds counter mana on our turn.
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Muldrotha, the Gravetide (from Command): Muldrotha, the Gravetide - Creature 6 / 6 [F] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN1): chose [play land Verdant Catacombs (from Graveyard): Play land by Muldrotha, the Gravetide (403) ] instead of Forge's [play land Command Tower (from Hand): Play land]
PILOT OVERRULED FORGE (search, MAIN1): chose [Bayou — Land - Swamp Forest — ({T}: Add {B} or {G}.)] instead of Forge's [Watery Grave — Land - Island Swamp — ({T}: Add {U} or {B}.) As Watery Grave enters, you ma]
- US cast Muldrotha, the Gravetide
- left battlefield: Verdant Catacombs was put into Graveyard from Battlefield.
- US activated Verdant Catacombs

## Turn 29 (P1, round 8) | life: P1 28, P2 33, P3 37, US 26
- attack: P1 assigned Orcish Siegemaster and Nazgûl to attack P3.
- P1 triggered The Ring
- P1 triggered Orcish Siegemaster
- attack: P3 assigned Y'shtola, Night's Blessed to block Orcish Siegemaster.
- P1 cast Commander's Sphere

## Turn 30 (P2, round 8)
- P2 cast Drivnod, Carnage Dominus

## Turn 31 (P3, round 8) | life: P1 26, P2 27, P3 37, US 22
- P3 cast Stroke of Midnight targeting [Drivnod, Carnage Dominus]
- P3 triggered Y'shtola, Night's Blessed
- P2 activated Drivnod, Carnage Dominus
- P3 triggered Vito, Thorn of the Dusk Rose targeting [P4]
- P3 triggered Black Market Connections
- P3 cast G'raha Tia, Scion Reborn
- P3 triggered Y'shtola, Night's Blessed
Damage to US this turn: Y'shtola, Night's Blessed (non-combat) 2

## Turn 32 (OUR TURN, round 8) | life: P1 19, P2 27, P3 36, US 20
Our hand: Survival of the Fittest, Command Tower, Heroic Intervention, Darkslick Shores
Our graveyard (6): Three Visits, Baleful Strix, Doc Aurlock, Grizzled Genius, Hostage Taker, Professor Dellian Fel, Verdant Catacombs
Board P1: 7 lands; Fellwar Stone (tapped 1), Nazgûl 3/4 {[P1P1 x 2]} (tapped 1), Orcish Siegemaster 0/5 (tapped 1), Commander's Sphere
Board P2: 5 lands; Marionette Apprentice 1/2, Servo Token 1/1 [token], Sephiroth, Fabled SOLDIER 3/3, Drivnod, Carnage Dominus 8/3 {[Indestructible]}, Human Token 1/1 [token]
Board P3: 6 lands; Fellwar Stone (tapped 1), Propaganda, Y'shtola, Night's Blessed 2/4, Vito, Thorn of the Dusk Rose 1/3, Black Market Connections, G'raha Tia, Scion Reborn 2/3
Board US: 8 lands; Talisman of Dominance, Cryogen Relic, Muldrotha, the Gravetide 6/6
MEMO (start of our turn):
THIS TURN: 10 mana after the land. One creature lane per turn, so Taker goes now and Doc waits.
1) Land lane: play Verdant Catacombs from the graveyard and fetch a basic Swamp. Keep Command Tower and Darkslick Shores in hand.
2) Cast Hostage Taker from the graveyard (4: Otawara, Underground Sea, Talisman {C}, Swamp). Exile Drivnod. It is indestructible, so exile is our only clean answer.
3) Cast Professor Dellian Fel from the graveyard (4: Overgrown Tomb, Bayou, Triome, Boseiju). −3 on Sephiroth. Without Drivnod, only Apprentice's single ping happens.
4) Attack P1 with Muldrotha. P1 has no untapped creatures.
5) Keep Tropical Island and Hinterland Harbor open for Heroic Intervention.

TARGET: Next turn, Doc Aurlock (creature lane, GU) makes later graveyard casts 2 cheaper. Add Baleful Strix via the artifact lane, Survival from hand, and Fel's 0 for cards. Survival tutors Massacre Wurm, Gray Merchant or Syr Konrad.

WIN PATH: Muldrotha beats, then Gray Merchant loops and Syr Konrad. About 4–5 turns. The fastest clocks are P2's drains and P1's Sauron.

THREATS & ANSWERS:
1) Drivnod plus Sephiroth: handled by Taker and Fel. Recast Sephiroth: Fel −3 again later.
2) P3's Y'shtola, Vito and G'raha drain: Fel −3 or Plaguecrafter. Y'shtola is black, so Shriekmaw can't hit it.
3) P1's Nazgûl and Sauron: Massacre Wurm, Otawara. Never block Nazgûl, and don't let creatures die.

HOLD: Heroic Intervention, 2 open, on opponents' turns. Use it versus Blasphemous Act or spot removal on Hostage Taker, since Drivnod returns if Taker leaves, or on Muldrotha.

REPLAN IF: Taker is countered or removed (then Otawara channel on Drivnod), Sauron is cast, or Sephiroth returns.
MEMO (executor escalation: P2: nonland permanents 5→3 (-2)):
THIS TURN: Attack P1 with Muldrotha and Hostage Taker. All of P1's creatures are tapped, so no blocks (25 → 17). Don't attack P3, because Propaganda taxes us. In main phase 2 cast nothing: only Zagoth Triome is untapped, all lanes left need 2, and Fel has already activated. Heroic Intervention can't be cast this round, so accept the risk.

TARGET: Next turn we have 10 mana. 1) Land lane: Verdant Catacombs from the graveyard, fetch Watery Grave untapped (11 mana). 2) Doc Aurlock from the graveyard (GU). 3) Survival (1G). 4) Baleful Strix, artifact lane (UB), to draw. 5) Fel +2, to 4, so −3 is ready. If we hold a creature card, Survival (G) discards it to find Massacre Wurm. Later discard Wurm to Survival so Muldrotha recasts it from the graveyard for {1}{B}{B}{B} with Doc. Keep 2 open (Tropical Island or Breeding Pool) for Heroic Intervention.

WIN PATH: A graveyard Wurm sweeps the X/2s. Then Gray Merchant (Survival target) plus Syr Konrad drain, and Muldrotha swings at P1. About 4 turns. P1's Sauron is the fastest opponent threat.

THREATS & ANSWERS: 1) Sauron cast by P1: Fel −3 or Otawara, paying ward by sacrificing Doc Aurlock (legendary), then recast Doc. 2) Sephiroth recast: Fel −3. 3) Y'shtola, Vito and G'raha drain: Wurm, Fel. 4) Nazgûl: never block it.

HOLD: Heroic Intervention with 2 green-capable open on opponents' turns, to protect Taker (so Drivnod stays exiled) and Muldrotha. Keep Command Tower and Darkslick Shores in hand while Catacombs is replayable.

REPLAN IF: Taker leaves (Drivnod returns: Otawara it), Sauron resolves, a wipe hits, or Grave Pact appears.
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Hostage Taker (from Graveyard): Hostage Taker - Creature 2 / 3 by Muldrotha, the Grav] instead of Forge's [play land Command Tower (from Hand): Play land]
PILOT OVERRULED FORGE (action, MAIN1): chose [play land Verdant Catacombs (from Graveyard): Play land by Muldrotha, the Gravetide (403) ] instead of Forge's [play land Command Tower (from Hand): Play land]
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Professor Dellian Fel (from Graveyard): Professor Dellian Fel by Muldrotha, the Grave] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN1): chose [Sephiroth, Fabled SOLDIER [P2, 3/3, commander]] instead of Forge's [Y'shtola, Night's Blessed [P3, 2/4, commander]]
ESCALATION (p=0.61): P2: nonland permanents 5→3 (-2)
PILOT OVERRULED FORGE (attack, COMBAT_DECLARE_ATTACKERS): chose [attack P1 (25 life)] instead of Forge's [don't attack with it]
- US cast Hostage Taker
- US triggered Hostage Taker targeting [Drivnod, Carnage Dominus]
- left battlefield: Drivnod, Carnage Dominus was put into Exile from Battlefield.
- left battlefield: Verdant Catacombs was put into Graveyard from Battlefield.
- US activated Verdant Catacombs
- US cast Professor Dellian Fel
- US activated Professor Dellian Fel targeting [Sephiroth, Fabled SOLDIER]
- left battlefield: Sephiroth, Fabled SOLDIER was put into Graveyard from Battlefield.
- P2 triggered Marionette Apprentice
- attack: US assigned Muldrotha, the Gravetide to attack P1.
- P3 triggered Y'shtola, Night's Blessed
- left battlefield: Commander's Sphere was put into Graveyard from Battlefield.
- P1 activated Commander's Sphere

## Turn 33 (P1, round 9)
- attack: P1 assigned Orcish Siegemaster and Nazgûl to attack Professor Dellian Fel.
- P1 triggered The Ring
- P1 triggered Orcish Siegemaster
- left battlefield: Professor Dellian Fel was put into Graveyard from Battlefield.
- P1 cast Sauron, the Dark Lord

## Turn 34 (P2, round 9)
- P2 cast The Masamune
- P1 triggered Sauron, the Dark Lord
- P2 activated The Masamune targeting [Marionette Apprentice]

## Turn 35 (P3, round 9) | life: P1 17, P2 25, P3 32, US 16
- P3 triggered Black Market Connections
- P3 cast Irenicus's Vile Duplication targeting [Y'shtola, Night's Blessed]
- P3 triggered Y'shtola, Night's Blessed
- P3 triggered G'raha Tia, Scion Reborn
- P1 triggered Sauron, the Dark Lord
- P3 triggered Vito, Thorn of the Dusk Rose targeting [P4]
- P3 cast Lyse Hext
- P1 triggered Sauron, the Dark Lord
- P3 triggered Y'shtola, Night's Blessed
- P3 triggered Y'shtola, Night's Blessed
Damage to US this turn: Y'shtola, Night's Blessed (non-combat) 2

## Turn 36 (OUR TURN, round 9) | life: P1 17, P2 19, P3 32, US 15
Our hand: Survival of the Fittest, Command Tower, Heroic Intervention, Darkslick Shores, The One Ring
Our graveyard (5): Three Visits, Baleful Strix, Doc Aurlock, Grizzled Genius, Verdant Catacombs, Professor Dellian Fel
Board P1: 7 lands; Fellwar Stone (tapped 1), Nazgûl 3/4 {[P1P1 x 2]} (tapped 1), Orcish Siegemaster 0/5 (tapped 1), Sauron, the Dark Lord 7/6, Orc Army Token 3/3 [token] {[P1P1 x 3]}
Board P2: 5 lands; Marionette Apprentice 1/2, Servo Token 1/1 [token], Human Token 1/1 [token], The Masamune
Board P3: 7 lands; Fellwar Stone (tapped 1), Propaganda, Y'shtola, Night's Blessed 2/4, Vito, Thorn of the Dusk Rose 1/3, Black Market Connections, G'raha Tia, Scion Reborn 2/3, Hero Token 5/5 [token] {[P1P1 x 4]}, Y'shtola, Night's Blessed 2/4 [token], Lyse Hext 2/2
Board US: 9 lands; Talisman of Dominance, Cryogen Relic, Muldrotha, the Gravetide 6/6, Hostage Taker 2/3
MEMO (start of our turn):
THIS TURN: 1) Land lane: Verdant Catacombs from the graveyard, fetch a basic Swamp (1 life, 11 mana). 2) Doc Aurlock from the graveyard (Otawara U + Boseiju G). 3) Professor Dellian Fel from the graveyard, costs BG after Doc (Swamp + Bayou). Use −3 on Vito. 4) Cast The One Ring (4: Underground Sea, Triome, Talisman, Hinterland Harbor). This gives us protection from everything until our next turn and blanks the Y'shtola/Vito drains and P1's 20 power. Tap the Ring now to draw 1. 5) Attack P2 with Muldrotha only; never attack P1 (Sauron blocks) or P3 (Propaganda). Keep Tropical Island and Breeding Pool open.

TARGET: Fel ticking, Doc, Survival of the Fittest active, with Massacre Wurm and Gray Merchant cycling through the graveyard. Missing: Survival needs a creature card in hand, so dig with Ring draws.

WIN PATH: Massacre Wurm clears P3's X/2s and P2's tokens. Then Gray Merchant and Syr Konrad drain, and Muldrotha beats down. About 4-5 turns. P1's Army/Sauron clock is fastest, around 2-3 turns.

THREATS & ANSWERS: 1) P3's drain engine (two Y'shtolas, G'raha, Hero): Fel −3 next turn on the Y'shtola commander, then Wurm. 2) Sauron and Siegemaster: Fel −3, paying ward by sacrificing Doc, then recast Doc. 3) Sephiroth recast: Fel or Strix blocks. Every spell we cast amasses P1's Army, so cast few.

HOLD: Heroic Intervention (Tropical Island + Breeding Pool) against Blasphemous Act or Toxic Deluge, to save Hostage Taker (keeps Drivnod exiled) and Muldrotha. Hold Baleful Strix and Survival until next turn.

REPLAN IF: The Ring is countered (P3 has Command Tower open), Hostage Taker dies, or P1 wheels.
PILOT OVERRULED FORGE (action, MAIN1): chose [play land Verdant Catacombs (from Graveyard): Play land by Muldrotha, the Gravetide (403) ] instead of Forge's [play land Command Tower (from Hand): Play land]
PILOT OVERRULED FORGE (action, MAIN1): chose [cast The One Ring (from Hand): The One Ring [Forge's heuristic AI would not do this: CantP] instead of Forge's [cast Heroic Intervention (from Hand): Permanents you control gain hexproof and indestructi]
PILOT OVERRULED FORGE (attack, COMBAT_DECLARE_ATTACKERS): chose [attack P2 (25 life)] instead of Forge's [attack P3 (32 life)]
PILOT OVERRULED FORGE (action, MAIN2): chose [Y'shtola, Night's Blessed [P3, 2/4, commander]] instead of Forge's [Y'shtola, Night's Blessed [P3, 2/4, token]]
- left battlefield: Verdant Catacombs was put into Graveyard from Battlefield.
- US activated Verdant Catacombs
- US cast The One Ring
- P1 triggered Sauron, the Dark Lord
- US triggered The One Ring
- US activated The One Ring
- US cast Heroic Intervention
- P1 triggered Sauron, the Dark Lord
- attack: US assigned Muldrotha, the Gravetide to attack P2.
- US cast Doc Aurlock, Grizzled Genius
- P1 triggered Sauron, the Dark Lord
- US cast Professor Dellian Fel
- P1 triggered Sauron, the Dark Lord
- US activated Professor Dellian Fel targeting [Y'shtola, Night's Blessed]
- left battlefield: Y'shtola, Night's Blessed was put into Graveyard from Battlefield.
- P3 triggered Y'shtola, Night's Blessed

## Turn 37 (P1, round 10)
PILOT OVERRULED FORGE (block, COMBAT_DECLARE_BLOCKERS): chose [block with Doc Aurlock, Grizzled Genius 2/3] instead of Forge's [no block (take the damage)]
- P1 cast Summons of Saruman
- attack: P1 assigned Orcish Siegemaster, Sauron, the Dark Lord, Orc Army Token and Nazgûl to attack Professor Dellian Fel.
- P1 triggered The Ring
- P1 triggered Orcish Siegemaster
- P1 triggered The Ring
- left battlefield: Professor Dellian Fel was put into Graveyard from Battlefield.
- left battlefield: Doc Aurlock, Grizzled Genius was put into Graveyard from Battlefield.
- P1 activated Barad-dûr
- P1 triggered The Ring
- P1 cast Call of the Ring

## Turn 38 (P2, round 10) | life: P1 17, P2 14, P3 32, US 15
- P2 cast Bolas's Citadel
- P1 triggered Sauron, the Dark Lord
- P2 cast Syr Konrad, the Grim
- P1 triggered Sauron, the Dark Lord
- P3 triggered Y'shtola, Night's Blessed

## Turn 39 (P3, round 10) | life: P1 -12, P2 -3, P3 51, US 15
MEMO (executor escalation: P3: life 32→51 (+19)):
THIS TURN: Syphon Mind now: discard Darkslick Shores (Muldrotha can replay it). P3 is fully tapped, so our turn is open. Our turn has 12 mana: 11 sources plus the Island land drop. The Ring's upkeep costs 1 life. Tap The One Ring and draw 2. Sac Cryogen Relic ({1}{U}): stun the tapped 5/5 Hero, draw. Cast Survival ({1}{G}). If we hold a creature card, pay {G} and discard it to fetch Massacre Wurm, then cast Wurm (6). It kills Vito, G'raha and Lyse Hext, and P3 loses 6. If we have no creature card, cast Doc from the graveyard ({G}{U}). Then cast Fel from the graveyard ({B}{G}) and −3 on Vito. Recast Cryogen for {U} and draw. Don't attack.

TARGET: Wurm on the battlefield, Survival active, Fel ticking, Gray Merchant and Syr Konrad recurring through the creature lane. Then Seal of Primordium or Assassin's Trophy on Propaganda and Ghostly Prison. Next Survival fetches: Glen Elendra, then Gray Merchant.

WIN PATH: Heads-up vs P3 (51). Wurm drain, then Gray Merchant each turn (black devotion is high), then Muldrotha and Wurm swing once the Prisons are gone. About 5-6 turns.

THREATS & ANSWERS: 1) Vito. Its lifelink Heroes swing for 9, plus Vito's 9 = 18, which kills us at 15. Answer: Wurm, or Fel −3. 2) Y'shtola: 2 per MV3+ spell. Answer: Fel −3 next turn. 3) Lifelink Heroes: stun them with Cryogen, block with Muldrotha. 4) Exsanguinate: Survival for Glen Elendra.

HOLD: Keep Muldrotha and Hostage Taker untapped as blockers. Fire Survival only with a creature card to discard.

REPLAN IF: P3 untaps a free counter, Vito survives our turn, or Ring burden life loss exceeds 3 (find Claws of Gix).
ESCALATION (p=0.82): P3: life 32→51 (+19)
- P3 triggered Black Market Connections
- P3 cast Ghostly Prison
- P3 triggered Y'shtola, Night's Blessed
- P3 triggered Lyse Hext
- P3 triggered G'raha Tia, Scion Reborn
- P1 triggered Sauron, the Dark Lord
- P3 triggered Vito, Thorn of the Dusk Rose targeting [P1]
- P3 cast Talisman of Dominance
- P3 triggered Lyse Hext
- P1 triggered Sauron, the Dark Lord
- P3 cast Arcane Signet
- P3 triggered Lyse Hext
- P1 triggered Sauron, the Dark Lord
- attack: P3 assigned Hero Token, Lyse Hext, G'raha Tia, Scion Reborn, Y'shtola, Night's Blessed and Vito, Thorn of the Dusk Rose to attack P1.
- P3 activated Vito, Thorn of the Dusk Rose
- P3 triggered Vito, Thorn of the Dusk Rose targeting [P1]
- P3 triggered Vito, Thorn of the Dusk Rose targeting [P2]
- P3 triggered Vito, Thorn of the Dusk Rose targeting [P2]
- P3 triggered Vito, Thorn of the Dusk Rose targeting [P2]
- P3 triggered Vito, Thorn of the Dusk Rose targeting [P2]
- P3 triggered Vito, Thorn of the Dusk Rose targeting [P2]
- P3 cast Syphon Mind
- P3 triggered Y'shtola, Night's Blessed
- P3 triggered Lyse Hext
- P3 triggered Y'shtola, Night's Blessed

## Turn 40 (OUR TURN, round 10) | life: P1 -12, P2 -3, P3 46, US 9
Our hand: Survival of the Fittest, Command Tower, Darkslick Shores
Our graveyard (7): Three Visits, Baleful Strix, Verdant Catacombs, Heroic Intervention, Professor Dellian Fel, Doc Aurlock, Grizzled Genius, Island
Board P3: 8 lands; Fellwar Stone (tapped 1), Propaganda, Vito, Thorn of the Dusk Rose 1/3 (tapped 1), Black Market Connections, G'raha Tia, Scion Reborn 2/3 (tapped 1), Hero Token 5/5 [token] {[P1P1 x 4]} (tapped 1), Y'shtola, Night's Blessed 2/4 [token], Lyse Hext 2/2 (tapped 1), Hero Token 4/4 [token] {[P1P1 x 3]}, Ghostly Prison, Talisman of Dominance (tapped 1), Arcane Signet (tapped 1)
Board US: 10 lands; Talisman of Dominance, Cryogen Relic, Muldrotha, the Gravetide 6/6, Hostage Taker 2/3, The One Ring {[BURDEN]}
MEMO (start of our turn):
THIS TURN: Let the stack resolve; Hostage Taker dies. Expect us at about 10 life after the Y'shtola and Vito drains and the Ring upkeep. Land: Command Tower, for 12 mana. Tap The One Ring and draw. Sac Cryogen ({1}{U}), stun the tapped 5/5 Hero, draw.
- If we hold a creature card (Grist counts): Survival ({1}{G}), then {G} and discard it to fetch Massacre Wurm. Cast Wurm (6); it kills Vito, G'raha and Lyse, and P3 loses 6.
- If we have no creature: Strix from the graveyard ({U}{B}, draw). Then Hostage Taker from the graveyard (4) exiling a Hero token, which is gone for good. Then Fel from the graveyard (4), −3 on Vito.
Don't attack.

TARGET: Next turn, Survival for Gravebreaker Lamia, which puts Pernicious Deed into our graveyard. Cast Deed from the graveyard and activate it at X=4: it kills their whole board and both Prisons, while Muldrotha (MV6) survives. Then Gray Merchant.

WIN PATH: After Deed, Gray Merchant, Wurm and Syr Konrad drains plus Muldrotha beats. P3 is at 47, so 5+ turns. P3 can kill us next turn: about 20 power against our 10 life.

THREATS & ANSWERS: 1) Vito: lifelink turns every life gain into a drain on us. Answer: Wurm or Fel −3. 2) Hero tokens: Cryogen stun, Otawara channel ({2}{U}) bounce, or Hostage Taker. 3) Y'shtola (2 damage per MV3+ spell): Deed next turn. 4) Exsanguinate: Glen Elendra later.

HOLD: Keep Muldrotha and Wurm untapped as blockers. Keep any spare 3 mana for an Otawara bounce on an attacking Hero during P3's turn. Don't channel Boseiju on the Prisons yet.

REPLAN IF: The card Hostage Taker exiled returns as a big threat, the Ring burden is 2 or more, or Wurm gets countered.
MEMO (executor escalation: we lost: Hostage Taker):
THIS TURN: P3 is fully tapped out; strike now. Play Command Tower (12 mana).
1. Demonic Tutor ({1}{B}) for Pernicious Deed.
2. Cast Deed ({1}{B}{G}).
3. Activate Deed at X=4 (4 mana). It kills Vito, G'raha, Lyse, Y'shtola, all Heroes, Propaganda, Ghostly Prison, Black Market Connections and their rocks. Muldrotha (MV6) and The One Ring (indestructible) survive. Cryogen Relic dies and draws a card. Our Talisman dies too; that's acceptable.
4. Attack with Muldrotha for 6.
5. Main 2, last 3 mana: Survival of the Fittest ({1}{G}), then {G} and discard Dalek Drone to fetch Glen Elendra Archmage. Don't cast Wayfarer's Bauble.

TARGET: Muldrotha protected by Glen Elendra. Each turn, Dalek Drone from the graveyard via the artifact lane kills a rebuilt creature and drains 3. Deed stays recastable from the graveyard (3). Survival finds Gray Merchant, Kokusho and Massacre Wurm.

WIN PATH: This is now heads-up versus P3 at 46. Muldrotha beats (6 a turn) plus Drone, Gray Merchant and Kokusho drains close it in about 5-6 turns. Our life is 9 and the Ring costs 2 each upkeep. Use Fel +2 from the graveyard for life when mana allows.

THREATS & ANSWERS: 1) A recast Y'shtola or Vito: Drone from the graveyard, or Fel −3. 2) Exsanguinate, or Swords/Void Rend on Muldrotha: Glen Elendra from next turn. 3) New Heroes: Deed recast.

HOLD: Keep Darkslick Shores (it enters tapped) and Wayfarer's Bauble for next turn. Keep Otawara as a land; don't channel it.

REPLAN IF: Deed or Demonic Tutor gets countered (Fierce Guardianship is free with Y'shtola out). Then cast Survival, discard Drone for Massacre Wurm, and keep Muldrotha home. Also replan if P3 flashes in a blocker.
ESCALATION (p=0.84): we lost: Hostage Taker
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Demonic Tutor (from Hand): Search your library for a card, put that card into your ha] instead of Forge's [cast Hostage Taker (from Graveyard): Hostage Taker - Creature 2 / 3 by Muldrotha, the Grav]
PILOT OVERRULED FORGE (search, MAIN1): chose [Pernicious Deed — Enchantment — {X}, Sacrifice Pernicious Deed: Destroy each artifact, cre] instead of Forge's [Kokusho, the Evening Star — Legendary Creature - Dragon Spirit — Flying When Kokusho, the ]
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Pernicious Deed (from Hand): Pernicious Deed [Forge's heuristic AI would not do this:] instead of Forge's [cast Hostage Taker (from Graveyard): Hostage Taker - Creature 2 / 3 by Muldrotha, the Grav]
- US triggered The One Ring
- P3 cast Dismember targeting [Hostage Taker]
- P3 triggered Y'shtola, Night's Blessed
- P3 triggered Lyse Hext
- P3 triggered G'raha Tia, Scion Reborn
- US activated The One Ring
- P3 triggered Vito, Thorn of the Dusk Rose targeting [P4]
- left battlefield: Hostage Taker was put into Graveyard from Battlefield.
- US cast Demonic Tutor
- US cast Pernicious Deed
- left battlefield: Pernicious Deed was put into Graveyard from Battlefield.
- US activated Pernicious Deed
- left battlefield: Talisman of Dominance was put into Graveyard from Battlefield.
- left battlefield: Cryogen Relic was put into Graveyard from Battlefield.
- left battlefield: Muldrotha, the Gravetide was put into Graveyard from Battlefield.
- left battlefield: Fellwar Stone was put into Graveyard from Battlefield.
- left battlefield: Propaganda was put into Graveyard from Battlefield.
- left battlefield: Vito, Thorn of the Dusk Rose was put into Graveyard from Battlefield.
- left battlefield: Black Market Connections was put into Graveyard from Battlefield.
- left battlefield: G'raha Tia, Scion Reborn was put into Graveyard from Battlefield.
- left battlefield: Y'shtola, Night's Blessed was put into Graveyard from Battlefield.
- left battlefield: Lyse Hext was put into Graveyard from Battlefield.
- left battlefield: Ghostly Prison was put into Graveyard from Battlefield.
- left battlefield: Talisman of Dominance was put into Graveyard from Battlefield.
- left battlefield: Arcane Signet was put into Graveyard from Battlefield.
- US triggered Cryogen Relic
Damage to US this turn: Y'shtola, Night's Blessed (non-combat) 2

## Turn 41 (P3, round 11)
- P3 cast Y'shtola, Night's Blessed

## Turn 42 (OUR TURN, round 11) | life: P1 -12, P2 -3, P3 43, US 13
Our hand: Survival of the Fittest, Darkslick Shores, Wayfarer's Bauble, Dalek Drone, Claws of Gix, Soul-Guide Lantern
Our graveyard (12): Three Visits, Baleful Strix, Verdant Catacombs, Heroic Intervention, Professor Dellian Fel, Doc Aurlock, Grizzled Genius, Island, Hostage Taker, Demonic Tutor, Pernicious Deed, Talisman of Dominance, Cryogen Relic
Board P3: 9 lands; Y'shtola, Night's Blessed 2/4
Board US: 11 lands; The One Ring {[BURDEN x 2]}
MEMO (start of our turn):
THIS TURN: Heads-up. We're at 7 and P3 has 1 open mana (Underground River).
1. Tap The One Ring (burden 3, draw 3).
2. Cast Claws of Gix (0), then {1} to sacrifice the Ring (life 8, no upkeep loss).
3. Play Darkslick Shores (it enters tapped).
4. Cast Dalek Drone (5) targeting Y'shtola (P3 goes to 43). Do this before any noncreature spell, since Fierce Guardianship is free while Y'shtola is out.
5. Cast Survival (2). If the Ring drew a creature, pay {G} and discard it to fetch Glen Elendra Archmage.
6. With what's left, cast Wayfarer's Bauble (1) and Soul-Guide Lantern (1). Lantern's entry trigger exiles the best spell in P3's graveyard (Exsanguinate first).

TARGET: Next turn, 14 lands: Muldrotha (10), Doc Aurlock from the graveyard (2), then The One Ring from the graveyard (2) for protection from everything. Then Glen Elendra, and Drone recurring every turn via Claws. Survival targets: Glen Elendra, Gray Merchant, Plaguecrafter.

WIN PATH: P3 is at 43. Muldrotha (6), the Drone recast each turn (kill plus drain 3), Gray Merchant and Fel's −6 emblem with Claws: about 5 turns. P3 can kill us any turn with Exsanguinate, so life gain comes first (Fel +2, Gray Merchant).

THREATS & ANSWERS: 1) Exsanguinate: Glen Elendra, or a drawn Counterspell or Swan Song. 2) Y'shtola recast: Drone (sacrifice it to Claws, recast it), Fel −3, or Plaguecrafter if P3 gives it protection. 3) Removal on Muldrotha: the recast Ring's protection.

HOLD: Keep Otawara and Boseiju as lands. Keep Lantern's graveyard exile for Emet-Selch recursion.

REPLAN IF: The Ring draws Counterspell or Swan Song: keep UU open and skip Bauble and Lantern. Y'shtola survives the Drone (Flawless Maneuver): hold the Claws sacrifice until P3's end step and aim for Plaguecrafter.
PILOT OVERRULED FORGE (action, MAIN1): chose [activate The One Ring (from Battlefield): {T}: Put a burden counter on The One Ring, then ] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Claws of Gix (from Hand): Claws of Gix] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Dalek Drone (from Hand): Dalek Drone - Creature 3 / 3 [Forge's heuristic AI would not] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN1): chose [activate Claws of Gix (from Battlefield): {1}, Sacrifice a permanent: You gain 1 life. [Fo] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN1): chose [activate Claws of Gix (from Battlefield): {1}, Sacrifice a permanent: You gain 1 life. [Fo] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN1): chose [activate Claws of Gix (from Battlefield): {1}, Sacrifice a permanent: You gain 1 life. [Fo] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN1): chose [activate Claws of Gix (from Battlefield): {1}, Sacrifice a permanent: You gain 1 life. [Fo] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN1): chose [activate Claws of Gix (from Battlefield): {1}, Sacrifice a permanent: You gain 1 life. [Fo] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN1): chose [activate Claws of Gix (from Battlefield): {1}, Sacrifice a permanent: You gain 1 life. [Fo] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
- US triggered The One Ring
- US activated The One Ring
- US cast Claws of Gix
- US cast Dalek Drone
- US triggered Dalek Drone targeting [Y'shtola, Night's Blessed]
- left battlefield: Y'shtola, Night's Blessed was put into Graveyard from Battlefield.
- left battlefield: Underground Sea was put into Graveyard from Battlefield.
- US activated Claws of Gix
- left battlefield: Hinterland Harbor was put into Graveyard from Battlefield.
- US activated Claws of Gix
- left battlefield: Overgrown Tomb was put into Graveyard from Battlefield.
- US activated Claws of Gix
- left battlefield: Tropical Island was put into Graveyard from Battlefield.
- US activated Claws of Gix
- left battlefield: Otawara, Soaring City was put into Graveyard from Battlefield.
- US activated Claws of Gix
- left battlefield: Boseiju, Who Endures was put into Graveyard from Battlefield.
- US activated Claws of Gix

## Turn 43 (P3, round 11)
- P3 cast Y'shtola, Night's Blessed

## Turn 44 (OUR TURN, round 11) | life: P1 -12, P2 -3, P3 40, US 11
Our hand: Survival of the Fittest, Wayfarer's Bauble, Soul-Guide Lantern, Secrets of the Dead, Mulldrifter, Siren Stormtamer, Sheoldred
Our graveyard (18): Three Visits, Baleful Strix, Verdant Catacombs, Heroic Intervention, Professor Dellian Fel, Doc Aurlock, Grizzled Genius, Island, Hostage Taker, Demonic Tutor, Pernicious Deed, Talisman of Dominance, Cryogen Relic, Underground Sea, Hinterland Harbor, Overgrown Tomb, Tropical Island, Otawara, Soaring City, Boseiju, Who Endures
Board P3: 10 lands; Y'shtola, Night's Blessed 2/4
Board US: 6 lands; The One Ring {[BURDEN x 3]}, Claws of Gix, Dalek Drone 3/3
MEMO (start of our turn):
THIS TURN: Heads-up. P3 is fully tapped out (10 lands) with only Y'shtola on board. We're at 10.
1. Tap The One Ring: burden 4, draw 4. Play any untapped land drawn.
2. Cast Sheoldred (5) first. It's a creature, so Fierce Guardianship can't hit it, and P3's only creature is Y'shtola, so P3 must sacrifice it.
3. Attack P3 with Dalek Drone (3 flying).
4. Pay {1} on Claws to sacrifice the Ring before P3's end step. Otherwise we lose 4 at upkeep.
5. Spare mana, in priority order: hold a drawn Swan Song or Counterspell for Exsanguinate, then the Ring sacrifice, then Siren Stormtamer (U), then Wayfarer's Bauble. Cast noncreature spells only after Y'shtola is gone.

TARGET: Reach 10 mana for Muldrotha, via Bauble fetches and Survival for Sakura-Tribe Elder or Birds of Paradise. Then Doc Aurlock, Secrets of the Dead and Glen Elendra Archmage, with Drone recast every turn via Claws.

WIN PATH: P3 is at 43. Drone (3) plus Sheoldred (4 menace) swing each turn, then Muldrotha, Drone recasts (drain 3) and Gray Merchant. About 5 turns. P3 can Exsanguinate us any turn; X=8 now takes us to about 3.

THREATS & ANSWERS: 1) Exsanguinate: a drawn Swan Song or Counterspell now, Glen Elendra via Survival next turn. 2) Y'shtola recast (costs 8): Drone recast, Fel −3, Sheoldred's saga. 3) Removal on Sheoldred: Stormtamer.

HOLD: Survival, Secrets and Mulldrifter until next turn (Survival fetches Glen Elendra, or a ramp creature). Keep Soul-Guide Lantern for Emet-Selch or recursion.

REPLAN IF: The Ring draws 2+ lands or ramp, which puts Muldrotha within reach next turn. P3 answers Sheoldred at instant speed. P3 recasts Y'shtola: Drone and Sheoldred's saga go first.
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Sheoldred (from Hand): Sheoldred - Creature 4 / 5 [Forge's heuristic AI would not do ] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN2): chose [activate Claws of Gix (from Battlefield): {1}, Sacrifice a permanent: You gain 1 life. [Fo] instead of Forge's [cast Siren Stormtamer (from Hand): Siren Stormtamer - Creature 1 / 1]
PILOT OVERRULED FORGE (action, MAIN2): chose [activate The One Ring (from Battlefield): {T}: Put a burden counter on The One Ring, then ] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
- US triggered The One Ring
- US cast Sheoldred
- US triggered Sheoldred
- left battlefield: Y'shtola, Night's Blessed was put into Graveyard from Battlefield.
- attack: US assigned Dalek Drone to attack P3.
- left battlefield: Bayou was put into Graveyard from Battlefield.
- US activated Claws of Gix
- US activated The One Ring

## Turn 45 (P3, round 12) | life: P1 -12, P2 -3, P3 41, US 10
- P3 cast Relic of Legends
- P3 cast Teferi, Time Raveler
- P3 activated Teferi, Time Raveler targeting [Sheoldred]
- P3 cast Frantic Search
- P3 cast Papalymo Totolymo
- P3 cast Sigil of Sleep targeting [Papalymo Totolymo]
- P3 triggered Papalymo Totolymo
Damage to US this turn: Papalymo Totolymo (non-combat) 1

## Turn 46 (OUR TURN, round 12) | life: P1 -12, P2 -3, P3 41, US 6
Our hand: Survival of the Fittest, Secrets of the Dead, Mulldrifter, Siren Stormtamer, Toxic Deluge, Marionette Apprentice, Shriekmaw, Sheoldred, Seal of Doom
Our graveyard (22): Three Visits, Baleful Strix, Verdant Catacombs, Heroic Intervention, Professor Dellian Fel, Doc Aurlock, Grizzled Genius, Island, Hostage Taker, Demonic Tutor, Pernicious Deed, Talisman of Dominance, Cryogen Relic, Underground Sea, Hinterland Harbor, Overgrown Tomb, Tropical Island, Otawara, Soaring City, Boseiju, Who Endures, Bayou, Soul-Guide Lantern
Board P3: 11 lands; Relic of Legends, Teferi, Time Raveler {[LOYALTY]}, Papalymo Totolymo 1/2, Sigil of Sleep
Board US: 5 lands; The One Ring {[BURDEN x 4]}, Claws of Gix, Dalek Drone 3/3
MEMO (start of our turn):
THIS TURN: We're at 6 and P3 is at 41. P3 has 3 open mana (Command Tower, Underground River, Relic) and 2 cards.
1. Tap The One Ring to burden 5 and draw 5. Play any land drawn.
2. Attack Teferi with Dalek Drone. It flies, so Papalymo can't block, and 3 damage kills Teferi at 1 loyalty. Killing Teferi restores our instant speed.
3. Keep {1} for Claws of Gix to sacrifice the Ring in our main 2. This is mandatory; otherwise we lose 5 at upkeep.
4. With the other 4 mana, in priority:
   a) If we drew Counterspell or Swan Song, hold its mana through P3's turn for Exsanguinate or Y'shtola's big spells.
   b) Cast Siren Stormtamer (U).
   c) Cast Survival (1G), then G and discard Mulldrifter to fetch Glen Elendra Archmage.

TARGET: Glen Elendra on board to stop Exsanguinate. Then Sheoldred to force a sacrifice, and Gray Merchant for drain plus lifegain. Survival next finds Sakura-Tribe Elder to ramp toward Muldrotha (10 mana).

WIN PATH: Stabilise first. Win with Drone swings, Gray Merchant (Sheoldred, Drone and Gary give devotion 6), then Muldrotha loops. About 6 turns. P3 can kill us any turn with Exsanguinate.

THREATS & ANSWERS:
1) Exsanguinate: a drawn counter now, Glen Elendra next turn.
2) Y'shtola recast: she is black, so Seal of Doom and Shriekmaw can't hit her. Use Sheoldred or Dellian Fel −3.
3) Papalymo's Sigil bounce: Stormtamer counters it.

HOLD: Seal of Doom and Shriekmaw for nonblack creatures. Toxic Deluge: we can't afford the life.

REPLAN IF: Teferi survives the attack. P3 casts Y'shtola. We fall to 3 life or lower.
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Siren Stormtamer (from Hand): Siren Stormtamer - Creature 1 / 1 [Forge's heuristic AI] instead of Forge's [cast Seal of Doom (from Hand): Seal of Doom]
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Survival of the Fittest (from Hand): Survival of the Fittest [Forge's heuristic AI wo] instead of Forge's [cast Seal of Doom (from Hand): Seal of Doom]
PILOT OVERRULED FORGE (action, MAIN1): chose [activate The One Ring (from Battlefield): {T}: Put a burden counter on The One Ring, then ] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
- US triggered The One Ring
- US cast Siren Stormtamer
- US cast Survival of the Fittest
- US activated The One Ring
- US cast Farseek
- attack: US assigned Dalek Drone to attack Teferi, Time Raveler.
- left battlefield: Teferi, Time Raveler was put into Graveyard from Battlefield.

## Turn 47 (P3, round 12)
- left battlefield: Papalymo Totolymo was put into Graveyard from Battlefield.
- P3 activated Papalymo Totolymo
- left battlefield: Sigil of Sleep was put into Graveyard from Battlefield.

## Turn 48 (OUR TURN, round 12) | life: P1 -12, P2 -3, P3 41, US 6
Our hand: Mulldrifter, Toxic Deluge, Shriekmaw, Sheoldred, Glen Elendra Archmage, Syr Konrad, the Grim, Barrin, Master Wizard, Baba Lysaga, Night Witch
Our graveyard (27): Three Visits, Baleful Strix, Verdant Catacombs, Heroic Intervention, Professor Dellian Fel, Doc Aurlock, Grizzled Genius, Island, Hostage Taker, Demonic Tutor, Pernicious Deed, Talisman of Dominance, Cryogen Relic, Underground Sea, Hinterland Harbor, Overgrown Tomb, Tropical Island, Otawara, Soaring City, Boseiju, Who Endures, Bayou, Soul-Guide Lantern
Board P3: 12 lands; Relic of Legends
Board US: 6 lands; The One Ring {[BURDEN x 5]}, Claws of Gix, Dalek Drone 3/3, Siren Stormtamer 1/1, Survival of the Fittest
MEMO (start of our turn):
THIS TURN: We are at 1 life. Pay no life at all: no fetches, shocks enter tapped, no Talisman, no Deluge.
1. Tap The One Ring (burden 6), draw 6. Then Claws {1}: sacrifice the Ring (we reach 2 life). This is mandatory, or we lose 6 at upkeep.
2. Play an untapped land if drawn. Cast Sol Ring if drawn.
3. If we drew Counterspell, hold UU for Y'shtola or Exsanguinate. If Swan Song, hold U.
4. If 6+ mana remains: Survival {G}, discard Shriekmaw, fetch Gray Merchant. Cast it (5). Devotion 4 drains 4, taking us to about 6. Skip Survival if Gary was drawn.
5. Otherwise use Survival to fetch Gary for next turn, and cast Glen Elendra (4) if affordable.
6. Attack P3 with Drone and Stormtamer; they have no creatures.

TARGET: Life 10+, with Glen Elendra, Sheoldred and Baba Lysaga on board. Baba sacrifices Claws, Stormtamer and a land to drain 3, gain 3 and draw 3.

WIN PATH: Drone swings, Gary drains (devotion 6 with Sheoldred), Syr Konrad. About 7 turns; P3 can kill us any turn.

THREATS & ANSWERS:
1) Y'shtola recast. Each MV3+ noncreature spell pings us 2 on cast, and countering the spell doesn't stop the ping. Answers: Counterspell on her; Sheoldred edict next turn; Barrin bounce. She is black, so Shriekmaw and Seal of Doom can't hit her.
2) Exsanguinate: Glen Elendra, Swan Song or Counterspell.

HOLD: Any counterspell mana. Toxic Deluge stays in hand.

REPLAN IF: Y'shtola resolves; we reach 10+ life; P3 casts Propaganda or removes Survival.
MEMO (executor escalation: we lost: Dalek Drone):
THIS TURN: Life 5. The Ring's 6 burden kills us at upkeep. First, Claws {1} (tap Command Tower): sacrifice The One Ring, gain 1, to 6. Keep Watery Grave open for U: Stormtamer counters anything targeting us or Stormtamer on P3's turn. Pay no life anywhere: no Delta, no Deluge. At cleanup, discard down to these 7: Forest, The Death of Gwen Stacy, Glen Elendra, Baba Lysaga, Dalek Drone, Sheoldred, Shriekmaw (Survival fodder).

TARGET: Next turn, play Forest for 4 mana (Grave, Tower, Swamp, Forest).
- If Y'shtola is on board: Death of Gwen Stacy (3) kills her; hold U.
- Otherwise: Baba Lysaga (3), plus Survival {G} discarding Shriekmaw for Gray Merchant.
- The turn after: Baba taps and sacrifices a land, Claws and Stormtamer (3 types) to drain 3, gain 3, draw 3. Or cast Gary.

WIN PATH: Stabilise first. Baba drains, Gary, Dalek Drone (kill plus 3), Sheoldred. P3 is at 41, so this is a long grind. Muldrotha (10 mana) is out of reach for now.

THREATS & ANSWERS:
1) Y'shtola: 2 per MV3+ spell she sees. Answers: Gwen Stacy chapter I, Dalek Drone, Sheoldred edict. She is black, so Shriekmaw and Seal of Doom can't hit her.
2) Exsanguinate or a big X drain: Glen Elendra, once cast. Stormtamer can't stop non-targeted drains.
3) Snuff Out or Swords on our key creature: Stormtamer.

HOLD: U for Stormtamer. Toxic Deluge and fetch lands stay unused while we are under 10 life.

REPLAN IF: we go below 4 life; P3 casts Y'shtola, Kambal or Propaganda; we draw a land or ramp, since 5 mana means Dalek Drone or Gary now.
PILOT OVERRULED FORGE (action, MAIN1): chose [activate Claws of Gix (from Battlefield): {1}, Sacrifice a permanent: You gain 1 life.] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN1): chose [activate The One Ring (from Battlefield): {T}: Put a burden counter on The One Ring, then ] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN1): chose [activate Claws of Gix (from Battlefield): {1}, Sacrifice a permanent: You gain 1 life.] instead of Forge's [play land Forest (from Hand): Play land]
PILOT OVERRULED FORGE (action, MAIN1): chose [activate Claws of Gix (from Battlefield): {1}, Sacrifice a permanent: You gain 1 life.] instead of Forge's [play land Forest (from Hand): Play land]
PILOT OVERRULED FORGE (action, MAIN1): chose [activate Claws of Gix (from Battlefield): {1}, Sacrifice a permanent: You gain 1 life.] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (attack, COMBAT_DECLARE_ATTACKERS): chose [don't attack with it] instead of Forge's [attack P3 (41 life)]
ESCALATION (p=0.83): we lost: Dalek Drone
PILOT OVERRULED FORGE (action, MAIN2): chose [activate Claws of Gix (from Battlefield): {1}, Sacrifice a permanent: You gain 1 life. [Fo] instead of Forge's [cast Underhanded Designs (from Hand): Underhanded Designs]
- US triggered The One Ring
- left battlefield: Swamp was put into Graveyard from Battlefield.
- US activated Claws of Gix
- US activated The One Ring
- left battlefield: Zagoth Triome was put into Graveyard from Battlefield.
- US activated Claws of Gix
- left battlefield: Darkslick Shores was put into Graveyard from Battlefield.
- US activated Claws of Gix
- left battlefield: Breeding Pool was put into Graveyard from Battlefield.
- US activated Claws of Gix
- attack: US assigned Dalek Drone to attack P3.
- P3 cast Sink into Stupor targeting [Dalek Drone]
- left battlefield: Claws of Gix was put into Graveyard from Battlefield.
- US activated Claws of Gix

## Turn 49 (P3, round 13)
MEMO (executor escalation: we lost: Claws of Gix):
THIS TURN: Our upkeep kills us. The One Ring has 6 burden counters and we are at 6 life. Claws of Gix is gone, and nothing in hand is instant-speed, so we cannot remove the Ring or gain life first. Removing the Ring in response to its trigger still counts 6 counters. Do nothing to the Ring. In upkeep, do not tap it: that makes 7 burden. Keep the untapped Command Tower's U for Stormtamer, but only against something that targets us. If P3 bounces or exiles the Ring (Sink into Stupor, Anguished Unmaking), let it resolve, because that saves us.

TARGET: Only if we survive upkeep:
- Ring gone: play Forest (4 mana) and cast The Death of Gwen Stacy on Y'shtola.
- Ring still here: in main phase tap it to draw, then play Forest. Cast Barrin (3), and next turn use {2} and sacrifice the Ring to bounce Y'shtola. If the draws include Sol Ring, do Barrin and the activation this turn (5 mana).

WIN PATH: Survive first. Then Baba Lysaga, sacrificing a land, an artifact and a creature, drains 3 and draws 3 each turn. P3 is at 41, so this is a long grind.

THREATS & ANSWERS: 1) The Ring's upkeep trigger: no answer. 2) Y'shtola pings 2 per MV3+ spell she sees: Gwen Stacy chapter I, or a Barrin bounce. 3) Targeted removal: Stormtamer.

HOLD: Toxic Deluge; pay no life anywhere. Hold Glen Elendra until we have the mana.

REPLAN IF: the Ring leaves the battlefield, our life total rises, or we somehow survive the upkeep trigger.
ESCALATION (p=0.81): we lost: Claws of Gix
PILOT OVERRULED FORGE (action, END_OF_TURN): chose [Do nothing now; let it resolve / let the turn pass (this skips o0, the play Forge's AI wou] instead of Forge's [activate Survival of the Fittest (from Battlefield): {G}, Discard a creature card: Search ]
- P3 cast Y'shtola, Night's Blessed

## Turn 50 (OUR TURN, round 13) | life: P1 -12, P2 -3, P3 41, US 0
- US triggered The One Ring
- Game Outcome: P1 has lost because life total reached 0
- Game Outcome: P2 has lost because life total reached 0
- Game Outcome: P3 has won because all opponents have lost
- Game Outcome: US has lost because life total reached 0