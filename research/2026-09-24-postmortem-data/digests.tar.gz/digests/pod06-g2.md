# pod06-g2: we are P1; opponents P2 Atraxa, Praetors' Voice, P3 Sephiroth, Fabled SOLDIER, P4 Edgar Markov
Result: Turn 14; US has lost because of obtaining 10 poison counters; P2 has won because all opponents have lost; P3 has lost because of obtaining 10 poison counters; P4 has lost because of obtaining 10 poison counters

## Turn 1 (OUR TURN, round 1)
Our hand: Underhanded Designs, Secrets of the Dead, Vrock, The One Ring, Plaguecrafter, Farseek, Cryogen Relic, Animate Dead
Our graveyard (0): 
Board US: 0 lands; no nonland permanents
Board P2: 0 lands; no nonland permanents
Board P3: 0 lands; no nonland permanents
Board P4: 0 lands; no nonland permanents
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
PILOT OVERRULED FORGE (discard, CLEANUP): chose [Farseek [ours, in hand]] instead of Forge's [Vrock [ours, 3/3, in hand]]

## Turn 2 (P2, round 1)

## Turn 3 (P3, round 1)

## Turn 4 (P4, round 1)

## Turn 5 (OUR TURN, round 2)
Our hand: Underhanded Designs, Secrets of the Dead, Vrock, The One Ring, Plaguecrafter, Cryogen Relic, Animate Dead, Demonic Tutor
Our graveyard (1): Farseek
Board US: 0 lands; no nonland permanents
Board P2: 1 lands; no nonland permanents
Board P3: 1 lands; no nonland permanents
Board P4: 1 lands; no nonland permanents
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
PILOT OVERRULED FORGE (discard, CLEANUP): chose [Demonic Tutor [ours, in hand]] instead of Forge's [Vrock [ours, 3/3, in hand]]

## Turn 6 (P2, round 2)
- P2 cast Prologue to Phyresis

## Turn 7 (P3, round 2)

## Turn 8 (P4, round 2)
- P4 cast Legion Lieutenant
- P4 triggered Edgar Markov

## Turn 9 (OUR TURN, round 3)
Our hand: Underhanded Designs, Secrets of the Dead, Vrock, The One Ring, Plaguecrafter, Cryogen Relic, Animate Dead, Zagoth Triome
Our graveyard (2): Farseek, Demonic Tutor
Board US: 0 lands; no nonland permanents
Board P2: 2 lands; no nonland permanents
Board P3: 2 lands; no nonland permanents
Board P4: 2 lands; Vampire Token 2/2 [token], Legion Lieutenant 2/2
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)

## Turn 10 (P2, round 3)
- P2 cast Thrummingbird

## Turn 11 (P3, round 3)
- P3 cast Sephiroth, Fabled SOLDIER
- P3 triggered Sephiroth, Fabled SOLDIER

## Turn 12 (P4, round 3) | life: P4 38
- P4 cast Welcoming Vampire
- P4 triggered Edgar Markov
- P4 cast Markov Baron
- P4 triggered Edgar Markov
- P4 triggered Welcoming Vampire

## Turn 13 (OUR TURN, round 4)
Our hand: Underhanded Designs, Secrets of the Dead, Vrock, The One Ring, Plaguecrafter, Cryogen Relic, Animate Dead, Survival of the Fittest
Our graveyard (2): Farseek, Demonic Tutor
Board US: 1 lands; no nonland permanents
Board P2: 3 lands; Thrummingbird 1/1
Board P3: 3 lands; Sephiroth, Fabled SOLDIER 3/3
Board P4: 3 lands; Vampire Token 3/3 [token] x3 (tapped 2), Legion Lieutenant 3/3 (tapped 1), Welcoming Vampire 4/5, Markov Baron 3/3
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
PILOT OVERRULED FORGE (discard, CLEANUP): chose [Survival of the Fittest [ours, in hand]] instead of Forge's [Vrock [ours, 3/3, in hand]]

## Turn 14 (P2, round 4)
- P2 cast Evolution Sage

## Turn 15 (P3, round 4)
- P3 cast Morbid Opportunist

## Turn 16 (P4, round 4) | life: P3 21, P4 41
- P4 cast Mavren Fein, Dusk Apostle
- P4 triggered Edgar Markov
- attack: P4 assigned Welcoming Vampire, Vampire Token, Legion Lieutenant, Vampire Token, Vampire Token and Markov Baron to attack P3.
- P4 triggered Mavren Fein, Dusk Apostle

## Turn 17 (OUR TURN, round 5)
Our hand: Underhanded Designs, Secrets of the Dead, Vrock, The One Ring, Plaguecrafter, Cryogen Relic, Animate Dead, Otawara, Soaring City
Our graveyard (3): Farseek, Demonic Tutor, Survival of the Fittest
Board US: 1 lands; no nonland permanents
Board P2: 4 lands; Thrummingbird 1/1, Evolution Sage 3/2
Board P3: 4 lands; Sephiroth, Fabled SOLDIER 3/3, Morbid Opportunist 1/3
Board P4: 3 lands; Vampire Token 3/3 [token] x5 (tapped 3), Legion Lieutenant 3/3 (tapped 1), Welcoming Vampire 4/5 (tapped 1), Markov Baron 3/3 (tapped 1), Mavren Fein, Dusk Apostle 4/4
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
PILOT OVERRULED FORGE (action, MAIN2): chose [cast Cryogen Relic (from Hand): Cryogen Relic] instead of Forge's [cast Underhanded Designs (from Hand): Underhanded Designs]
- US cast Cryogen Relic
- US triggered Cryogen Relic

## Turn 18 (P2, round 5) | life: P3 21, P4 40
- P2 triggered Evolution Sage
- attack: P2 assigned Thrummingbird to attack P4.
- P2 triggered Thrummingbird
- P2 cast Atraxa, Praetors' Voice
- P2 triggered Atraxa, Praetors' Voice

## Turn 19 (P3, round 5)
- P3 cast Bontu's Monument

## Turn 20 (P4, round 5) | life: P2 31, P3 21, P4 40
- P4 cast Forerunner of the Legion
- P4 triggered Edgar Markov
- P4 triggered Forerunner of the Legion
- attack: P4 assigned Welcoming Vampire and Mavren Fein, Dusk Apostle to attack P2.
- P4 triggered Mavren Fein, Dusk Apostle
- P4 triggered Forerunner of the Legion targeting [Welcoming Vampire]

## Turn 21 (OUR TURN, round 6)
Our hand: Underhanded Designs, Secrets of the Dead, Vrock, The One Ring, Plaguecrafter, Animate Dead, Nurturing Peatland, Mind Stone
Our graveyard (3): Farseek, Demonic Tutor, Survival of the Fittest
Board US: 2 lands; Cryogen Relic
Board P2: 5 lands; Thrummingbird 1/1 (tapped 1), Evolution Sage 3/2, Atraxa, Praetors' Voice 4/4
Board P3: 5 lands; Sephiroth, Fabled SOLDIER 3/3, Morbid Opportunist 1/3, Bontu's Monument
Board P4: 3 lands; Vampire Token 3/3 [token] x7, Legion Lieutenant 3/3, Welcoming Vampire 4/5 (tapped 1), Markov Baron 3/3, Mavren Fein, Dusk Apostle 4/4 (tapped 1), Forerunner of the Legion 4/4
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
PILOT OVERRULED FORGE (action, MAIN1): chose [activate Cryogen Relic (from Battlefield): {1}{U}, Sacrifice this artifact: Put a stun cou] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (discard, CLEANUP): chose [Mind Stone [ours, in hand]] instead of Forge's [Vrock [ours, 3/3, in hand]]
- left battlefield: Cryogen Relic was put into Graveyard from Battlefield.
- US activated Cryogen Relic targeting []
- US triggered Cryogen Relic

## Turn 22 (P2, round 6) | life: P2 35, P3 21, P4 36
- P2 triggered Evolution Sage
- attack: P2 assigned Atraxa, Praetors' Voice to attack P4.
- P2 activated Raffine's Tower
- P2 cast Dreamtide Whale
- P2 triggered Atraxa, Praetors' Voice

## Turn 23 (P3, round 6) | life: P2 34, P3 22, P4 35, US 39
- P3 cast Endrek Sahr, Master Breeder
- P3 triggered Bontu's Monument

## Turn 24 (P4, round 6) | life: P2 3, P3 26, P4 40, US 39
- attack: P4 assigned Welcoming Vampire, Mavren Fein, Dusk Apostle, Forerunner of the Legion, Vampire Token, Legion Lieutenant, Vampire Token, Vampire Token, Markov Baron, Vampire Token, Vampire Token, Vampire Token and Vampire Token to attack P2.
- P4 triggered Mavren Fein, Dusk Apostle
- P4 triggered Forerunner of the Legion targeting [Welcoming Vampire]
- P4 cast Boros Charm
- left battlefield: Legion Lieutenant was put into Graveyard from Battlefield.
- left battlefield: Mavren Fein, Dusk Apostle was put into Graveyard from Battlefield.
- left battlefield: Evolution Sage was put into Graveyard from Battlefield.
- P3 triggered Sephiroth, Fabled SOLDIER targeting [P4]
- P3 triggered Sephiroth, Fabled SOLDIER targeting [P4]
- P3 triggered Sephiroth, Fabled SOLDIER targeting [P4]
- P3 triggered Sephiroth, Fabled SOLDIER targeting [P4]
- P3 triggered Morbid Opportunist

## Turn 25 (OUR TURN, round 7) | life: P2 3, P3 26, P4 40, US 37
Our hand: Underhanded Designs, Secrets of the Dead, Vrock, The One Ring, Plaguecrafter, Animate Dead, Twisted Embrace, Cabal Pit
Our graveyard (5): Farseek, Demonic Tutor, Survival of the Fittest, Cryogen Relic, Mind Stone
Board US: 3 lands; no nonland permanents
Board P2: 6 lands; Thrummingbird 1/1, Atraxa, Praetors' Voice 4/4, Dreamtide Whale 7/5 {[TIME x 3]}
Board P3: 6 lands; Sephiroth, One-Winged Angel 5/5, Morbid Opportunist 1/3, Bontu's Monument, Endrek Sahr, Master Breeder 2/2
Board P4: 3 lands; Vampire Token 2/2 [token] x7 (tapped 6), Welcoming Vampire 3/4 (tapped 1), Markov Baron 2/2 (tapped 1), Forerunner of the Legion 3/3 (tapped 1)
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
- US cast Animate Dead targeting [Evolution Sage]
- US triggered Animate Dead
- US cast Underhanded Designs
- P2 triggered Dreamtide Whale
Damage to US this turn: Cabal Pit (non-combat) 1

## Turn 26 (P2, round 7) | life: P2 7, P3 26, P4 36, US 37
- P2 triggered Dreamtide Whale
- attack: P2 assigned Atraxa, Praetors' Voice to attack P4.
- P2 activated Indatha Triome
- P2 triggered Atraxa, Praetors' Voice

## Turn 27 (P3, round 7) | life: P2 6, P3 27, P4 30, US 36
- attack: P3 assigned Sephiroth, One-Winged Angel to attack P4.
- P3 triggered Sephiroth, One-Winged Angel
- P3 cast Nine-Lives Familiar
- P3 triggered Bontu's Monument
- P3 triggered Endrek Sahr, Master Breeder
- P2 cast Counterspell targeting [Nine-Lives Familiar - Creature 1 / 1]
- P3 cast Sol Ring
- P2 triggered Dreamtide Whale

## Turn 28 (P4, round 7)
- P4 cast Charismatic Conqueror
- P4 triggered Edgar Markov
- P4 triggered Welcoming Vampire
- P4 triggered Forerunner of the Legion targeting [Welcoming Vampire]
- P4 triggered Forerunner of the Legion targeting [Welcoming Vampire]
- P4 cast Swords to Plowshares targeting [Atraxa, Praetors' Voice]
- P2 triggered Dreamtide Whale
- left battlefield: Evolution Sage was put into Exile from Battlefield.
- Game Outcome: US has lost because of obtaining 10 poison counters
- Game Outcome: P2 has won because all opponents have lost
- Game Outcome: P3 has lost because of obtaining 10 poison counters
- Game Outcome: P4 has lost because of obtaining 10 poison counters