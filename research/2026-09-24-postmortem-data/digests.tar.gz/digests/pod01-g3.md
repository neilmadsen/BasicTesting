# pod01-g3: we are P4; opponents P1 Sauron, the Dark Lord, P2 Sephiroth, Fabled SOLDIER, P3 Y'shtola, Night's Blessed
Result: Turn 19; P1 has lost because life total reached 0; P2 has lost because life total reached 0; P3 has won because all opponents have lost; US has lost because life total reached 0

## Turn 1 (P1, round 1)

## Turn 2 (P2, round 1)
- P2 cast Gravecrawler

## Turn 3 (P3, round 1)

## Turn 4 (OUR TURN, round 1)
Our hand: Swamp, Watery Grave, Soul-Guide Lantern, Survival of the Fittest, Animate Dead, Claws of Gix, Arcane Signet, Gravebreaker Lamia
Our graveyard (0): 
Board P1: 1 lands; no nonland permanents
Board P2: 1 lands; Gravecrawler 2/1
Board P3: 1 lands; no nonland permanents
Board US: 0 lands; no nonland permanents
MEMO (start of our turn):
THIS TURN: Play Watery Grave tapped (don't pay 2 life; we have no 1-mana play worth making). Cast Claws of Gix for {0}. Keep Swamp for next turn. No instant-speed plays on opponents' turns.

TARGET: Next turn, Swamp, then Arcane Signet and tap it for 1 (hold that mana, or cast Lantern only if a Gravecrawler or Bloodghast is in P2's yard). We have only 2 lands, so prioritise land draws. Then Survival of the Fittest: discard Gravebreaker Lamia for Sakura-Tribe Elder or Birds, later Shriekmaw, Plaguecrafter or Massacre Wurm. Cast Muldrotha around turn 7-8. Lamia entering puts Executioner's Capsule or Seal of Doom in the yard to recur each turn.

WIN PATH: Grind the table with recurring Capsule, Seals and Shriekmaw, then close with Gray Merchant or Syr Konrad drains plus Muldrotha beats. Our clock is roughly turns 10-12. P2 can combo on turns 5-7, P1 wins on turns 6-8.

THREATS & ANSWERS:
1. P2 Sephiroth, Pitiless Plunderer, Ashnod's Altar or Grave Pact. Kill Sephiroth before 4 deaths in one turn, using Shriekmaw via Survival or Executioner's Capsule. Soul-Guide Lantern exiles Gravecrawler, and its sac exiles their graveyards. Every creature dying drains us, so Massacre Wurm feeds Sephiroth.
2. P1 Sauron. Ward needs a legendary sacrifice, so use an edict (Plaguecrafter). Cast fewer, bigger spells once he's out.
3. P3 Y'shtola: Capsule works, but lower priority.

HOLD: Soul-Guide Lantern until P2 or P1 has graveyard value. Hold Animate Dead for a stolen fatty.

REPLAN IF: Sephiroth lands with sac fodder (rush removal); P1 casts Sauron early; we miss land drops (Survival for Sakura-Tribe Elder first).
PILOT OVERRULED FORGE (action, MAIN1): chose [play land Watery Grave (from Hand): Play land] instead of Forge's [play land Swamp (from Hand): Play land]
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Claws of Gix (from Hand): Claws of Gix] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
- US cast Claws of Gix

## Turn 5 (P1, round 2)

## Turn 6 (P2, round 2) | life: P3 38
- attack: P2 assigned Gravecrawler to attack P3.

## Turn 7 (P3, round 2)
- P3 cast Arcane Signet

## Turn 8 (OUR TURN, round 2)
Our hand: Swamp, Soul-Guide Lantern, Survival of the Fittest, Animate Dead, Arcane Signet, Gravebreaker Lamia, Assassin's Trophy
Our graveyard (0): 
Board P1: 2 lands; no nonland permanents
Board P2: 2 lands; Gravecrawler 2/1 (tapped 1)
Board P3: 2 lands; Arcane Signet
Board US: 1 lands; Claws of Gix
MEMO (start of our turn):
THIS TURN: Play Swamp. Cast Arcane Signet using Swamp and Watery Grave. Tap Signet for {1} and cast Soul-Guide Lantern. Its enter trigger will have no target, which is fine. We want it on the battlefield because its {T}, sacrifice ability costs no mana, works at instant speed and exiles every opponent's graveyard. Use it in response to Reanimate, Living Death, or a Gravecrawler or Bloodghast loop. Otherwise do nothing on opponents' turns.

TARGET: Next turn, play a land if we draw one: 3 lands plus Signet makes 4 mana. Cast Survival of the Fittest ({1}{G}) and keep {B}{G} up for Assassin's Trophy. Signet is our only green source, so plan the {G} carefully. The turn after, pay {G} to discard Gravebreaker Lamia and fetch Sakura-Tribe Elder, then Shriekmaw or Plaguecrafter. Muldrotha needs 6 mana. Missing pieces: lands, Sol Ring, Executioner's Capsule, Seal of Doom.

WIN PATH: Recur Capsule, Seals and Shriekmaw to lock the board, then close with Gray Merchant or Syr Konrad drains plus Muldrotha. Our clock is about 5 or more turns out. The table is also slow, and nobody threatens lethal next round.

THREATS & ANSWERS:
1. P2 Sephiroth (3 mana, likely soon), Pitiless Plunderer, Ashnod's Altar, Grave Pact. Answer with Trophy or a Shriekmaw fetched by Survival. Lantern handles the Gravecrawler recursion.
2. P1 Sauron. Answer with an edict (Plaguecrafter) because ward requires a legendary sacrifice. Save Lantern for Living Death.
3. P3 Y'shtola: low priority.

HOLD: Assassin's Trophy for Sephiroth or a combo piece. Animate Dead for a good creature in an opponent's graveyard. Lamia is Survival discard fodder, so don't hard-cast it.

REPLAN IF: Sephiroth or Plunderer lands (Trophy at once); we miss land drops (Survival for Sakura-Tribe Elder first); Sauron is cast (edict plan).
- US cast Arcane Signet

## Turn 9 (P1, round 3) | life: P1 39, P3 38
- P1 cast Nazgûl
- P1 triggered Nazgûl
- P1 triggered Nazgûl

## Turn 10 (P2, round 3) | life: P1 39, P2 37, P3 38, US 38
- P2 cast Feed the Swarm targeting [Nazgûl]
- left battlefield: Nazgûl was put into Graveyard from Battlefield.
- attack: P2 assigned Gravecrawler to attack US.
Damage to US this turn: Gravecrawler (combat) 2

## Turn 11 (P3, round 3)
- P3 cast Delney, Streetwise Lookout

## Turn 12 (OUR TURN, round 3)
Our hand: Soul-Guide Lantern, Survival of the Fittest, Animate Dead, Gravebreaker Lamia, Assassin's Trophy, Boseiju, Who Endures
Our graveyard (0): 
Board P1: 3 lands; no nonland permanents
Board P2: 3 lands; Gravecrawler 2/1 (tapped 1)
Board P3: 3 lands; Arcane Signet (tapped 1), Delney, Streetwise Lookout 2/2
Board US: 2 lands; Claws of Gix, Arcane Signet
MEMO (start of our turn):
THIS TURN: Play Boseiju, Who Endures as the land drop. Cast Survival of the Fittest ({1}{G}) using Boseiju for {G} and Swamp. Keep Watery Grave ({B}) and Arcane Signet ({G}) up for Assassin's Trophy on opponents' turns. Trophy's first target is Sephiroth, then Pitiless Plunderer, Ashnod's Altar or Grave Pact. Don't Trophy Gravecrawler or Delney. Soul-Guide Lantern waits until next turn.

TARGET: Next turn (5 mana with a land drop):
1. Cast Lantern ({1}).
2. Pay {G} to Survival, discard Gravebreaker Lamia, and fetch Sakura-Tribe Elder.
3. Cast Animate Dead ({1}{B}) on Lamia in our graveyard. Lamia's enter trigger puts Executioner's Capsule into our graveyard.

The turn after, cast Muldrotha (6 mana, no tax yet) and start recurring Capsule. Missing pieces: green lands, Sol Ring, Executioner's Capsule, Seal of Doom, Plaguecrafter.

WIN PATH: Lock the board with recurring Capsule, Seals and Shriekmaw, then Survival for Gray Merchant or Syr Konrad and drain out. Our clock is about 6 turns. Nobody at the table threatens lethal soon; P2's combo is the fastest, around turns 5-7.

THREATS & ANSWERS:
1. P2 Sephiroth, Plunderer or Altar: Trophy now, then Shriekmaw via Survival.
2. P1 Sauron: Trophy CANNOT hit him (ward needs a legendary sacrifice). Answer with Plaguecrafter via Survival. Save Lantern for Living Death or Reanimate.
3. P3 Y'shtola: Trophy only if P2 is quiet.

HOLD: Trophy mana every opponent turn. Animate Dead is for Lamia. Lamia is discard fodder, so never hard-cast it.

REPLAN IF: Sephiroth lands and we have already spent Trophy (Survival for Shriekmaw); Sauron is cast (Survival for Plaguecrafter); we miss a land drop (Survival for Sakura-Tribe Elder first); Survival is removed (cast Lamia normally).
PILOT OVERRULED FORGE (action, DRAW): chose [Nykthos, Shrine to Nyx [P2]] instead of Forge's [Delney, Streetwise Lookout [P3, 2/2]]
- US cast Assassin's Trophy targeting [Nykthos, Shrine to Nyx]
- left battlefield: Nykthos, Shrine to Nyx was put into Graveyard from Battlefield.
- US cast Animate Dead targeting [Nazgûl]
- US triggered Animate Dead
- US triggered Nazgûl
- US triggered Nazgûl

## Turn 13 (P1, round 4) | life: P1 38, P2 37, P3 38, US 38
- P1 cast Claim the Precious targeting [Nazgûl]
- left battlefield: Nazgûl was put into Graveyard from Battlefield.
- left battlefield: Animate Dead was put into Graveyard from Battlefield.
- US triggered Animate Dead

## Turn 14 (P2, round 4) | life: P1 38, P2 38, P3 35, US 38
- attack: P2 assigned Gravecrawler to attack P3.
- P2 cast Sephiroth, Fabled SOLDIER
- P2 triggered Sephiroth, Fabled SOLDIER
- left battlefield: Gravecrawler was put into Graveyard from Battlefield.
- P2 triggered Sephiroth, Fabled SOLDIER targeting [P3]

## Turn 15 (P3, round 4) | life: P1 38, P2 38, P3 35, US 36
- P3 cast Lethal Scheme targeting [Sephiroth, Fabled SOLDIER]
- left battlefield: Sephiroth, Fabled SOLDIER was put into Graveyard from Battlefield.
- attack: P3 assigned Delney, Streetwise Lookout to attack US.
Damage to US this turn: Delney, Streetwise Lookout (combat) 2

## Turn 16 (OUR TURN, round 4)
Our hand: Soul-Guide Lantern, Survival of the Fittest, Gravebreaker Lamia, Command Tower
Our graveyard (2): Assassin's Trophy, Animate Dead
Board P1: 4 lands; no nonland permanents
Board P2: 4 lands; no nonland permanents
Board P3: 4 lands; Arcane Signet (tapped 1), Delney, Streetwise Lookout 2/2 (tapped 1)
Board US: 3 lands; Claws of Gix, Arcane Signet
MEMO (start of our turn):
THIS TURN: 1) Play Command Tower (5 mana). 2) Cast Survival of the Fittest ({1}{G}: Boseiju + Swamp). 3) Activate Survival ({G}: Arcane Signet), discard Gravebreaker Lamia, fetch Sakura-Tribe Elder. 4) Cast Elder ({1}{G}: Command Tower + Watery Grave). Sacrifice Elder for a basic Forest at P3's end step, or earlier if it would die. We have no instant interaction this round, because Trophy is in the graveyard.

TARGET: Next turn, 7 mana if we hit a land: Muldrotha (6) + Soul-Guide Lantern (1). Lantern's enter trigger exiles Gravecrawler or P1's best reanimation target. The turn after, cast Animate Dead from our graveyard onto Lamia. Lamia's trigger puts Executioner's Capsule into the graveyard. Then recast Capsule through the artifact lane every turn and use Survival every turn. Missing: Capsule, Hostage Taker, Plaguecrafter, Sol Ring.

WIN PATH: Recurring removal locks the board, then Survival finds Gray Merchant or Syr Konrad to drain. That is about 6 turns away. Nobody threatens lethal now, since the table is nearly empty.

THREATS & ANSWERS: 1) P2's Sephiroth recast (5 mana next turn). It is black, so Shriekmaw, Capsule and Seal of Doom can't hit it. Use Survival for Hostage Taker, or Vraska's -3. 2) P1 Sauron: ward means we never target him. Answer with Plaguecrafter or Toxic Deluge. 3) P3 Y'shtola is also black: Hostage Taker or Plaguecrafter.

HOLD: Lantern until Muldrotha resolves. Never target Sauron. Discard fodder for Survival goes to the graveyard, not the stack.

REPLAN IF: Survival is removed (hard-cast Lamia next turn instead). We miss the land drop (Muldrotha waits; cast Lantern and use Survival). Sephiroth resolves (fetch Hostage Taker). Reanimate or Living Death is cast (prioritize Lantern).
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Survival of the Fittest (from Hand): Survival of the Fittest [Forge's heuristic AI wo] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN1): chose [activate Survival of the Fittest (from Battlefield): {G}, Discard a creature card: Search ] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (search, MAIN1): chose [Hostage Taker — Creature - Human Pirate — When Hostage Taker enters, exile another target ] instead of Forge's [Syr Konrad, the Grim — Legendary Creature - Human Knight — Whenever another creature dies,]
PILOT OVERRULED FORGE (trigger-target, MAIN2): chose [Gravecrawler [P2, 2/1, in graveyard]] instead of Forge's [Lethal Scheme [P3, in graveyard]]
- US cast Survival of the Fittest
- US activated Survival of the Fittest
- US cast Soul-Guide Lantern
- US triggered Soul-Guide Lantern targeting [Gravecrawler]
- left battlefield: Soul-Guide Lantern was put into Graveyard from Battlefield.
- US activated Soul-Guide Lantern

## Turn 17 (P1, round 5)
- P1 cast Fellwar Stone
- P1 cast Talisman of Creativity

## Turn 18 (P2, round 5)
- P2 cast Dictate of Erebos

## Turn 19 (P3, round 5) | life: P1 36, P2 34, P3 39, US 35
PILOT OVERRULED FORGE (action, END_OF_TURN): chose [activate Claws of Gix (from Battlefield): {1}, Sacrifice a permanent: You gain 1 life. [Fo] instead of Forge's [activate Survival of the Fittest (from Battlefield): {G}, Discard a creature card: Search ]
- P3 cast Circle of Power
- attack: P3 assigned Delney, Streetwise Lookout to attack P2.
- P3 cast Talisman of Progress
- P3 triggered Wizard Token
- P3 triggered Wizard Token
- left battlefield: Claws of Gix was put into Graveyard from Battlefield.
- US activated Claws of Gix
Damage to US this turn: Wizard Token (non-combat) 2

## Turn 20 (OUR TURN, round 5)
Our hand: Hostage Taker, Pernicious Deed
Our graveyard (5): Assassin's Trophy, Animate Dead, Gravebreaker Lamia, Soul-Guide Lantern, Claws of Gix
Board P1: 5 lands; Fellwar Stone (tapped 1), Talisman of Creativity
Board P2: 5 lands; Dictate of Erebos
Board P3: 5 lands; Arcane Signet (tapped 1), Delney, Streetwise Lookout 2/2 (tapped 1), Wizard Token 0/1 [token], Talisman of Progress
Board US: 4 lands; Arcane Signet, Survival of the Fittest
MEMO (start of our turn):
THIS TURN: 1) Activate Survival ({G} from Boseiju): discard Hostage Taker, fetch Sakura-Tribe Elder. 2) Cast Elder ({1}{G}: Command Tower + Swamp). 3) Keep Elder as a blocker. Sacrifice it for a basic Forest at P3's end step, or in response to removal or a Dictate sacrifice. 4) Watery Grave and Signet stay open, but we have no instants.

TARGET: Next turn we have 6 mana even without a land drop: 5 lands plus Signet. Cast Muldrotha (6). If we have a 7th mana, add Claws of Gix (0) and Soul-Guide Lantern (1) from the graveyard. The turn after: Hostage Taker from the graveyard (creature lane), Animate Dead onto Lamia (enchantment lane), and Lamia puts Vraska, Golgari Queen or Executioner's Capsule into the graveyard. Missing: Vraska, Capsule, Plaguecrafter, Gray Merchant.

WIN PATH: Lock the board with recurring removal. Then Survival finds Gray Merchant or Syr Konrad and we drain over about 6 turns. The fastest opponent is P2's drain, which is not lethal soon.

THREATS & ANSWERS:
1) Sephiroth recast by P2 (5 mana) with Dictate of Erebos. Answer with Hostage Taker from the graveyard, Vraska's -3, or Deed at X=3.
2) Sauron (P1 has 7 mana). Never target him. Answer with Plaguecrafter or Toxic Deluge.
3) Y'shtola, then Delney. Both are black-safe from Capsule, so use Hostage Taker.
Don't chump-block into Sephiroth's drains.

HOLD: Pernicious Deed stays in hand. Use it for a go-wide board, Sephiroth plus fodder, or Dictate at X=5. Muldrotha comes first next turn.

REPLAN IF: Survival or Elder is removed before we get the land (hold Muldrotha until the 6th source). Sauron resolves (fetch Plaguecrafter). Reanimate or Living Death is cast (Lantern goes right after Muldrotha).
PILOT OVERRULED FORGE (action, MAIN1): chose [activate Survival of the Fittest (from Battlefield): {G}, Discard a creature card: Search ] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (search, MAIN1): chose [Plaguecrafter — Creature - Human Shaman — When Plaguecrafter enters, each player sacrifice] instead of Forge's [Gray Merchant of Asphodel — Creature - Zombie — When Gray Merchant of Asphodel enters, eac]
- US activated Survival of the Fittest
- US cast Plaguecrafter
- US triggered Plaguecrafter
- left battlefield: Plaguecrafter was put into Graveyard from Battlefield.

## Turn 21 (P1, round 6)
- P1 cast Sauron, the Dark Lord

## Turn 22 (P2, round 6)
- P2 activated Reassembling Skeleton
- P2 cast Warren Soultrader
- P1 triggered Sauron, the Dark Lord

## Turn 23 (P3, round 6) | life: P1 36, P2 32, P3 39, US 35
- attack: P3 assigned Delney, Streetwise Lookout to attack P1.
- left battlefield: Reassembling Skeleton was put into Graveyard from Battlefield.
- P2 activated Warren Soultrader
- P2 triggered Dictate of Erebos
- left battlefield: Delney, Streetwise Lookout was put into Graveyard from Battlefield.
- P2 activated Reassembling Skeleton
- left battlefield: Reassembling Skeleton was put into Graveyard from Battlefield.
- P2 activated Warren Soultrader
- P2 triggered Dictate of Erebos
- left battlefield: Sauron, the Dark Lord was put into Graveyard from Battlefield.
- P3 cast Alphinaud Leveilleur
- P3 triggered Alphinaud Leveilleur targeting [P3]
- P3 cast Y'shtola, Night's Blessed
- P3 triggered Alphinaud Leveilleur

## Turn 24 (OUR TURN, round 6)
Our hand: Pernicious Deed, Hinterland Harbor
Our graveyard (7): Assassin's Trophy, Animate Dead, Gravebreaker Lamia, Soul-Guide Lantern, Claws of Gix, Hostage Taker, Plaguecrafter
Board P1: 6 lands; Fellwar Stone (tapped 1), Talisman of Creativity (tapped 1)
Board P2: 6 lands; Dictate of Erebos, Warren Soultrader 3/3, Treasure Token [token]
Board P3: 6 lands; Arcane Signet (tapped 1), Talisman of Progress (tapped 1), Alphinaud Leveilleur 2/4, Y'shtola, Night's Blessed 2/4
Board US: 4 lands; Arcane Signet, Survival of the Fittest
MEMO (start of our turn):
THIS TURN: 1) Play Hinterland Harbor. It enters untapped because Watery Grave is an Island. 2) Cast Pernicious Deed ({1}{B}{G}: Swamp B, Boseiju G, Command Tower 1). Opponents are tapped out now (P1 has 1 mana, P3 has none). 3) Keep Watery Grave, Harbor and Signet open (3 mana). Pop Deed at instant speed for X≤3 only if (a) removal targets Deed, or (b) P2's sacrifice loop would reach four Sephiroth drains. Otherwise do not pop.

TARGET: Next turn, main phase 1: tap all 6 sources and pop Deed at X=5. That kills Dictate, Y'shtola, Alphinaud, Soultrader and all opponents' rocks, and loses our Signet and Survival. If we draw a creature first, use Survival ({G}) before the pop: discard it and fetch Massacre Wurm, Shriekmaw or Eternal Witness. The turn after, on a clear board: Muldrotha (6), Deed from graveyard, Claws of Gix, and Plaguecrafter or Hostage Taker. Missing: a 6th land, Vraska, Golgari Queen, Executioner's Capsule, Gray Merchant.

WIN PATH: Recast Deed and the edicts every turn, then Lamia (via Animate Dead) or Demonic Tutor finds Gray Merchant or Syr Konrad to drain. The clock is long. P2's loop is the fastest danger and has no near-term lethal.

THREATS & ANSWERS: 1) P2 Dictate plus fodder, and Sephiroth: Deed at X=5. 2) Sauron recast (8 mana, MV6, Deed can't reach it): Plaguecrafter via Muldrotha, and never target him. 3) Y'shtola: Deed X≥4, then Hostage Taker.

HOLD: Muldrotha stays in the command zone until Dictate is gone. With Dictate out, he is our only creature, and P2's Skeleton-into-Soultrader loop edicts him. Keep 3 mana open this cycle.

REPLAN IF: Deed is countered or exiled (then Muldrotha only with fodder). Sauron resolves. Living Death or Reanimate is cast (Lantern after Muldrotha). Dictate leaves early (cast Muldrotha next turn).
PILOT OVERRULED FORGE (action, MAIN2): chose [cast Pernicious Deed (from Hand): Pernicious Deed] instead of Forge's [cast Muldrotha, the Gravetide (from Command): Muldrotha, the Gravetide - Creature 6 / 6]
- US cast Pernicious Deed

## Turn 25 (P1, round 7) | life: P1 35, P2 32, P3 39, US 35
- P1 cast Sauron, the Dark Lord

## Turn 26 (P2, round 7)
- P2 activated Reassembling Skeleton
- P2 cast Drivnod, Carnage Dominus
- P1 triggered Sauron, the Dark Lord

## Turn 27 (P3, round 7) | life: P1 33, P2 29, P3 41, US 33
- P3 cast Alisaie Leveilleur
- P1 triggered Sauron, the Dark Lord
- P3 triggered Alisaie Leveilleur targeting [P3]
- P3 cast Cleansing Nova
- P3 triggered Y'shtola, Night's Blessed
- P3 triggered Alphinaud Leveilleur
- P1 triggered Sauron, the Dark Lord
- left battlefield: Arcane Signet was put into Graveyard from Battlefield.
- left battlefield: Talisman of Progress was put into Graveyard from Battlefield.
- left battlefield: Arcane Signet was put into Graveyard from Battlefield.
- left battlefield: Survival of the Fittest was put into Graveyard from Battlefield.
- left battlefield: Pernicious Deed was put into Graveyard from Battlefield.
- left battlefield: Fellwar Stone was put into Graveyard from Battlefield.
- left battlefield: Talisman of Creativity was put into Graveyard from Battlefield.
- left battlefield: Dictate of Erebos was put into Graveyard from Battlefield.
- left battlefield: Reassembling Skeleton was put into Graveyard from Battlefield.
- P2 activated Warren Soultrader
Damage to US this turn: Y'shtola, Night's Blessed (non-combat) 2

## Turn 28 (OUR TURN, round 7)
Our hand: Braids, Arisen Nightmare
Our graveyard (10): Assassin's Trophy, Animate Dead, Gravebreaker Lamia, Soul-Guide Lantern, Claws of Gix, Hostage Taker, Plaguecrafter, Arcane Signet, Survival of the Fittest, Pernicious Deed
Board P1: 6 lands; Sauron, the Dark Lord 7/6, Orc Army Token 3/3 [token] {[P1P1 x 3]}
Board P2: 7 lands; Warren Soultrader 3/3, Drivnod, Carnage Dominus 8/3, Treasure Token [token]
Board P3: 7 lands; Alphinaud Leveilleur 2/4, Y'shtola, Night's Blessed 2/4, Alisaie Leveilleur 3/2
Board US: 5 lands; no nonland permanents
MEMO (start of our turn):
THIS TURN: Nova wiped our Deed, Signet and Survival. We have 5 mana and Muldrotha costs 6, so no Muldrotha this turn. Cast Braids ({1}{B}{B}: Swamp, Watery Grave, Command Tower). This gives P1's Army +1, which is acceptable. At end step, do NOT sacrifice anything: we need every land and Braids. On their turns, block Drivnod with Braids, since trading kills it. Also block Y'shtola or Alphinaud freely. Never block Alisaie (first strike) or chump-block.

TARGET: Next turn with a 6th land: Muldrotha (6), then Claws of Gix from graveyard (0). The turn after: Hostage Taker (4) on Drivnod or Y'shtola, then Plaguecrafter or Deed. Braids is Muldrotha's edict fodder. Missing: land #6, Gray Merchant, Vraska Golgari Queen, Executioner's Capsule.

WIN PATH: With Muldrotha online, recast Deed, Plaguecrafter and Taker each turn. Then Lamia (5 mana) puts Gray Merchant into the graveyard to recast for drains. The clock is long. P1's Army plus wheel is the fastest, with no lethal on us this cycle (we're at 33).

THREATS & ANSWERS: 1) P1 Sauron and Army: Plaguecrafter edict. Deed at X≥4 kills the Army. Assassin's Trophy on Sauron only by paying ward with Braids. 2) P2 Drivnod: Braids block, or Hostage Taker. 3) P3 Y'shtola: Hostage Taker or Deed at X=4. Feed Sauron fewer spells: prefer bigger casts.

HOLD: Keep Boseiju and Harbor untapped (nothing to use them on). Keep Braids alive as edict protection for Muldrotha.

REPLAN IF: Braids is removed (Muldrotha still goes down with land #6). Sephiroth returns alongside Drivnod (then Deed or Taker targets Drivnod first). A wheel or Living Death happens (then Lantern after Muldrotha). There is no 6th land (then hold and pass).
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Braids, Arisen Nightmare (from Hand): Braids, Arisen Nightmare - Creature 3 / 3 [Forg] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (confirm, END_OF_TURN): chose [no] instead of Forge's [yes, do it]
- US cast Braids, Arisen Nightmare
- P1 triggered Sauron, the Dark Lord
- US triggered Braids, Arisen Nightmare

## Turn 29 (P1, round 8) | life: P1 32, P2 27, P3 30, US 33
- P1 cast Summons of Saruman
- attack: P1 assigned Sauron, the Dark Lord and Orc Army Token to attack P3.
- P1 triggered Sauron, the Dark Lord
- P1 triggered Sauron, the Dark Lord
- P1 cast One Ring to Rule Them All
- P1 triggered One Ring to Rule Them All
- P1 triggered Sauron, the Dark Lord
- P2 activated Drivnod, Carnage Dominus
- P3 triggered Y'shtola, Night's Blessed

## Turn 30 (P2, round 8) | life: P1 21, P2 27, P3 30, US 33
- attack: P2 assigned Drivnod, Carnage Dominus and Warren Soultrader to attack P1.
- P2 cast Sephiroth, Fabled SOLDIER
- P1 triggered Sauron, the Dark Lord
- P2 triggered Sephiroth, Fabled SOLDIER
- P2 cast Morbid Opportunist
- P1 triggered Sauron, the Dark Lord
- P3 triggered Y'shtola, Night's Blessed

## Turn 31 (P3, round 8) | life: P1 9, P2 23, P3 34, US 29
- P3 cast Quantum Misalignment targeting [Alphinaud Leveilleur]
- P3 triggered Y'shtola, Night's Blessed
- P1 triggered Sauron, the Dark Lord
- P3 triggered Alphinaud Leveilleur targeting [P3]
- P3 cast Helm of the Ghastlord targeting [Alphinaud Leveilleur]
- P3 triggered Y'shtola, Night's Blessed
- P3 triggered Alphinaud Leveilleur
- P3 triggered Alphinaud Leveilleur
- P1 triggered Sauron, the Dark Lord
- attack: P3 assigned Alisaie Leveilleur, Alphinaud Leveilleur and Y'shtola, Night's Blessed to attack P1.
- P3 triggered Alphinaud Leveilleur
- P3 triggered Y'shtola, Night's Blessed
Damage to US this turn: Y'shtola, Night's Blessed (non-combat) 4

## Turn 32 (OUR TURN, round 8) | life: P1 4, P2 21, P3 32, US 29
Our hand: Swamp
Our graveyard (17): Assassin's Trophy, Animate Dead, Gravebreaker Lamia, Soul-Guide Lantern, Claws of Gix, Hostage Taker, Plaguecrafter, Arcane Signet, Survival of the Fittest, Pernicious Deed, Eternal Witness, Nurturing Peatland, Swamp, Dalek Drone, Shriekmaw, Syr Konrad, the Grim, The Death of Gwen Stacy
Board P1: 7 lands; Sauron, the Dark Lord 7/6 (tapped 1), Orc Army Token 8/8 [token] {[P1P1 x 8]} (tapped 1), One Ring to Rule Them All {[LORE]}
Board P2: 8 lands; Warren Soultrader 3/3 (tapped 1), Drivnod, Carnage Dominus 8/3 {[Indestructible]} (tapped 1), Sephiroth, Fabled SOLDIER 3/3, Morbid Opportunist 1/3
Board P3: 8 lands; Alphinaud Leveilleur 3/5, Y'shtola, Night's Blessed 2/4, Alisaie Leveilleur 3/2 (tapped 1), Alphinaud Leveilleur 2/4 [token], Helm of the Ghastlord
Board US: 5 lands; Braids, Arisen Nightmare 3/3
MEMO (start of our turn):
THIS TURN: Every opponent is tapped out. Play Swamp from hand (6 mana). Cast Muldrotha (6). Cast Claws of Gix from graveyard (0, artifact lane). Attack P1 with Braids only; Sauron and the Army are tapped, so P1 goes 9→6. At end step, Braids sacrifices Claws. No opponent has an artifact, so each loses 2 and we draw 3. P1 goes to 4. On opponents' turns, don't block Sauron or Drivnod with Muldrotha. Muldrotha may block Sephiroth or P3's creatures. Chump only if unblocked damage is lethal.

TARGET: Kill P1 next turn. That also removes his Ring saga, whose chapter III would drain us about 7. Play Nurturing Peatland from graveyard for 7 mana. Line A: Dalek Drone (5) targeting a P1 creature other than Sauron (P1 loses 3), Claws (0), then Braids sacrifices Claws at end (2). Line B, if P1 has only Sauron: Syr Konrad (5), then Animate Dead (2) on Dalek. Dalek leaving our graveyard pings 1, and its kill pings 1. Add Braids' 2 for 4 total. Attack P1 with Muldrotha too.

WIN PATH: P1 dies next turn. Then grind P2 (23) and P3 (34) with Braids drains, Konrad and recurring Dalek. Later, Lamia finds Gray Merchant.

THREATS & ANSWERS: 1) P2: Sephiroth likely transforms when the Ring's chapter II kills their fodder. Plaguecrafter or Dalek on Sephiroth, and Hostage Taker on Drivnod. 2) P1 Sauron: Dalek on the Army and edict with Plaguecrafter; never target Sauron (ward). 3) P3 Y'shtola: Hostage Taker.

HOLD: Keep Peatland in the graveyard as next turn's land. Keep the 3 drawn cards; hold instants (Counterspell, Swan Song) for Blasphemous Act or Exsanguinate.

REPLAN IF: P1 gains life or blocks; Muldrotha or Braids is removed; P1 dies from others.
PILOT OVERRULED FORGE (action, MAIN1): chose [play land Swamp (from Hand): Play land] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Muldrotha, the Gravetide (from Command): Muldrotha, the Gravetide - Creature 6 / 6 [F] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Claws of Gix (from Graveyard): Claws of Gix by Muldrotha, the Gravetide (403) (Artifa] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
- US cast Muldrotha, the Gravetide
- P1 triggered Sauron, the Dark Lord
- US cast Claws of Gix
- P1 triggered Sauron, the Dark Lord
- attack: US assigned Braids, Arisen Nightmare to attack P1.
- US triggered Braids, Arisen Nightmare
- left battlefield: Claws of Gix was put into Graveyard from Battlefield.

## Turn 33 (P1, round 9) | life: P1 4, P2 29, P3 24, US 29
- P1 triggered One Ring to Rule Them All
- left battlefield: Warren Soultrader was put into Graveyard from Battlefield.
- left battlefield: Morbid Opportunist was put into Graveyard from Battlefield.
- left battlefield: Alphinaud Leveilleur was put into Graveyard from Battlefield.
- P2 triggered Sephiroth, Fabled SOLDIER targeting [P3]
- P2 triggered Sephiroth, Fabled SOLDIER targeting [P3]
- P2 triggered Sephiroth, Fabled SOLDIER targeting [P3]
- P2 triggered Sephiroth, Fabled SOLDIER targeting [P3]
- P2 triggered Sephiroth, Fabled SOLDIER targeting [P3]
- P2 triggered Sephiroth, Fabled SOLDIER targeting [P3]
- P2 triggered Sephiroth, Fabled SOLDIER targeting [P3]
- P2 triggered Sephiroth, Fabled SOLDIER targeting [P3]
- P2 triggered Morbid Opportunist
- P1 cast Saruman, the White Hand
- P1 triggered Path of Ancestry
- P3 triggered Y'shtola, Night's Blessed

## Turn 34 (P2, round 9) | life: P1 -1, P2 29, P3 22, US 27
MEMO (executor escalation: P3: life 34→22 (-12)):
THIS TURN: Now, on P2's Braids trigger, sacrifice nothing and lose 2 life. Never sacrifice lands, Braids or Muldrotha. We have no mana on P3's turn. If attacked, Muldrotha may block Y'shtola, Alisaie or Alphinaud. Never block Drivnod, and never chump, because every death feeds P2's emblem. Our turn, 7 mana:
1. Play Nurturing Peatland from the graveyard (land lane).
2. Claws of Gix from the graveyard (0, artifact lane).
3. Cryogen Relic from hand (2): draw.
4. Hostage Taker from the graveyard (4, creature lane), exiling Drivnod. Destroy can't kill it, since it's indestructible.
5. Claws {1}: sacrifice Relic, draw.
6. End step: Braids sacrifices Claws. Neither opponent has artifacts, so each loses 2 and we draw 2.
Don't attack.

TARGET: Next turn, cast Drivnod from exile (5, any mana) before Taker dies. Then Glen Elendra with {U} open to guard Muldrotha. Then Syr Konrad (Drivnod doubles his triggers) and Gravebreaker Lamia fetching Gray Merchant.

WIN PATH: Braids drains 2 each per turn, plus Dalek (3), Konrad pings and Gray Merchant's devotion to black. P3 (22) dies first, then P2 (29). That is about 4-5 turns, versus P3's Exsanguinate and P2's grinding drains.

THREATS & ANSWERS: 1) P2: Drivnod goes to Hostage Taker. Answer Ashnod's Altar, Grave Pact or Pitiless Plunderer with Pernicious Deed or Dalek. Don't kill Sephiroth, since a recast and re-transform means a second emblem. 2) P3: Y'shtola gets Dalek or Hostage Taker later; Glen counters Exsanguinate, Swords or Void Rend. Don't feed deaths: avoid Plaguecrafter, chump blocks and creature sacrifices to Braids.

HOLD: Glen in hand until we can leave {U} open. Keep Underhanded Designs back.

REPLAN IF: Muldrotha or Hostage Taker is removed before Drivnod is cast, an opponent plays an artifact, or P2 finds Altar or Plunderer.
ESCALATION (p=0.85): P3: life 34→22 (-12)
PILOT OVERRULED FORGE (confirm, END_OF_TURN): chose [no] instead of Forge's [yes, do it]
- attack: P2 assigned Drivnod, Carnage Dominus and Sephiroth, One-Winged Angel to attack P1.
- P2 triggered Sephiroth, One-Winged Angel
- attack: P1 assigned Saruman, the White Hand to block Drivnod, Carnage Dominus.
- P2 cast Braids, Arisen Nightmare
- P2 triggered Braids, Arisen Nightmare
- P3 triggered Y'shtola, Night's Blessed
- left battlefield: Swamp was put into Graveyard from Battlefield.

## Turn 35 (P3, round 9) | life: P1 -1, P2 18, P3 23, US 21
- P3 triggered Quantum Misalignment
- P3 cast Quantum Misalignment targeting [Alphinaud Leveilleur]
- P3 triggered Y'shtola, Night's Blessed
- P3 triggered Alphinaud Leveilleur targeting [P3]
- P3 cast Vindicate targeting [Sephiroth, One-Winged Angel]
- P3 triggered Y'shtola, Night's Blessed
- P3 triggered Alphinaud Leveilleur
- P3 triggered Alphinaud Leveilleur
- left battlefield: Sephiroth, One-Winged Angel was put into Graveyard from Battlefield.
- P2 triggered Emblem — Sephiroth, One-Winged Angel targeting [P3]
- attack: P3 assigned Alisaie Leveilleur and Alphinaud Leveilleur to attack P2.
- P3 triggered Alphinaud Leveilleur
- P3 cast G'raha Tia, Scion Reborn
- P3 cast Lyse Hext
- P3 cast Talisman of Dominance
- P3 triggered Lyse Hext
- P3 triggered G'raha Tia, Scion Reborn
- P3 cast Talisman of Hierarchy
- P3 triggered Lyse Hext
- P3 cast Sol Ring
- P3 triggered Lyse Hext
- P3 triggered Y'shtola, Night's Blessed
- P3 cast Transpose
- P3 triggered Y'shtola, Night's Blessed
- P3 triggered Lyse Hext
Damage to US this turn: Y'shtola, Night's Blessed (non-combat) 6

## Turn 36 (OUR TURN, round 9) | life: P1 -1, P2 16, P3 21, US 20
Our hand: Underhanded Designs, Glen Elendra Archmage, Cryogen Relic, Sol Ring
Our graveyard (17): Assassin's Trophy, Animate Dead, Gravebreaker Lamia, Soul-Guide Lantern, Hostage Taker, Plaguecrafter, Arcane Signet, Survival of the Fittest, Pernicious Deed, Eternal Witness, Nurturing Peatland, Swamp, Dalek Drone, Shriekmaw, Syr Konrad, the Grim, The Death of Gwen Stacy, Claws of Gix
Board P2: 8 lands; Drivnod, Carnage Dominus 8/3 {[Indestructible]} (tapped 1), Braids, Arisen Nightmare 3/3
Board P3: 9 lands; Alphinaud Leveilleur 3/5, Y'shtola, Night's Blessed 2/4, Alisaie Leveilleur 3/2 (tapped 1), Helm of the Ghastlord, Alphinaud Leveilleur 2/4 [token], G'raha Tia, Scion Reborn 2/3, Lyse Hext 2/2, Hero Token 3/3 [token] {[P1P1 x 2]}, Talisman of Dominance (tapped 1), Talisman of Hierarchy (tapped 1), Sol Ring (tapped 1), Wizard Token 0/1 [token]
Board US: 6 lands; Braids, Arisen Nightmare 3/3, Muldrotha, the Gravetide 6/6
MEMO (start of our turn):
THIS TURN (7 mana: 6 lands plus Peatland):
1. Play Nurturing Peatland from the graveyard (land lane).
2. Cast Pernicious Deed from the graveyard ({1}{B}{G}: Swamp, Boseiju, +1) using the enchantment lane.
3. Activate the Deed at X=4 with the other 4 lands. This kills all 8 of P3's creatures (including Y'shtola), Helm, both Talismans, Sol Ring, and both Braids.
   - Each death drains us about 1 through P2's emblem, which is accepted. Muldrotha (6) survives, and so does Drivnod (indestructible).
4. Afterward, cast Claws of Gix from the graveyard for 0 (artifact lane).
- Keep Sol Ring in hand. Don't attack.
- On P2's turn: if Drivnod attacks us, take it. Block with Muldrotha only if 8 damage would leave us at 3 or less.

TARGET: Next turn:
- Sol Ring (1), then Hostage Taker from the graveyard (4) exiling Drivnod.
- Cryogen Relic (2).
- Later, cast Drivnod from exile, Braids again, and Glen Elendra with {U} open.
- After that, Syr Konrad and Gravebreaker Lamia fetching Gray Merchant.

WIN PATH: Braids' drain, Dalek's 3, Konrad's pings and Gray Merchant. P3, crippled at 23, dies first, then P2 (about 28 after drains). Roughly 4-5 turns.

THREATS & ANSWERS:
1. P2 Drivnod: Hostage Taker (destroy can't kill it).
2. P2 Ashnod's Altar, Grave Pact or Plunderer: channel Boseiju ({G} with Muldrotha out) on the artifact or enchantment. Recast the Deed for creatures.
3. P3 recasting Y'shtola: Dalek Drone (Shriekmaw can't hit a black creature). Glen counters Exsanguinate.
- Don't feed deaths after this turn: no Plaguecrafter, no chump blocks.

HOLD: Sol Ring, Glen Elendra, Underhanded Designs, Cryogen Relic, all for next turn. Nothing we cast before the Deed would survive it except Muldrotha.

REPLAN IF:
- The Deed cast is countered (for example by Fierce Guardianship).
- P3 saves its board with Flawless Maneuver.
- Our life drops to 10 or less.
- Muldrotha dies.
- P2 plays Altar, Plunderer or Grave Pact.
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Pernicious Deed (from Graveyard): Pernicious Deed by Muldrotha, the Gravetide (403) (] instead of Forge's [play land Nurturing Peatland (from Graveyard): Play land by Muldrotha, the Gravetide (403)]
PILOT OVERRULED FORGE (action, MAIN1): chose [play land Nurturing Peatland (from Graveyard): Play land by Muldrotha, the Gravetide (403)] instead of Forge's [play land Nurturing Peatland (from Graveyard): Play land by Muldrotha, the Gravetide (403)]
PILOT OVERRULED FORGE (trigger-target, MAIN1): chose [Drivnod, Carnage Dominus [P2, 8/3, tapped]] instead of Forge's [Alphinaud Leveilleur [P3, 3/5]]
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Claws of Gix (from Graveyard): Claws of Gix by Muldrotha, the Gravetide (403) (Artifa] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
- US cast Pernicious Deed
- US cast Hostage Taker
- US triggered Hostage Taker targeting [Drivnod, Carnage Dominus]
- left battlefield: Drivnod, Carnage Dominus was put into Exile from Battlefield.
- US cast Claws of Gix
- US triggered Braids, Arisen Nightmare
- left battlefield: Swamp was put into Graveyard from Battlefield.

## Turn 37 (P2, round 10) | life: P1 -1, P2 19, P3 5, US 16
MEMO (executor escalation: P3: life 23→15 (-8)):
THIS TURN: Now, at P2's end step with 0 mana, answer P2's Braids trigger. If P2 sacrificed a land, we sacrifice a Swamp. If an artifact, we sacrifice Claws of Gix. If a creature or enchantment, take the 2 life loss. Never let a creature of ours die: each death drains 4 while P2 has Drivnod, emblem and Sephiroth. Our turn (8 mana: replay a graveyard Swamp, 7 lands, Sol Ring): Sol Ring (1), then Hostage Taker from graveyard (4) exiling Drivnod (exile, not destroy). Then Cryogen Relic (2). Keep {U} open for Swan Song. At end step, Braids sacrifices Relic.

TARGET: Next turn (10 mana), cast Drivnod from exile (5) and Syr Konrad from graveyard (5). The turn after, cast The One Ring (4) and pop Deed at X=4 (4). We control Drivnod, so Konrad hits twice per death: about 11 deaths is 22 to each opponent. The Ring stops the emblem targeting us.

WIN PATH: The Deed turn kills P3 (15). Then Muldrotha 6, Drivnod 8, Konrad 5 and Gray Merchant close on P2 in 1-2 turns. P2 is fastest: a wipe with Drivnod kills anyone now.

THREATS & ANSWERS:
1. Drivnod: Hostage Taker this turn.
2. P2 Toxic Deluge or Meathook Massacre: Swan Song.
3. Sephiroth (a 4th death in one turn gives a second emblem): The One Ring on the Deed turn; Dalek Drone if mana is spare.
4. Exsanguinate: Swan Song.
Don't feed deaths: no Plaguecrafter, chump blocks or Shriekmaw.

HOLD: Swan Song with {U} open. Hold The One Ring for the Deed turn. Hold Glen Elendra. Keep Deed on the board.

REPLAN IF: Hostage Taker leaves play before we cast Drivnod; the Deed is removed; our life drops to 12 or less; Muldrotha dies; P3 wipes first.
ESCALATION (p=0.67): P3: life 23→15 (-8)
- P2 cast Dark Ritual
- P2 cast Sephiroth, Fabled SOLDIER
- P2 triggered Sephiroth, Fabled SOLDIER
- P2 cast Plaguecrafter
- P2 triggered Plaguecrafter
- left battlefield: Plaguecrafter was put into Graveyard from Battlefield.
- left battlefield: Hostage Taker was put into Graveyard from Battlefield.
- P2 triggered Sephiroth, Fabled SOLDIER targeting [P3]
- P2 triggered Emblem — Sephiroth, One-Winged Angel targeting [P3]
- P2 triggered Sephiroth, Fabled SOLDIER targeting [P3]
- P2 triggered Emblem — Sephiroth, One-Winged Angel targeting [P3]
- P2 triggered Sephiroth, Fabled SOLDIER targeting [P3]
- P2 triggered Emblem — Sephiroth, One-Winged Angel targeting [P3]
- P2 triggered Braids, Arisen Nightmare
- P3 triggered Y'shtola, Night's Blessed
- P3 cast Dismember targeting [Drivnod, Carnage Dominus]
- P3 triggered Y'shtola, Night's Blessed
- P3 triggered Lyse Hext
- P3 triggered G'raha Tia, Scion Reborn
- P2 activated Drivnod, Carnage Dominus
- left battlefield: Drivnod, Carnage Dominus was put into Graveyard from Battlefield.
- P2 triggered Sephiroth, Fabled SOLDIER targeting [P3]
- P2 triggered Sephiroth, Fabled SOLDIER targeting [P3]
- P2 triggered Emblem — Sephiroth, One-Winged Angel targeting [P3]
- left battlefield: Swamp was put into Graveyard from Battlefield.
Damage to US this turn: Y'shtola, Night's Blessed (non-combat) 2

## Turn 38 (P3, round 10) | life: P1 -1, P2 -2, P3 36, US -2
MEMO (executor escalation: P3: life 15→5 (-10)):
THIS TURN: P3's turn, and we have 0 mana, so only blocks matter. Muldrotha blocks the biggest attacker. Braids chump-blocks freely to save life, since it dies to our Deed anyway.
Our turn (8 mana):
1. Replay a Swamp from the graveyard.
2. Sol Ring (1).
3. The One Ring (4). We gain protection from everything, so P2's emblem can't target us and must target P3.
4. Activate Pernicious Deed at X=4 (4). This kills all of P3's creatures and tokens, P2's Braids and Sephiroth, our Braids, Claws and Sol Ring. That is about 11 deaths, and all 11 emblem drains must hit P3, who is at 5, so P3 dies.
5. If the Ring is countered, keep the Deed on the board. Fire it at X=4 only if our life is 14 or more; otherwise cast Glen Elendra (4) and hold the Deed. It is instant speed.

TARGET: Heads-up against P2 with Muldrotha and the Ring drawing. Next turn recast Syr Konrad (5) and Deed (3) from the graveyard, and Claws (0).

WIN PATH: P3 dies this turn. Then Muldrotha swings for 6 a turn, plus Konrad, Dalek Drone and Gray Merchant, to beat P2 (about 30 life) in 4-5 turns.

THREATS & ANSWERS:
1. P3's alpha strike or a wipe now: blocks only.
2. P2's recursive fodder and emblem drains on us: the Ring covers us until our next turn, then recast Deed and use Plaguecrafter sparingly.
3. P2's wipes: Swan Song.

HOLD: Swan Song, Glen Elendra, Cryogen Relic and Underhanded Designs.

REPLAN IF: P3 dies before our turn (then cast the Ring and hold the Deed); P3's life exceeds the death count; the Deed or Muldrotha is removed; the Ring is countered.
ESCALATION (p=0.81): P3: life 15→5 (-10)
- P3 triggered Transpose
- P3 cast Transpose
- P3 triggered Y'shtola, Night's Blessed
- P3 triggered Lyse Hext
- P3 triggered G'raha Tia, Scion Reborn
- P3 cast Exsanguinate
- P3 triggered Y'shtola, Night's Blessed
- P3 triggered Alphinaud Leveilleur
- P3 triggered Alphinaud Leveilleur
- P3 triggered Lyse Hext
- P3 triggered G'raha Tia, Scion Reborn
- attack: P3 assigned Lyse Hext, Hero Token, Alphinaud Leveilleur, Alisaie Leveilleur, Hero Token, Y'shtola, Night's Blessed, Alphinaud Leveilleur and G'raha Tia, Scion Reborn to attack P2.
- attack: P2 assigned Braids, Arisen Nightmare to block Lyse Hext.
- Game Outcome: P1 has lost because life total reached 0
- Game Outcome: P2 has lost because life total reached 0
- Game Outcome: P3 has won because all opponents have lost
- Game Outcome: US has lost because life total reached 0
Damage to US this turn: Y'shtola, Night's Blessed (non-combat) 4