# pod06-g4: we are P1; opponents P2 Atraxa, Praetors' Voice, P3 Sephiroth, Fabled SOLDIER, P4 Edgar Markov
Result: Turn 27; US has lost because life total reached 0; P2 has lost because life total reached 0; P3 has won because all opponents have lost; P4 has lost because life total reached 0

## Turn 1 (OUR TURN, round 1)
Our hand: Drowned Catacomb, Sol Ring, Twisted Embrace, Cabal Pit, Seal of Doom, Forest, Overgrown Tomb, Survival of the Fittest
Our graveyard (0): 
Board US: 0 lands; no nonland permanents
Board P2: 0 lands; no nonland permanents
Board P3: 0 lands; no nonland permanents
Board P4: 0 lands; no nonland permanents
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
- US cast Sol Ring

## Turn 2 (P2, round 1)

## Turn 3 (P3, round 1)
- P3 cast Dark Ritual
- P3 cast Sephiroth, Fabled SOLDIER
- P3 triggered Sephiroth, Fabled SOLDIER

## Turn 4 (P4, round 1)

## Turn 5 (OUR TURN, round 2) | life: US 39
Our hand: Drowned Catacomb, Twisted Embrace, Cabal Pit, Seal of Doom, Overgrown Tomb, Survival of the Fittest, Misty Rainforest
Our graveyard (0): 
Board US: 1 lands; Sol Ring
Board P2: 1 lands; no nonland permanents
Board P3: 1 lands; Sephiroth, Fabled SOLDIER 3/3
Board P4: 1 lands; no nonland permanents
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
- US cast Seal of Doom
Damage to US this turn: Cabal Pit (non-combat) 1

## Turn 6 (P2, round 2)

## Turn 7 (P3, round 2) | life: US 36
- attack: P3 assigned Sephiroth, Fabled SOLDIER to attack US.
- P3 triggered Sephiroth, Fabled SOLDIER
- P3 cast Forsaken Miner
Damage to US this turn: Sephiroth, Fabled SOLDIER (combat) 3

## Turn 8 (P4, round 2)
- P4 cast Vampire Socialite
- P4 triggered Edgar Markov

## Turn 9 (OUR TURN, round 3)
Our hand: Drowned Catacomb, Twisted Embrace, Overgrown Tomb, Survival of the Fittest, Misty Rainforest, Command Tower
Our graveyard (0): 
Board US: 2 lands; Sol Ring, Seal of Doom
Board P2: 2 lands; no nonland permanents
Board P3: 2 lands; Sephiroth, Fabled SOLDIER 3/3 (tapped 1), Forsaken Miner 2/2
Board P4: 2 lands; Vampire Token 1/1 [token], Vampire Socialite 2/2
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
PILOT OVERRULED FORGE (action, MAIN1): chose [play land Drowned Catacomb (from Hand): Play land] instead of Forge's [play land Command Tower (from Hand): Play land]
- US cast Survival of the Fittest

## Turn 10 (P2, round 3) | life: P3 41, P4 39, US 36
- P2 cast Blighted Agent
- left battlefield: Seal of Doom was put into Graveyard from Battlefield.
- US activated Seal of Doom targeting [Blighted Agent]
- left battlefield: Blighted Agent was put into Graveyard from Battlefield.
- P3 triggered Sephiroth, Fabled SOLDIER targeting [P4]

## Turn 11 (P3, round 3) | life: P3 42, P4 35, US 36
- attack: P3 assigned Sephiroth, Fabled SOLDIER and Forsaken Miner to attack P4.
- P3 triggered Sephiroth, Fabled SOLDIER
- left battlefield: Forsaken Miner was put into Graveyard from Battlefield.
- P3 triggered Sephiroth, Fabled SOLDIER targeting [P4]
- P3 triggered Forsaken Miner
- P3 cast Blood Artist

## Turn 12 (P4, round 3) | life: P3 39, P4 35, US 36
- attack: P4 assigned Vampire Socialite and Vampire Token to attack P3.
- P4 cast Talisman of Hierarchy

## Turn 13 (OUR TURN, round 4) | life: P3 39, P4 35, US 35
Our hand: Twisted Embrace, Overgrown Tomb, Misty Rainforest, Command Tower, Kaya's Ghostform
Our graveyard (1): Seal of Doom
Board US: 3 lands; Sol Ring, Survival of the Fittest
Board P2: 2 lands; no nonland permanents
Board P3: 3 lands; Sephiroth, Fabled SOLDIER 3/3 (tapped 1), Forsaken Miner 2/2, Blood Artist 0/1
Board P4: 3 lands; Vampire Token 1/1 [token] (tapped 1), Vampire Socialite 2/2 (tapped 1), Talisman of Hierarchy
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
- US cast Muldrotha, the Gravetide
Damage to US this turn: Cabal Pit (non-combat) 1

## Turn 14 (P2, round 4)
- P2 cast Skrelv, Defector Mite

## Turn 15 (P3, round 4) | life: P3 39, P4 26, US 35
- P3 cast Feed the Swarm targeting [Muldrotha, the Gravetide]
- left battlefield: Muldrotha, the Gravetide was put into Graveyard from Battlefield.
- P3 triggered Sephiroth, Fabled SOLDIER targeting [P4]
- P3 triggered Blood Artist targeting [P4]
- attack: P3 assigned Sephiroth, Fabled SOLDIER, Forsaken Miner and Blood Artist to attack P4.
- P3 triggered Sephiroth, Fabled SOLDIER
- left battlefield: Forsaken Miner was put into Graveyard from Battlefield.
- P3 triggered Sephiroth, Fabled SOLDIER targeting [P4]
- P3 triggered Blood Artist targeting [P4]
- P3 triggered Forsaken Miner
- P3 triggered Forsaken Miner
- left battlefield: Forsaken Miner was put into Graveyard from Battlefield.
- P3 triggered Sephiroth, Fabled SOLDIER targeting [P4]
- P3 triggered Blood Artist targeting [P4]
- P3 triggered Forsaken Miner
- P3 triggered Forsaken Miner

## Turn 16 (P4, round 4) | life: P3 36, P4 22, US 35
- attack: P4 assigned Vampire Socialite and Vampire Token to attack P3.
- P4 cast Champion of Dusk
- P4 triggered Edgar Markov
- P4 triggered Champion of Dusk

## Turn 17 (OUR TURN, round 5) | life: P3 38, P4 17, US 33
Our hand: Twisted Embrace, Overgrown Tomb, Misty Rainforest, Kaya's Ghostform, Dalek Drone
Our graveyard (1): Seal of Doom
Board US: 4 lands; Sol Ring, Survival of the Fittest
Board P2: 2 lands; Skrelv, Defector Mite 1/1
Board P3: 4 lands; Sephiroth, Fabled SOLDIER 3/3 (tapped 1), Blood Artist 0/1 (tapped 1), Forsaken Miner 2/2
Board P4: 4 lands; Vampire Token 1/1 [token] (tapped 1), Vampire Socialite 2/2 (tapped 1), Talisman of Hierarchy (tapped 1), Vampire Token 2/2 [token] {[P1P1]}, Champion of Dusk 5/5 {[P1P1]}
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
PILOT OVERRULED FORGE (search, MAIN1): chose [Zagoth Triome — Land - Swamp Forest Island — ({T}: Add {B}, {G}, or {U}.) Zagoth Triome en] instead of Forge's [Underground Sea — Land - Island Swamp — ({T}: Add {U} or {B}.)]
- left battlefield: Misty Rainforest was put into Graveyard from Battlefield.
- US activated Misty Rainforest
- US cast Dalek Drone
- US triggered Dalek Drone targeting [Champion of Dusk]
- left battlefield: Champion of Dusk was put into Graveyard from Battlefield.
- P3 triggered Sephiroth, Fabled SOLDIER targeting [P4]
- P3 triggered Blood Artist targeting [P4]
- US cast Kaya's Ghostform targeting [Dalek Drone]
Damage to US this turn: Cabal Pit (non-combat) 1

## Turn 18 (P2, round 5)
- P2 cast Fellwar Stone

## Turn 19 (P3, round 5) | life: P3 46, P4 6, US 33
- P3 cast Dictate of Erebos
- attack: P3 assigned Sephiroth, Fabled SOLDIER and Forsaken Miner to attack P4.
- P3 triggered Sephiroth, Fabled SOLDIER
- left battlefield: Forsaken Miner was put into Graveyard from Battlefield.
- P3 triggered Sephiroth, Fabled SOLDIER targeting [P4]
- P3 triggered Blood Artist targeting [P4]
- P3 triggered Dictate of Erebos
- P3 triggered Forsaken Miner
- P3 triggered Forsaken Miner
- left battlefield: Dalek Drone was put into Graveyard from Battlefield.
- left battlefield: Skrelv, Defector Mite was put into Graveyard from Battlefield.
- left battlefield: Kaya's Ghostform was put into Graveyard from Battlefield.
- P3 triggered Sephiroth, Fabled SOLDIER targeting [P4]
- P3 triggered Blood Artist targeting [P4]
- P3 triggered Sephiroth, Fabled SOLDIER targeting [P4]
- P3 triggered Blood Artist targeting [P4]
- P3 triggered Sephiroth, Fabled SOLDIER targeting [P4]
- P3 triggered Blood Artist targeting [P4]
- US triggered Kaya's Ghostform
- P3 triggered Forsaken Miner
- P3 triggered Forsaken Miner
- P3 triggered Forsaken Miner
- P3 triggered Forsaken Miner
- P3 triggered Forsaken Miner
- P3 triggered Forsaken Miner
- US triggered Dalek Drone targeting [Sephiroth, Fabled SOLDIER]
- left battlefield: Sephiroth, Fabled SOLDIER was put into Graveyard from Battlefield.
- P3 triggered Blood Artist targeting [P4]
- P3 triggered Dictate of Erebos
- P3 triggered Forsaken Miner
- left battlefield: Dalek Drone was put into Graveyard from Battlefield.
- P3 triggered Blood Artist targeting [P4]
- P3 triggered Blood Artist targeting [P4]
- P3 triggered Forsaken Miner
- P3 triggered Forsaken Miner

## Turn 20 (P4, round 5) | life: P3 38, P4 6, US 33
- P4 cast Edgar Markov
- attack: P4 assigned Edgar Markov and Vampire Socialite to attack P3.
- P4 triggered Edgar Markov

## Turn 21 (OUR TURN, round 6) | life: P3 39, P4 5, US 33
Our hand: Twisted Embrace, Overgrown Tomb, Mishra's Bauble
Our graveyard (4): Seal of Doom, Misty Rainforest, Kaya's Ghostform, Dalek Drone
Board US: 5 lands; Sol Ring, Survival of the Fittest
Board P2: 2 lands; Fellwar Stone
Board P3: 5 lands; Blood Artist 0/1, Dictate of Erebos
Board P4: 5 lands; Vampire Socialite 3/3 {[P1P1]} (tapped 1), Talisman of Hierarchy (tapped 1), Edgar Markov 5/5 {[P1P1]} (tapped 1)
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Mishra's Bauble (from Hand): Mishra's Bauble] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN1): chose [activate Mishra's Bauble (from Battlefield): {T}, Sacrifice Mishra's Bauble: Look at the t] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Twisted Embrace (from Hand): Twisted Embrace → target: Sol Ring [ours] [Forge's heuri] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
- US cast Mishra's Bauble
- left battlefield: Mishra's Bauble was put into Graveyard from Battlefield.
- US activated Mishra's Bauble targeting [P4]
- US cast Twisted Embrace targeting [Sol Ring]
- US triggered Twisted Embrace targeting [Edgar Markov]
- left battlefield: Edgar Markov was put into Graveyard from Battlefield.
- P3 triggered Blood Artist targeting [P4]
- P3 triggered Forsaken Miner

## Turn 22 (P2, round 6)
- US triggered Mishra's Bauble
- P2 cast Farseek

## Turn 23 (P3, round 6) | life: P3 40, P4 4, US 33
- P3 cast Zodiark, Umbral God
- P3 triggered Zodiark, Umbral God
- left battlefield: Blood Artist was put into Graveyard from Battlefield.
- P3 cast Dreadhorde Invasion
- P3 triggered Dictate of Erebos
- P3 triggered Blood Artist targeting [P4]
- P3 triggered Zodiark, Umbral God
- P3 triggered Forsaken Miner
- left battlefield: Vampire Socialite was put into Graveyard from Battlefield.
- P3 triggered Zodiark, Umbral God

## Turn 24 (P4, round 6)
- P4 cast Drana, Liberator of Malakir
- P4 triggered Edgar Markov
- P4 cast Welcoming Vampire
- P4 triggered Edgar Markov

## Turn 25 (OUR TURN, round 7) | life: P3 40, P4 4, US 31
Our hand: Vraska, Golgari Queen, Baba Lysaga, Night Witch
Our graveyard (5): Seal of Doom, Misty Rainforest, Kaya's Ghostform, Dalek Drone, Mishra's Bauble
Board US: 6 lands; Sol Ring, Survival of the Fittest, Twisted Embrace
Board P2: 3 lands; Fellwar Stone (tapped 1)
Board P3: 6 lands; Dictate of Erebos, Zodiark, Umbral God 7/7 {[P1P1 x 2]}, Dreadhorde Invasion
Board P4: 6 lands; Talisman of Hierarchy, Vampire Token 1/1 [token] x2, Drana, Liberator of Malakir 2/3, Welcoming Vampire 2/3
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
PILOT OVERRULED FORGE (action, MAIN2): chose [play land Misty Rainforest (from Graveyard): Play land by Muldrotha, the Gravetide (100) (] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN2): chose [cast Mishra's Bauble (from Graveyard): Mishra's Bauble by Muldrotha, the Gravetide (100) (] instead of Forge's [activate Misty Rainforest (from Battlefield): {T}, Pay 1 life, Sacrifice Misty Rainforest:]
PILOT OVERRULED FORGE (action, MAIN2): chose [activate Mishra's Bauble (from Battlefield): {T}, Sacrifice Mishra's Bauble: Look at the t] instead of Forge's [activate Misty Rainforest (from Battlefield): {T}, Pay 1 life, Sacrifice Misty Rainforest:]
PILOT OVERRULED FORGE (action, MAIN2): chose [cast Kaya's Ghostform (from Graveyard): Kaya's Ghostform by Muldrotha, the Gravetide (100)] instead of Forge's [cast Kaya's Ghostform (from Graveyard): Kaya's Ghostform by Muldrotha, the Gravetide (100)]
- US cast Muldrotha, the Gravetide
- US cast Mishra's Bauble
- left battlefield: Mishra's Bauble was put into Graveyard from Battlefield.
- US activated Mishra's Bauble targeting [P4]
- left battlefield: Misty Rainforest was put into Graveyard from Battlefield.
- US activated Misty Rainforest
- US cast Kaya's Ghostform targeting [Muldrotha, the Gravetide]
Damage to US this turn: Cabal Pit (non-combat) 1

## Turn 26 (P2, round 7)
- US triggered Mishra's Bauble
- P2 cast Atraxa, Praetors' Voice
- P2 triggered Atraxa, Praetors' Voice

## Turn 27 (P3, round 7) | life: P3 39, P4 4, US 31
- P3 triggered Dreadhorde Invasion
- attack: P3 assigned Zodiark, Umbral God to attack P4.
- attack: P4 assigned Vampire Token to block Zodiark, Umbral God.
- P3 cast Sephiroth, Fabled SOLDIER
- P3 triggered Sephiroth, Fabled SOLDIER

## Turn 28 (P4, round 7) | life: P3 38, P4 3, US 31
- P4 cast Vampire of the Dire Moon
- P4 triggered Edgar Markov
- P4 triggered Welcoming Vampire
- P4 cast Olivia's Wrath
- P3 cast Village Rites
- P3 triggered Dictate of Erebos
- P3 triggered Sephiroth, Fabled SOLDIER targeting [P4]
- P3 triggered Zodiark, Umbral God
- P3 triggered Forsaken Miner
- left battlefield: Sephiroth, Fabled SOLDIER was put into Graveyard from Battlefield.
- P3 triggered Dictate of Erebos
- P3 triggered Zodiark, Umbral God
- left battlefield: Muldrotha, the Gravetide was put into Graveyard from Battlefield.
- left battlefield: Atraxa, Praetors' Voice was put into Graveyard from Battlefield.
- left battlefield: Kaya's Ghostform was put into Graveyard from Battlefield.
- US triggered Kaya's Ghostform
- P3 triggered Zodiark, Umbral God
- P3 triggered Zodiark, Umbral God
- P3 triggered Zodiark, Umbral God
- P3 triggered Zodiark, Umbral God
- left battlefield: Forsaken Miner was put into Graveyard from Battlefield.
- P3 triggered Dictate of Erebos
- left battlefield: Vampire of the Dire Moon was put into Graveyard from Battlefield.
- P3 triggered Zodiark, Umbral God
- attack: P4 assigned Drana, Liberator of Malakir to attack P3.
- P4 triggered Drana, Liberator of Malakir

## Turn 29 (OUR TURN, round 8) | life: P3 38, P4 3, US 30
Our hand: Vraska, Golgari Queen, Baba Lysaga, Night Witch, Otawara, Soaring City, Sinister Concoction
Our graveyard (5): Seal of Doom, Dalek Drone, Mishra's Bauble, Misty Rainforest, Kaya's Ghostform
Board US: 7 lands; Sol Ring, Survival of the Fittest, Twisted Embrace
Board P2: 3 lands; Fellwar Stone (tapped 1)
Board P3: 7 lands; Dictate of Erebos, Zodiark, Umbral God 14/14 {[P1P1 x 9]} (tapped 1), Dreadhorde Invasion
Board P4: 7 lands; Talisman of Hierarchy, Drana, Liberator of Malakir 3/4 {[P1P1]} (tapped 1), Welcoming Vampire 2/3
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
PILOT OVERRULED FORGE (action, MAIN2): chose [cast Mishra's Bauble (from Graveyard): Mishra's Bauble by Muldrotha, the Gravetide (100) (] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN2): chose [activate Mishra's Bauble (from Battlefield): {T}, Sacrifice Mishra's Bauble: Look at the t] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
- US cast Muldrotha, the Gravetide
- US cast Mishra's Bauble
- left battlefield: Mishra's Bauble was put into Graveyard from Battlefield.
- US activated Mishra's Bauble targeting [P4]
Damage to US this turn: Cabal Pit (non-combat) 1

## Turn 30 (P2, round 8)
- US triggered Mishra's Bauble
- P2 cast Tekuthal, Inquiry Dominus

## Turn 31 (P3, round 8) | life: P3 37, P4 3, US 30
- P3 triggered Dreadhorde Invasion
- P3 cast The Masamune
- P3 activated The Masamune targeting [Zodiark, Umbral God]
- attack: P3 assigned Zodiark, Umbral God to attack P4.
- attack: P4 assigned Welcoming Vampire to block Zodiark, Umbral God.
- left battlefield: Welcoming Vampire was put into Graveyard from Battlefield.
- P3 cast Demon's Disciple
- P3 triggered Demon's Disciple
- left battlefield: Drana, Liberator of Malakir was put into Graveyard from Battlefield.
- left battlefield: Muldrotha, the Gravetide was put into Graveyard from Battlefield.
- left battlefield: Tekuthal, Inquiry Dominus was put into Graveyard from Battlefield.
- P3 triggered Dictate of Erebos
- P3 triggered Zodiark, Umbral God
- P3 triggered Zodiark, Umbral God
- P3 triggered Zodiark, Umbral God
- P3 triggered Zodiark, Umbral God

## Turn 32 (P4, round 8)
- P4 cast Edgar Markov

## Turn 33 (OUR TURN, round 9)
Our hand: Vraska, Golgari Queen, Baba Lysaga, Night Witch, Sinister Concoction, Boseiju, Who Endures, Massacre Wurm
Our graveyard (5): Seal of Doom, Dalek Drone, Misty Rainforest, Kaya's Ghostform, Mishra's Bauble
Board US: 8 lands; Sol Ring, Survival of the Fittest, Twisted Embrace
Board P2: 4 lands; Fellwar Stone (tapped 1)
Board P3: 8 lands; Dictate of Erebos, Zodiark, Umbral God 18/18 {[P1P1 x 13]} (tapped 1), Dreadhorde Invasion, The Masamune, Demon's Disciple 3/1
Board P4: 7 lands; Talisman of Hierarchy (tapped 1), Edgar Markov 4/4
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
- US cast Vraska, Golgari Queen
- US activated Vraska, Golgari Queen targeting [Demon's Disciple]
- left battlefield: Demon's Disciple was put into Graveyard from Battlefield.
- P3 triggered Dictate of Erebos
- left battlefield: Edgar Markov was put into Graveyard from Battlefield.
- P3 triggered Zodiark, Umbral God
- US cast Baba Lysaga, Night Witch
- US cast Sinister Concoction

## Turn 34 (P2, round 9)
- P2 cast Atraxa, Praetors' Voice
- P2 triggered Atraxa, Praetors' Voice

## Turn 35 (P3, round 9) | life: P3 38, P4 1, US 30
- P3 triggered Dreadhorde Invasion
- attack: P3 assigned Zodiark, Umbral God to attack Vraska, Golgari Queen.
- attack: US assigned Baba Lysaga, Night Witch to block Zodiark, Umbral God.
- left battlefield: Baba Lysaga, Night Witch was put into Graveyard from Battlefield.
- P3 cast Sephiroth, Fabled SOLDIER
- P3 triggered Sephiroth, Fabled SOLDIER
- P3 cast Bloodghast
- P3 triggered Dictate of Erebos
- P3 triggered Sephiroth, Fabled SOLDIER targeting [P4]
- P3 triggered Zodiark, Umbral God
- P3 triggered Forsaken Miner
- left battlefield: Atraxa, Praetors' Voice was put into Graveyard from Battlefield.
- P3 triggered Sephiroth, Fabled SOLDIER targeting [P4]
- P3 triggered Zodiark, Umbral God

## Turn 36 (P4, round 9)
PILOT OVERRULED FORGE (action, END_OF_TURN): chose [Do nothing now; let it resolve / let the turn pass (this skips o0, the play Forge's AI wou] instead of Forge's [activate Survival of the Fittest (from Battlefield): {G}, Discard a creature card: Search ]
- P4 cast Sanguine Bond
- P4 cast Knight of the Ebon Legion
- P4 triggered Edgar Markov
- P4 cast Blood Artist
- P4 triggered Edgar Markov

## Turn 37 (OUR TURN, round 10) | life: P3 36, P4 4, US 16
Our hand: Massacre Wurm, Eternal Witness
Our graveyard (6): Seal of Doom, Dalek Drone, Misty Rainforest, Kaya's Ghostform, Mishra's Bauble, Baba Lysaga, Night Witch
Board US: 9 lands; Sol Ring, Survival of the Fittest, Twisted Embrace, Vraska, Golgari Queen {[LOYALTY]}, Sinister Concoction
Board P2: 5 lands; Fellwar Stone (tapped 1)
Board P3: 9 lands; Dictate of Erebos, Zodiark, Umbral God 21/21 {[P1P1 x 16]} (tapped 1), Dreadhorde Invasion, The Masamune, Sephiroth, Fabled SOLDIER 3/3, Forsaken Miner 2/2, Bloodghast 2/1
Board P4: 7 lands; Talisman of Hierarchy (tapped 1), Sanguine Bond, Vampire Token 1/1 [token] x2, Knight of the Ebon Legion 1/2, Blood Artist 0/1
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
MEMO (executor escalation: us: life 30→21 (-9)):
You've hit your session limit · resets 6:40pm (UTC)
PILOT OVERRULED FORGE (action, MAIN1): chose [activate Sinister Concoction (from Battlefield): {B}, Pay 1 life, Discard a card, Sacrific] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
ESCALATION (p=0.73): us: life 30→21 (-9)
PILOT OVERRULED FORGE (action, MAIN1): chose [activate Vraska, Golgari Queen (from Battlefield): +2: You may sacrifice another permanent] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN1): chose [play land Bojuka Bog (from Hand): Play land] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (trigger-target, MAIN1): chose [P3 (38 life)] instead of Forge's [P4 (5 life)]
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Massacre Wurm (from Hand): Massacre Wurm - Creature 6 / 5 [Forge's heuristic AI would] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
- left battlefield: Sinister Concoction was put into Graveyard from Battlefield.
- US activated Sinister Concoction targeting [Sephiroth, Fabled SOLDIER]
- left battlefield: Sephiroth, Fabled SOLDIER was put into Graveyard from Battlefield.
- P3 triggered Dictate of Erebos
- P4 triggered Blood Artist targeting [P1]
- left battlefield: Cabal Pit was put into Graveyard from Battlefield.
- US activated Cabal Pit targeting [Bloodghast]
- left battlefield: Bloodghast was put into Graveyard from Battlefield.
- P3 triggered Dictate of Erebos
- P4 triggered Blood Artist targeting [P1]
- P4 triggered Sanguine Bond targeting [P1]
- P3 triggered Zodiark, Umbral God
- P4 triggered Blood Artist targeting [P1]
- P4 triggered Sanguine Bond targeting [P1]
- P4 triggered Sanguine Bond targeting [P1]
- P3 triggered Zodiark, Umbral God
- P4 triggered Blood Artist targeting [P1]
- P4 triggered Sanguine Bond targeting [P1]
- US activated Vraska, Golgari Queen
- left battlefield: Drowned Catacomb was put into Graveyard from Battlefield.
- US triggered Bojuka Bog targeting [P3]
- US cast Massacre Wurm
- US triggered Massacre Wurm
- left battlefield: Forsaken Miner was put into Graveyard from Battlefield.
- left battlefield: Knight of the Ebon Legion was put into Graveyard from Battlefield.
- left battlefield: Blood Artist was put into Graveyard from Battlefield.
- US triggered Massacre Wurm
- US triggered Massacre Wurm
- US triggered Massacre Wurm
- P3 triggered Dictate of Erebos
- P4 triggered Blood Artist targeting [P1]
- P4 triggered Blood Artist targeting [P1]
- P4 triggered Blood Artist targeting [P1]
- P4 triggered Sanguine Bond targeting [P1]
- P4 triggered Sanguine Bond targeting [P1]
- P4 triggered Sanguine Bond targeting [P1]
- left battlefield: Massacre Wurm was put into Graveyard from Battlefield.
- P3 triggered Zodiark, Umbral God

## Turn 38 (P2, round 10)
- P2 cast Doubling Season

## Turn 39 (P3, round 10) | life: P3 35, P4 -20, US 16
- P3 triggered Dreadhorde Invasion
- attack: P3 assigned Zodiark, Umbral God to attack P4.
- P3 cast Sephiroth, Fabled SOLDIER
- P3 triggered Sephiroth, Fabled SOLDIER

## Turn 40 (OUR TURN, round 10) | life: P3 35, P4 -20, US 17
Our hand: Seal of Primordium
Our graveyard (12): Seal of Doom, Dalek Drone, Misty Rainforest, Kaya's Ghostform, Mishra's Bauble, Baba Lysaga, Night Witch, Eternal Witness, Sinister Concoction, Hostage Taker, Cabal Pit, Drowned Catacomb, Massacre Wurm
Board US: 8 lands; Sol Ring, Survival of the Fittest, Twisted Embrace, Vraska, Golgari Queen {[LOYALTY x 3]}
Board P2: 5 lands; Fellwar Stone (tapped 1), Doubling Season
Board P3: 10 lands; Dictate of Erebos, Zodiark, Umbral God 24/24 {[P1P1 x 19]} (tapped 1), Dreadhorde Invasion, The Masamune, Zombie Army Token 1/1 [token] {[P1P1]}, Sephiroth, Fabled SOLDIER 3/3
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
PILOT OVERRULED FORGE (action, MAIN1): chose [activate Vraska, Golgari Queen (from Battlefield): +2: You may sacrifice another permanent] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
- US activated Vraska, Golgari Queen
- left battlefield: Forest was put into Graveyard from Battlefield.
- US cast Seal of Primordium
- left battlefield: Seal of Primordium was put into Graveyard from Battlefield.
- US activated Seal of Primordium targeting [Dictate of Erebos]
- left battlefield: Dictate of Erebos was put into Graveyard from Battlefield.
- US cast Siren Stormtamer

## Turn 41 (P2, round 11) | life: P2 39, P3 35, P4 -20, US 17
- left battlefield: Verdant Catacombs was put into Graveyard from Battlefield.
- P2 activated Verdant Catacombs
- P2 cast Oko, Thief of Crowns
- P2 activated Oko, Thief of Crowns
- P2 cast Glistening Sphere
- P2 triggered Glistening Sphere

## Turn 42 (P3, round 11) | life: P2 28, P3 52, P4 -20, US 8
- P3 triggered Dreadhorde Invasion
- attack: P3 assigned Zombie Army Token to attack P2.
- P3 triggered Sephiroth, Fabled SOLDIER
- left battlefield: Oko, Thief of Crowns was put into Graveyard from Battlefield.
- P3 cast Gray Merchant of Asphodel
- P3 triggered Gray Merchant of Asphodel

## Turn 43 (OUR TURN, round 11)
Our hand: Underhanded Designs
Our graveyard (14): Seal of Doom, Dalek Drone, Misty Rainforest, Kaya's Ghostform, Mishra's Bauble, Baba Lysaga, Night Witch, Eternal Witness, Sinister Concoction, Hostage Taker, Cabal Pit, Drowned Catacomb, Massacre Wurm, Forest, Seal of Primordium
Board US: 7 lands; Sol Ring, Survival of the Fittest, Twisted Embrace, Vraska, Golgari Queen {[LOYALTY x 5]}, Siren Stormtamer 1/1
Board P2: 6 lands; Fellwar Stone (tapped 1), Doubling Season, Food Token [token] x2, Glistening Sphere (tapped 1)
Board P3: 10 lands; Zodiark, Umbral God 24/24 {[P1P1 x 19]} (tapped 1), Dreadhorde Invasion, The Masamune, Zombie Army Token 2/2 [token] {[P1P1 x 2]} (tapped 1), Sephiroth, Fabled SOLDIER 3/3 (tapped 1), Gray Merchant of Asphodel 2/4
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
- US activated Vraska, Golgari Queen targeting [Sephiroth, Fabled SOLDIER]
- left battlefield: Sephiroth, Fabled SOLDIER was put into Graveyard from Battlefield.
- US cast Underhanded Designs

## Turn 44 (P2, round 11)
- P2 cast Atraxa, Praetors' Voice
- P2 triggered Atraxa, Praetors' Voice

## Turn 45 (P3, round 12) | life: P2 28, P3 51, P4 -20, US 6
- P3 triggered Dreadhorde Invasion
- P3 cast Skullclamp
- P3 activated Skullclamp targeting [Zodiark, Umbral God]
- attack: P3 assigned Gray Merchant of Asphodel to attack US.
- left battlefield: Siren Stormtamer was put into Graveyard from Battlefield.
- left battlefield: Vraska, Golgari Queen was put into Graveyard from Battlefield.
Damage to US this turn: Gray Merchant of Asphodel (combat) 2

## Turn 46 (OUR TURN, round 12)
Our hand: Syr Konrad, the Grim
Our graveyard (16): Seal of Doom, Dalek Drone, Misty Rainforest, Kaya's Ghostform, Mishra's Bauble, Baba Lysaga, Night Witch, Eternal Witness, Sinister Concoction, Hostage Taker, Cabal Pit, Drowned Catacomb, Massacre Wurm, Forest, Seal of Primordium, Siren Stormtamer, Vraska, Golgari Queen
Board US: 7 lands; Sol Ring, Survival of the Fittest, Twisted Embrace, Underhanded Designs
Board P2: 6 lands; Fellwar Stone (tapped 1), Doubling Season, Food Token [token] x2, Glistening Sphere (tapped 1), Atraxa, Praetors' Voice 4/4
Board P3: 10 lands; Zodiark, Umbral God 25/23 {[P1P1 x 19]} (tapped 1), Dreadhorde Invasion, The Masamune, Zombie Army Token 3/3 [token] {[P1P1 x 3]} (tapped 1), Gray Merchant of Asphodel 2/4 (tapped 1), Skullclamp
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
- US cast Syr Konrad, the Grim

## Turn 47 (P2, round 12) | life: P2 32, P3 47, P4 -20, US 6
- attack: P2 assigned Atraxa, Praetors' Voice to attack P3.
- P2 cast Bloom Tender
- P2 cast Arcane Signet
- P2 cast Sol Ring
- P2 triggered Atraxa, Praetors' Voice

## Turn 48 (P3, round 12) | life: P2 30, P3 45, P4 -20, US 6
- P3 triggered Dreadhorde Invasion
- attack: P3 assigned Zodiark, Umbral God and Zombie Army Token to attack P2.
- P2 activated Food Token
- attack: P2 assigned Bloom Tender to block Zodiark, Umbral God.
- left battlefield: Bloom Tender was put into Graveyard from Battlefield.
- US triggered Syr Konrad, the Grim
- P3 cast Sephiroth, Fabled SOLDIER
- P3 triggered Sephiroth, Fabled SOLDIER
- US activated Syr Konrad, the Grim
- US activated Syr Konrad, the Grim

## Turn 49 (OUR TURN, round 13)
Our hand: Toxic Deluge
Our graveyard (18): Seal of Doom, Dalek Drone, Misty Rainforest, Kaya's Ghostform, Mishra's Bauble, Baba Lysaga, Night Witch, Eternal Witness, Sinister Concoction, Hostage Taker, Cabal Pit, Drowned Catacomb, Massacre Wurm, Forest, Seal of Primordium, Siren Stormtamer, Vraska, Golgari Queen, The Death of Gwen Stacy, Underground Sea
Board US: 7 lands; Sol Ring, Survival of the Fittest, Twisted Embrace, Underhanded Designs, Syr Konrad, the Grim 5/4
Board P2: 6 lands; Fellwar Stone (tapped 1), Doubling Season, Food Token [token], Glistening Sphere, Atraxa, Praetors' Voice 4/4, Arcane Signet, Sol Ring (tapped 1)
Board P3: 11 lands; Zodiark, Umbral God 25/23 {[P1P1 x 19]} (tapped 1), Dreadhorde Invasion, The Masamune, Zombie Army Token 4/4 [token] {[P1P1 x 4]} (tapped 1), Gray Merchant of Asphodel 2/4, Skullclamp, Sephiroth, Fabled SOLDIER 3/3
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Toxic Deluge (from Hand): As an additional cost to cast this spell, pay X life. All c] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
- US cast Toxic Deluge

## Turn 50 (P2, round 13) | life: P2 34, P3 41, P4 -20, US 6
- attack: P2 assigned Atraxa, Praetors' Voice to attack P3.
- P2 triggered Atraxa, Praetors' Voice

## Turn 51 (P3, round 13) | life: P2 24, P3 37, P4 -20, US 1
- P3 triggered Dreadhorde Invasion
- attack: P3 assigned Zodiark, Umbral God and Zombie Army Token to attack P2.
- attack: P2 assigned Atraxa, Praetors' Voice to block Zodiark, Umbral God.
- left battlefield: Atraxa, Praetors' Voice was put into Graveyard from Battlefield.
- P3 triggered Sephiroth, Fabled SOLDIER targeting [P1]
- US triggered Syr Konrad, the Grim
- P3 triggered Forsaken Miner
- left battlefield: Forsaken Miner was put into Graveyard from Battlefield.
- P3 cast Deadly Dispute
- P3 triggered Sephiroth, Fabled SOLDIER targeting [P1]
- P3 triggered Zodiark, Umbral God
- US triggered Syr Konrad, the Grim
- P3 triggered Forsaken Miner
- P2 activated Food Token
- P3 cast Syr Konrad, the Grim
- US activated Syr Konrad, the Grim
- P3 triggered Syr Konrad, the Grim
- P3 triggered Syr Konrad, the Grim
- US triggered Syr Konrad, the Grim
- US triggered Syr Konrad, the Grim
- US activated Syr Konrad, the Grim
- US activated Syr Konrad, the Grim
- P3 triggered Syr Konrad, the Grim
- US triggered Syr Konrad, the Grim
Damage to US this turn: Syr Konrad, the Grim (non-combat) 3

## Turn 52 (OUR TURN, round 13)
Our hand: Counterspell
Our graveyard (22): Seal of Doom, Dalek Drone, Misty Rainforest, Kaya's Ghostform, Mishra's Bauble, Baba Lysaga, Night Witch, Eternal Witness, Sinister Concoction, Hostage Taker, Cabal Pit, Drowned Catacomb, Massacre Wurm, Forest, Seal of Primordium, Siren Stormtamer, Vraska, Golgari Queen, The Death of Gwen Stacy, Underground Sea, Toxic Deluge, Hinterland Harbor
Board US: 7 lands; Sol Ring, Survival of the Fittest, Twisted Embrace, Underhanded Designs, Syr Konrad, the Grim 5/4
Board P2: 7 lands; Fellwar Stone, Doubling Season, Glistening Sphere, Arcane Signet, Sol Ring (tapped 1)
Board P3: 11 lands; Zodiark, Umbral God 26/24 {[P1P1 x 20]} (tapped 1), Dreadhorde Invasion, The Masamune, Zombie Army Token 5/5 [token] {[P1P1 x 5]} (tapped 1), Gray Merchant of Asphodel 2/4, Skullclamp, Sephiroth, Fabled SOLDIER 3/3, Forsaken Miner 2/2, Treasure Token [token], Syr Konrad, the Grim 5/4
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)

## Turn 53 (P2, round 14) | life: P2 18, P3 37, P4 -20, US 0
- P2 cast Atraxa, Praetors' Voice
- US cast Counterspell targeting [Atraxa, Praetors' Voice - Creature 4 / 4]
- P3 triggered Syr Konrad, the Grim
- US triggered Syr Konrad, the Grim
- P3 activated Syr Konrad, the Grim
- P3 triggered Syr Konrad, the Grim
- left battlefield: Forsaken Miner was put into Graveyard from Battlefield.
- P3 activated Syr Konrad, the Grim
- P3 triggered Sephiroth, Fabled SOLDIER targeting [P2]
- P3 triggered Syr Konrad, the Grim
- P3 triggered Zodiark, Umbral God
- P3 triggered Forsaken Miner
- P3 triggered Syr Konrad, the Grim
Damage to US this turn: Syr Konrad, the Grim (non-combat) 1

## Turn 54 (P3, round 14) | life: P2 -9, P3 36, P4 -20, US 0
- P3 triggered Dreadhorde Invasion
- attack: P3 assigned Zodiark, Umbral God, Zombie Army Token, Syr Konrad, the Grim, Sephiroth, Fabled SOLDIER and Gray Merchant of Asphodel to attack P2.
- P3 triggered Sephiroth, Fabled SOLDIER
- P3 triggered Dreadhorde Invasion
- Game Outcome: US has lost because life total reached 0
- Game Outcome: P2 has lost because life total reached 0
- Game Outcome: P3 has won because all opponents have lost
- Game Outcome: P4 has lost because life total reached 0