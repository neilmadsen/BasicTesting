# pod03-g4: we are P4; opponents P1 Teval, the Balanced Scale, P2 Giada, Font of Hope, P3 Edgar Markov
Result: Turn 25; P1 has lost because life total reached 0; P2 has won because all opponents have lost; P3 has lost because life total reached 0; US has lost because life total reached 0

## Turn 1 (P1, round 1)

## Turn 2 (P2, round 1)
- P2 cast Land Tax

## Turn 3 (P3, round 1)
- P3 cast Knight of the Ebon Legion
- P3 triggered Edgar Markov

## Turn 4 (OUR TURN, round 1)
Our hand: Toxic Deluge, Soul-Guide Lantern, Baleful Strix, Arcane Signet, Professor Dellian Fel, Swamp, Gray Merchant of Asphodel
Our graveyard (0): 
Board P1: 1 lands; no nonland permanents
Board P2: 1 lands; Land Tax
Board P3: 1 lands; Vampire Token 1/1 [token], Knight of the Ebon Legion 1/2
Board US: 0 lands; no nonland permanents
MEMO (start of our turn):
THIS TURN: Play Swamp, then cast Soul-Guide Lantern (1). All graveyards are empty, so its ETB fizzles harmlessly. It sits ready as instant-speed "exile each opponent's graveyard." Pass. There is nothing to do on opponents' turns.

TARGET: Next turn: land plus Arcane Signet. Turn after: Baleful Strix, holding up blocks. Then Professor Dellian Fel on 4 mana, and Muldrotha on 6 around our turn 5-6. Priority tutor/draw targets: Sol Ring, Mind Stone, Talisman, Farseek, Nature's Lore, Executioner's Capsule, Claws of Gix, Seal of Doom.

WIN PATH: Muldrotha recurring Strix, Capsule and Dellian's -3 each turn. Then Gray Merchant plus a sac outlet (Claws of Gix, Vraska) to recast Merchant every turn and drain. Aim to lock by turn 8, close by turns 11-12. P3 Edgar is fastest (turns 6-8).

THREATS & ANSWERS:
1. P3 Edgar wide board: Toxic Deluge at a small X (2-3) once there are 4+ tokens or a lord. Pay only what's needed. Strix blocks the Knight (its pump gives deathtouch, so trades are fine).
2. P2 Giada: Dellian -3 on arrival. Strix is a deathtouch flying blocker.
3. P1 Teval self-mill/Living Death: Lantern tap-sac in response to Living Death or a reanimation spell. Don't pick off its yard one card at a time.

HOLD: Toxic Deluge until the board is wide, not before. Don't sac Lantern for a card while P1 is stocking its yard. Gray Merchant waits until devotion is 4+ and a recursion outlet exists.

REPLAN IF: we miss land drops (then prioritise Signet and cheap draw). Replan if P3 lands Vito, Exquisite Blood or Skullclamp, or if P1 casts Living Death or mills heavily.
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Soul-Guide Lantern (from Hand): Soul-Guide Lantern [Forge's heuristic AI would not do] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
- US cast Soul-Guide Lantern
- left battlefield: Soul-Guide Lantern was put into Graveyard from Battlefield.
- US activated Soul-Guide Lantern

## Turn 5 (P1, round 2)
- P1 cast Sakura-Tribe Elder
- left battlefield: Sakura-Tribe Elder was put into Graveyard from Battlefield.
- P1 activated Sakura-Tribe Elder

## Turn 6 (P2, round 2)
- P2 triggered Land Tax
- P2 cast Authority of the Consuls

## Turn 7 (P3, round 2) | life: P2 40
- attack: P3 assigned Vampire Token and Knight of the Ebon Legion to attack P2.
- P3 cast Blood Artist
- P3 triggered Edgar Markov
- P2 triggered Authority of the Consuls
- P2 triggered Authority of the Consuls

## Turn 8 (OUR TURN, round 2)

## Turn 9 (P1, round 3) | life: P2 41
- P1 triggered Underground Mortuary
- P1 cast Six
- P2 triggered Authority of the Consuls

## Turn 10 (P2, round 3)
- P2 triggered Land Tax
- P2 cast Giada, Font of Hope

## Turn 11 (P3, round 3) | life: P1 37, P2 41, P3 40, US 39
- P3 cast Damn targeting [Giada, Font of Hope]
- left battlefield: Giada, Font of Hope was put into Graveyard from Battlefield.
- P3 triggered Blood Artist targeting [P4]
- attack: P3 assigned Vampire Token, Knight of the Ebon Legion and Vampire Token to attack P1.

## Turn 12 (OUR TURN, round 3)
Our hand: Toxic Deluge, Baleful Strix, Arcane Signet, Professor Dellian Fel, Gray Merchant of Asphodel, Invasion of Innistrad, Bayou
Our graveyard (1): Soul-Guide Lantern
Board P1: 4 lands; Six 2/4 (tapped 1)
Board P2: 3 lands; Land Tax, Authority of the Consuls
Board P3: 3 lands; Vampire Token 1/1 [token] x2 (tapped 2), Knight of the Ebon Legion 1/2 (tapped 1), Blood Artist 0/1
Board US: 1 lands; no nonland permanents
MEMO (start of our turn):
THIS TURN: Play Bayou and cast Arcane Signet with Swamp plus Bayou (2 mana). Pass. Strix can't be cast yet because we have no blue until Signet untaps. There are no instant plays this cycle.

TARGET: Next turn, land plus Signet gives 4 mana. Cast Professor Dellian Fel and -3 on Blood Artist, or on Teval if it has landed. The following turn, cast Baleful Strix (Signet for U) and hold Invasion of Innistrad's flash (4). Muldrotha comes at 6 mana. Tutor targets: Sol Ring, Mind Stone, Talisman of Dominance, Farseek, Executioner's Capsule, Claws of Gix, Seal of Doom. We are short on lands (only Bayou in hand), so prioritise land and ramp draws.

WIN PATH: Muldrotha recurs Dellian's -3, Capsule and Strix each turn. Later, Gray Merchant plus Claws of Gix or Vraska drains every turn. Lock by about turn 20, close within 3-4 rounds. P3 is fastest (Edgar's tokens plus Blood Artist drain).

THREATS & ANSWERS:
1. P3 Edgar: Blood Artist gets Dellian -3. Vito, Captivating Vampire or Bloodthirsty Conqueror get Invasion (flash). Toxic Deluge only after Blood Artist is dead, or each death drains us.
2. P1 Teval (not yet cast) gets Invasion or Dellian -3. Killing it doesn't stop the engine. Six is low priority.
3. P2 (7 cards, Land Tax refuelling): Giada is dead. Recast Giada, or an early Angel, gets Dellian -3.
Authority of the Consuls makes our creatures enter tapped, so don't count Strix as a blocker the turn it lands.

HOLD: Toxic Deluge while Blood Artist lives. Gray Merchant until devotion is 4+ with a sac outlet. Invasion for a kill-on-sight target, not a token.

REPLAN IF: P3 casts Vito, Exquisite Blood or Skullclamp. P1 casts Living Death or Teval. We miss the next land drop (then play Signet-fuelled Strix and hunt for lands). Someone wipes.
- US cast Arcane Signet

## Turn 13 (P1, round 4) | life: P1 36, P2 42, P3 38, US 39
- left battlefield: Misty Rainforest was put into Graveyard from Battlefield.
- P1 activated Misty Rainforest
- attack: P1 assigned Six to attack P3.
- P1 triggered Six
- P1 cast Teval, the Balanced Scale
- P2 triggered Authority of the Consuls

## Turn 14 (P2, round 4)
- P2 triggered Land Tax
- P2 cast Smothering Tithe

## Turn 15 (P3, round 4) | life: P1 30, P2 42, P3 37, US 39
- P2 triggered Smothering Tithe
- left battlefield: Marsh Flats was put into Graveyard from Battlefield.
- P3 activated Marsh Flats
- attack: P3 assigned Vampire Token, Knight of the Ebon Legion and Vampire Token to attack P1.
- P3 activated Knight of the Ebon Legion
- P3 triggered Knight of the Ebon Legion

## Turn 16 (OUR TURN, round 4)
Our hand: Toxic Deluge, Baleful Strix, Professor Dellian Fel, Gray Merchant of Asphodel, Invasion of Innistrad, Woodland Cemetery
Our graveyard (1): Soul-Guide Lantern
Board P1: 5 lands; Six 2/4 (tapped 1), Teval, the Balanced Scale 4/4 (tapped 1)
Board P2: 4 lands; Land Tax, Authority of the Consuls, Smothering Tithe, Treasure Token [token] x2
Board P3: 4 lands; Vampire Token 1/1 [token] x2 (tapped 2), Knight of the Ebon Legion 2/3 {[P1P1]} (tapped 1), Blood Artist 0/1
Board US: 2 lands; Arcane Signet
MEMO (start of our turn):
THIS TURN: Play Woodland Cemetery; it enters untapped because we control Swamp and Bayou. Cast Toxic Deluge with X=4 (pay 4 life), tapping Swamp, Bayou and Cemetery. This kills Teval (4/4), Six, Knight, Blood Artist and both tokens. Blood Artist's triggers may cost us up to 6 more life; that is accepted. Keep Signet untapped and pass. No instant plays this cycle. Decline Smothering Tithe's {2} unless that mana would otherwise go unused.

TARGET: Next turn, cast Professor Dellian Fel onto an empty board: 0 to draw, or -3 on any recast Giada or Vampire. The turn after, cast Baleful Strix (Signet for U) or hold Invasion's flash. Muldrotha at 6 mana. Tutor or draw priorities: lands, Sol Ring, Mind Stone, Talisman of Dominance, Farseek, Executioner's Capsule, Claws of Gix.

WIN PATH: Muldrotha recurs Dellian, Capsule and Strix each turn. Later, Gray Merchant plus Claws of Gix or Vraska drains every turn. Close in about 3-4 rounds after the lock. P3 is fastest: Edgar's eminence rebuilds tokens.

THREATS & ANSWERS:
1. P3: Vito, Bloodthirsty Conqueror or Captivating Vampire get Invasion (flash). Exquisite Blood or Skullclamp need a Seal or Assassin's Trophy.
2. P1: a recast Teval (now costs 6) gets Dellian -3 or Invasion. Hold Soul-Guide Lantern recursion for Living Death or a reanimation.
3. P2: Giada (costs 4 now) or an early Angel gets Dellian -3.

HOLD: Invasion for a kill-on-sight target, not a token. Gray Merchant until devotion is 4+ and we have a sac outlet. Strix until Muldrotha, unless we need a blocker. Authority of the Consuls makes it enter tapped.

REPLAN IF: Someone responds to Deluge with protection, such as Teferi's Protection. Vito combo pieces land. Living Death resolves. We miss a land drop.
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Toxic Deluge (from Hand): As an additional cost to cast this spell, pay X life. All c] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
- P2 triggered Smothering Tithe
- US cast Toxic Deluge

## Turn 17 (P1, round 5) | life: P1 30, P2 40, P3 37, US 39
- P2 triggered Smothering Tithe
- attack: P1 assigned Teval, the Balanced Scale and Six to attack P2.
- P1 triggered Teval, the Balanced Scale
- P1 triggered Six
- P1 triggered Teval, the Balanced Scale
- P2 triggered Authority of the Consuls
- P1 triggered Teval, the Balanced Scale
- P2 triggered Authority of the Consuls
- P1 cast Kheru Goldkeeper
- P1 triggered Teval, the Balanced Scale
- P2 triggered Authority of the Consuls
- P2 triggered Authority of the Consuls

## Turn 18 (P2, round 5)
- P2 triggered Land Tax
- P2 cast Archangel of Thune
- P2 cast Swiftfoot Boots
- P2 cast Segovian Angel

## Turn 19 (P3, round 5) | life: P1 23, P2 40, P3 37, US 39
- P2 triggered Smothering Tithe
- attack: P3 assigned Knight of the Ebon Legion, Vampire Token and Vampire Token to attack P1.
- P3 activated Knight of the Ebon Legion
- P3 cast Sol Ring
- P3 cast Talisman of Indulgence
- P3 triggered Knight of the Ebon Legion

## Turn 20 (OUR TURN, round 5) | life: P1 23, P2 40, P3 38, US 38
Our hand: Baleful Strix, Professor Dellian Fel, Gray Merchant of Asphodel, Invasion of Innistrad, Overgrown Tomb
Our graveyard (2): Soul-Guide Lantern, Toxic Deluge
Board P1: 7 lands; Six 2/4 (tapped 1), Teval, the Balanced Scale 4/4 (tapped 1), Zombie Druid Token 2/2 [token] x3 (tapped 3), Kheru Goldkeeper 3/3 (tapped 1)
Board P2: 5 lands; Land Tax, Authority of the Consuls, Smothering Tithe, Archangel of Thune 3/4, Swiftfoot Boots, Segovian Angel 1/1, Treasure Token [token]
Board P3: 4 lands; Vampire Token 1/1 [token] x2 (tapped 2), Knight of the Ebon Legion 3/4 {[P1P1 x 2]} (tapped 1), Blood Artist 0/1, Sol Ring (tapped 1), Talisman of Indulgence
Board US: 3 lands; Arcane Signet
MEMO (start of our turn):
THIS TURN: Decline Smothering Tithe's {2}. Play Overgrown Tomb, paying 2 life so it enters untapped (5 mana). Cast Professor Dellian Fel (4) and use −3 on Archangel of Thune now, before P2 can equip Swiftfoot Boots. Blood Artist's trigger on that is fine. Keep the last 1 mana spare and pass. No instant plays this cycle, since Invasion needs 4.

TARGET: Muldrotha at 6 mana, which needs one more land or rock (Sol Ring, Mind Stone, Talisman of Dominance). Then Dellian recurs from the graveyard each turn to −3 a threat. Add Baleful Strix, Executioner's Capsule and Claws of Gix, and keep Invasion held as flash removal.

WIN PATH: Muldrotha loop, then Gray Merchant once devotion is 5+ and it can be sacrificed (Claws of Gix, Vraska) to drain every turn. P1 is fastest, with 7 flying power and a zombie swarm. We're at about 37 life, so we're safe this round. Our close is roughly 4 rounds out.

THREATS & ANSWERS:
1. P2 Thune: Dellian −3 today. Recast Giada or angels: Dellian again, or Invasion.
2. P1 Teval and Kheru fliers: Invasion (flash) on Kheru or a reanimated fatty. Living Death means don't stock creatures in our yard.
3. P3 Vito, Bloodthirsty Conqueror or Captivating Vampire: Invasion. Exquisite Blood or Skullclamp: Seal of Primordium or Assassin's Trophy.
Don't feed: creature entries (Authority of the Consuls lifegain), our creatures dying (Blood Artist), or paying Tithe.

HOLD: Invasion for a kill-on-sight target. Gray Merchant for now. Strix until Muldrotha or a flier needs a deathtouch blocker.

REPLAN IF: Thune gets hexproof or dies in response. We draw a land (then go Muldrotha next turn). Vito combo pieces land. A wipe hits.
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Professor Dellian Fel (from Hand): Professor Dellian Fel [Forge's heuristic AI would ] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN1): chose [Archangel of Thune [P2, 3/4]] instead of Forge's [Teval, the Balanced Scale [P1, 4/4, commander, tapped]]
- P2 triggered Smothering Tithe
- US cast Professor Dellian Fel
- US activated Professor Dellian Fel targeting [Archangel of Thune]
- left battlefield: Archangel of Thune was put into Graveyard from Battlefield.
- P3 triggered Blood Artist targeting [P4]

## Turn 21 (P1, round 6) | life: P1 22, P2 44, P3 38, US 27
- left battlefield: Misty Rainforest was put into Graveyard from Battlefield.
- P1 activated Misty Rainforest
- P2 triggered Smothering Tithe
- attack: P1 assigned Six, Kheru Goldkeeper, Zombie Druid Token, Zombie Druid Token and Zombie Druid Token to attack US.
- P1 triggered Teval, the Balanced Scale
- P1 triggered Six
- P1 triggered Teval, the Balanced Scale
- P1 triggered Kheru Goldkeeper
- P2 triggered Authority of the Consuls
- P1 triggered Teval, the Balanced Scale
- P1 triggered Kheru Goldkeeper
- P2 triggered Authority of the Consuls
- left battlefield: Professor Dellian Fel was put into Graveyard from Battlefield.
- P1 cast River Kelpie
- P2 triggered Authority of the Consuls
- P1 cast Wonder
- P2 triggered Authority of the Consuls
Damage to US this turn: Six (combat) 2, Kheru Goldkeeper (combat) 3, Zombie Druid Token (combat) 6

## Turn 22 (P2, round 6) | life: P1 21, P2 47, P3 38, US 27
- P2 triggered Land Tax
- P2 triggered Seraph Sanctuary
- P2 cast Herald of War
- P2 triggered Seraph Sanctuary
- P2 cast Giada, Font of Hope
- P2 triggered Seraph Sanctuary
- attack: P2 assigned Segovian Angel to attack P1.

## Turn 23 (P3, round 6) | life: P1 12, P2 49, P3 39, US 26
- P2 triggered Smothering Tithe
- P3 cast Patron of the Vein
- P3 triggered Edgar Markov
- P2 triggered Authority of the Consuls
- P3 triggered Patron of the Vein targeting [Teval, the Balanced Scale]
- P2 triggered Authority of the Consuls
- left battlefield: Teval, the Balanced Scale was put into Graveyard from Battlefield.
- P3 triggered Blood Artist targeting [P4]
- P3 triggered Patron of the Vein
- attack: P3 assigned Knight of the Ebon Legion, Vampire Token, Vampire Token and Blood Artist to attack P1.
- P3 triggered Knight of the Ebon Legion

## Turn 24 (OUR TURN, round 6) | life: P1 12, P2 49, P3 51, US 14
Our hand: Baleful Strix, Gray Merchant of Asphodel, Invasion of Innistrad, Pernicious Deed
Our graveyard (3): Soul-Guide Lantern, Toxic Deluge, Professor Dellian Fel
Board P1: 9 lands; Six 2/4 (tapped 1), Zombie Druid Token 2/2 [token] x5 (tapped 5), Kheru Goldkeeper 3/3 (tapped 1), River Kelpie 3/3 (tapped 1), Wonder 2/2 (tapped 1)
Board P2: 6 lands; Land Tax, Authority of the Consuls, Smothering Tithe, Swiftfoot Boots, Segovian Angel 1/1, Herald of War 3/3, Giada, Font of Hope 2/2, Treasure Token [token]
Board P3: 5 lands; Vampire Token 2/2 [token] {[P1P1]} x3 (tapped 3), Knight of the Ebon Legion 5/6 {[P1P1 x 4]} (tapped 1), Blood Artist 1/2 {[P1P1]} (tapped 1), Sol Ring (tapped 1), Talisman of Indulgence, Patron of the Vein 5/5 {[P1P1]} (tapped 1)
Board US: 4 lands; Arcane Signet
MEMO (start of our turn):
THIS TURN: Decline Smothering Tithe's {2}. Cast Pernicious Deed with Swamp, Bayou (G) and Woodland Cemetery. Keep Overgrown Tomb and Arcane Signet untapped (2 mana). Don't cast Strix: Authority makes it enter tapped, so it can't block this cycle, and its draw feeds Tithe. On opponents' turns, activate Deed at X=2 if either happens:
(a) Deed is targeted by removal. Pop in response.
(b) Attacks at us would drop us below 10. Pop after attackers are declared.
X=2 kills every token, Giada, Segovian Angel, Knight, Blood Artist, Boots, Authority, Land Tax, Sol Ring, Talisman and our Signet. Otherwise keep Deed.

TARGET: Next turn, if we draw a land: land, then Muldrotha (6). With no land and boards still wide, pop Deed at X=5 (5 mana). Otherwise flash Invasion on Patron. After that, Muldrotha recasts Dellian each turn to −3 a threat, and recasts Deed from the graveyard.

WIN PATH: Muldrotha loop, then Gray Merchant once devotion is 5+, with Claws of Gix to sacrifice and recast it. P1 at 12 is the first drain target. Our clock is about 4 rounds. P1 (20 power) and P3 are the fastest.

THREATS & ANSWERS:
1. P1's 5 Zombies, Kheru and Kelpie: Deed. Wonder in P1's graveyard gives all their creatures flying. Only kill Wonder if Patron is alive to exile it, or recast Lantern to exile it.
2. P3's Vito, Bloodthirsty Conqueror or Patron: Invasion (flash).
3. P2's Giada: Deed X=2. Herald: Dellian later.
Toxic Deluge in our graveyard is dead (a sorcery; only Eternal Witness gets it back).

HOLD: Invasion for Vito, Conqueror or Patron. Gray Merchant until devotion is 5+. Strix until Muldrotha is out.

REPLAN IF: Deed is removed or countered. Vito, Exquisite Blood or Conqueror lands. Wonder hits P1's graveyard. We fall below 12 life.
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Pernicious Deed (from Hand): Pernicious Deed [Forge's heuristic AI would not do this:] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN2): chose [activate Pernicious Deed (from Battlefield): {X}, Sacrifice Pernicious Deed: Destroy each ] instead of Forge's [cast Baleful Strix (from Hand): Baleful Strix - Creature 1 / 1]
- P2 triggered Smothering Tithe
- US cast Pernicious Deed
- left battlefield: Pernicious Deed was put into Graveyard from Battlefield.
- US activated Pernicious Deed
- left battlefield: Arcane Signet was put into Graveyard from Battlefield.
- left battlefield: Land Tax was put into Graveyard from Battlefield.
- left battlefield: Authority of the Consuls was put into Graveyard from Battlefield.
- left battlefield: Swiftfoot Boots was put into Graveyard from Battlefield.
- left battlefield: Segovian Angel was put into Graveyard from Battlefield.
- left battlefield: Giada, Font of Hope was put into Graveyard from Battlefield.
- left battlefield: Knight of the Ebon Legion was put into Graveyard from Battlefield.
- left battlefield: Blood Artist was put into Graveyard from Battlefield.
- left battlefield: Sol Ring was put into Graveyard from Battlefield.
- left battlefield: Talisman of Indulgence was put into Graveyard from Battlefield.
- P3 triggered Patron of the Vein
- P3 triggered Blood Artist targeting [P4]
- P3 triggered Patron of the Vein
- P3 triggered Blood Artist targeting [P4]
- P3 triggered Patron of the Vein
- P3 triggered Blood Artist targeting [P4]
- P3 triggered Patron of the Vein
- P3 triggered Blood Artist targeting [P4]
- P3 triggered Patron of the Vein
- P3 triggered Blood Artist targeting [P4]
- P3 triggered Patron of the Vein
- P3 triggered Blood Artist targeting [P4]
- P3 triggered Patron of the Vein
- P3 triggered Blood Artist targeting [P4]
- P3 triggered Blood Artist targeting [P4]
- P3 triggered Blood Artist targeting [P4]
- P3 triggered Blood Artist targeting [P4]
- P3 triggered Blood Artist targeting [P4]
- P3 triggered Blood Artist targeting [P4]

## Turn 25 (P1, round 7)
- P1 triggered Kheru Goldkeeper
- attack: P1 assigned Six to attack P2.
- P1 triggered Six
- P1 triggered Kheru Goldkeeper
- attack: P2 assigned Herald of War to block Six.
- P1 triggered Hedge Maze
- P1 cast Teval, the Balanced Scale
- P1 cast Jarad, Golgari Lich Lord

## Turn 26 (P2, round 7)
- P2 cast Sword of the Animist
- P2 activated Sword of the Animist targeting [Herald of War]

## Turn 27 (P3, round 7)
- P2 triggered Smothering Tithe
- attack: P3 assigned Patron of the Vein to attack P1.
- attack: P1 assigned Wonder to block Patron of the Vein.
- left battlefield: Wonder was put into Graveyard from Battlefield.
- P3 triggered Patron of the Vein
- P1 triggered Teval, the Balanced Scale
- P3 cast Stromkirk Captain
- P3 triggered Edgar Markov

## Turn 28 (OUR TURN, round 7)
Our hand: Baleful Strix, Gray Merchant of Asphodel, Invasion of Innistrad, Drowned Catacomb
Our graveyard (5): Soul-Guide Lantern, Toxic Deluge, Professor Dellian Fel, Pernicious Deed, Arcane Signet
Board P1: 10 lands; Six 2/4 (tapped 1), Kheru Goldkeeper 3/3, River Kelpie 3/3, Teval, the Balanced Scale 4/4, Jarad, Golgari Lich Lord 7/7, Zombie Druid Token 2/2 [token]
Board P2: 7 lands; Smothering Tithe, Herald of War 4/4, Sword of the Animist, Treasure Token [token]
Board P3: 5 lands; Patron of the Vein 14/14 {[P1P1 x 9]} (tapped 1), Vampire Token 2/2 [token], Stromkirk Captain 2/2
Board US: 4 lands; no nonland permanents
MEMO (start of our turn):
THIS TURN: Decline Smothering Tithe's {2} (and again on Strix's draw). Play Drowned Catacomb; it enters untapped because we control a Swamp. That gives 5 mana. Cast Baleful Strix with Catacomb (U) and Swamp (B), and draw. Keep Bayou, Woodland Cemetery and Overgrown Tomb open. If the draw is Assassin's Trophy or Heroic Intervention, hold it for opponents' turns. Blocking: Strix blocks Patron of the Vein if P3 attacks us; deathtouch kills Patron. On P1's or P2's turns, block with Strix only if the unblocked damage would put us at 0 or less.

TARGET: Next turn, land drop, then Muldrotha (6). The turn after, recast Pernicious Deed, Dellian (−3 a threat) and Soul-Guide Lantern from the graveyard. Tutor Claws of Gix or Massacre Wurm.

WIN PATH: Devotion from Muldrotha, Dellian, Deed, Strix and Gray Merchant is 6, so each Merchant cast drains P1 (at 12) by 6. Pop Deed at X=5 to kill Merchant, then recast Merchant from the graveyard to drain again. This takes 3–4 rounds, and we are behind P1 and P3.

THREATS & ANSWERS:
1. P3's Patron is 14 power flying, exactly lethal to us. Answer it with a Strix block only. Invasion does NOT kill it: −13 leaves a 1/1 because of Stromkirk Captain.
2. P1's Jarad drains by sacrificing creatures, and River Kelpie persists. Teval and Kheru are fliers. Answer: flash Invasion on Jarad next turn, or later.
3. P2's Herald of War: Dellian later.
Toxic Deluge is dead in the graveyard.

HOLD: Invasion (needs 4 mana, so next turn). Gray Merchant until devotion is 5 or more.

REPLAN IF: Strix is removed, we fall below 8, Stromkirk Captain dies (Invasion then kills Patron), Living Death resolves, or Vito lands.
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Baleful Strix (from Hand): Baleful Strix - Creature 1 / 1 [Forge's heuristic AI would] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
- P2 triggered Smothering Tithe
- US cast Baleful Strix
- US triggered Baleful Strix
- P2 triggered Smothering Tithe
- US cast Mind Stone

## Turn 29 (P1, round 8) | life: P1 12, P2 36, P3 51, US 14
MEMO (executor escalation: P2: life 49→36 (-13); P2: nonland permanents 4→8 (+4)):
THIS TURN: No plays now; Invasion needs 4 and we have 2. Decline every Smothering Tithe {2}. Flash Invasion of Innistrad (4: Bayou, Woodland Cemetery, Overgrown Tomb, Drowned Catacomb) at P3's end step, targeting Jarad; -13 kills it. Cast it earlier only to stop a lethal attack on us or a Vito combo. Make P3 the Siege's protector. Blocks: Strix (deathtouch) blocks Jarad or Herald if either attacks us.

TARGET: Next turn, land drop, then Muldrotha (6). If the land gives a 7th mana, recast Soul-Guide Lantern (1) and immediately {T}, sacrifice it to exile all opponents' graveyards, cutting off P1's Living Death and Jarad return. Tutor targets later: Claws of Gix, Massacre Wurm.

WIN PATH: Devotion from Muldrotha 1, Strix 1, the Invasion battle 2 and Merchant 2 is 6. Recast Deed for 7. Merchant drains P1 (12) twice, turn N+2, then pop Deed at X=5 (Muldrotha survives) and recast Merchant. We race P1's clock of 1–2 turns.

THREATS & ANSWERS:
1. P1 Jarad 8/8 with sacrifice-drain: Invasion now, then Lantern to exile the yard.
2. P1 fliers (Teval 4, Kheru 3): Dellian -3 later.
3. P2 Herald of War: Strix block.
4. P3: Stromkirk Captain and token are minor.

HOLD: Gray Merchant until devotion is at least 5 (Muldrotha plus the battle on board). Keep Strix home as a blocker.

REPLAN IF: We drop below 8. Jarad returns to P1's hand. A wipe or Living Death resolves. P2 lands Thune or Avacyn. Vito appears.
ESCALATION (p=0.65): P2: life 49→36 (-13); P2: nonland permanents 4→8 (+4)
- P2 triggered Smothering Tithe
- P1 cast Assassin's Trophy targeting [Patron of the Vein]
- left battlefield: Patron of the Vein was put into Graveyard from Battlefield.
- attack: P1 assigned Teval, the Balanced Scale and Jarad, Golgari Lich Lord to attack P2.
- P1 triggered Teval, the Balanced Scale
- P1 triggered River Kelpie
- P1 triggered Kheru Goldkeeper
- P1 triggered Teval, the Balanced Scale
- P2 triggered Smothering Tithe
- P1 cast Gravecrawler
- P1 triggered River Kelpie
- P1 triggered Kheru Goldkeeper
- P1 triggered Teval, the Balanced Scale
- P2 triggered Smothering Tithe
- P1 cast Wight of the Reliquary
- P1 cast Life from the Loam targeting [Foreboding Landscape, Misty Rainforest, Swamp]
- P1 triggered Kheru Goldkeeper
- P1 triggered Teval, the Balanced Scale
- P1 cast The Scarab God
- P1 triggered River Kelpie
- P1 triggered Kheru Goldkeeper
- P1 triggered Teval, the Balanced Scale
- P1 triggered Kheru Goldkeeper
- P1 triggered Teval, the Balanced Scale
- P1 activated The Scarab God targeting [Archangel of Thune]

## Turn 30 (P2, round 8)
MEMO (executor escalation: P1: nonland permanents 8→15 (+7); P1: creatures 7→15 (+8)):
THIS TURN: In response to Farewell, crack Mind Stone: pay {1} from Overgrown Tomb, tap and sacrifice Mind Stone, draw a card. Decline Tithe's {2}; the Treasure it makes is exiled anyway. Strix and our graveyard are lost regardless. We have no mana left until our untap. Decline all later Tithe payments.

TARGET: Rebuild after the reset. On our turn, play a land. If Muldrotha is affordable (6 plus any tax), cast her. Otherwise play the drawn card and hold Invasion (4) with flash. Next, refill the graveyard with self-sacrificing permanents so the lanes work again. Tutor targets: Executioner's Capsule, Claws of Gix, Massacre Wurm (vs Edgar tokens).

WIN PATH: P1 is at 12 and the lowest. Muldrotha (6/6) attacks plus Gray Merchant drains. Cast Merchant only at devotion 4 or more (Muldrotha 1 + Merchant 2 + battle 2 = 5). Estimated close is 3–4 turns; every opponent is rebuilding too.

THREATS & ANSWERS:
1. P1 recasting Teval or reanimators with 6 cards in hand: Invasion -13/-13 at instant speed.
2. P3 Edgar eminence and Vito: Invasion if Vito lands, otherwise later Wurm.
3. P2 angels (Giada, Thune): Invasion if unanswered and swinging.
Don't chump-block into P3 drain effects.

HOLD: Invasion of Innistrad for the first real threat (Vito > Teval > Thune/Giada); cast it on the opponent's end step only if nothing appears. Hold Gray Merchant until devotion is at least 4.

REPLAN IF: Farewell is countered or modes differ, P1 casts Living Death with a refilled yard, Vito or Exquisite Blood appears, or we fall below 8.
ESCALATION (p=0.89): P1: nonland permanents 8→15 (+7); P1: creatures 7→15 (+8)
PILOT OVERRULED FORGE (action, MAIN1): chose [activate Mind Stone (from Battlefield): {1}, {T}, Sacrifice Mind Stone: Draw a card. [Forg] instead of Forge's [Do nothing now; let it resolve / let the turn pass]
- P2 cast Farewell
- left battlefield: Mind Stone was put into Graveyard from Battlefield.
- US activated Mind Stone
- P2 triggered Smothering Tithe
- left battlefield: Sword of the Animist was put into Exile from Battlefield.
- left battlefield: Baleful Strix was put into Exile from Battlefield.
- left battlefield: Herald of War was put into Exile from Battlefield.
- left battlefield: Stromkirk Captain was put into Exile from Battlefield.
- left battlefield: Six was put into Exile from Battlefield.
- left battlefield: Kheru Goldkeeper was put into Exile from Battlefield.
- left battlefield: River Kelpie was put into Exile from Battlefield.
- left battlefield: Teval, the Balanced Scale was put into Exile from Battlefield.
- left battlefield: Jarad, Golgari Lich Lord was put into Exile from Battlefield.
- left battlefield: Gravecrawler was put into Exile from Battlefield.
- left battlefield: Wight of the Reliquary was put into Exile from Battlefield.
- left battlefield: The Scarab God was put into Exile from Battlefield.
- left battlefield: Archangel of Thune was put into Exile from Battlefield.
- left battlefield: Smothering Tithe was put into Exile from Battlefield.

## Turn 31 (P3, round 8) | life: P1 7, P2 36, P3 51, US 14
- P3 cast Edgar Markov
- attack: P3 assigned Edgar Markov to attack P1.
- P3 triggered Edgar Markov

## Turn 32 (OUR TURN, round 8) | life: P1 5, P2 34, P3 49, US 20
Our hand: Gray Merchant of Asphodel, Invasion of Innistrad, Dalek Drone, The Death of Gwen Stacy
Our graveyard (0): 
Board P1: 12 lands; no nonland permanents
Board P2: 8 lands; no nonland permanents
Board P3: 6 lands; Edgar Markov 5/5 {[P1P1]} (tapped 1)
Board US: 5 lands; no nonland permanents
MEMO (start of our turn):
THIS TURN: No land in hand. Cast Dalek Drone (5, tapping all lands) and target Edgar Markov. Edgar dies and P3 loses 3. Edgar's recast costs 8 and P3 has 6 lands. Leave the Drone home; it can't attack this turn. We have no mana on opponents' turns, so take no instant plays. Don't chump-block into P3.

TARGET: Kill P1 (7 life) next turn with Drone (BB) plus Gray Merchant (BB), which is devotion 4. Merchant drains everyone 4 and puts P1 at 3. Drone, a 3/3 flier with menace, then attacks P1 for 3, which is lethal. Afterwards, rebuild toward Muldrotha: tutor Executioner's Capsule and Claws of Gix.

WIN PATH: Next turn, play any drawn land. Cast Merchant in main 1 (5 mana; P1 to 3, we gain 12). Then attack P1 with the Drone. Menace needs two blockers. If P1 has two or more fliers or reach blockers, or has gained life, still drain and hit whoever is open. After P1 dies, grind P3 and P2 with Muldrotha recasting Drone and Merchant.

THREATS & ANSWERS: 1) P1 recasting Teval or Scarab God (6 cards, 12 lands): Gwen Stacy chapter I or Invasion, after the lethal turn. 2) P3 Vito or Exquisite Blood: Invasion. 3) P2 angels: Invasion, or Drone recast later.

HOLD: Invasion, Merchant and Gwen Stacy. Next turn, spend 5 on Merchant before anything else. Only use the 6th mana on Gwen (3) if it fits.

REPLAN IF: The Drone is removed (P2 has 2 Plains open). Then Merchant drains only 2, so cast Gwen/Invasion for devotion first. Also replan if P1 gains life, makes two or more flying blockers, or casts Teval.
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Gray Merchant of Asphodel (from Hand): Gray Merchant of Asphodel - Creature 2 / 4 [Fo] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
- US cast Gray Merchant of Asphodel
- US triggered Gray Merchant of Asphodel

## Turn 33 (P1, round 9) | life: P1 4, P2 34, P3 49, US 20
- left battlefield: Misty Rainforest was put into Graveyard from Battlefield.
- P1 activated Misty Rainforest
- P1 cast Teval, the Balanced Scale
- P1 activated Foreboding Landscape

## Turn 34 (P2, round 9) | life: P1 4, P2 35, P3 49, US 20
- P2 cast Avacyn, Angel of Hope
- P2 triggered Seraph Sanctuary

## Turn 35 (P3, round 9) | life: P1 4, P2 35, P3 46, US 20
- P3 cast Ruinous Ultimatum
- P1 cast An Offer You Can't Refuse targeting [Destroy all nonland permanents your opponents control.]
- attack: P3 assigned Edgar Markov to attack P1.
- P3 triggered Edgar Markov
- attack: P1 assigned Teval, the Balanced Scale to block Edgar Markov.
- left battlefield: Teval, the Balanced Scale was put into Graveyard from Battlefield.

## Turn 36 (OUR TURN, round 9) | life: P1 2, P2 35, P3 43, US 20
Our hand: Invasion of Innistrad, Dalek Drone, The Death of Gwen Stacy, Survival of the Fittest
Our graveyard (0): 
Board P1: 13 lands; no nonland permanents
Board P2: 9 lands; Avacyn, Angel of Hope 8/8
Board P3: 7 lands; Edgar Markov 6/6 {[P1P1 x 2]} (tapped 1), Treasure Token [token] x2
Board US: 5 lands; Gray Merchant of Asphodel 2/4
MEMO (start of our turn):
THIS TURN: No land in hand. Go to combat first and attack P1 with Gray Merchant. P1 has no creatures, so P1 drops from 4 to 2. In main 2, cast Dalek Drone (all 5 lands) and target Edgar Markov: Edgar dies and P3 loses 3. We have no mana on opponents' turns. Never block with the Drone and never chump-block.

TARGET: Kill P1 next turn. Then land Muldrotha with Drone, Merchant and Gwen Stacy recurring. Survival of the Fittest finds Massacre Wurm, Gravebreaker Lamia and Syr Konrad.

WIN PATH: Next turn, attack P1 (2 life) with Drone (3/3 flying, menace) and Merchant. Either one connecting is lethal. Menace means P1 needs two flying or reach blockers to stop the Drone. If P1 has two or more such blockers, cast Gwen Stacy (3) first; chapter I kills one, and the Drone becomes unblockable. Then grind P3 and P2 with Merchant drains.

THREATS & ANSWERS: 1) P1 at 2 life: Teval via Command Beacon, Scarab God, or Living Death. Gwen Stacy chapter I kills a blocker. 2) Avacyn: she is indestructible, so only Invasion's -13/-13 kills her. Save Invasion for her or for P3's Vito. 3) P3 recasting Edgar (8 mana, and P3 has 9 with treasures): Gwen Stacy or a Drone recast. Don't let our creatures die into P3's drain triggers.

HOLD: Invasion, Gwen Stacy and Survival. Next turn, keep Invasion (4) unless it is needed to clear a blocker for lethal.

REPLAN IF: The Drone is removed; then Merchant alone must connect, so clear its blocker. Also replan if P1 gains life, gets two or more flying blockers, or casts Living Death.
- US cast Dalek Drone
- US triggered Dalek Drone targeting [Edgar Markov]
- left battlefield: Edgar Markov was put into Graveyard from Battlefield.
- attack: US assigned Gray Merchant of Asphodel to attack P1.

## Turn 37 (P1, round 10)
- P1 cast Teval, the Balanced Scale
- P1 cast Kishla Skimmer

## Turn 38 (P2, round 10) | life: P1 2, P2 37, P3 43, US 20
- P2 cast Angel of Vitality
- P2 triggered Seraph Sanctuary
- attack: P2 assigned Avacyn, Angel of Hope to attack P1.
- attack: P1 assigned Kishla Skimmer to block Avacyn, Angel of Hope.
- left battlefield: Kishla Skimmer was put into Graveyard from Battlefield.
- P2 cast Vanquisher's Banner

## Turn 39 (P3, round 10)
- P3 cast Edgar Markov

## Turn 40 (OUR TURN, round 10) | life: P1 -1, P2 37, P3 43, US 20
Our hand: Invasion of Innistrad, The Death of Gwen Stacy, Survival of the Fittest, Counterspell
Our graveyard (0): 
Board P1: 14 lands; Teval, the Balanced Scale 4/4
Board P2: 10 lands; Avacyn, Angel of Hope 9/9, Angel of Vitality 5/5, Vanquisher's Banner
Board P3: 7 lands; Treasure Token [token], Edgar Markov 4/4
Board US: 5 lands; Gray Merchant of Asphodel 2/4, Dalek Drone 3/3
MEMO (start of our turn):
THIS TURN: No land in hand. Cast nothing before combat and keep all 5 lands open. Attack P1 (2 life) with Dalek Drone and Gray Merchant. Teval is P1's only creature, and menace means Teval alone cannot block the Drone. If P1 removes, tricks or flashes a blocker before blocks, respond with Invasion of Innistrad (4) on Teval so the Merchant also connects. If Teval blocks the Merchant, let it die; Muldrotha recasts it later. In main 2, cast nothing. Keep 4 open, including Drowned Catacomb. On P2's turn, flash Invasion on Avacyn when she attacks, or at P2's end step.

TARGET: P1 dead. Avacyn gone, so Angel of Vitality becomes killable. Muldrotha (6 mana; we need a 6th source) recurring the Drone, Merchant and Gwen Stacy. Survival of the Fittest then fetches Massacre Wurm, Syr Konrad and Kokusho.

WIN PATH: Remove P1 today. Then Merchant and Drone drains plus flying beats grind P2 (37) and P3 (43) over about 4 turns. P2's fliers (14 power) can kill us in 2 turns if unchecked.

THREATS & ANSWERS: 1) Avacyn, indestructible: only Invasion's -13/-13 kills her, so Invasion is earmarked for her. 2) Angel of Vitality: Gwen Stacy after Avacyn is gone. 3) P3's Edgar and Vampires: a Drone recast or Massacre Wurm. Never chump-block.

HOLD: Invasion with 4 lands open. Gwen Stacy for next turn. Counterspell is uncastable because we have only one blue source. Survival waits until we have a creature card to discard.

REPLAN IF: P1 survives combat or gains life, Invasion gets countered, or P2 wipes the board.
MEMO (executor escalation: we lost: Gray Merchant of Asphodel):
THIS TURN: Main 2, no land in hand. Cast nothing now and keep all 5 lands open. On P2's turn, flash Invasion of Innistrad (4) on Avacyn at P2's beginning of combat. If P2 casts Akroma's Will or pumps, respond with Invasion on Avacyn then. -13/-13 kills her through indestructible. If Giada lands and Avacyn is already dead, Giada becomes the target. Counterspell is uncastable, since Drowned Catacomb is our only blue source. Take P3's Edgar hit; Drone is tapped anyway.

TARGET: Avacyn dead, then Angel of Vitality and Giada dead, P3 kept free of Vampires. Muldrotha needs a 6th land to recur Merchant, Drone and Gwen Stacy. Survival of the Fittest then fetches Massacre Wurm, Kokusho and Syr Konrad.

WIN PATH: P1 is gone. Grind P2 (37) and P3 (43) with Merchant and Drone drains, then Kokusho. Our clock is slow, about 5+ turns. Theirs: Avacyn 9 + Vitality 5 + Edgar 5 is 19 a turn, and we're at 20. Killing Avacyn is survival, not optional.

THREATS & ANSWERS: 1) Avacyn: Invasion only. 2) Angel of Vitality or Giada: Gwen Stacy next turn (3), after Avacyn is gone. 3) Edgar and Vampires: Drone recast or Massacre Wurm later. Never chump-block. Never gain P2 life.

HOLD: Invasion and 4 lands for P2's turn. Next turn with 5 lands: Gwen Stacy (3) on Vitality, then Survival (2). If we draw a land, still prefer this over Muldrotha unless we have 8+ mana.

REPLAN IF: Invasion is fizzled (Teferi's Protection), a Flawless Maneuver-style trick saves Avacyn, P2 wipes, or our life falls to 10 or below before our turn.
PILOT OVERRULED FORGE (attack, COMBAT_DECLARE_ATTACKERS): chose [attack P1 (2 life)] instead of Forge's [don't attack with it]
PILOT OVERRULED FORGE (attack, COMBAT_DECLARE_ATTACKERS): chose [attack P1 (2 life)] instead of Forge's [don't attack with it]
ESCALATION (p=0.86): we lost: Gray Merchant of Asphodel
PILOT OVERRULED FORGE (action, MAIN2): chose [Take no further action this phase: hold remaining mana and cards (this skips o0, the play ] instead of Forge's [cast The Death of Gwen Stacy (from Hand): The Death of Gwen Stacy]
- attack: US assigned Gray Merchant of Asphodel and Dalek Drone to attack P1.
- attack: P1 assigned Teval, the Balanced Scale to block Gray Merchant of Asphodel.
- left battlefield: Gray Merchant of Asphodel was put into Graveyard from Battlefield.

## Turn 41 (P2, round 11) | life: P1 -1, P2 41, P3 29, US 20
- attack: P2 assigned Angel of Vitality and Avacyn, Angel of Hope to attack P3.
- P2 cast Giada, Font of Hope
- P2 triggered Vanquisher's Banner
- P2 triggered Seraph Sanctuary
- P2 cast Exemplar of Light
- P2 triggered Vanquisher's Banner
- P2 triggered Seraph Sanctuary
- P2 triggered Exemplar of Light
- P2 triggered Exemplar of Light

## Turn 42 (P3, round 11)
MEMO (executor escalation: P3: life 43→29 (-14); P3: nonland permanents 2→6 (+4); P3: creatures 1→5 (+4)):
THIS TURN: Now, during P3's turn: hold. At P3's END STEP, flash Invasion of Innistrad (4 mana) with -13/-13 on Avacyn. P2 is fully tapped out, so the window is safe. Pick P3 to protect the battle. Take P3's attack; Drone is tapped. Our turn: cast The Death of Gwen Stacy (3) with chapter I destroying Exemplar of Light, then Survival of the Fittest (2). If we draw a blue land (Watery Grave, Underground Sea, Darkslick Shores and so on), skip Survival: cast Gwen (3) and hold UU Counterspell for Akroma's Will or a wipe on P2's turn.

TARGET: Avacyn and Exemplar dead, then Angel of Vitality and Giada. Sixth land, then Muldrotha to recast Gray Merchant, Drone and Gwen Stacy. Survival fetches Massacre Wurm (vs Vampire tokens), Kokusho and Syr Konrad.

WIN PATH: Grind with Muldrotha recurring Merchant and Drone drains, then Kokusho. Slow, 5+ turns. P2's flyers are the fastest clock, so they die first.

THREATS & ANSWERS: 1) Avacyn: Invasion now. 2) Exemplar 8/8: Gwen next turn. 3) Vitality and Giada (8 flying): untapped Drone blocks Giada on P2's turn; trading is fine there. 4) Edgar and Vampires: Drone recast or Massacre Wurm later. Never chump P3. Never gain P2 life.

HOLD: Counterspell until we have two blue sources.

REPLAN IF: Our life is 10 or below after P3's combat (then Gwen hits Vitality or Exemplar based on who can kill us), Avacyn survives Invasion, P3 reveals Vito or Exquisite Blood, or P2 wipes.
ESCALATION (p=0.61): P3: life 43→29 (-14); P3: nonland permanents 2→6 (+4); P3: creatures 1→5 (+4)
PILOT OVERRULED FORGE (action, END_OF_TURN): chose [cast Invasion of Innistrad (from Hand): Invasion of Innistrad [Forge's heuristic AI would ] instead of Forge's [Do nothing now; let it resolve / let the turn pass]
PILOT OVERRULED FORGE (trigger-target, END_OF_TURN): chose [Avacyn, Angel of Hope [P2, 9/9]] instead of Forge's [Vampire Token [P3, 1/1, token]]
- P3 cast Yahenni, Undying Partisan
- P3 triggered Edgar Markov
- P3 cast Forerunner of the Legion
- P3 triggered Edgar Markov
- P3 triggered Forerunner of the Legion
- US cast Invasion of Innistrad
- US triggered Invasion of Innistrad targeting [Avacyn, Angel of Hope]
- left battlefield: Avacyn, Angel of Hope was put into Graveyard from Battlefield.
- P3 triggered Yahenni, Undying Partisan

## Turn 43 (OUR TURN, round 11)
Our hand: The Death of Gwen Stacy, Survival of the Fittest, Counterspell, Sakura-Tribe Elder
Our graveyard (1): Gray Merchant of Asphodel
Board P2: 11 lands; Angel of Vitality 5/5 (tapped 1), Vanquisher's Banner, Giada, Font of Hope 3/3, Exemplar of Light 8/8 {[P1P1 x 4]}
Board P3: 7 lands; Treasure Token [token], Edgar Markov 4/4, Vampire Token 1/1 [token] x2, Yahenni, Undying Partisan 3/3 {[P1P1]}, Forerunner of the Legion 2/2
Board US: 5 lands; Dalek Drone 3/3, Invasion of Innistrad {[DEFENSE x 5]}
MEMO (start of our turn):
THIS TURN: No land in hand, so there is no land drop. 1) Cast The Death of Gwen Stacy (3 mana). Chapter I destroys Exemplar of Light, the biggest flyer. 2) Cast Sakura-Tribe Elder (2 mana). Keep it as a ground blocker. When it blocks Edgar or the biggest attacker from P3, sacrifice it before damage and fetch a basic Island. If it isn't needed, sacrifice it at P3's end step for an Island. Keep Dalek Drone home and untapped: don't attack the battle or anyone.

TARGET: Next turn, 6+ lands (with the Island) to cast Muldrotha (6), and two blue sources so Counterspell is live. Then recast Gray Merchant from the graveyard. Survival of the Fittest fetches Massacre Wurm, Kokusho and Syr Konrad. Claws of Gix lets Drone and Gwen loop.

WIN PATH: Muldrotha recurs Merchant (drains 5-7 per cast), then Kokusho and Konrad. This takes 5+ turns. P2's flyers are the fastest clock.

THREATS & ANSWERS: 1) P2's flyers (Angel of Vitality 5/5 and Giada 3/3 after Exemplar dies). Drone blocks Giada; trading is fine. Akroma's Will could deal about 16 and we have no answer yet. 2) P3's wide board (Edgar, Yahenni, tokens): Massacre Wurm later via Survival. Never chump P3 except with Elder and its sacrifice. 3) Vito or Exquisite Blood: Counterspell once UU is up. Never gain P2 life. Gwen chapter III: target opponents' graveyards only, never ours.

HOLD: Counterspell (UU not available until next turn). Survival waits for spare mana next turn.

REPLAN IF: We drop to 10 or below, Exemplar survives (Flawless Maneuver), P2 wipes, or Vito or Exquisite Blood appears.
PILOT OVERRULED FORGE (action, MAIN1): chose [cast The Death of Gwen Stacy (from Hand): The Death of Gwen Stacy [Forge's heuristic AI wo] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Sakura-Tribe Elder (from Hand): Sakura-Tribe Elder - Creature 1 / 1 [Forge's heuristi] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (attack, COMBAT_DECLARE_ATTACKERS): chose [don't attack with it] instead of Forge's [attack Invasion of Innistrad [ours]]
- US cast The Death of Gwen Stacy
- US triggered The Death of Gwen Stacy targeting [Exemplar of Light]
- P2 cast Flawless Maneuver
- US cast Sakura-Tribe Elder
- left battlefield: Sakura-Tribe Elder was put into Graveyard from Battlefield.
- US activated Sakura-Tribe Elder
- P3 triggered Yahenni, Undying Partisan

## Turn 44 (P2, round 11) | life: P1 -1, P2 62, P3 12, US 20
- P2 triggered Emeria, the Sky Ruin targeting [Avacyn, Angel of Hope]
- P2 triggered Seraph Sanctuary
- P2 triggered Exemplar of Light
- P2 triggered Exemplar of Light
- attack: P2 assigned Exemplar of Light, Angel of Vitality and Giada, Font of Hope to attack P3.
- P2 cast Angel of Destiny
- P2 triggered Vanquisher's Banner
- P2 triggered Seraph Sanctuary
- P2 triggered Exemplar of Light
- P2 cast Righteous Valkyrie
- P2 triggered Vanquisher's Banner
- P2 triggered Seraph Sanctuary
- P2 triggered Exemplar of Light
- P2 cast Metropolis Reformer
- P2 triggered Vanquisher's Banner
- P2 triggered Seraph Sanctuary
- P2 triggered Righteous Valkyrie
- P2 triggered Exemplar of Light
- P2 triggered Exemplar of Light
- P2 triggered Angel of Destiny

## Turn 45 (P3, round 12)
- P3 cast Bloodthirsty Conqueror
- P3 triggered Edgar Markov
- P3 triggered Forerunner of the Legion targeting [Edgar Markov]
- P3 triggered Forerunner of the Legion targeting [Edgar Markov]

## Turn 46 (OUR TURN, round 12)
Our hand: Survival of the Fittest, Counterspell, Forest
Our graveyard (2): Gray Merchant of Asphodel, Sakura-Tribe Elder
Board P2: 12 lands; Angel of Vitality 7/7 (tapped 1), Vanquisher's Banner, Giada, Font of Hope 5/5, Exemplar of Light 15/15 {[P1P1 x 9]} (tapped 1), Avacyn, Angel of Hope 14/14 {[P1P1 x 3]}, Angel of Destiny 9/13 {[P1P1 x 4]}, Righteous Valkyrie 10/12 {[P1P1 x 5]}, Metropolis Reformer 11/12 {[P1P1 x 6]}
Board P3: 7 lands; Treasure Token [token], Edgar Markov 4/4, Vampire Token 1/1 [token] x3, Yahenni, Undying Partisan 4/4 {[P1P1 x 2]}, Forerunner of the Legion 2/2, Bloodthirsty Conqueror 5/5
Board US: 6 lands; Dalek Drone 3/3, Invasion of Innistrad {[DEFENSE x 5]}, The Death of Gwen Stacy {[LORE x 2]}
MEMO (start of our turn):
THIS TURN: 1) Gwen chapter II: discard Forest; do not take 3 (P3's Bloodthirsty Conqueror heals them). 2) Cast Muldrotha with all 6 lands (tax 0; Island for U). 3) Play Forest from our graveyard via Muldrotha's land lane. Nothing else fits. Keep Dalek Drone and Muldrotha home. On P2's turn, Drone blocks Angel of Destiny (18 double-strike damage), otherwise Exemplar. Never block Metropolis Reformer. Muldrotha blocks Edgar.

TARGET: Hostage Taker (via Survival, once a creature card is in hand) exiles Avacyn, which ends indestructible. Then Toxic Deluge (Demonic Tutor) or Pernicious Deed breaks P2's board. Kill Bloodthirsty Conqueror with Drone recast or Plaguecrafter.

WIN PATH: Next turn, pay Gray Merchant (5) from five non-blue lands, keeping Island and Drowned Catacomb for Counterspell. Devotion is 7 after Gwen leaves. First hit P3 with Drone (menace flyer, effectively unblockable). Cast Merchant only if P3 is at 7 or less, or Conqueror is dead. P2 wins soonest, possibly next turn.

THREATS & ANSWERS: 1) Angel of Destiny: P2 is at 55 or more, so any player it attacks loses at P2's end step. Answer: Hostage Taker, Deluge, or drain P2 below 55. 2) Avacyn: Hostage Taker. 3) Conqueror: Drone recast. 4) Vito or Exquisite Blood: Counterspell. Never make P2 gain life.

HOLD: Counterspell (live from next turn, UU) for Vito, Exquisite Blood, Akroma's Will or a wipe. Hold Survival until we have a creature card to discard.

REPLAN IF: Muldrotha is removed, we are at 10 or below, Angel of Destiny attacks us, Avacyn leaves, or P3 dies.
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Muldrotha, the Gravetide (from Command): Muldrotha, the Gravetide - Creature 6 / 6 [F] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN1): chose [play land Forest (from Graveyard): Play land by Muldrotha, the Gravetide (403) (Land)] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
- US triggered The Death of Gwen Stacy
- US cast Muldrotha, the Gravetide

## Turn 47 (P2, round 12) | life: P1 -1, P2 133, P3 -44, US 20
- attack: P2 assigned Exemplar of Light, Avacyn, Angel of Hope, Metropolis Reformer, Righteous Valkyrie, Angel of Destiny, Angel of Vitality and Giada, Font of Hope to attack P3.
- attack: P3 assigned Bloodthirsty Conqueror to block Exemplar of Light.
- P2 triggered Angel of Destiny
- P2 triggered Exemplar of Light
- P2 triggered Exemplar of Light
- P2 triggered Angel of Destiny
- P2 triggered Angel of Destiny
- P2 triggered Angel of Destiny
- P2 triggered Angel of Destiny
- P2 triggered Angel of Destiny
- P2 triggered Angel of Destiny
- P2 triggered Exemplar of Light
- P2 triggered Exemplar of Light
- P2 triggered Exemplar of Light
- P2 triggered Exemplar of Light
- P2 triggered Exemplar of Light
- P2 triggered Exemplar of Light
- P2 cast Urza's Incubator
- P2 cast Pearl Medallion
- P2 cast Archaeomancer's Map
- P2 triggered Archaeomancer's Map
- P2 activated War Room
- P2 cast Folk Hero
- P2 triggered Angel of Destiny

## Turn 48 (OUR TURN, round 12) | life: P1 -1, P2 126, P3 -44, US 26
Our hand: Survival of the Fittest, Counterspell, Marsh Flats
Our graveyard (3): Gray Merchant of Asphodel, Sakura-Tribe Elder, The Death of Gwen Stacy
Board P2: 13 lands; Angel of Vitality 7/7 (tapped 1), Vanquisher's Banner, Giada, Font of Hope 5/5, Exemplar of Light 22/22 {[P1P1 x 16]} (tapped 1), Avacyn, Angel of Hope 14/14 {[P1P1 x 3]}, Angel of Destiny 9/13 {[P1P1 x 4]} (tapped 1), Righteous Valkyrie 10/12 {[P1P1 x 5]} (tapped 1), Metropolis Reformer 11/12 {[P1P1 x 6]}, Urza's Incubator, Pearl Medallion, Archaeomancer's Map, Folk Hero
Board US: 7 lands; Dalek Drone 3/3, Invasion of Innistrad {[DEFENSE x 5]}, Muldrotha, the Gravetide 6/6
MEMO (start of our turn):
THIS TURN: 1) Play Marsh Flats and crack it (1 life) for Underground Sea. 2) Cast Gray Merchant from the graveyard (creature lane) using Swamp, Bayou, Woodland Cemetery, Overgrown Tomb and Forest. Devotion is 7 (Muldrotha 1, Drone 2, Invasion 2, Merchant 2), so P2 goes to 126 and we go to about 26. 3) Keep Island, Drowned Catacomb and Underground Sea untapped for Counterspell. Do not attack; Avacyn and Reformer are untapped. On P2's turn, Drone blocks Exemplar (22); if Exemplar doesn't attack, it blocks the biggest non-Reformer attacker. Never block Metropolis Reformer. Muldrotha cannot block flyers.

TARGET: Avacyn gone (Hostage Taker), then Toxic Deluge or Pernicious Deed. Survival needs a creature card in hand to start fetching.

WIN PATH: None realistic this turn or next. P2 is at 126+ with Angel of Destiny active, and any attack from it kills us at their end step. We are playing for P2 holding back attackers.

THREATS & ANSWERS: 1) Angel of Destiny. Its -13/-13 answer (Invasion) is stuck on the battlefield, so we have no answer. 2) Avacyn makes the rest indestructible, so Drone and Gwen can't kill anything. 3) Akroma's Will or a wipe: Counterspell.

HOLD: Counterspell (UU) for Akroma's Will, Farewell or a wipe. Hold Survival until we have a creature card to discard. Skip Gwen: its chapter I is dead into indestructible. Skip Sakura-Tribe Elder: we need the UU.

REPLAN IF: we survive P2's turn, Avacyn or Destiny leaves, we draw Hostage Taker, Deluge or a tutor, or P2 casts a wipe.
PILOT OVERRULED FORGE (action, MAIN1): chose [play land Marsh Flats (from Hand): Play land] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (search, MAIN1): chose [Underground Sea — Land - Island Swamp — ({T}: Add {U} or {B}.)] instead of Forge's [Zagoth Triome — Land - Swamp Forest Island — ({T}: Add {B}, {G}, or {U}.) Zagoth Triome en]
PILOT OVERRULED FORGE (action, MAIN2): chose [Take no further action this phase: hold remaining mana and cards (this skips o0, the play ] instead of Forge's [cast Survival of the Fittest (from Hand): Survival of the Fittest]
- US triggered The Death of Gwen Stacy targeting []
- left battlefield: The Death of Gwen Stacy was put into Graveyard from Battlefield.
- left battlefield: Marsh Flats was put into Graveyard from Battlefield.
- US activated Marsh Flats
- US cast Gray Merchant of Asphodel
- US triggered Gray Merchant of Asphodel

## Turn 49 (P2, round 13) | life: P1 -1, P2 156, P3 -44, US -55
- P2 cast Serra's Emissary
- P2 triggered Vanquisher's Banner
- P2 triggered Giada, Font of Hope
- P2 triggered Seraph Sanctuary
- P2 triggered Righteous Valkyrie
- P2 triggered Exemplar of Light
- P2 triggered Exemplar of Light
- P2 triggered Exemplar of Light
- P2 cast Lightning Greaves
- P2 activated Lightning Greaves targeting [Exemplar of Light]
- attack: P2 assigned Exemplar of Light, Avacyn, Angel of Hope, Metropolis Reformer, Righteous Valkyrie, Angel of Destiny, Angel of Vitality and Giada, Font of Hope to attack US.
- P2 triggered Angel of Destiny
- P2 triggered Exemplar of Light
- Game Outcome: P1 has lost because life total reached 0
- Game Outcome: P2 has won because all opponents have lost
- Game Outcome: P3 has lost because life total reached 0
- Game Outcome: US has lost because life total reached 0
Damage to US this turn: Angel of Destiny (combat) 18, Exemplar of Light (combat) 25, Avacyn, Angel of Hope (combat) 14, Metropolis Reformer (combat) 11, Righteous Valkyrie (combat) 10, Angel of Vitality (combat) 7, Giada, Font of Hope (combat) 5