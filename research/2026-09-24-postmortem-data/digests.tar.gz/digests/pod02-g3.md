# pod02-g3: we are P4; opponents P1 Teval, the Balanced Scale, P2 Hearthhull, the Worldseed, P3 Giada, Font of Hope
Result: Turn 18; P1 has lost because life total reached 0; P2 has lost because life total reached 0; P3 has won because all opponents have lost; US has lost because life total reached 0

## Turn 1 (P1, round 1)

## Turn 2 (P2, round 1)

## Turn 3 (P3, round 1)
- P3 cast Sol Ring

## Turn 4 (OUR TURN, round 1)
Our hand: Mulldrifter, Woodland Cemetery, Darkslick Shores, Soul-Guide Lantern, Dalek Drone, Tropical Island, Vrock, Waterlogged Grove
Our graveyard (0): 
Board P1: 1 lands; no nonland permanents
Board P2: 1 lands; no nonland permanents
Board P3: 1 lands; Sol Ring
Board US: 0 lands; no nonland permanents
MEMO (start of our turn):
THIS TURN: Play Darkslick Shores; it enters untapped only while we control 2 or fewer other lands, so it goes first. Tap it for Soul-Guide Lantern ({1}). Its ETB has no target now and simply fizzles. That is fine: we want Lantern on board early as instant-speed yard exile against P1's self-mill. Nothing else is castable.

TARGET: Land order: T2 Tropical Island, T3 Woodland Cemetery (untapped, since Trop is a Forest), T4 Waterlogged Grove. T3: evoke Mulldrifter ({2}{U}) to draw 2 and stock the creature lane. T5: Dalek Drone ({3}{B}{B}) on the best opposing creature. T6: Muldrotha, then recur Mulldrifter and Drone each turn. Missing: ramp (Sol Ring, Arcane Signet, Farseek, Sakura-Tribe Elder), Executioner's Capsule, Seal of Primordium, Claws of Gix.

WIN PATH: Recurring Drone and Capsule kills, then Vrock drains 3 from each opponent each end step once a sac engine runs, plus Gray Merchant. The table's fastest clock is P2/P3 at turns 6-8, so our target is to lock the board by turn 8.

THREATS & ANSWERS: 1) P3 Giada (ahead with Sol Ring): first Dalek Drone target, or Archangel of Thune/Avacyn if they land. 2) P2 Hearthhull: Drone can't hit it (noncreature artifact); needs Seal of Primordium or Assassin's Trophy. 3) P1 Living Death/Reanimate: answer with Lantern.

HOLD: Keep Lantern. Tap-sacrifice it to exile all opponents' graveyards only in response to Living Death, Reanimate, or a large P1 yard. Never sacrifice it for the draw. Don't cast Vrock before a sac engine is running.

REPLAN IF: P3 lands Giada plus angels fast (race Drone out), P1's yard reaches 10+ cards, or we draw ramp (cast Muldrotha a turn early).
PILOT OVERRULED FORGE (action, MAIN1): chose [play land Darkslick Shores (from Hand): Play land] instead of Forge's [play land Tropical Island (from Hand): Play land]

## Turn 5 (P1, round 2)
- P1 cast Arcane Signet

## Turn 6 (P2, round 2) | life: P2 38
- P2 cast Farseek

## Turn 7 (P3, round 2)
- P3 cast Giada, Font of Hope

## Turn 8 (OUR TURN, round 2)
Our hand: Mulldrifter, Woodland Cemetery, Soul-Guide Lantern, Dalek Drone, Tropical Island, Vrock, Waterlogged Grove, Command Tower
Our graveyard (0): 
Board P1: 2 lands; Arcane Signet
Board P2: 3 lands; no nonland permanents
Board P3: 2 lands; Sol Ring (tapped 1), Giada, Font of Hope 2/2
Board US: 1 lands; no nonland permanents
MEMO (start of our turn):
THIS TURN: 1) Play Tropical Island. It enters untapped, and it counts as a Forest for Woodland Cemetery next turn. 2) Tap Darkslick Shores for Soul-Guide Lantern ({1}). Its ETB exiles Farseek from P2's graveyard; that is minor, but otherwise the mana is wasted. 3) Leave Tropical Island up; there is nothing else to use it on. Pass.

TARGET: Land drops in order: T3 Woodland Cemetery (untapped), T4 Waterlogged Grove, T5 Command Tower. T3: evoke Mulldrifter ({2}{U}) to draw 2 and stock the creature lane. T4: cast whatever we drew (ramp first). T5: Dalek Drone ({3}{B}{B}) on Giada or the biggest angel. T6+: Muldrotha ({3}{B}{G}{U}), then recur Mulldrifter and Drone. Missing: Sol Ring, Arcane Signet, Farseek, Seal of Primordium, Executioner's Capsule, Claws of Gix, and a 6th land.

WIN PATH: Recur Drone kills (3 drain each), then Vrock drains 3 from each opponent per end step once we sacrifice something every turn. Target lock by turn 8, close by turn 11. P2 and P3 are the fastest clocks (turns 6-8).

THREATS & ANSWERS: 1) P3 Giada with Sol Ring: Dalek Drone on T5, or earlier if we draw ramp. 2) P2 Hearthhull, a noncreature artifact: Drone can't hit it; it needs Seal of Primordium or Assassin's Trophy. 3) P1 Living Death or Reanimate: answer with Lantern's sacrifice.

HOLD: Keep Lantern on board. Tap and sacrifice it to exile all opponents' graveyards only in response to Living Death or Reanimate, or once P1's yard reaches 8+ cards. Never sacrifice it to draw. Hold Vrock until a sacrifice engine is running. Don't sacrifice Waterlogged Grove; we need every land.

REPLAN IF: P3 lands an angel with counters or Archangel of Thune (Drone it first); P2 casts Hearthhull (search for Seal or Trophy); or we draw ramp (Muldrotha a turn early).
PILOT OVERRULED FORGE (action, MAIN2): chose [Take no further action this phase: hold remaining mana and cards (this skips o0, the play ] instead of Forge's [activate Soul-Guide Lantern (from Battlefield): {T}, Sacrifice Soul-Guide Lantern: Exile e]
PILOT OVERRULED FORGE (action, END_OF_TURN): chose [Do nothing now; let it resolve / let the turn pass (this skips o0, the play Forge's AI wou] instead of Forge's [activate Soul-Guide Lantern (from Battlefield): {T}, Sacrifice Soul-Guide Lantern: Exile e]
- US cast Soul-Guide Lantern
- US triggered Soul-Guide Lantern targeting [Farseek]

## Turn 9 (P1, round 3)
PILOT OVERRULED FORGE (action, UPKEEP): chose [Do nothing now; let it resolve / let the turn pass (this skips o0, the play Forge's AI wou] instead of Forge's [activate Soul-Guide Lantern (from Battlefield): {T}, Sacrifice Soul-Guide Lantern: Exile e]
PILOT OVERRULED FORGE (action, DRAW): chose [Do nothing now; let it resolve / let the turn pass (this skips o0, the play Forge's AI wou] instead of Forge's [activate Soul-Guide Lantern (from Battlefield): {T}, Sacrifice Soul-Guide Lantern: Exile e]
PILOT OVERRULED FORGE (action, MAIN1): chose [Do nothing now; let it resolve / let the turn pass (this skips o0, the play Forge's AI wou] instead of Forge's [activate Soul-Guide Lantern (from Battlefield): {T}, Sacrifice Soul-Guide Lantern: Exile e]
PILOT OVERRULED FORGE (action, COMBAT_DECLARE_ATTACKERS): chose [Do nothing now; let it resolve / let the turn pass (this skips o0, the play Forge's AI wou] instead of Forge's [activate Soul-Guide Lantern (from Battlefield): {T}, Sacrifice Soul-Guide Lantern: Exile e]
PILOT OVERRULED FORGE (action, COMBAT_END): chose [Do nothing now; let it resolve / let the turn pass (this skips o0, the play Forge's AI wou] instead of Forge's [activate Soul-Guide Lantern (from Battlefield): {T}, Sacrifice Soul-Guide Lantern: Exile e]
PILOT OVERRULED FORGE (action, MAIN2): chose [Do nothing now; let it resolve / let the turn pass (this skips o0, the play Forge's AI wou] instead of Forge's [activate Soul-Guide Lantern (from Battlefield): {T}, Sacrifice Soul-Guide Lantern: Exile e]
PILOT OVERRULED FORGE (action, END_OF_TURN): chose [Do nothing now; let it resolve / let the turn pass (this skips o0, the play Forge's AI wou] instead of Forge's [activate Soul-Guide Lantern (from Battlefield): {T}, Sacrifice Soul-Guide Lantern: Exile e]
- P1 cast Teval, the Balanced Scale

## Turn 10 (P2, round 3)
PILOT OVERRULED FORGE (action, UPKEEP): chose [Do nothing now; let it resolve / let the turn pass (this skips o0, the play Forge's AI wou] instead of Forge's [activate Soul-Guide Lantern (from Battlefield): {T}, Sacrifice Soul-Guide Lantern: Exile e]
PILOT OVERRULED FORGE (action, DRAW): chose [Do nothing now; let it resolve / let the turn pass (this skips o0, the play Forge's AI wou] instead of Forge's [activate Soul-Guide Lantern (from Battlefield): {T}, Sacrifice Soul-Guide Lantern: Exile e]
PILOT OVERRULED FORGE (action, MAIN1): chose [Do nothing now; let it resolve / let the turn pass (this skips o0, the play Forge's AI wou] instead of Forge's [activate Soul-Guide Lantern (from Battlefield): {T}, Sacrifice Soul-Guide Lantern: Exile e]
PILOT OVERRULED FORGE (action, COMBAT_BEGIN): chose [Do nothing now; let it resolve / let the turn pass (this skips o0, the play Forge's AI wou] instead of Forge's [activate Soul-Guide Lantern (from Battlefield): {T}, Sacrifice Soul-Guide Lantern: Exile e]
PILOT OVERRULED FORGE (action, COMBAT_DECLARE_ATTACKERS): chose [Do nothing now; let it resolve / let the turn pass (this skips o0, the play Forge's AI wou] instead of Forge's [activate Soul-Guide Lantern (from Battlefield): {T}, Sacrifice Soul-Guide Lantern: Exile e]
PILOT OVERRULED FORGE (action, MAIN2): chose [Do nothing now; let it resolve / let the turn pass (this skips o0, the play Forge's AI wou] instead of Forge's [activate Soul-Guide Lantern (from Battlefield): {T}, Sacrifice Soul-Guide Lantern: Exile e]
PILOT OVERRULED FORGE (action, END_OF_TURN): chose [Do nothing now; let it resolve / let the turn pass (this skips o0, the play Forge's AI wou] instead of Forge's [activate Soul-Guide Lantern (from Battlefield): {T}, Sacrifice Soul-Guide Lantern: Exile e]
- left battlefield: Swamp was put into Graveyard from Battlefield.
- P2 cast Harrow

## Turn 11 (P3, round 3)
PILOT OVERRULED FORGE (action, DRAW): chose [Do nothing now; let it resolve / let the turn pass (this skips o0, the play Forge's AI wou] instead of Forge's [activate Soul-Guide Lantern (from Battlefield): {T}, Sacrifice Soul-Guide Lantern: Exile e]
PILOT OVERRULED FORGE (action, MAIN1): chose [Do nothing now; let it resolve / let the turn pass (this skips o0, the play Forge's AI wou] instead of Forge's [activate Soul-Guide Lantern (from Battlefield): {T}, Sacrifice Soul-Guide Lantern: Exile e]
PILOT OVERRULED FORGE (action, MAIN1): chose [Do nothing now; let it resolve / let the turn pass (this skips o0, the play Forge's AI wou] instead of Forge's [activate Soul-Guide Lantern (from Battlefield): {T}, Sacrifice Soul-Guide Lantern: Exile e]
PILOT OVERRULED FORGE (action, COMBAT_BEGIN): chose [Do nothing now; let it resolve / let the turn pass (this skips o0, the play Forge's AI wou] instead of Forge's [activate Soul-Guide Lantern (from Battlefield): {T}, Sacrifice Soul-Guide Lantern: Exile e]
PILOT OVERRULED FORGE (action, COMBAT_END): chose [Do nothing now; let it resolve / let the turn pass (this skips o0, the play Forge's AI wou] instead of Forge's [activate Soul-Guide Lantern (from Battlefield): {T}, Sacrifice Soul-Guide Lantern: Exile e]
PILOT OVERRULED FORGE (action, END_OF_TURN): chose [Do nothing now; let it resolve / let the turn pass (this skips o0, the play Forge's AI wou] instead of Forge's [activate Soul-Guide Lantern (from Battlefield): {T}, Sacrifice Soul-Guide Lantern: Exile e]
- P3 cast Lyra Dawnbringer

## Turn 12 (OUR TURN, round 3)
Our hand: Mulldrifter, Woodland Cemetery, Dalek Drone, Vrock, Waterlogged Grove, Command Tower
Our graveyard (0): 
Board P1: 3 lands; Arcane Signet (tapped 1), Teval, the Balanced Scale 4/4
Board P2: 4 lands; no nonland permanents
Board P3: 3 lands; Sol Ring (tapped 1), Giada, Font of Hope 3/3 (tapped 1), Lyra Dawnbringer 6/6 {[P1P1]}
Board US: 2 lands; Soul-Guide Lantern
MEMO (start of our turn):
THIS TURN: 1) Play Woodland Cemetery. It enters untapped because Tropical Island is a Forest. 2) Evoke Mulldrifter ({2}{U}; take U from Darkslick Shores or Tropical Island) to draw 2 and put it in the graveyard for Muldrotha later. That uses all 3 mana. No instant-speed plays this round except Lantern.

TARGET: T4: play Waterlogged Grove and cast any ramp drawn (Sol Ring, Arcane Signet, Mind Stone, Talisman of Dominance, Farseek, Nature's Lore). T5: Command Tower, then Dalek Drone ({3}{B}{B}) on Lyra Dawnbringer. T6 (T5 with ramp): Muldrotha ({3}{B}{G}{U}), then evoke Mulldrifter from the graveyard every turn. Missing pieces: ramp, Executioner's Capsule, Seal of Primordium, Claws of Gix.

WIN PATH: Muldrotha plus Vrock. Evoking Mulldrifter from the graveyard each turn means a permanent left, so Vrock drains 3 from each opponent every end step. Recurred Dalek Drone drains 3 more. Close by around turn 10. P3 is the fastest clock (Lyra hits for 6 a turn).

THREATS & ANSWERS: 1) P3 Lyra 6/6 (lifelink anthem): first Dalek Drone. 2) P3 Giada: recurred Drone once Muldrotha is out, or Drone her first if an angel enters with counters. 3) P2 Hearthhull, a noncreature artifact: Seal of Primordium or Assassin's Trophy, not Drone. 4) P1 Living Death or Reanimate: Lantern's sacrifice.

HOLD: Soul-Guide Lantern. Sacrifice it only in response to Living Death or Reanimate, or once P1's graveyard reaches 8+. Never sacrifice it to draw. Hold Vrock until Muldrotha and a sacrifice loop are running. Never sacrifice Waterlogged Grove.

REPLAN IF: Mulldrifter draws Sol Ring or other ramp (Muldrotha a turn early); P3 casts Archangel of Thune or Avacyn (Drone that instead); Hearthhull lands (search for Seal of Primordium); an opponent casts a wipe.
PILOT OVERRULED FORGE (action, UPKEEP): chose [Do nothing now; let it resolve / let the turn pass (this skips o0, the play Forge's AI wou] instead of Forge's [activate Soul-Guide Lantern (from Battlefield): {T}, Sacrifice Soul-Guide Lantern: Exile e]
PILOT OVERRULED FORGE (action, MAIN1): chose [play land Woodland Cemetery (from Hand): Play land] instead of Forge's [play land Command Tower (from Hand): Play land]
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Mulldrifter (from Hand): Evoke {2}{U} (You may cast this spell for its evoke cost. If] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
- left battlefield: Soul-Guide Lantern was put into Graveyard from Battlefield.
- US activated Soul-Guide Lantern
- US cast Mulldrifter
- US triggered Mulldrifter
- US triggered Mulldrifter
- left battlefield: Mulldrifter was put into Graveyard from Battlefield.

## Turn 13 (P1, round 4)
- P1 cast The Scarab God

## Turn 14 (P2, round 4) | life: P2 37
- P2 cast Roiling Regrowth
- left battlefield: Swamp was put into Graveyard from Battlefield.
- left battlefield: Swamp was put into Graveyard from Battlefield.
- P2 cast Crop Rotation
- left battlefield: Bloodstained Mire was put into Graveyard from Battlefield.
- P2 activated Bloodstained Mire
- left battlefield: Fabled Passage was put into Graveyard from Battlefield.
- P2 activated Fabled Passage
- P2 cast Tear Asunder targeting [Arcane Signet] []
- left battlefield: Arcane Signet was put into Exile from Battlefield.

## Turn 15 (P3, round 4) | life: P1 34, P2 37, P3 46
- P3 cast Serra Paragon
- P3 triggered Path of Ancestry
- P3 cast Resplendent Angel
- attack: P3 assigned Lyra Dawnbringer to attack P1.
- P3 triggered Resplendent Angel

## Turn 16 (OUR TURN, round 4)
Our hand: Dalek Drone, Vrock, Waterlogged Grove, Command Tower, The Coming of Galactus, Swamp, Takenuma, Abandoned Mire, Massacre Wurm
Our graveyard (2): Soul-Guide Lantern, Mulldrifter
Board P1: 4 lands; Teval, the Balanced Scale 4/4, The Scarab God 5/5
Board P2: 6 lands; no nonland permanents
Board P3: 4 lands; Sol Ring (tapped 1), Giada, Font of Hope 3/3 (tapped 1), Lyra Dawnbringer 6/6 {[P1P1]} (tapped 1), Serra Paragon 6/7 {[P1P1 x 2]}, Resplendent Angel 7/7 {[P1P1 x 3]}, Angel Token 9/9 [token] {[P1P1 x 4]}
Board US: 3 lands; no nonland permanents
MEMO (start of our turn):
THIS TURN: 1) Play Command Tower. It enters untapped, giving 4 mana. 2) Pass holding all 4. At the end of P3's turn, channel Takenuma ({3}{B}, instant speed): mill 3, then return the best creature card from our graveyard. Priority: Hostage Taker > Shriekmaw > Baleful Strix > Plaguecrafter > Mulldrifter. Channel sooner only if we're about to lose the mana to a wipe.

TARGET: Next turn: play Swamp (5 lands) and cast Dalek Drone on Lyra. That kills the anthem and the lifelink that feeds Resplendent's tokens. Turn after: Grove (6 lands) and The Coming of Galactus on the biggest remaining Angel. Then Muldrotha ({3}{B}{G}{U}). Missing pieces: Toxic Deluge, Pernicious Deed, Hostage Taker, Demonic Tutor.

WIN PATH: Muldrotha recurs Drone and Mulldrifter while Vrock drains 3 from each opponent per end step, plus Galactus drains and a 16/16 flier. Our clock is roughly 6+ turns. P3 is fastest: 31 flying power now, so we may face lethal in 2 turns.

THREATS & ANSWERS: 1) P3 Lyra: Drone next turn. 2) P3 Angel token and Resplendent: Galactus chapter I, then a Deluge if we draw it. 3) P1 Scarab God steals creature cards from our graveyard, and killing it only returns it to hand. Answer it with Hostage Taker, or Lantern via Muldrotha. Don't leave fatties in our graveyard. 4) P2 Hearthhull, if cast: Galactus chapter I.

HOLD: Vrock until something of ours leaves each turn. Hold Massacre Wurm until Lyra is dead, when its -2/-2 kills Giada and tokens. Keep Grove; don't sacrifice it.

REPLAN IF: P3 wipes the board; a Deluge or Deed is milled or drawn; Scarab God takes something of ours; we drop below 25 life (Drone or Galactus becomes pure defence).
PILOT OVERRULED FORGE (action, MAIN2): chose [activate Takenuma, Abandoned Mire (from Hand): Channel — {3}{B}, Discard Takenuma, Abandon] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
- US activated Takenuma, Abandoned Mire

## Turn 17 (P1, round 5)
- P1 triggered The Scarab God
- P1 activated The Scarab God targeting [Spore Frog]

## Turn 18 (P2, round 5)
- P2 cast Moraug, Fury of Akoum

## Turn 19 (P3, round 5) | life: P1 6, P2 37, P3 78
- P3 cast Angel of Vitality
- attack: P3 assigned Resplendent Angel, Lyra Dawnbringer, Serra Paragon and Angel Token to attack P1.
- P3 cast The Book of Exalted Deeds
- P3 triggered Resplendent Angel
- P3 triggered The Book of Exalted Deeds

## Turn 20 (OUR TURN, round 5) | life: P1 6, P2 37, P3 75
Our hand: Dalek Drone, Vrock, Waterlogged Grove, The Coming of Galactus, Swamp, Massacre Wurm, Mulldrifter, Seal of Doom
Our graveyard (4): Soul-Guide Lantern, Takenuma, Abandoned Mire, Verdant Catacombs, Misty Rainforest
Board P1: 4 lands; Teval, the Balanced Scale 4/4, The Scarab God 5/5, Spore Frog 4/4 [token]
Board P2: 7 lands; Moraug, Fury of Akoum 6/6
Board P3: 5 lands; Sol Ring (tapped 1), Giada, Font of Hope 3/3, Lyra Dawnbringer 6/6 {[P1P1]} (tapped 1), Serra Paragon 6/7 {[P1P1 x 2]} (tapped 1), Resplendent Angel 7/7 {[P1P1 x 3]} (tapped 1), Angel Token 9/9 [token] {[P1P1 x 4]}, Angel of Vitality 10/10 {[P1P1 x 5]}, The Book of Exalted Deeds, Angel Token 10/10 [token] {[P1P1 x 6]}, Angel Token 12/12 [token] {[P1P1 x 7]}
Board US: 4 lands; no nonland permanents
MEMO (start of our turn):
THIS TURN: 1) Play Swamp (5 lands, 5 mana). 2) Cast Dalek Drone ({3}{B}{B}) targeting Lyra Dawnbringer. That strips the anthem and every Angel's lifelink, and P3 loses 3. Pass with 0 mana. If P3 attacks us, Drone chump-blocks the biggest attacker (about 11/11). Without Lyra that leaves roughly 39 damage against our 40 life, and P1's Scarab God upkeep drain comes first. If P3 attacks someone else, don't block.

TARGET: Next turn play Waterlogged Grove (6 lands). If we drew Pernicious Deed or Toxic Deluge, wipe P3's Angels. Otherwise cast Muldrotha ({3}{B}{G}{U}) to open the lanes: replay fetches, recast Lantern, evoke Mulldrifter every turn. Missing pieces: Pernicious Deed (X=5 clears every Angel, Book and Sol Ring), Toxic Deluge, Demonic Tutor.

WIN PATH: Vrock plus a sacrifice each turn drains 3 per opponent. P1 at 6 dies to 2 Vrock triggers. Galactus drains and its 16/16 finish P2 and P3 after a wipe. P3 can kill anyone next turn, so we're behind until Deed or Deluge lands.

THREATS & ANSWERS: 1) P3's Angel swarm (about 63 flying power): Drone now, Seal of Doom at instant speed later, Deed or Deluge. 2) Giada: Massacre Wurm's -2/-2 kills her once Lyra is dead. 3) P1 Scarab God steals creature cards from our graveyard. Recast Lantern via Muldrotha and pop it to exile their yard. 4) P2 Hearthhull, if cast: Galactus chapter I.

HOLD: Grove as next turn's land; don't sacrifice it. Hold Wurm, Vrock and Galactus until P3's swarm is handled or a wipe is in hand.

REPLAN IF: P3 wipes the board; we drop under 15 life; P1 fogs with Spore Frog; we draw Deed, Deluge or Demonic Tutor.
PILOT OVERRULED FORGE (action, MAIN1): chose [play land Swamp (from Hand): Play land] instead of Forge's [play land Waterlogged Grove (from Hand): Play land]
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Dalek Drone (from Hand): Dalek Drone - Creature 3 / 3 [Forge's heuristic AI would not] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (trigger-target, MAIN1): chose [Lyra Dawnbringer [P3, 6/6, tapped]] instead of Forge's [Angel Token [P3, 12/12, token]]
- US cast Dalek Drone
- US triggered Dalek Drone targeting [Lyra Dawnbringer]
- left battlefield: Lyra Dawnbringer was put into Graveyard from Battlefield.

## Turn 21 (P1, round 6) | life: P1 6, P2 36, P3 74, US 39
- P1 triggered The Scarab God
- P1 activated The Scarab God targeting [Lyra Dawnbringer]

## Turn 22 (P2, round 6)
- P2 cast Augur of Autumn
- P2 triggered Moraug, Fury of Akoum
- left battlefield: Terramorphic Expanse was put into Graveyard from Battlefield.
- P2 activated Terramorphic Expanse
- P2 triggered Moraug, Fury of Akoum
- P2 cast Hearthhull, the Worldseed
- P2 activated Hearthhull, the Worldseed
- P2 activated Hearthhull, the Worldseed
- P2 triggered Moraug, Fury of Akoum
- P2 triggered Moraug, Fury of Akoum

## Turn 23 (P3, round 6)
- attack: P3 assigned Angel of Vitality, Angel Token, Resplendent Angel, Serra Paragon, Giada, Font of Hope, Angel Token and Angel Token to attack P1.
- P3 activated Resplendent Angel
- P3 cast Flawless Maneuver
- left battlefield: Spore Frog was put into Graveyard from Battlefield.
- P1 activated Spore Frog

## Turn 24 (OUR TURN, round 6) | life: P1 10, P2 36, P3 74, US 38
Our hand: Vrock, Waterlogged Grove, The Coming of Galactus, Massacre Wurm, Mulldrifter, Seal of Doom, Heroic Intervention
Our graveyard (4): Soul-Guide Lantern, Takenuma, Abandoned Mire, Verdant Catacombs, Misty Rainforest
Board P1: 4 lands; Teval, the Balanced Scale 4/4, The Scarab God 5/5, Lyra Dawnbringer 4/4 [token]
Board P2: 8 lands; Moraug, Fury of Akoum 6/6, Augur of Autumn 2/3, Hearthhull, the Worldseed 6/7 {[CHARGE x 8]}
Board P3: 5 lands; Sol Ring (tapped 1), Giada, Font of Hope 2/2, Serra Paragon 5/6 {[P1P1 x 2]} (tapped 1), Resplendent Angel 6/6 {[P1P1 x 3]} (tapped 1), Angel Token 8/8 [token] {[P1P1 x 4]}, Angel of Vitality 9/9 {[P1P1 x 5]} (tapped 1), The Book of Exalted Deeds, Angel Token 9/9 [token] {[P1P1 x 6]} (tapped 1), Angel Token 11/11 [token] {[P1P1 x 7]}
Board US: 5 lands; Dalek Drone 3/3
MEMO (start of our turn):
THIS TURN: 1) Play Waterlogged Grove (6 mana; it costs 1 life per tap). 2) Evoke Mulldrifter ({2}{U}) with Grove, Tropical Island and Command Tower. Keep Swamp, Woodland and Darkslick for black. 3) If we drew Toxic Deluge, cast it with X=11 (kills every creature, ours too). Otherwise cast Seal of Doom ({2}{B}). If we drew Demonic Tutor, cast Seal anyway and hold Tutor. 4) On P3's attack: sacrifice Seal on the biggest Angel coming at us. Dalek Drone chump-blocks the next biggest. Seal can't hit black creatures (Teval, Scarab God, Lyra token, Hearthhull).

TARGET: Muldrotha out with the lanes looping Seal, Lantern, Mulldrifter and fetches, and P3's Angels gone. Missing: Toxic Deluge, Pernicious Deed, Ratchet Bomb. Demonic Tutor finds Deluge.

WIN PATH: P1 is at 6. Two Vrock end-step triggers kill P1 (sacrificing Seal satisfies Vrock). So do The Coming of Galactus chapters II and III plus one Vrock trigger. Galactus's 16/16 finishes P2 and P3 after a wipe. P3 can nearly kill us in one swing (about 50 flying power against our 39 life), so we are behind until a wipe lands.

THREATS & ANSWERS: 1) P3's Angels: Seal, Drone chump, then Deluge or Deed. 2) Giada: Massacre Wurm. 3) Hearthhull: Galactus chapter I. 4) The Scarab God steals creatures from graveyards, so don't let Drone die needlessly.

HOLD: Heroic Intervention for protecting Muldrotha later. Hold Vrock, Wurm and Galactus for next turn. Next turn choose Galactus on the biggest Angel if the swarm is still up, otherwise Muldrotha.

REPLAN IF: we draw Deluge, Deed, Ratchet Bomb or Demonic Tutor; we drop below 20; P1 steals Mulldrifter; someone wipes the board.
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Mulldrifter (from Hand): Evoke {2}{U} (You may cast this spell for its evoke cost. If] instead of Forge's [cast Massacre Wurm (from Hand): Massacre Wurm - Creature 6 / 5]
PILOT OVERRULED FORGE (action, MAIN1): chose [Angel of Vitality [P3, 9/9, tapped]] instead of Forge's [Angel Token [P3, 11/11, token]]
PILOT OVERRULED FORGE (attack, COMBAT_DECLARE_ATTACKERS): chose [attack P1 (6 life)] instead of Forge's [don't attack with it]
- US cast Mulldrifter
- US triggered Mulldrifter
- US triggered Mulldrifter
- left battlefield: Mulldrifter was put into Graveyard from Battlefield.
- US cast Seal of Doom
- left battlefield: Seal of Doom was put into Graveyard from Battlefield.
- US activated Seal of Doom targeting [Angel of Vitality]
- left battlefield: Angel of Vitality was put into Graveyard from Battlefield.
- attack: US assigned Dalek Drone to attack P1.
- attack: P1 assigned Teval, the Balanced Scale and Lyra Dawnbringer to block Dalek Drone.
- left battlefield: Dalek Drone was put into Graveyard from Battlefield.

## Turn 25 (P1, round 7) | life: P1 10, P2 35, P3 70, US 37
- P1 triggered The Scarab God
- P1 activated The Scarab God targeting [Dalek Drone]
- P1 triggered Dalek Drone targeting [Angel Token]

## Turn 26 (P2, round 7) | life: P1 6, P2 35, P3 66, US 33
- P2 triggered Moraug, Fury of Akoum
- P2 triggered Moraug, Fury of Akoum
- left battlefield: Mountain was put into Graveyard from Battlefield.
- P2 activated Hearthhull, the Worldseed
- P2 triggered Hearthhull, the Worldseed
- P2 cast Korvold, Fae-Cursed King
- P2 triggered Korvold, Fae-Cursed King
- left battlefield: Forest was put into Graveyard from Battlefield.
- P2 triggered Hearthhull, the Worldseed
- P2 triggered Korvold, Fae-Cursed King
- P2 cast Exploration Broodship

## Turn 27 (P3, round 7) | life: P1 3, P2 35, P3 66, US 33
- P3 cast Angel of Vitality
- attack: P3 assigned Angel Token, Angel Token, Resplendent Angel, Serra Paragon and Giada, Font of Hope to attack P1.
- attack: P1 assigned Teval, the Balanced Scale to block Angel Token.
- left battlefield: Teval, the Balanced Scale was put into Graveyard from Battlefield.
- left battlefield: Lyra Dawnbringer was put into Graveyard from Battlefield.
- left battlefield: Dalek Drone was put into Graveyard from Battlefield.
- P3 cast Battle Angels of Tyr
- P3 triggered Path of Ancestry

## Turn 28 (OUR TURN, round 7) | life: P1 3, P2 35, P3 66, US 31
Our hand: Vrock, The Coming of Galactus, Massacre Wurm, Heroic Intervention, Polluted Delta, Toxic Deluge, Hostage Taker
Our graveyard (6): Soul-Guide Lantern, Takenuma, Abandoned Mire, Verdant Catacombs, Misty Rainforest, Mulldrifter, Seal of Doom
Board P1: 5 lands; The Scarab God 5/5
Board P2: 7 lands; Moraug, Fury of Akoum 6/6, Augur of Autumn 2/3, Hearthhull, the Worldseed 6/7 {[CHARGE x 8]} (tapped 1), Korvold, Fae-Cursed King 5/5 {[P1P1]}, Exploration Broodship
Board P3: 5 lands; Sol Ring (tapped 1), Giada, Font of Hope 2/2, Serra Paragon 5/6 {[P1P1 x 2]} (tapped 1), Resplendent Angel 6/6 {[P1P1 x 3]} (tapped 1), Angel Token 8/8 [token] {[P1P1 x 4]}, The Book of Exalted Deeds, Angel Token 9/9 [token] {[P1P1 x 6]} (tapped 1), Angel of Vitality 9/9 {[P1P1 x 5]}, Battle Angels of Tyr 10/10 {[P1P1 x 6]}
Board US: 6 lands; no nonland permanents
MEMO (start of our turn):
THIS TURN: 1) Play Polluted Delta, crack it (1 life) for Underground Sea; if it's missing, take Drowned Catacomb. 2) Toxic Deluge ({2}{B}: Swamp, Woodland, Darkslick) with X=10. This kills all of P3's Angels (Battle Angels is 10/10), Hearthhull, Korvold, Moraug and Scarab God. We go to 22. 3) Hostage Taker ({2}{U}{B}: Sea, Tropical, Tower, Grove) exiling Sol Ring; cast Sol Ring next turn. Do not cast Taker before Deluge. P3 can swing about 49 flying at our 32, so the wipe is mandatory.

TARGET: Muldrotha looping fetches, Seal of Doom and Mulldrifter, with Vrock triggering every end step. Missing: Pernicious Deed, Ratchet Bomb, Soul-Guide Lantern online (it needs Muldrotha).

WIN PATH: P1 is at 3. Next turn cast Vrock (5), then sacrifice Waterlogged Grove ({1}, tap, sacrifice) or crack a fetch. P1 loses 3 at our end step. Then Galactus drains and the 16/16, Vrock and Wurm drains close out P2 and P3.

THREATS & ANSWERS: 1) P1: Scarab God returns to hand, and Living Death could return P3's dead Angels. Kill P1 with Vrock next turn. 2) P3 rebuilding (Giada, Book of Exalted Deeds): Galactus chapter I or Massacre Wurm. 3) P2 recasting Hearthhull or Korvold: Galactus chapter I. Avoid needless sacrifices while Mayhem Devil could be out.

HOLD: Vrock, Massacre Wurm, The Coming of Galactus, Heroic Intervention (to protect Vrock or Muldrotha from a wipe or removal next turn).

REPLAN IF: Living Death resolves; P1 gains life; Deluge is countered; we drop below 15; Hostage Taker is removed before Sol Ring is cast.
PILOT OVERRULED FORGE (search, MAIN1): chose [Underground Sea — Land - Island Swamp — ({T}: Add {U} or {B}.)] instead of Forge's [Breeding Pool — Land - Forest Island — ({T}: Add {G} or {U}.) As Breeding Pool enters, you]
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Toxic Deluge (from Hand): As an additional cost to cast this spell, pay X life. All c] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (trigger-target, MAIN2): chose [Sol Ring [P3, tapped]] instead of Forge's [Angel Token [P3, 8/8, token]]
- left battlefield: Polluted Delta was put into Graveyard from Battlefield.
- US activated Polluted Delta
- US cast Toxic Deluge
- US cast Hostage Taker
- US triggered Hostage Taker targeting [Sol Ring]
- left battlefield: Sol Ring was put into Exile from Battlefield.

## Turn 29 (P1, round 8)
- P1 triggered The Scarab God
- P1 activated The Scarab God targeting [Mulldrifter]
- P1 triggered Mulldrifter

## Turn 30 (P2, round 8)
- P2 cast Putrefy targeting [Angel Token]
- P1 cast An Offer You Can't Refuse targeting [Destroy target artifact or creature. It can't be regenerated.]
- P2 cast Tireless Provisioner

## Turn 31 (P3, round 8) | life: P1 3, P2 9, P3 66, US 20
- attack: P3 assigned Battle Angels of Tyr, Angel Token, Angel of Vitality and Angel Token to attack P2.
- P3 triggered Battle Angels of Tyr
- attack: P1 assigned Mulldrifter to block Battle Angels of Tyr.
- attack: P2 assigned Korvold, Fae-Cursed King to block Battle Angels of Tyr.
- left battlefield: Mulldrifter was put into Graveyard from Battlefield.
- left battlefield: Korvold, Fae-Cursed King was put into Graveyard from Battlefield.
- P3 triggered Battle Angels of Tyr
- P3 triggered Battle Angels of Tyr
- left battlefield: Battle Angels of Tyr was put into Exile from Battlefield.
- left battlefield: Battle Angels of Tyr was put into Exile from Battlefield.
- P3 activated Bonders' Enclave
- P3 cast Arcane Signet
- P3 cast Authority of the Consuls
Damage to US this turn: Battle Angels of Tyr (combat) 11

## Turn 32 (OUR TURN, round 8) | life: P1 0, P2 6, P3 67, US 20
Our hand: Vrock, The Coming of Galactus, Massacre Wurm, Heroic Intervention, Sakura-Tribe Elder
Our graveyard (7): Soul-Guide Lantern, Takenuma, Abandoned Mire, Verdant Catacombs, Misty Rainforest, Seal of Doom, Polluted Delta, Toxic Deluge
Board P1: 5 lands; The Scarab God 5/5
Board P2: 7 lands; Moraug, Fury of Akoum 6/6, Augur of Autumn 2/3, Hearthhull, the Worldseed 6/7 {[CHARGE x 8]}, Exploration Broodship, Treasure Token [token] x2, Tireless Provisioner 3/2
Board P3: 6 lands; Giada, Font of Hope 2/2, Serra Paragon 5/6 {[P1P1 x 2]}, Resplendent Angel 6/6 {[P1P1 x 3]}, Angel Token 8/8 [token] {[P1P1 x 4]}, The Book of Exalted Deeds, Angel Token 9/9 [token] {[P1P1 x 6]} (tapped 1), Angel of Vitality 9/9 {[P1P1 x 5]} (tapped 1), Battle Angels of Tyr 10/10 {[P1P1 x 6]} (tapped 1), Arcane Signet (tapped 1), Authority of the Consuls
Board US: 7 lands; Hostage Taker 2/3
MEMO (start of our turn):
THIS TURN: 1) Cast Sol Ring from Hostage Taker's exile for {1} from a land. 2) Cast Vrock ({3}{B}{B}) with Sol Ring's {C}{C} plus Swamp, Underground Sea and Darkslick. It enters tapped because of Authority of the Consuls. 3) Cast Sakura-Tribe Elder ({1}{G}) with Tropical and Command Tower. Sacrifice it in main phase 1 for a basic Forest. It must leave before the end step. 4) End step: Vrock drains 3. P1 (at 3) dies, P2 goes to 6, P3 to 63. P1 is fully tapped out and can't answer this.

TARGET: Survive P3's turn. Next turn cast Massacre Wurm (P2 loses 4 from Augur and Provisioner dying), then sacrifice Waterlogged Grove so Vrock's drain kills P2. Muldrotha after that, recasting Seal of Doom and fetches. Missing: Pernicious Deed, reached through Demonic Tutor.

WIN PATH: P1 dies tonight and P2 next turn (Wurm plus Vrock). Then Galactus and Vrock drains grind P3 down from about 63.

THREATS & ANSWERS: 1) P3 has about 49 flying power against our 20, and we have no answer in hand. Next turn Pernicious Deed with X=4 kills the Angels; Galactus chapter I kills Battle Angels. 2) P2's Hearthhull (black, so Seal of Doom can't hit it) and Moraug: Galactus chapter I. Don't feed P2 needless sacrifices.

HOLD: The Coming of Galactus, Massacre Wurm and Heroic Intervention for next turn. Heroic Intervention can't be afforded this turn; accept the risk.

REPLAN IF: Vrock is removed before the end step (then aim Wurm and Vrock at P2 next turn); P1 gains life; we survive below 10; we draw Deed or Demonic Tutor.
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Sol Ring (from Exile): Sol Ring by Hostage Taker (397) (may spend mana as though it w] instead of Forge's [cast Massacre Wurm (from Hand): Massacre Wurm - Creature 6 / 5]
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Vrock (from Hand): Vrock - Creature 3 / 3 [Forge's heuristic AI would not do this: Ca] instead of Forge's [cast Massacre Wurm (from Hand): Massacre Wurm - Creature 6 / 5]
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Sakura-Tribe Elder (from Hand): Sakura-Tribe Elder - Creature 1 / 1 [Forge's heuristi] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (search, MAIN1): chose [Forest — Basic Land - Forest — ({T}: Add {G}.)] instead of Forge's [Swamp — Basic Land - Swamp — ({T}: Add {B}.)]
PILOT OVERRULED FORGE (attack, COMBAT_DECLARE_ATTACKERS): chose [attack P1 (3 life)] instead of Forge's [don't attack with it]
- US cast Sol Ring
- US cast Vrock
- P3 triggered Authority of the Consuls
- US cast Sakura-Tribe Elder
- P3 triggered Authority of the Consuls
- left battlefield: Sakura-Tribe Elder was put into Graveyard from Battlefield.
- US activated Sakura-Tribe Elder
- attack: US assigned Hostage Taker to attack P1.
- attack: P1 assigned The Scarab God to block Hostage Taker.
- left battlefield: Hostage Taker was put into Graveyard from Battlefield.
- US triggered Vrock

## Turn 33 (P2, round 9) | life: P1 0, P2 6, P3 59, US 12
- P2 cast Planar Engineering
- left battlefield: Mountain was put into Graveyard from Battlefield.
- left battlefield: Swamp was put into Graveyard from Battlefield.
- P2 triggered Hearthhull, the Worldseed
- P2 triggered Hearthhull, the Worldseed
- P2 triggered Moraug, Fury of Akoum
- P2 triggered Tireless Provisioner
- P2 triggered Moraug, Fury of Akoum
- P2 triggered Tireless Provisioner
- P2 triggered Moraug, Fury of Akoum
- P2 triggered Tireless Provisioner
- P2 triggered Moraug, Fury of Akoum
- left battlefield: Forest was put into Graveyard from Battlefield.
- P2 activated Hearthhull, the Worldseed
- P2 triggered Hearthhull, the Worldseed
- P2 triggered Moraug, Fury of Akoum
- P2 triggered Moraug, Fury of Akoum
- P2 triggered Moraug, Fury of Akoum
- P2 triggered Tireless Provisioner
- P2 triggered Bojuka Bog targeting [P4]
- P2 cast Conduit of Worlds
- P2 triggered Moraug, Fury of Akoum
- P2 triggered Tireless Provisioner
- left battlefield: Forest was put into Graveyard from Battlefield.
- P2 activated Hearthhull, the Worldseed
- P2 triggered Hearthhull, the Worldseed
- P2 triggered Moraug, Fury of Akoum
- P2 triggered Tireless Provisioner
- P2 activated Exploration Broodship
- P2 activated Exploration Broodship
- P2 triggered Moraug, Fury of Akoum
- P2 triggered Tireless Provisioner
- P2 activated Exploration Broodship
- P2 activated Canyon Slough
- P2 triggered Moraug, Fury of Akoum
- P2 triggered Moraug, Fury of Akoum
- P2 triggered Moraug, Fury of Akoum
- P2 triggered Moraug, Fury of Akoum

## Turn 34 (P3, round 9) | life: P1 0, P2 -26, P3 68, US 1
- attack: P3 assigned Battle Angels of Tyr, Angel Token, Angel of Vitality, Angel Token, Resplendent Angel, Serra Paragon and Giada, Font of Hope to attack P2.
- P3 triggered Battle Angels of Tyr
- attack: P2 assigned Exploration Broodship to block Battle Angels of Tyr.
- P3 activated Resplendent Angel
- P3 triggered Battle Angels of Tyr
- P3 triggered Battle Angels of Tyr
- left battlefield: Battle Angels of Tyr was put into Exile from Battlefield.
- P3 cast Luminarch Ascension
- P3 triggered Resplendent Angel
- P3 triggered The Book of Exalted Deeds
Damage to US this turn: Battle Angels of Tyr (combat) 11

## Turn 35 (OUR TURN, round 9) | life: P1 0, P2 -26, P3 68, US 1
Our hand: The Coming of Galactus, Massacre Wurm, Heroic Intervention, Glen Elendra Archmage
Our graveyard (0): 
Board P3: 7 lands; Giada, Font of Hope 2/2, Serra Paragon 5/6 {[P1P1 x 2]} (tapped 1), Resplendent Angel 6/6 {[P1P1 x 3]} (tapped 1), Angel Token 8/8 [token] {[P1P1 x 4]}, The Book of Exalted Deeds, Angel Token 9/9 [token] {[P1P1 x 6]} (tapped 1), Angel of Vitality 9/9 {[P1P1 x 5]} (tapped 1), Battle Angels of Tyr 10/10 {[P1P1 x 6]} (tapped 1), Arcane Signet (tapped 1), Authority of the Consuls, Treasure Token [token], Luminarch Ascension, Angel Token 10/10 [token] {[P1P1 x 7]}, Angel Token 12/12 [token] {[P1P1 x 8]}
Board US: 8 lands; Sol Ring, Vrock 3/3
MEMO (start of our turn):
THIS TURN: We are at 1 life. P3 has about 70 flying power and our new creatures enter tapped (Authority of the Consuls), so we need a full wipe tonight. Never tap Waterlogged Grove for mana or crack a fetch: paying 1 life kills us.
1) Pay {1} from Forest to sacrifice Waterlogged Grove and draw a card. Grove leaving also turns on Vrock tonight. 8 mana remains (6 lands plus Sol Ring's 2).
2) If the draw is Pernicious Deed: cast it ({1}{B}{G}), then activate it with X=4 (Sol Ring plus 2 lands). This kills every Angel (tokens are mana value 0, the biggest nonland is 4), plus Book, Authority, Ascension and Treasure. Vrock survives; we lose Sol Ring.
3) If the draw is an untapped land, play it.
4) Otherwise cast Massacre Wurm ({3}{B}{B}{B}). It kills Giada, so P3 loses 2.
5) End step: Vrock drains 3.

TARGET: An empty P3 board with Vrock alive. Then Muldrotha, Wurm, Galactus, Glen Elendra.

WIN PATH: Only if the wipe lands: Vrock, Wurm and Galactus drains, then a 16/16 flyer against P3's roughly 63 life. Otherwise we lose this turn cycle.

THREATS & ANSWERS: P3's whole flying board is lethal. The only answer is Deed (X=4). Toxic Deluge is unusable at 1 life. Demonic Tutor into Deed is one mana short, so don't try it.

HOLD: Heroic Intervention: it doesn't stop combat damage to us, so it's irrelevant. Keep Glen Elendra; P3 has no cards in hand.

REPLAN IF: The Grove draw is Deed, Ratchet Bomb, Demonic Tutor or a land. Recount mana first.
MEMO (executor escalation: we lost: Vrock):
THIS TURN: We are at 1 life and nothing we hold stops P3's flying attack. Vrock and Grove are in the graveyard, and Muldrotha isn't out, so we can't recast either. Only Command Tower and Underground Sea are untapped (2 mana), so no further plays fit. End the turn and hold UU for Counterspell. On P3's turn, counter only a spell that changes the outcome, such as a new Angel or anything that grants lifelink or double strike (Akroma's Will). Never pay life: any life payment kills us. If a non-flyer attacks, block it with Massacre Wurm.

TARGET: Survive P3's next attack, which only happens if P3 doesn't swing. Then untap 9 mana (7 lands plus Sol Ring) and cast Muldrotha.

WIN PATH: Realistically none this cycle. P3 is at 68 with about 70 flying power, and we have no flyers or fog. If we survive: Muldrotha, recast Vrock from the graveyard next turn, then Galactus drains and Wurm triggers.

THREATS & ANSWERS: P3's flying Angel board is lethal next combat, and we have no answer in hand. Counterspell is for P3's top-deck. Glen Elendra (4 mana) can't be cast now.

HOLD: Counterspell (UU from Command Tower and Underground Sea). Heroic Intervention doesn't prevent combat damage, so don't waste it; it only matters against a wipe if we survive. Keep Galactus and Glen Elendra.

REPLAN IF: P3 doesn't attack, or loses creatures. Then next turn cast Muldrotha, recount mana, and recast Vrock or Galactus.
PILOT OVERRULED FORGE (action, MAIN1): chose [activate Waterlogged Grove (from Battlefield): {1}, {T}, Sacrifice Waterlogged Grove: Draw] instead of Forge's [cast Massacre Wurm (from Hand): Massacre Wurm - Creature 6 / 5]
PILOT OVERRULED FORGE (attack, COMBAT_DECLARE_ATTACKERS): chose [attack P3 (68 life)] instead of Forge's [don't attack with it]
PILOT OVERRULED FORGE (action, COMBAT_DECLARE_BLOCKERS): chose [Do nothing now; let it resolve / let the turn pass (this skips o0, the play Forge's AI wou] instead of Forge's [cast Heroic Intervention (from Hand): Permanents you control gain hexproof and indestructi]
ESCALATION (p=0.93): we lost: Vrock
- left battlefield: Waterlogged Grove was put into Graveyard from Battlefield.
- US activated Waterlogged Grove
- US cast Massacre Wurm
- US triggered Massacre Wurm
- P3 triggered Authority of the Consuls
- left battlefield: Giada, Font of Hope was put into Graveyard from Battlefield.
- US triggered Massacre Wurm
- attack: US assigned Vrock to attack P3.
- attack: P3 assigned Angel Token to block Vrock.
- left battlefield: Vrock was put into Graveyard from Battlefield.

## Turn 36 (P3, round 9) | life: P1 0, P2 -26, P3 77, US -70
- attack: P3 assigned Angel Token, Battle Angels of Tyr, Angel Token, Angel Token, Angel of Vitality, Angel Token, Resplendent Angel and Serra Paragon to attack US.
- P3 triggered Battle Angels of Tyr
- P3 activated Resplendent Angel
- Game Outcome: P1 has lost because life total reached 0
- Game Outcome: P2 has lost because life total reached 0
- Game Outcome: P3 has won because all opponents have lost
- Game Outcome: US has lost because life total reached 0
Damage to US this turn: Angel Token (combat) 39, Battle Angels of Tyr (combat) 10, Angel of Vitality (combat) 9, Resplendent Angel (combat) 8, Serra Paragon (combat) 5