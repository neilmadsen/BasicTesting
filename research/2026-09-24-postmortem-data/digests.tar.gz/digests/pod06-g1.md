# pod06-g1: we are P1; opponents P2 Atraxa, Praetors' Voice, P3 Sephiroth, Fabled SOLDIER, P4 Edgar Markov
Result: Turn 20; US has lost because life total reached 0; P2 has lost because life total reached 0; P3 has won because all opponents have lost; P4 has lost because life total reached 0

## Turn 1 (OUR TURN, round 1) | life: US 39
Our hand: Bayou, Polluted Delta, Toxic Deluge, Underground Sea, Siren Stormtamer, Executioner's Capsule, Assassin's Trophy, Sakura-Tribe Elder
Our graveyard (0): 
Board US: 0 lands; no nonland permanents
Board P2: 0 lands; no nonland permanents
Board P3: 0 lands; no nonland permanents
Board P4: 0 lands; no nonland permanents
MEMO (start of our turn):
THIS TURN: Play Polluted Delta, pay 1 life and fetch Zagoth Triome (it enters tapped, which costs nothing on turn 1). Cast nothing. Plan for the next turns:
- T2: play Underground Sea and cast Sakura-Tribe Elder (1G). Sacrifice Elder at an opponent's end step, or to fetch at need, for a basic Forest.
- T3: play Bayou. Cast Executioner's Capsule (B) and keep BG open for Assassin's Trophy.
- Then land drops toward Muldrotha on T4 or T5, at 6 mana.

TARGET: Muldrotha on board with Capsule, Elder, Delta and the Seals cycling through the graveyard lanes. Siren Stormtamer guards her. Missing: Doc Aurlock, Seal of Primordium, Cryogen Relic, Survival of the Fittest.

WIN PATH: Lock the board by T7–9 with recurring removal, then drain with Gray Merchant or Syr Konrad and beat down with Muldrotha. P3 is the fastest threat (combo T5–7), then P4 (T6–8), then P2 (poison T7–9).

THREATS & ANSWERS:
1. P3: Pitiless Plunderer, Ashnod's Altar, Grave Pact go to Trophy. Capsule can't hit black creatures.
2. P4: Vito or Exquisite Blood go to Trophy. Vampires are black, so Capsule is dead against them.
3. P2: Tekuthal and Inexorable Tide go to Trophy. Capsule is for nonblack creatures only; Atraxa is black.
- Toxic Deluge is for a vampire or fodder swarm. It feeds Sephiroth's drain, so cast it before he transforms.

HOLD: Trophy with BG open from T3 onward. Keep Stormtamer in hand until Muldrotha lands. Keep Deluge until the board is wide. Don't chump-block, since P3 and P4 profit from deaths.

REPLAN IF: Sephiroth plus fodder or Edgar's tokens go wide early (Deluge sooner). P2 lands a proliferator early. We draw ramp and can cast Muldrotha on T4.
PILOT OVERRULED FORGE (action, MAIN1): chose [play land Polluted Delta (from Hand): Play land] instead of Forge's [play land Underground Sea (from Hand): Play land]
PILOT OVERRULED FORGE (search, MAIN1): chose [Zagoth Triome — Land - Swamp Forest Island — ({T}: Add {B}, {G}, or {U}.) Zagoth Triome en] instead of Forge's [Tropical Island — Land - Forest Island — ({T}: Add {G} or {U}.)]
- left battlefield: Polluted Delta was put into Graveyard from Battlefield.
- US activated Polluted Delta

## Turn 2 (P2, round 1)
- P2 cast Venerated Rotpriest

## Turn 3 (P3, round 1)
- P3 cast Sol Ring

## Turn 4 (P4, round 1)

## Turn 5 (OUR TURN, round 2)
Our hand: Bayou, Toxic Deluge, Underground Sea, Siren Stormtamer, Executioner's Capsule, Assassin's Trophy, Sakura-Tribe Elder, Heroic Intervention
Our graveyard (1): Polluted Delta
Board US: 1 lands; no nonland permanents
Board P2: 1 lands; Venerated Rotpriest 1/2
Board P3: 1 lands; Sol Ring
Board P4: 1 lands; no nonland permanents
MEMO (start of our turn):
THIS TURN: Play Bayou and cast Sakura-Tribe Elder, using G from Zagoth Triome plus 1 from Bayou. Keep Elder untapped as a blocker. If Venerated Rotpriest attacks us, block with Elder, then sacrifice Elder before damage to fetch a Swamp. Otherwise sacrifice Elder at P4's end step for a Swamp. It enters tapped but untaps for our turn.

NEXT TURN: Play Underground Sea (4 lands). Cast Executioner's Capsule (B), then keep BG open for Assassin's Trophy. Muldrotha comes at 6 mana, likely in two to three turns, so prioritise drawn ramp.

TARGET: Muldrotha on board, guarded by Siren Stormtamer, recurring Capsule, Elder and Polluted Delta through the graveyard lanes. Missing: Doc Aurlock, Grizzled Genius, Seal of Primordium, Cryogen Relic and Survival of the Fittest.

WIN PATH: Lock the board by turns 7–9, then close with Gray Merchant or Syr Konrad drains plus Muldrotha beats. P3 is fastest (combo turns 5–7), then P4, then P2 (poison).

THREATS & ANSWERS:
1. P3 (Sol Ring, can cast Sephiroth next turn): Assassin's Trophy for Pitiless Plunderer, Ashnod's Altar or Grave Pact. Capsule can't hit black creatures.
2. P4: Trophy for Vito, Exquisite Blood or Bloodthirsty Conqueror. Toxic Deluge answers a token swarm.
3. P2: Trophy for Tekuthal or Inexorable Tide. Capsule can hit green Rotpriest later if poison piles up.
- Don't feed Sephiroth: cast Deluge before he racks up deaths.

HOLD: Trophy, Stormtamer until Muldrotha lands, Heroic Intervention for a wipe, and Deluge until a board goes wide.

REPLAN IF: Sephiroth or a vampire swarm arrives early (Deluge next turn). A Plunderer or Altar combo piece lands (Trophy it immediately). We draw Sol Ring or a Signet, so Muldrotha comes a turn sooner.
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Assassin's Trophy (from Hand): Destroy target permanent an opponent controls. Its con] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (action, MAIN1): chose [Sol Ring [P3]] instead of Forge's [Venerated Rotpriest [P2, 1/2]]
- US cast Assassin's Trophy targeting [Sol Ring]
- left battlefield: Sol Ring was put into Graveyard from Battlefield.

## Turn 6 (P2, round 2) | life: P4 39, US 39
- attack: P2 assigned Venerated Rotpriest to attack P4.
- P2 cast Bloom Tender

## Turn 7 (P3, round 2)
- P3 cast Sephiroth, Fabled SOLDIER
- P3 triggered Sephiroth, Fabled SOLDIER

## Turn 8 (P4, round 2)
- P4 cast Charismatic Conqueror
- P4 triggered Edgar Markov

## Turn 9 (OUR TURN, round 3) | life: P3 41, P4 38, US 39
Our hand: Toxic Deluge, Underground Sea, Siren Stormtamer, Executioner's Capsule, Sakura-Tribe Elder, Heroic Intervention, Braids, Arisen Nightmare
Our graveyard (2): Polluted Delta, Assassin's Trophy
Board US: 2 lands; no nonland permanents
Board P2: 2 lands; Venerated Rotpriest 1/2 (tapped 1), Bloom Tender 1/1
Board P3: 3 lands; Sephiroth, Fabled SOLDIER 3/3
Board P4: 2 lands; Vampire Token 1/1 [token], Charismatic Conqueror 2/2
MEMO (start of our turn):
THIS TURN: Play Underground Sea. Cast Sakura-Tribe Elder ({1}{G}: G from Zagoth Triome, 1 from Underground Sea). Cast Executioner's Capsule (B from Bayou). When Charismatic Conqueror triggers on each, choose to tap the permanent so P4 gets no token. Neither needs to be untapped this round. Sacrifice Elder for a Swamp at P4's end step, or earlier in response to removal or an edict. Its death drains us 1 via Sephiroth, which is acceptable.

TARGET: Muldrotha plus Siren Stormtamer up, with Capsule and Elder recurring each turn and Braids sacrificing spent artifacts or Delta at end step. Missing: Doc Aurlock, Seal of Primordium, Seal of Doom, Demonic Tutor, Survival of the Fittest, Gray Merchant.

WIN PATH: Next turn, activate Capsule ({1}{B}) and cast Braids ({1}{B}{B}) with 5 mana. Muldrotha comes the turn after. Close with Braids drains and Gray Merchant or Syr Konrad recursion. P3 is fastest (Sephiroth loops), so aim to be locked before then.

THREATS & ANSWERS:
1. P3 Sephiroth is black, so Capsule can't hit it. Use Toxic Deluge if fodder piles up. Don't feed it deaths needlessly.
2. P4's Conqueror or Vito: Capsule hits Conqueror. Vito and Bloodthirsty Conqueror are black, so they need Deluge or tutored Seals.
3. P2 Rotpriest poison: Capsule is fine on it later.
- Assassin's Trophy is an instant and is gone. Muldrotha can't recast it.

HOLD: Toxic Deluge until 4+ enemy creatures. Heroic Intervention and Stormtamer until Muldrotha lands.

REPLAN IF: Plunderer, Altar or Grave Pact appears; a vampire swarm forms (cast Deluge); or Vito lands.
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Sakura-Tribe Elder (from Hand): Sakura-Tribe Elder - Creature 1 / 1 [Forge's heuristi] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (search, MAIN1): chose [Swamp — Basic Land - Swamp — ({T}: Add {B}.)] instead of Forge's [Forest — Basic Land - Forest — ({T}: Add {G}.)]
PILOT OVERRULED FORGE (action, MAIN2): chose [cast Executioner's Capsule (from Hand): Executioner's Capsule] instead of Forge's [cast Siren Stormtamer (from Hand): Siren Stormtamer - Creature 1 / 1]
- US cast Sakura-Tribe Elder
- P4 triggered Charismatic Conqueror
- left battlefield: Sakura-Tribe Elder was put into Graveyard from Battlefield.
- US activated Sakura-Tribe Elder
- P3 triggered Sephiroth, Fabled SOLDIER targeting [P4]
- US cast Executioner's Capsule
- P4 triggered Charismatic Conqueror

## Turn 10 (P2, round 3)
- P2 cast Bloated Contaminator
- P4 triggered Charismatic Conqueror

## Turn 11 (P3, round 3) | life: P2 37, P3 41, P4 38, US 39
- attack: P3 assigned Sephiroth, Fabled SOLDIER to attack P2.
- P3 triggered Sephiroth, Fabled SOLDIER
- P3 cast Morbid Opportunist
- P4 triggered Charismatic Conqueror

## Turn 12 (P4, round 3) | life: P2 35, P3 41, P4 38, US 39
- attack: P4 assigned Charismatic Conqueror to attack P2.
- P4 cast Mavren Fein, Dusk Apostle
- P4 triggered Edgar Markov

## Turn 13 (OUR TURN, round 4) | life: P2 35, P3 42, P4 37, US 39
Our hand: Toxic Deluge, Siren Stormtamer, Heroic Intervention, Braids, Arisen Nightmare
Our graveyard (3): Polluted Delta, Assassin's Trophy, Sakura-Tribe Elder
Board US: 4 lands; Executioner's Capsule
Board P2: 3 lands; Venerated Rotpriest 1/2, Bloom Tender 1/1 (tapped 1), Bloated Contaminator 4/4 (tapped 1)
Board P3: 4 lands; Sephiroth, Fabled SOLDIER 3/3 (tapped 1), Morbid Opportunist 1/3 (tapped 1)
Board P4: 3 lands; Vampire Token 1/1 [token] x3, Charismatic Conqueror 2/2, Mavren Fein, Dusk Apostle 2/2
MEMO (start of our turn):
THIS TURN: Play any land drawn. Main 1: cast Toxic Deluge with X=4 ({2}{B}: Swamp, Bayou, Zagoth Triome). That kills all ten enemy creatures, including Sephiroth, Contaminator and the whole vampire board. Expect about 9 Sephiroth drains plus the 4 life paid, so we end around 26. Sephiroth dies too, so it can't transform or give P3 the emblem. Then cast Siren Stormtamer (U from Underground Sea). Don't attack. Keep Executioner's Capsule unused.

TARGET: Braids next turn, then Muldrotha at 6 lands, recurring Capsule, Sakura-Tribe Elder and Delta. Missing: Doc Aurlock, Seal of Primordium, Seal of Doom, Demonic Tutor, Survival of the Fittest, Gray Merchant, Massacre Wurm.

WIN PATH: Everyone rebuilds from zero while we keep 4 lands, Capsule, Stormtamer and Braids. Next turn cast Braids ({1}{B}{B}), plus a Capsule activation if a 5th land arrives. Close with Braids drains, then Gray Merchant or Syr Konrad recursion. P3's Sephiroth loop (turns 5-7) is the fastest clock, and this wipe resets it.

THREATS & ANSWERS:
1. P3 rebuild (Pitiless Plunderer, Ashnod's Altar, Grave Pact). Capsule can't hit black creatures, so find a Seal via draws.
2. P4 Vito or Exquisite Blood. Capsule can't hit Vito. Save Stormtamer for defence.
3. P2 recast of Contaminator or Rotpriest, or Atraxa. Capsule ({1}{B}) hits Contaminator; Atraxa is black.

HOLD: Heroic Intervention until Muldrotha or Braids is out. Stormtamer's sacrifice ability is only for removal aimed at Braids or Muldrotha.

REPLAN IF: A response pumps a creature above 4 toughness. A drain wave drops us below 20. Someone flashes in Plunderer or Grave Pact. We draw a tutor.
PILOT OVERRULED FORGE (action, MAIN2): chose [cast Siren Stormtamer (from Hand): Siren Stormtamer - Creature 1 / 1] instead of Forge's [cast Marionette Apprentice (from Hand): Marionette Apprentice - Creature 1 / 2]
- left battlefield: Executioner's Capsule was put into Graveyard from Battlefield.
- US activated Executioner's Capsule targeting [Bloated Contaminator]
- left battlefield: Bloated Contaminator was put into Graveyard from Battlefield.
- P3 triggered Sephiroth, Fabled SOLDIER targeting [P4]
- P3 triggered Morbid Opportunist
- US cast Siren Stormtamer
- P4 triggered Charismatic Conqueror

## Turn 14 (P2, round 4) | life: P2 34, P3 42, P4 37, US 39
- left battlefield: Windswept Heath was put into Graveyard from Battlefield.
- P2 activated Windswept Heath

## Turn 15 (P3, round 4) | life: P2 34, P3 42, P4 34, US 39
- attack: P3 assigned Sephiroth, Fabled SOLDIER to attack P4.
- P3 triggered Sephiroth, Fabled SOLDIER
- P3 cast Drivnod, Carnage Dominus
- P4 triggered Charismatic Conqueror

## Turn 16 (P4, round 4)
- P4 cast Vengeful Bloodwitch
- P4 triggered Edgar Markov
- P4 cast Blood Artist
- P4 triggered Edgar Markov

## Turn 17 (OUR TURN, round 5)
Our hand: Toxic Deluge, Heroic Intervention, Braids, Arisen Nightmare, Marionette Apprentice, Drowned Catacomb
Our graveyard (4): Polluted Delta, Assassin's Trophy, Sakura-Tribe Elder, Executioner's Capsule
Board US: 4 lands; Siren Stormtamer 1/1
Board P2: 4 lands; Venerated Rotpriest 1/2, Bloom Tender 1/1
Board P3: 5 lands; Sephiroth, Fabled SOLDIER 3/3 (tapped 1), Morbid Opportunist 1/3, Drivnod, Carnage Dominus 8/3 (tapped 1)
Board P4: 4 lands; Vampire Token 1/1 [token] x5, Charismatic Conqueror 2/2, Mavren Fein, Dusk Apostle 2/2, Vengeful Bloodwitch 1/1, Blood Artist 0/1
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Toxic Deluge (from Hand): As an additional cost to cast this spell, pay X life. All c] instead of Forge's [Take no further action this phase: hold remaining mana and cards]
PILOT OVERRULED FORGE (attack, COMBAT_DECLARE_ATTACKERS): chose [don't attack with it] instead of Forge's [attack P4 (34 life)]
- US cast Toxic Deluge
- US cast Marionette Apprentice
- US triggered Marionette Apprentice
- P4 triggered Charismatic Conqueror
- P4 triggered Charismatic Conqueror

## Turn 18 (P2, round 5) | life: P2 34, P3 44, P4 33, US 38
- P2 cast Assassin's Trophy targeting [Drivnod, Carnage Dominus]
- left battlefield: Drivnod, Carnage Dominus was put into Graveyard from Battlefield.
- P3 triggered Sephiroth, Fabled SOLDIER targeting [P4]
- P3 triggered Sephiroth, Fabled SOLDIER targeting [P4]
- P3 triggered Morbid Opportunist
- P4 triggered Blood Artist targeting [P1]

## Turn 19 (P3, round 5) | life: P2 34, P3 39, P4 30, US 38
- attack: P3 assigned Sephiroth, Fabled SOLDIER to attack P4.
- P3 triggered Sephiroth, Fabled SOLDIER
- P3 cast Bolas's Citadel
- P4 triggered Charismatic Conqueror
- P3 cast Dictate of Erebos

## Turn 20 (P4, round 5)

## Turn 21 (OUR TURN, round 6) | life: P2 31, P3 37, P4 27, US 37
Our hand: Heroic Intervention, Braids, Arisen Nightmare, Binding the Old Gods
Our graveyard (5): Polluted Delta, Assassin's Trophy, Sakura-Tribe Elder, Executioner's Capsule, Toxic Deluge
Board US: 5 lands; Siren Stormtamer 1/1, Marionette Apprentice 1/2, Servo Token 1/1 [token]
Board P2: 4 lands; Venerated Rotpriest 1/2, Bloom Tender 1/1
Board P3: 7 lands; Sephiroth, Fabled SOLDIER 3/3 (tapped 1), Morbid Opportunist 1/3, Bolas's Citadel (tapped 1), Dictate of Erebos
Board P4: 5 lands; Vampire Token 1/1 [token] x5, Charismatic Conqueror 2/2, Mavren Fein, Dusk Apostle 2/2, Vengeful Bloodwitch 1/1, Blood Artist 0/1
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
PILOT OVERRULED FORGE (attack, COMBAT_DECLARE_ATTACKERS): chose [don't attack with it] instead of Forge's [attack P4 (30 life)]
- P4 activated Voldaren Estate
- US cast Braids, Arisen Nightmare
- P4 triggered Charismatic Conqueror
- US triggered Braids, Arisen Nightmare
- US triggered Marionette Apprentice
- P3 triggered Sephiroth, Fabled SOLDIER targeting [P4]
- P3 triggered Morbid Opportunist
- P4 triggered Blood Artist targeting [P1]

## Turn 22 (P2, round 6)
- P2 cast Vorinclex, Monstrous Raider
- P4 triggered Charismatic Conqueror

## Turn 23 (P3, round 6) | life: P2 30, P3 37, P4 23, US 36
PILOT OVERRULED FORGE (action, MAIN2): chose [activate Siren Stormtamer (from Battlefield): {U}, Sacrifice Siren Stormtamer: Counter tar] instead of Forge's [Do nothing now; let it resolve / let the turn pass]
- attack: P3 assigned Sephiroth, Fabled SOLDIER to attack P4.
- P3 triggered Sephiroth, Fabled SOLDIER
- P3 triggered Bojuka Bog targeting [P1]
- left battlefield: Siren Stormtamer was put into Graveyard from Battlefield.
- US activated Siren Stormtamer targeting [When Bojuka Bog enters, exile all cards from target player's graveyard. [Zone Changer: Bojuka Bog]]
- P3 triggered Sephiroth, Fabled SOLDIER targeting [P4]
- P3 triggered Morbid Opportunist
- P4 triggered Blood Artist targeting [P1]
- US triggered Marionette Apprentice
- P3 cast Syr Konrad, the Grim
- P4 triggered Charismatic Conqueror

## Turn 24 (P4, round 6) | life: P2 30, P3 37, P4 22, US 36
- left battlefield: Marsh Flats was put into Graveyard from Battlefield.
- P4 activated Marsh Flats
- P4 cast Legion Lieutenant
- P4 triggered Edgar Markov

## Turn 25 (OUR TURN, round 7) | life: P2 26, P3 35, P4 15, US 34
Our hand: Heroic Intervention, Binding the Old Gods, Animate Dead, Forest, Mishra's Bauble
Our graveyard (6): Polluted Delta, Assassin's Trophy, Sakura-Tribe Elder, Executioner's Capsule, Toxic Deluge, Siren Stormtamer
Board US: 5 lands; Marionette Apprentice 1/2, Braids, Arisen Nightmare 3/3
Board P2: 5 lands; Venerated Rotpriest 1/2, Bloom Tender 1/1 (tapped 1), Vorinclex, Monstrous Raider 6/6 (tapped 1)
Board P3: 8 lands; Sephiroth, Fabled SOLDIER 3/3 (tapped 1), Morbid Opportunist 1/3, Bolas's Citadel, Dictate of Erebos, Syr Konrad, the Grim 5/4 (tapped 1)
Board P4: 6 lands; Vampire Token 2/2 [token] x6, Charismatic Conqueror 3/3, Mavren Fein, Dusk Apostle 3/3, Vengeful Bloodwitch 2/2, Blood Artist 1/2, Blood Token [token], Legion Lieutenant 2/2
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
PILOT OVERRULED FORGE (action, MAIN1): chose [play land Forest (from Hand): Play land] instead of Forge's [cast Animate Dead (from Hand): Animate Dead → target: Drivnod, Carnage Dominus [P3, 8/3, i]
PILOT OVERRULED FORGE (action, MAIN1): chose [cast Mishra's Bauble (from Hand): Mishra's Bauble] instead of Forge's [cast Animate Dead (from Hand): Animate Dead → target: Drivnod, Carnage Dominus [P3, 8/3, i]
PILOT OVERRULED FORGE (action, MAIN1): chose [Sakura-Tribe Elder [ours, 1/1, in graveyard]] instead of Forge's [Drivnod, Carnage Dominus [P3, 8/3, in graveyard]]
PILOT OVERRULED FORGE (search, MAIN1): chose [Forest — Basic Land - Forest — ({T}: Add {G}.)] instead of Forge's [Island — Basic Land - Island — ({T}: Add {U}.)]
- US cast Heroic Intervention
- US cast Mishra's Bauble
- P4 triggered Charismatic Conqueror
- US cast Animate Dead targeting [Sakura-Tribe Elder]
- US triggered Animate Dead
- P4 triggered Charismatic Conqueror
- left battlefield: Sakura-Tribe Elder was put into Graveyard from Battlefield.
- US activated Sakura-Tribe Elder
- left battlefield: Animate Dead was put into Graveyard from Battlefield.
- US triggered Marionette Apprentice
- US triggered Animate Dead
- P3 triggered Sephiroth, Fabled SOLDIER targeting [P4]
- P3 triggered Syr Konrad, the Grim
- P3 triggered Morbid Opportunist
- P4 triggered Blood Artist targeting [P1]
- attack: US assigned Braids, Arisen Nightmare to attack P4.
- P4 activated Voldaren Estate
- US triggered Braids, Arisen Nightmare
- left battlefield: Forest was put into Graveyard from Battlefield.
Damage to US this turn: Syr Konrad, the Grim (non-combat) 1

## Turn 26 (P2, round 7) | life: P2 26, P3 35, P4 9, US 34
- attack: P2 assigned Vorinclex, Monstrous Raider to attack P4.
- P2 cast Atraxa, Praetors' Voice
- P4 triggered Charismatic Conqueror
- P2 cast Tekuthal, Inquiry Dominus
- P4 triggered Charismatic Conqueror
- P2 triggered Atraxa, Praetors' Voice
- P3 activated Syr Konrad, the Grim

## Turn 27 (P3, round 7) | life: P2 25, P3 44, P4 12, US 18
- attack: P3 assigned Syr Konrad, the Grim to attack P4.
- attack: P4 assigned Mavren Fein, Dusk Apostle and Charismatic Conqueror to block Syr Konrad, the Grim.
- left battlefield: Syr Konrad, the Grim was put into Graveyard from Battlefield.
- left battlefield: Charismatic Conqueror was put into Graveyard from Battlefield.
- P3 triggered Sephiroth, Fabled SOLDIER targeting [P4]
- P3 triggered Dictate of Erebos
- P3 triggered Sephiroth, Fabled SOLDIER targeting [P4]
- P3 triggered Syr Konrad, the Grim
- P3 triggered Morbid Opportunist
- P4 triggered Blood Artist targeting [P1]
- P4 triggered Vengeful Bloodwitch targeting [P1]
- P4 triggered Blood Artist targeting [P1]
- left battlefield: Marionette Apprentice was put into Graveyard from Battlefield.
- left battlefield: Venerated Rotpriest was put into Graveyard from Battlefield.
- P3 triggered Sephiroth, Fabled SOLDIER targeting [P4]
- P3 triggered Sephiroth, Fabled SOLDIER targeting [P4]
- P3 triggered Sephiroth, Fabled SOLDIER targeting [P4]
- P4 triggered Vengeful Bloodwitch targeting [P1]
- P4 triggered Blood Artist targeting [P1]
- P4 triggered Blood Artist targeting [P1]
- P4 triggered Blood Artist targeting [P1]
- P3 cast Dreadhorde Invasion
- P3 cast Plaguecrafter
- P3 triggered Plaguecrafter
- left battlefield: Morbid Opportunist was put into Graveyard from Battlefield.
- left battlefield: Braids, Arisen Nightmare was put into Graveyard from Battlefield.
- left battlefield: Bloom Tender was put into Graveyard from Battlefield.
- P3 triggered Dictate of Erebos
- P3 triggered Emblem — Sephiroth, One-Winged Angel targeting [P4]
- P3 triggered Emblem — Sephiroth, One-Winged Angel targeting [P4]
- P3 triggered Emblem — Sephiroth, One-Winged Angel targeting [P4]
- P3 triggered Emblem — Sephiroth, One-Winged Angel targeting [P4]
- P4 triggered Blood Artist targeting [P1]
- P4 triggered Vengeful Bloodwitch targeting [P1]
- P4 triggered Blood Artist targeting [P1]
- P4 triggered Blood Artist targeting [P1]
- P4 triggered Blood Artist targeting [P1]
- left battlefield: Tekuthal, Inquiry Dominus was put into Graveyard from Battlefield.
- P3 triggered Emblem — Sephiroth, One-Winged Angel targeting [P4]
- P3 triggered Emblem — Sephiroth, One-Winged Angel targeting [P4]
- P4 triggered Vengeful Bloodwitch targeting [P1]
- P4 triggered Blood Artist targeting [P1]
- P4 triggered Blood Artist targeting [P1]
- P3 cast Pitiless Plunderer
- P3 cast Marionette Apprentice
- P3 triggered Marionette Apprentice
- P4 activated Blood Token
- P4 activated Blood Token
Damage to US this turn: Syr Konrad, the Grim (non-combat) 1

## Turn 28 (P4, round 7) | life: P2 25, P3 39, P4 12, US 18
- P4 cast Edgar Markov
- attack: P4 assigned Edgar Markov to attack P3.
- P4 triggered Edgar Markov
- P4 triggered Mavren Fein, Dusk Apostle

## Turn 29 (OUR TURN, round 8) | life: P2 25, P3 45, P4 11, US 13
Our hand: Binding the Old Gods, Massacre Wurm, Takenuma, Abandoned Mire, Farseek, Vraska, Golgari Queen, Sheoldred
Our graveyard (12): Polluted Delta, Assassin's Trophy, Executioner's Capsule, Toxic Deluge, Siren Stormtamer, Heroic Intervention, Sakura-Tribe Elder, Animate Dead, Forest, Nature's Lore, Marionette Apprentice, Braids, Arisen Nightmare
Board US: 6 lands; Mishra's Bauble
Board P2: 5 lands; Vorinclex, Monstrous Raider 6/6 (tapped 1), Atraxa, Praetors' Voice 4/4 (tapped 1)
Board P3: 9 lands; Sephiroth, One-Winged Angel 5/5, Bolas's Citadel, Dictate of Erebos, Dreadhorde Invasion, Plaguecrafter 3/2, Pitiless Plunderer 1/4, Marionette Apprentice 1/2, Servo Token 1/1 [token]
Board P4: 6 lands; Vampire Token 2/2 [token] x5, Mavren Fein, Dusk Apostle 3/3, Vengeful Bloodwitch 2/2, Blood Artist 1/2, Legion Lieutenant 2/2, Edgar Markov 5/5 (tapped 1)
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
PILOT OVERRULED FORGE (action, MAIN1): chose [activate Mishra's Bauble (from Battlefield): {T}, Sacrifice Mishra's Bauble: Look at the t] instead of Forge's [play land Takenuma, Abandoned Mire (from Hand): Play land]
- left battlefield: Mishra's Bauble was put into Graveyard from Battlefield.
- US activated Mishra's Bauble targeting [P4]
- US cast Farseek
- US cast Sheoldred
- US triggered Sheoldred
- left battlefield: Vorinclex, Monstrous Raider was put into Graveyard from Battlefield.
- left battlefield: Marionette Apprentice was put into Graveyard from Battlefield.
- left battlefield: Blood Artist was put into Graveyard from Battlefield.
- P3 triggered Emblem — Sephiroth, One-Winged Angel targeting [P4]
- P3 triggered Dictate of Erebos
- P3 triggered Emblem — Sephiroth, One-Winged Angel targeting [P4]
- P3 triggered Emblem — Sephiroth, One-Winged Angel targeting [P4]
- P3 triggered Pitiless Plunderer
- P4 triggered Blood Artist targeting [P1]
- P4 triggered Blood Artist targeting [P1]
- P4 triggered Vengeful Bloodwitch targeting [P1]
- P4 triggered Blood Artist targeting [P1]
- left battlefield: Sheoldred was put into Graveyard from Battlefield.
- left battlefield: Atraxa, Praetors' Voice was put into Graveyard from Battlefield.
- P3 triggered Emblem — Sephiroth, One-Winged Angel targeting [P4]
- P3 triggered Emblem — Sephiroth, One-Winged Angel targeting [P4]
- P3 triggered Emblem — Sephiroth, One-Winged Angel targeting [P4]
- P4 triggered Vengeful Bloodwitch targeting [P1]

## Turn 30 (P2, round 8)
- US triggered Mishra's Bauble
- P2 cast Teferi, Master of Time
- P2 activated Teferi, Master of Time
- P2 cast Path to Exile targeting [Edgar Markov]
- left battlefield: Edgar Markov was put into Exile from Battlefield.

## Turn 31 (P3, round 8) | life: P2 25, P3 45, P4 5, US 11
- P3 triggered Dreadhorde Invasion
- P3 cast Reactor Raid
- P3 cast Sheoldred's Edict
- left battlefield: Teferi, Master of Time was put into Graveyard from Battlefield.
- attack: P3 assigned Sephiroth, One-Winged Angel and Plaguecrafter to attack P4.
- P3 triggered Sephiroth, One-Winged Angel
- left battlefield: Plaguecrafter was put into Graveyard from Battlefield.
- P3 triggered Dictate of Erebos
- P3 triggered Emblem — Sephiroth, One-Winged Angel targeting [P4]
- P3 triggered Emblem — Sephiroth, One-Winged Angel targeting [P4]
- P3 triggered Pitiless Plunderer
- P4 triggered Vengeful Bloodwitch targeting [P1]
- P3 triggered Emblem — Sephiroth, One-Winged Angel targeting [P4]
- P4 triggered Vengeful Bloodwitch targeting [P1]
- P3 cast Bontu's Monument
- P3 cast Black Market Connections

## Turn 32 (P4, round 8)
- P4 cast Edgar Markov

## Turn 33 (OUR TURN, round 9) | life: P2 25, P3 46, P4 5, US 10
Our hand: Binding the Old Gods, Massacre Wurm, Vraska, Golgari Queen, Cryogen Relic, Otawara, Soaring City
Our graveyard (15): Polluted Delta, Assassin's Trophy, Executioner's Capsule, Toxic Deluge, Siren Stormtamer, Heroic Intervention, Sakura-Tribe Elder, Animate Dead, Forest, Nature's Lore, Marionette Apprentice, Braids, Arisen Nightmare, Mishra's Bauble, Farseek, Sheoldred
Board US: 8 lands; no nonland permanents
Board P2: 5 lands; no nonland permanents
Board P3: 10 lands; Sephiroth, One-Winged Angel 5/5 (tapped 1), Bolas's Citadel, Dictate of Erebos, Dreadhorde Invasion, Pitiless Plunderer 1/4, Servo Token 1/1 [token], Zombie Army Token 1/1 [token] {[P1P1]}, Treasure Token [token], Bontu's Monument, Black Market Connections
Board P4: 8 lands; Mavren Fein, Dusk Apostle 3/3, Vengeful Bloodwitch 2/2, Legion Lieutenant 2/2, Vampire Token 2/2 [token] x2, Edgar Markov 5/5
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
PILOT OVERRULED FORGE (action, MAIN2): chose [cast Muldrotha, the Gravetide (from Command): Muldrotha, the Gravetide - Creature 6 / 6] instead of Forge's [cast Massacre Wurm (from Hand): Massacre Wurm - Creature 6 / 5]
PILOT OVERRULED FORGE (action, MAIN2): chose [cast Executioner's Capsule (from Graveyard): Executioner's Capsule by Muldrotha, the Grave] instead of Forge's [cast Braids, Arisen Nightmare (from Graveyard): Braids, Arisen Nightmare - Creature 3 / 3 ]
PILOT OVERRULED FORGE (action, MAIN2): chose [activate Executioner's Capsule (from Battlefield): {1}{B}, {T}, Sacrifice Executioner's Ca] instead of Forge's [cast Sakura-Tribe Elder (from Graveyard): Sakura-Tribe Elder - Creature 1 / 1 by Muldrotha]
- US cast Muldrotha, the Gravetide
- US cast Executioner's Capsule
- left battlefield: Executioner's Capsule was put into Graveyard from Battlefield.
- US activated Executioner's Capsule targeting [Mavren Fein, Dusk Apostle]
- left battlefield: Mavren Fein, Dusk Apostle was put into Graveyard from Battlefield.
- P3 triggered Emblem — Sephiroth, One-Winged Angel targeting [P4]
- P4 triggered Vengeful Bloodwitch targeting [P1]

## Turn 34 (P2, round 9)
- P2 cast Oko, Thief of Crowns
- P2 activated Oko, Thief of Crowns

## Turn 35 (P3, round 9) | life: P2 25, P3 41, P4 -2, US 7
- P3 triggered Dreadhorde Invasion
- P3 triggered Black Market Connections
- attack: P3 assigned Sephiroth, One-Winged Angel, Zombie Army Token, Pitiless Plunderer and Servo Token to attack P4.
- P3 triggered Sephiroth, One-Winged Angel
- left battlefield: Pitiless Plunderer was put into Graveyard from Battlefield.
- P3 cast Village Rites
- P3 triggered Dictate of Erebos
- P3 triggered Emblem — Sephiroth, One-Winged Angel targeting [P4]
- left battlefield: Muldrotha, the Gravetide was put into Graveyard from Battlefield.
- P3 triggered Emblem — Sephiroth, One-Winged Angel targeting [P4]
- P3 triggered Emblem — Sephiroth, One-Winged Angel targeting [P4]
- P4 triggered Vengeful Bloodwitch targeting [P1]
- P3 cast Fell the Profane targeting [Edgar Markov]
- left battlefield: Edgar Markov was put into Graveyard from Battlefield.
- P3 triggered Emblem — Sephiroth, One-Winged Angel targeting [P4]
- P4 triggered Vengeful Bloodwitch targeting [P1]
- P3 triggered Dictate of Erebos
- P3 triggered Emblem — Sephiroth, One-Winged Angel targeting [P1]
- P3 cast Skullclamp
- P3 cast The Masamune
- P3 cast Grave Pact
- P3 activated The Masamune targeting [Sephiroth, One-Winged Angel]
- P3 activated Skullclamp targeting [Sephiroth, One-Winged Angel]

## Turn 36 (OUR TURN, round 9) | life: P2 25, P3 38, P4 -2, US 5
Our hand: Binding the Old Gods, Massacre Wurm, Vraska, Golgari Queen, Cryogen Relic, Seal of Doom
Our graveyard (15): Polluted Delta, Assassin's Trophy, Toxic Deluge, Siren Stormtamer, Heroic Intervention, Sakura-Tribe Elder, Animate Dead, Forest, Nature's Lore, Marionette Apprentice, Braids, Arisen Nightmare, Mishra's Bauble, Farseek, Sheoldred, Executioner's Capsule
Board US: 9 lands; no nonland permanents
Board P2: 6 lands; Oko, Thief of Crowns {[LOYALTY x 6]}, Food Token [token]
Board P3: 11 lands; Sephiroth, One-Winged Angel 6/4 (tapped 1), Bolas's Citadel, Dictate of Erebos, Dreadhorde Invasion, Zombie Army Token 2/2 [token] {[P1P1 x 2]} (tapped 1), Treasure Token [token] x2, Bontu's Monument, Black Market Connections, Skullclamp, The Masamune, Grave Pact
MEMO (start of our turn):
You've hit your session limit · resets 6:40pm (UTC)
PILOT OVERRULED FORGE (action, MAIN2): chose [cast Executioner's Capsule (from Graveyard): Executioner's Capsule by Muldrotha, the Grave] instead of Forge's [cast Sakura-Tribe Elder (from Graveyard): Sakura-Tribe Elder - Creature 1 / 1 by Muldrotha]
- US cast Muldrotha, the Gravetide
- US cast Executioner's Capsule
- US cast Siren Stormtamer
- P3 cast Withering Torment targeting [Muldrotha, the Gravetide]
- left battlefield: Muldrotha, the Gravetide was put into Graveyard from Battlefield.
- P3 triggered Emblem — Sephiroth, One-Winged Angel targeting [P1]
- P3 triggered Emblem — Sephiroth, One-Winged Angel targeting [P1]

## Turn 37 (P2, round 10) | life: P2 25, P3 35, P4 -2, US 5
- P2 activated Oko, Thief of Crowns targeting [Food Token]
- attack: P2 assigned Food Token to attack P3.
- P2 cast Atraxa, Praetors' Voice
- P2 triggered Atraxa, Praetors' Voice

## Turn 38 (P3, round 10) | life: P2 16, P3 35, P4 -2, US 0
- P3 triggered Dreadhorde Invasion
- P3 triggered Black Market Connections
- P3 cast Unearth targeting [Plaguecrafter]
- P3 triggered Plaguecrafter
- left battlefield: Siren Stormtamer was put into Graveyard from Battlefield.
- P3 triggered Dictate of Erebos
- P3 triggered Grave Pact
- P3 triggered Emblem — Sephiroth, One-Winged Angel targeting [P1]
- P3 triggered Emblem — Sephiroth, One-Winged Angel targeting [P1]
- P3 triggered Emblem — Sephiroth, One-Winged Angel targeting [P1]
- P3 triggered Emblem — Sephiroth, One-Winged Angel targeting [P1]
- P3 triggered Emblem — Sephiroth, One-Winged Angel targeting [P1]
- P3 triggered Emblem — Sephiroth, One-Winged Angel targeting [P1]
- left battlefield: Atraxa, Praetors' Voice was put into Graveyard from Battlefield.
- P3 triggered Emblem — Sephiroth, One-Winged Angel targeting [P2]
- P3 triggered Emblem — Sephiroth, One-Winged Angel targeting [P2]
- attack: P3 assigned Sephiroth, One-Winged Angel to attack Oko, Thief of Crowns.
- P3 triggered Sephiroth, One-Winged Angel
- P3 cast Bloodghast
- P3 triggered Bontu's Monument
- P3 cast Nine-Lives Familiar
- P3 triggered Bontu's Monument
- P3 cast Braids, Arisen Nightmare
- P3 triggered Bontu's Monument
- P3 cast Jet Medallion
- P3 triggered Braids, Arisen Nightmare
- left battlefield: Bloodghast was put into Graveyard from Battlefield.
- P3 triggered Dictate of Erebos
- P3 triggered Grave Pact
- P3 triggered Emblem — Sephiroth, One-Winged Angel targeting [P2]
- P3 triggered Emblem — Sephiroth, One-Winged Angel targeting [P2]

## Turn 39 (P2, round 10)
- P2 cast Skithiryx, the Blight Dragon
- P2 activated Skithiryx, the Blight Dragon
- attack: P2 assigned Skithiryx, the Blight Dragon to attack P3.
- P2 activated Oko, Thief of Crowns

## Turn 40 (P3, round 10) | life: P2 0, P3 40, P4 -2, US 0
- P3 triggered Dreadhorde Invasion
- P3 triggered Black Market Connections
- P3 triggered Bloodghast
- attack: P3 assigned Plaguecrafter, Nine-Lives Familiar and Braids, Arisen Nightmare to attack P2.
- P3 triggered Sephiroth, One-Winged Angel
- left battlefield: Bloodghast was put into Graveyard from Battlefield.
- P3 triggered Dictate of Erebos
- P3 triggered Grave Pact
- P3 triggered Emblem — Sephiroth, One-Winged Angel targeting [P2]
- P3 triggered Emblem — Sephiroth, One-Winged Angel targeting [P2]
- left battlefield: Skithiryx, the Blight Dragon was put into Graveyard from Battlefield.
- P3 triggered Emblem — Sephiroth, One-Winged Angel targeting [P2]
- P3 triggered Emblem — Sephiroth, One-Winged Angel targeting [P2]
- left battlefield: Oko, Thief of Crowns was put into Graveyard from Battlefield.
- P3 cast Forsaken Miner
- P3 triggered Bontu's Monument
- P3 triggered Braids, Arisen Nightmare
- left battlefield: Forsaken Miner was put into Graveyard from Battlefield.
- P3 triggered Dictate of Erebos
- P3 triggered Grave Pact
- P3 triggered Emblem — Sephiroth, One-Winged Angel targeting [P2]
- P3 triggered Emblem — Sephiroth, One-Winged Angel targeting [P2]
- P3 triggered Forsaken Miner
- P3 triggered Forsaken Miner
- Game Outcome: US has lost because life total reached 0
- Game Outcome: P2 has lost because life total reached 0
- Game Outcome: P3 has won because all opponents have lost
- Game Outcome: P4 has lost because life total reached 0